# AmazonBusiness_Invoice_1GY4-NMWC-L3GR.pdf

<figure>

amazon business

</figure>


Invoice

Invoice # 1GY4-NMWC-L3GR
January 23, 2026


<table>
<tr>
<th>Invoice summary</th>
<th>Payment due by March 24, 2026</th>
</tr>
<tr>
<td>Item subtotal before tax</td>
<td>$ 72.52</td>
</tr>
<tr>
<td>Shipping &amp; handling</td>
<td>$ 0.00</td>
</tr>
<tr>
<td>Promos &amp; discounts</td>
<td>$ 0.00</td>
</tr>
<tr>
<td>Total before tax</td>
<td>$ 72.52</td>
</tr>
<tr>
<td>Tax</td>
<td>$ 5.08</td>
</tr>
<tr>
<td>Amount due</td>
<td>$ 77.60 USD</td>
</tr>
</table>


Pay by


<table>
<tr>
<th colspan="2">Electronic funds transfer (EFT/ACH/Wire)</th>
<th>Check</th>
</tr>
<tr>
<td>Account name</td>
<td>Amazon Capital Services, Inc</td>
<td>Amazon Capital Services</td>
</tr>
<tr>
<td>Bank name</td>
<td>Wells Fargo Bank</td>
<td>PO Box 035184</td>
</tr>
<tr>
<td>ACH routing # (ABA)</td>
<td>121000248</td>
<td>Seattle, WA 98124-5184</td>
</tr>
<tr>
<td>Bank account # (DDA)</td>
<td>41630410119045568</td>
<td></td>
</tr>
<tr>
<td>SWIFT code (wire transfer)</td>
<td>WFBIUS6S</td>
<td></td>
</tr>
</table>


Electronic Funds Transfer: Add invoice number(s) in the description field.
Email: Send remittance details to ar-businessinvoicing@amazon.com. (This
mailbox only accepts payment details. For help, contact customer support.)


<table>
<tr>
<td>Account #</td>
<td>AQQ7OF85PC4Y3</td>
</tr>
<tr>
<td>Payment terms</td>
<td>Net 60</td>
</tr>
<tr>
<td>Purchase date</td>
<td>22-Jan-2026</td>
</tr>
<tr>
<td>Purchased by</td>
<td>Jasmine Wilks</td>
</tr>
</table>


Registered business name
Emerson Electric Co.

Bill to
Emerson Professional Tools, LLC
PO Box 270625
Saint Louis, MO 63127-0625

Ship to
Greenlee Tools/Jasmine Wilks
4320 EXECUTIVE DR STE 400
SOUTHAVEN, MS 38672-8116

Invoice details


<table>
<tr>
<th>Description</th>
<th>Qty</th>
<th>Unit price</th>
<th>Item subtotal before tax</th>
<th>Tax</th>
</tr>
<tr>
<td>1 Solo 4 oz White Paper Cone Cups (Case of 5000) ASIN: Sold by: Amazon.com Services, Inc B00RQDMCIC Order # 114-9208176-7581035</td>
<td>1</td>
<td>$72.52</td>
<td>$72.52</td>
<td>7.000%</td>
</tr>
</table>


<table>
<tr>
<td>Total before tax</td>
<td>$72.52</td>
</tr>
<tr>
<td>Tax</td>
<td>$5.08</td>
</tr>
<tr>
<td>Amount due</td>
<td>$77.60</td>
</tr>
</table>


<!-- PageFooter="FAQS" -->
<!-- PageNumber="Page1 of 2" -->
<!-- PageBreak -->


<figure>

<!-- PageHeader="amazon business" -->

</figure>


Invoice
Invoice # 1GY4-NMWC-L3GR

How is tax calculated?
Visit https://www.amazon.com/gp/help/customer/display.html?nodeId=G202036190

How are digital products and services taxed?
Visit https://www.amazon.com/gp/help/customer/display.html?nodeId=T18ikShu13no6ZK3jZ

When will I get a refund for undelivered items?
You can expect to get your refund within 7 calendar days after we receive confirmation that your package was undeliverable (exclusions apply).

<!-- PageNumber="Page2 of 2" -->
