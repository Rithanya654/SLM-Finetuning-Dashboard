# WHIRLPOOL CORPORATION-Credit.pdf

<figure>

Whirlpool
CORPORATION

</figure>


2000 M-63, MD7560
Benton Harbor, MI 49022-2692

BILL TO: 2089724

MAR-CONE APPLIANCE PARTS CO.

071326

1 CITYPLACE DR STE 400

SAINT LOUIS MO 63141-7065

USA

SHIP TO: 41156

MARCONE SUPPLY

298 MEDFORD ST

MALDEN MA 02148-6601

USA

SOLD TO: 41156

MARCONE SUPPLY

298 MEDFORD ST

MALDEN MA 02148-6601

USA

CREDIT MEMO

REMIT TO:

WHIRLPOOL CORPORATION

PO Box 88129

CHICAGO IL 60695-1129


<table>
<tr>
<td>CREDIT MEMO NO</td>
<td>9350530646</td>
</tr>
<tr>
<td>CREDIT MEMO DATE</td>
<td>01/30/2026</td>
</tr>
<tr>
<td>PAGE NO</td>
<td>1 of 2</td>
</tr>
<tr>
<td>CUSTOMER P.O. NO</td>
<td>CRO011326MA-1</td>
</tr>
<tr>
<td>ORDER NO</td>
<td>6002827168</td>
</tr>
<tr>
<td>CROSS REF. NO</td>
<td>9350530646</td>
</tr>
<tr>
<td>SHIP MANIFEST NO</td>
<td></td>
</tr>
<tr>
<td>TERMS/PLAN NO</td>
<td>WD26</td>
</tr>
<tr>
<td>APPROVAL NO</td>
<td></td>
</tr>
<tr>
<td>CREDIT MEMO TOTAL</td>
<td>(1235.00) USD</td>
</tr>
<tr>
<td>DUE DATE</td>
<td></td>
</tr>
<tr>
<td colspan="2">TERMS DRAFT 30 DAYS W/NO DISCOUNT DUNS NO</td>
</tr>
</table>


CONTACT INFORMATION:

Credit - St. Joseph, MI

1-877-299-1750


<table>
<tr>
<th>LINE NO.</th>
<th>MODEL/ PART NUMBER/ORDERED MODEL/ PART NUMBER/SHIPPED</th>
<th>DESCRIPTION OF ORDERED DESCRIPTION OF SHIPPED</th>
<th>SKU NO./ UPC CODE</th>
<th>QUANTITY SHIPPED</th>
<th>UNIT PRICE</th>
<th>EXTENDED AMOUNT</th>
</tr>
<tr>
<td>1</td>
<td>WP8507P236-60</td>
<td>CNTRL-ELEC</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CORE HANDLING CREDIT</td>
<td></td>
<td></td>
<td></td>
<td>(5.00)</td>
</tr>
<tr>
<td>2</td>
<td>W10310240</td>
<td>CNTRL-ELEC</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CORE HANDLING CREDIT</td>
<td></td>
<td></td>
<td></td>
<td>(5.00)</td>
</tr>
<tr>
<td>3</td>
<td>W10352689</td>
<td>CNTRL-ELEC</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CORE HANDLING CREDIT</td>
<td></td>
<td></td>
<td></td>
<td>(5.00)</td>
</tr>
<tr>
<td>4</td>
<td>W11100513</td>
<td>CNTRL-ELEC</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CORE HANDLING CREDIT</td>
<td></td>
<td></td>
<td></td>
<td>(5.00)</td>
</tr>
<tr>
<td>5</td>
<td>W11116592</td>
<td>CNTRL-ELEC</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CORE HANDLING CREDIT</td>
<td></td>
<td></td>
<td></td>
<td>(5.00)</td>
</tr>
<tr>
<td>6</td>
<td>W11116592</td>
<td>CNTRL-ELEC</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CORE HANDLING CREDIT</td>
<td></td>
<td></td>
<td></td>
<td>(5.00)</td>
</tr>
<tr>
<td>7</td>
<td>W11201284</td>
<td>CNTRL-ELEC</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CORE HANDLING CREDIT</td>
<td></td>
<td></td>
<td></td>
<td>(5.00)</td>
</tr>
<tr>
<td>8</td>
<td>W11236887</td>
<td>CONSOLE</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CORE HANDLING CREDIT</td>
<td></td>
<td></td>
<td></td>
<td>(5.00)</td>
</tr>
</table>


Merchandise may not be returned without priorapproval

<!-- PageBreak -->

CREDIT MEMO NO 9350530646

<!-- PageNumber="PAGE NO: 2 of 2" -->


<table>
<tr>
<th>LINE NO.</th>
<th>MODEL/ PART NUMBER/ORDERED MODEL/ PART NUMBER/SHIPPED</th>
<th>DESCRIPTION OF ORDERED DESCRIPTION OF SHIPPED</th>
<th>SKU NO./ UPC CODE</th>
<th>QUANTITY SHIPPED</th>
<th>UNIT PRICE</th>
<th>EXTENDED AMOUNT</th>
</tr>
<tr>
<td>9</td>
<td>W11236900</td>
<td>CONSOLE</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CORE HANDLING CREDIT</td>
<td></td>
<td></td>
<td></td>
<td>(5.00)</td>
</tr>
<tr>
<td>10</td>
<td>W11293216</td>
<td>CONSOLE</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CORE HANDLING CREDIT</td>
<td></td>
<td></td>
<td></td>
<td>(5.00)</td>
</tr>
<tr>
<td>11</td>
<td>W11384512</td>
<td>CONSOLE</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CORE HANDLING CREDIT</td>
<td></td>
<td></td>
<td></td>
<td>(5.00)</td>
</tr>
<tr>
<td>12</td>
<td>W11417462</td>
<td>CNTRL-ELEC</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CORE HANDLING CREDIT</td>
<td></td>
<td></td>
<td></td>
<td>(5.00)</td>
</tr>
<tr>
<td>13</td>
<td>W11550656</td>
<td>CNTRL-ELEC</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CORE HANDLING CREDIT</td>
<td></td>
<td></td>
<td></td>
<td>(5.00)</td>
</tr>
<tr>
<td>14</td>
<td>W11583890</td>
<td>CNTRL-ELEC</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CORE HANDLING CREDIT</td>
<td></td>
<td></td>
<td></td>
<td>(5.00)</td>
</tr>
<tr>
<td>15</td>
<td>W11603810</td>
<td>CNTRL-ELEC</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CORE HANDLING CREDIT</td>
<td></td>
<td></td>
<td></td>
<td>(5.00)</td>
</tr>
<tr>
<td>16</td>
<td>W11607637</td>
<td>CNTRL-ELEC</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CORE HANDLING CREDIT</td>
<td></td>
<td></td>
<td></td>
<td>(5.00)</td>
</tr>
<tr>
<td>17</td>
<td>W11607637</td>
<td>CNTRL-ELEC</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CORE HANDLING CREDIT</td>
<td></td>
<td></td>
<td></td>
<td>(5.00)</td>
</tr>
<tr>
<td>18</td>
<td>W11607637</td>
<td>CNTRL-ELEC</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CORE HANDLING CREDIT</td>
<td></td>
<td></td>
<td></td>
<td>(5.00)</td>
</tr>
<tr>
<td>19</td>
<td>W11607637</td>
<td>CNTRL-ELEC</td>
<td></td>
<td>1</td>
<td>(60.00)</td>
<td>(60.00)</td>
</tr>
<tr>
<td></td>
<td>PO # CRO011326MA-1</td>
<td>CORE HANDLING CREDIT Credit Request # 6002827168</td>
<td colspan="2">Sub Total (1140.00)</td>
<td></td>
<td>(5.00)</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>TOTAL</td>
<td></td>
<td>USD</td>
<td>(1235.00)</td>
</tr>
</table>


CARRIER INFO:

PRO NO:

TRAILER NO:

Merchandise may not be returned without prior approval
