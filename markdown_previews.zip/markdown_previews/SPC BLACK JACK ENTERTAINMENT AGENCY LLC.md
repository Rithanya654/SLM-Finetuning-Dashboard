# SPC BLACK JACK ENTERTAINMENT AGENCY LLC.docx

<table>
<tr>
<th colspan="2">Black Jack Entertainment Agency LLC Schwarz Vendor 828474 985 Linwood Ave. Columbus, OH 43206 614 629-7614 Wolfmanblack5@gmail.com</th>
<th>INVOICE INVOICE #3684 01/20/2026</th>
<th colspan="2">TO: Bunzl Retail Services 6000 Green Point Dr. S. Groveport, OH 43125</th>
<th>SOLD TO: Bunzl Retail Services 6000 GREEN POINT DR S. GROVEPORT, OH 43125</th>
<th></th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="4">COMMENTS OR SPECIAL INSTRUCTIONS: Email invoices to bd-brs@dataserv-stl.com</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3"></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<table>
<tr>
<th colspan="3">Salesperson</th>
<th colspan="2">Invoice #</th>
<th colspan="2">Terms</th>
</tr>
<tr>
<td colspan="3">Brian Bowman</td>
<td colspan="2">3684</td>
<td colspan="2">Due upon receipt</td>
</tr>
<tr>
<td></td>
<td>P.O. #</td>
<td colspan="2">Container #</td>
<td colspan="2">Unit Price</td>
<td>Total</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">FSCU4963564</td>
<td colspan="2">300</td>
<td>300</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2"></td>
<td colspan="2">Subtitle</td>
<td>$300.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2"></td>
<td colspan="2">Sales tax</td>
<td>$0</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2"></td>
<td colspan="2">Shipping &amp; Handling</td>
<td>N/A</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2"></td>
<td colspan="2">Total Due</td>
<td>$300.00</td>
</tr>
</table>


Make all checks payable to:

Black Jack Entertainment Agency LLC

If you have any questions concerning this invoice, contact Brian Bowman 614.629.7614

THANK YOU FOR YOUR BUSINESS
