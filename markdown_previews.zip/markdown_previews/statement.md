# statement.pdf

<figure>

setra

Gems®
Sensors & Controls
OUR EXPERIENCE . YOUR SOLLITICIN

</figure>


Setra Systems LLC.
159 Swanson Road
Boxborough, MA 01719-1304
Phone 800-257-3872
www.setra.com

Remit to
Bank of America
Lockbox Services
12003 Collection Center Drive
Chicago, Ill 60693

ACH

Bank of America
1401 Elm Steet 2nd floor
Dallas TX 75202
Account # 8765100157
Routing# 071923284

02/02/2026 7:00:15

<!-- PageNumber="Page 1 of 1" -->

Please include one of the following on payment details/reference - Invoice#, Account#, or Sales Order #

48371
SUPREME INTEGRATED TECHNOLOGY INC
PO BOX 925009
HOUSTON TX 77066
United States


# STATEMENT

preferred method of payment is ACH


<table>
<tr>
<th>Invoice Nbr</th>
<th>Invoice Date</th>
<th>Customer PO</th>
<th>Comment</th>
<th colspan="2">Gross Amount</th>
<th>Amount Due</th>
<th>Due Date</th>
<th>Discount Available</th>
<th>Discount Due Date</th>
</tr>
<tr>
<td>74396</td>
<td>03/12/2025</td>
<td></td>
<td>OVERPAID INV</td>
<td colspan="2">27,150.00-</td>
<td>6,657.93-</td>
<td>03/12/2025</td>
<td></td>
<td>03/12/2025</td>
</tr>
<tr>
<td>75898</td>
<td>05/02/2025</td>
<td></td>
<td>PJOBBBAID 1503845</td>
<td colspan="2">26,893.87-</td>
<td>6,635.97-</td>
<td>05/02/2025</td>
<td></td>
<td>05/02/2025</td>
</tr>
<tr>
<td>76871</td>
<td>06/03/2025</td>
<td></td>
<td>OVERPAID 1516804+5</td>
<td colspan="2">111,000.00-</td>
<td>27,750.00-</td>
<td>06/03/2025</td>
<td></td>
<td>06/03/2025</td>
</tr>
<tr>
<td>79835</td>
<td>09/09/2025</td>
<td></td>
<td>DUP PMT 1520341</td>
<td colspan="2">55,500.00-</td>
<td>55,500.00-</td>
<td>09/09/2025</td>
<td></td>
<td>09/09/2025</td>
</tr>
<tr>
<td>1561745</td>
<td>12/29/2025</td>
<td>5003690</td>
<td>Sales Order24824488</td>
<td></td>
<td>1,505.11</td>
<td>1,505.11</td>
<td>01/28/2026</td>
<td></td>
<td>01/08/2026</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Due:</td>
<td colspan="3">95,038.79-</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>
