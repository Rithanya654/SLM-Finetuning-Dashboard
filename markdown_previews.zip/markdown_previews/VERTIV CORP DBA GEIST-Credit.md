# VERTIV CORP DBA GEIST-Credit.PDF

Vertiv Corporation
dba Geist
29755 Network Place
Chicago, IL 60673-1297
800-432-3219 Fax: 402-474-4369

CREDIT MEMO

275815-02

1/16/2026

BILL TO:

SHIP TO:

VERTIV CORPORATION HFM 43USOLDE
PO BOX 8629
ST. LOUIS MO 63126

Ship Via:

FOB:

Terms:

Net 30 Days

Due Date:

2/15/2026


<table>
<tr>
<th>Item Number</th>
<th>Description</th>
<th>Pack Slip #</th>
<th>PO #</th>
<th>Order Date</th>
<th>Ship Date</th>
<th>Quantity</th>
<th>Price</th>
<th>Extension</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>-1</td>
<td>150.500000</td>
<td>-150.50</td>
</tr>
<tr>
<td></td>
<td colspan="2">CREDIT FOR INVOICE 269025-02 PO #130332429</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<table>
<tr>
<td>Subtotal:</td>
<td>-150.50</td>
</tr>
<tr>
<td>Tax:</td>
<td>0.00</td>
</tr>
<tr>
<td>Freight:</td>
<td>0.00</td>
</tr>
<tr>
<td>Total:</td>
<td>-150.50</td>
</tr>
</table>


All Prices Are Shown in USD

Thank You
All Payments in US Dollars Only

Country of Origin: United Sates of America

INFORMATION TO BUYER This order between the Buyer and Seller is limited to Seller's Terms and Conditions located at termsconditions vertiv.com unless a formal
agreement governing this Purchase Order/transaction has been executed by the parties, in which case the Terms and Conditions of the signed agreement shall govern Seller
hereby objects to all Buyer's terms and conditions received by Seller and/or issued by Buyer.

Remit To Information:
. Payee can be either Geist or Vertiv Corporation

. Email remittance copies should be sent to accountsreceivable@geistglobal.com

Vertiv Corporation Banking Instructions:

Entity Name: Vertiv Corporation

Account: 192864806

Account Name: Vertiv Corporation

Lockbox No .: 29755

Bank: JPMorgan Chase Bank, NA (IL)

ABA/Routing: 071000013

Overnight Mail (overnight/courier delivery packages)
JPMorgan Chase - Lockbox Processing
Attn: VERTIV CORPORATION Box# 29755
131 S Dearborn, 6th Floor

Residents of California are encouraged to read Seller's Privacy Notice for Customers and Suppliers- California available at
www.vertiv.com/ca-privacy <http://www.vertiv.com/ca-privacy>.
