# ELECTROLUX CANADA CORPORATION-Credit.pdf

<figure>

Electrolux
Electrolux Canada Corporation

</figure>


<table>
<tr>
<td>Bill To / Facturer:</td>
<td>Sold To / Vendu à:</td>
</tr>
<tr>
<td>68007212</td>
<td>50301908</td>
</tr>
<tr>
<td>MARCONE-APW ULC</td>
<td>MARCONE-APW, ULC</td>
</tr>
<tr>
<td>PO BOX 411340</td>
<td>PO BOX 411340</td>
</tr>
<tr>
<td>SAINT LOUIS MO 63141</td>
<td>SAINT LOUIS MO 63141</td>
</tr>
<tr>
<td>USA</td>
<td>USA</td>
</tr>
</table>


Ship To / EXPÉDIÉ:

70278206

MARCONE-APW, VAUGHN

505 CITYVIEW BLVD UNIT 2

WOODBRIDGE ON L4H 0L8

Canada

Incoterms: FCA, Free Carrier

Credit Note / Note
de crédit

7326146136


<table>
<tr>
<td>Document date / Date du document:</td>
<td>[page 1 of 2] 01/29/2026</td>
</tr>
<tr>
<td>Net due date / Date d'échéance nette:</td>
<td>03/30/2026</td>
</tr>
<tr>
<td>Currency / Devise:</td>
<td>CAD</td>
</tr>
<tr>
<td>Payment Terms / Modalités de paiement:</td>
<td rowspan="2">60 days net 68007212</td>
</tr>
<tr>
<td>Your account with us / Votre compte avec nous:</td>
</tr>
<tr>
<td>G.S.T / H.S.T:</td>
<td>865645212</td>
</tr>
<tr>
<td>Q.S.T:</td>
<td>1089062485</td>
</tr>
</table>


PO Number /
Commande n º
WCI short parts
Week of Jan 11

Order No /
Numéro de
commande.
7702774786

Order Date /
Date de
commande
01/29/2026

Delivery No/
Numéro de
livraison

BOL No /
Numéro de
borderau
d'expedition

RG / ZN
Région /
Zone
CA50/CC5

PC /
Liste de
prix

SCAC
Code

PRO No /
Numéro
PRO

LOT No /
Numéro de
lot.


<table>
<tr>
<th>Item / Article</th>
<th>Model Id / Identifiant du modèle</th>
<th>Description / La description</th>
<th>Quantity/ Quantité</th>
<th>Unit price / Prix unitaire</th>
<th>Rate Unit / Unité tarifaire</th>
<th>Amount / Montante</th>
</tr>
<tr>
<td rowspan="2">10</td>
<td>240372409</td>
<td>FRAME,SLIDING SHELF,FULL WIDTH</td>
<td>1</td>
<td>-61.76</td>
<td>CAD</td>
<td>-61.76</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>-61.76</td>
<td>CAD</td>
<td>-61.76</td>
</tr>
<tr>
<td rowspan="2">20</td>
<td>5304513480</td>
<td>GRILL, VENT</td>
<td>2</td>
<td>-74.78</td>
<td>CAD</td>
<td>-149.56</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>-74.78</td>
<td>CAD</td>
<td>-149.56</td>
</tr>
<tr>
<td rowspan="2">30</td>
<td>5304519241</td>
<td>LATCH ASSEMBLY, DOOR LOCK</td>
<td>1</td>
<td>-49.58</td>
<td>CAD</td>
<td>-49.58</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>-49.58</td>
<td>CAD</td>
<td>-49.58</td>
</tr>
<tr>
<td rowspan="2">40</td>
<td>5304522396</td>
<td>FILTER</td>
<td>1</td>
<td>-15.11</td>
<td>CAD</td>
<td>-15.11</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>-15.11</td>
<td>CAD</td>
<td>-15.11</td>
</tr>
</table>


ALL LATE PAYMENTS MAY BE SUBJECT TO A LATE PAYMENT PENALTY CALCULATED AT THE RATE OF ONE AND ONE-HALF PERCENT (1.5%)
PER MONTH OR THE MAXIMUM ALLOWABLE BY LAW, WHICHEVER IS LESS.
TOUS LES PAIEMENTS EN RETARD PEUVENT ÊTRE SOUMIS À UNE PENALITE DE PAIEMENT DE RETARD CALCULÉE AU TAUX D'UN ET DEMI
(1.5%) POUR CENT PAR MOIS OU AU MAXIMUM PERMIS PAR LA LOI, SI CELA EST MOINS.

ALL ORDERS ARE CONSIDERED FOB ORIGIN UNLESS COVERED BY A SPECIFIC AGREEMENT WITH ELECTROLUX.
TOUTES LES COMMANDES SONT CONSIDÉRÉES FOB ORIGINE SAUF COUVERT D'UN ACCORD SPÉCIFIQUE AVEC ELECTROLUX.

For Billing Inquires/
Pour demandes
de facturation:

Telephone: 905-813-7700
Fax: 905-813-1220

Payment via EFT
Beneficiary: Electrolux Canada Corp
Account Number: 4011784709
ABA/Routing Number: 0270 00012
SWIFT: CHASCATTCTS
BankName: JPMorgan ChaseBank NA

<!-- PageBreak -->


<figure>

Electrolux
Electrolux Canada Corporation

</figure>


Bill To / Facturer:

68007212

MARCONE-APW ULC

PO BOX 411340

SAINT LOUIS MO 63141

USA

Sold To / Vendu à:

50301908

MARCONE-APW, ULC

PO BOX 411340

SAINT LOUIS MO 63141

USA

Ship To / EXPÉDIÉ:

70278206

MARCONE-APW, VAUGHN

505 CITYVIEW BLVD UNIT 2

WOODBRIDGE ON L4H 0L8

Canada

Incoterms: FCA, Free Carrier

Credit Note / Note

de crédit

7326146136


<table>
<tr>
<td>Document date / Date du document:</td>
<td>[page 2 of 2] 01/29/2026</td>
</tr>
<tr>
<td>Net due date / Date d'échéance nette:</td>
<td>03/30/2026</td>
</tr>
<tr>
<td>Currency / Devise:</td>
<td>CAD</td>
</tr>
<tr>
<td>Payment Terms / Modalités de paiement:</td>
<td>60 days net</td>
</tr>
<tr>
<td>Your account with us / Votre compte avec nous:</td>
<td>68007212</td>
</tr>
<tr>
<td>G.S.T / H.S.T:</td>
<td>865645212</td>
</tr>
<tr>
<td>Q.S.T:</td>
<td>1089062485</td>
</tr>
</table>


<table>
<tr>
<td>Total Freight / Fret</td>
<td>0.00</td>
</tr>
<tr>
<td>Sub-Total / Total Partiel</td>
<td>-276.01</td>
</tr>
<tr>
<td>P.S.T / T.V.Q</td>
<td>0.00</td>
</tr>
<tr>
<td>G.S.T / H.S.T</td>
<td>-35.88</td>
</tr>
<tr>
<td>Total / Totale</td>
<td>-311.89</td>
</tr>
</table>


NOTES:

ALL LATE PAYMENTS MAY BE SUBJECT TO A LATE PAYMENT PENALTY CALCULATED AT THE RATE OF ONE AND ONE-HALF PERCENT (1.5%)
PER MONTH OR THE MAXIMUM ALLOWABLE BY LAW, WHICHEVER IS LESS.
TOUS LES PAIEMENTS EN RETARD PEUVENT ÊTRE SOUMIS À UNE PENALITE DE PAIEMENT DE RETARD CALCULÉE AU TAUX D'UN ET DEMI
(1.5%) POUR CENT PAR MOIS OU AU MAXIMUM PERMIS PAR LA LOI, SI CELA EST MOINS.

ALL ORDERS ARE CONSIDERED FOB ORIGIN UNLESS COVERED BY A SPECIFIC AGREEMENT WITH ELECTROLUX.
TOUTES LES COMMANDES SONT CONSIDEREES FOB ORIGINE SAUF COUVERT D'UN ACCORD SPÉCIFIQUE AVEC ELECTROLUX.

For Billing Inquires/
Pour demandes
de facturation:

Telephone: 905-813-7700
Fax: 905-813-1220

Payment via EFT
Beneficiary: Electrolux Canada Corp
Account Number: 4011784709
ABA/Routing Number: 0270 00012
SWIFT: CHASCATTCTS
BankName: JPMorgan ChaseBank NA
