# ADAC inv 2 1 26 1279-NRN CONSULTING LLC.xls

## Sheet: Sheet2

|  |  |  |  |  | INVOICE |  |
|---|---|---|---|---|---|---|
| Name | NRN Consulting LLC,  Noreen Ness |  |  |  |  |  |
| Address | 1517 Prospect Lakes Dr |  |  |  |  |  |
| State | Wentzville, MO 63385 |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  | DATE: | 2026-02-01 00:00:00 |  |
|  |  |  |  | INVOICE # | 2026-1279 |  |
|  |  |  |  |  |  |  |
| Bill To: |  |  |  |  |  |  |
| ADAC Automotive |  |  |  |  |  |  |
| 5670 Eagle Drive, SE |  |  |  |  |  |  |
| Grand Rapids, MI. 49512 |  |  |  |  |  |  |
| John Vereeke |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
| Assembly plant |  |  | P. O. Number |  | Terms |  |
| GM Wentzville - 31xx |  |  |  |  | Due upon reciept |  |
|  |  |  |  |  |  |  |
| Week Ending           Date |  | Description                                                                                                Services rendered for quality & accum visits |  |  |  | Total       Amount |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
| 1936-01-25 00:00:00 |  | 31xx-2 build support |  |  |  | 240 |
| 2026-02-01 00:00:00 |  | 31xx-2 build support |  |  |  | 300 |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  | Balance Due | 540 |