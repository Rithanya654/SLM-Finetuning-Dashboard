# National Grid Gas Jan 2026.pdf

<figure>

nationalgrid

</figure>


SERVICE FOR
HINGHAM WATER TREATMENT
900 MAIN ST UNIT BLDG, GAS
HINGHAM MA 02043

BILLING PERIOD

Dec 29, 2025 to Jan 29, 2026


<table>
<tr>
<th>ACCOUNT NUMBER</th>
<th>PLEASE PAY BY</th>
<th>AMOUNT DUE</th>
</tr>
<tr>
<td>63669-38003</td>
<td>Feb 22, 2026</td>
<td>$ 12,228.41</td>
</tr>
</table>


www.nationalgridus.com
CUSTOMER SERVICE
1-800-233-5325
Monday-Friday, 7AM-7PM
GAS EMERGENCIES
1-800-233-5325
24 Hours/Day - 7 Days/Week
(Does not replace 911 emergency
medical services)
PARA ESPANOL
1-800-233-5325
CORRESPONDENCE ADDRESS
PO Box 1040
Northborough, MA 01532

PAYMENT ADDRESS

PO BOX 371338

PITTSBURGH, PA 15250-7338

DATE BILL ISSUED

Jan 29, 2026

BU 60054

PO 1000627785

rec 5001202880

Gas Usage History


<table>
<tr>
<th>Month</th>
<th>Therms</th>
<th>Month</th>
<th>Therms</th>
</tr>
<tr>
<td>Feb 25</td>
<td>6726</td>
<td>Sep 25</td>
<td>00</td>
</tr>
<tr>
<td>Mar 25</td>
<td>6264</td>
<td>Oct 25</td>
<td>00</td>
</tr>
<tr>
<td>Apr 25</td>
<td>4151</td>
<td>Nov 25</td>
<td>00</td>
</tr>
<tr>
<td>May 25</td>
<td>548</td>
<td>Dec 25</td>
<td>1885</td>
</tr>
<tr>
<td>Jun 25</td>
<td>00</td>
<td>Jan 26</td>
<td>4693</td>
</tr>
<tr>
<td>Jul 25</td>
<td>00</td>
<td>Feb 26</td>
<td>5889</td>
</tr>
<tr>
<td>Aug 25</td>
<td>00</td>
<td></td>
<td></td>
</tr>
</table>


nationalgrid


<table>
<tr>
<td colspan="3"></td>
</tr>
<tr>
<td colspan="2">ACCOUNT BALANCE</td>
<td></td>
</tr>
<tr>
<td>Previous Balance</td>
<td></td>
<td>9,786.08</td>
</tr>
<tr>
<td>Payment Received on JAN 14 (ACH)</td>
<td>THANK YOU</td>
<td>- 9,786.08</td>
</tr>
<tr>
<td>Current Charges</td>
<td></td>
<td>+ 12,228.41</td>
</tr>
<tr>
<td></td>
<td>Amount Due</td>
<td>$ 12,228.41</td>
</tr>
</table>


To avoid late payment charges of 1.08%, $ 12,228.41 must be received by Feb 22 2026.

If you're concerned about paying your bill, we offer programs and services that can
help. Visit https://ngrid.com/hereforyou to learn more.


<table>
<tr>
<th colspan="4">SUMMARY OF CURRENT CHARGES</th>
</tr>
<tr>
<th></th>
<th>DELIVERY SERVICES</th>
<th>SUPPLY SERVICES</th>
<th>TOTAL</th>
</tr>
<tr>
<td>Gas Service</td>
<td>6,244.15</td>
<td>5,984.26</td>
<td>12,228.41</td>
</tr>
<tr>
<td>Total Current Charges</td>
<td>$ 6,244.15</td>
<td>$ 5,984.26</td>
<td>$ 12,228.41</td>
</tr>
</table>


In compliance with a recent ruling by the Massachusetts Department of Public
Utilities, National Grid will change the Distribution Adjustment line item on your gas
bill as of November 1, 2025. Please note, this is only a change in the bill
presentation and does not represent additional bill charges. Moving forward, the
Distribution Adjustment line item will be broken into two components - with one
line item dedicated to Energy Efficiency program costs, and the Other line item for
various costs to support infrastructure upgrades and assistance programs for
income-eligible customers.

\*
Save time and money! Sign up for paperless billing and receive a $ 0.38 credit on
your monthly bill. Visit our website to enroll today!

Utility Worker Safety Reminder: State laws are in place to help protect utility
workers while they are performing their job duties. Causing physical injury to, or
assaulting, a utility worker is punishable by law, and penalties include potential jail
time.

KEEP THIS PORTION FOR YOUR RECORDS.

RETURN THIS PORTION WITH YOUR PAYMENT.


<table>
<tr>
<th>ACCOUNT NUMBER</th>
<th>PLEASE PAY BY</th>
<th>AMOUNT DUE</th>
</tr>
<tr>
<td>63669-38003</td>
<td>Feb 22, 2026</td>
<td>$ 12,228.41</td>
</tr>
</table>


PO Box 1040
Northborough MA 01532


<figure>

ENTER AMOUNT ENCLOSED
$

Write account number on check and make payable
to National Grid

</figure>


HINGHAM WATER TREATMENT
900 MAIN ST UNIT BLDG, GAS
HINGHAM MA 02043-3504

019984

NATIONAL GRID
PO BOX 371338
PITTSBURGH PA 15250-7338

001222841 63669380031001222841053

<!-- PageNumber="PAGE 1 of 3" -->
<!-- PageBreak -->

<!-- PageNumber="PAGE 2 of 3" -->


<figure>

nationalgrid

</figure>


SERVICE FOR
HINGHAM WATER TREATMENT
900 MAIN ST UNIT BLDG, GAS
HINGHAM MA 02043

BILLING PERIOD

Dec 29, 2025 to Jan 29, 2026


<table>
<tr>
<th>ACCOUNT NUMBER</th>
<th>PLEASE PAY BY</th>
<th>AMOUNT DUE</th>
</tr>
<tr>
<td>63669-38003</td>
<td>Feb 22, 2026</td>
<td>$ 12,228.41</td>
</tr>
</table>


Choosing an Energy Supplier You can
choose who supplies your energy. No
matter which energy supplier you choose,
National Grid will continue to deliver
energy to you safely, efficiently and
reliably. We will also continue to provide
your customer service, including
emergency response and storm
restoration. National Grid is dedicated to
creating an open energy market that lets
you choose from a variety of competitive
energy suppliers, who may offer different
pricing options. For information on
authorized energy suppliers and how to
choose, please visit us online at
https://www.nationalgridus.com/energy-
service-companies/MA-Gas/

DETAIL OF CURRENT CHARGES

Delivery Services


<table>
<tr>
<th colspan="2">Service Period</th>
<th>No. of days</th>
<th>Current Reading -</th>
<th>Previous Reading =</th>
<th>Measured CCF x ☒</th>
<th>Therm Factor</th>
<th>=</th>
<th>Therms Used</th>
</tr>
<tr>
<td colspan="2">Dec 29 - Jan 29</td>
<td>31</td>
<td>33100 Actual</td>
<td>27422 Actual</td>
<td>5678</td>
<td>1.03720</td>
<td></td>
<td>5889</td>
</tr>
<tr>
<td colspan="6">METER NUMBER 00405934 NEXT SCHEDULED READ DATE ON OR ABOUT Mar 2</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="6">RATE G-43B Large C&amp;I Low Load Factor</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Minimum</td>
<td>Charge</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>129.17</td>
</tr>
<tr>
<td colspan="3">Delivery Peak</td>
<td></td>
<td>0.6033 x ☒</td>
<td>5889 therms</td>
<td></td>
<td></td>
<td>3,552.84</td>
</tr>
<tr>
<td colspan="2">Dist Adj -</td>
<td>Energy</td>
<td>Efficiency</td>
<td>0.1653 x ☒</td>
<td>5889 therms</td>
<td></td>
<td></td>
<td>973.44</td>
</tr>
<tr>
<td colspan="2">Distribution</td>
<td>Adj -</td>
<td>Other</td>
<td>0.2074 x ☒</td>
<td>5889 therms</td>
<td></td>
<td></td>
<td>1,221.40</td>
</tr>
<tr>
<td colspan="2">Sales Tax</td>
<td></td>
<td></td>
<td>6.25 %</td>
<td></td>
<td></td>
<td></td>
<td>367.30</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td>Total Delivery</td>
<td>Services</td>
<td></td>
<td></td>
<td>$ 6,244.15</td>
</tr>
<tr>
<td colspan="2">Supply Services</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">SUPPLIER National Grid</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Gas Supply Peak</td>
<td></td>
<td>0.9564 x ☒</td>
<td>5889 therms</td>
<td></td>
<td></td>
<td>5,632.24</td>
</tr>
<tr>
<td colspan="2">Sales Tax</td>
<td></td>
<td></td>
<td>6.25 %</td>
<td></td>
<td></td>
<td></td>
<td>352.02</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">Total Supply Services</td>
<td></td>
<td></td>
<td>$ 5,984.26</td>
</tr>
</table>


<!-- PageBreak -->


# nationalgrid


<table>
<tr>
<th rowspan="2">www.nationalgridus.com Glossary of Terms</th>
<th>Payment Plans</th>
<th>Right to Dispute Your Gas Bill</th>
</tr>
<tr>
<td rowspan="4">To help pay down overdue charges, call to discuss your eligibility for one of our payment plans. We also offer Budget Billing (also known as Balanced Billing) which averages your annual energy costs to avoid large fluctuations in you monthly bills. Please call or visit www.nationalgridus.com to find out more about this and other payment plans. Rights To Gas Service For Residential Customers During Financial Hardship If you cannot pay your gas bill because of a financial hardship and there exists a serious illness, or there is an infant under the age of 12 months, or all adults living in the home are over the age of 65 and there is a minor child in the residence, or if it is between November 15 and March 15, if your service is heat related we will not shut off your gas service. To protect yourself, call us immediately and we will send you a financial statement which you can complete and return. In addition, you must</td>
<td rowspan="4">If you believe your bill is not correct or wish to dispute it, or if you have a service quality problem or dispute please contact us. We will investigate the dispute and tell you what we find. If, after our investigation, you still think the bill is not correct,or continue to dispute the time the arrearage is to be paid,or the service quality problem has not been addressed you have the right to appeal by calling the Massachusetts Department of Public Utilities (DPU) at 877-886-5066 or 617-737-2836 or TTY(hearing impaired only) 1-800-439-2370,by writing to the DPU,Consumer Division, One South Station, Boston,MA 02110,or by visiting the DPU's site www.mass.gov/dpu. Non-Residential Customers All unpaid balances more than 30 days in arrears are subject to late payment charges at the rate equal to the rate paid on the 2-year US Treasury notes for the preceding 12 months ending December 31,plus 10%. Non-residential customers will be notified of late payment</td>
</tr>
<tr>
<td>Meter Read, Estimated: Your meter was not read. Your bill was calculated on the amount of gas you used during a similar period last year, or weather conditions for heating customers.</td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td>CCF - The unit of gas volume (100 cubic feet) as measured</td>
</tr>
<tr>
<td>by your meter.</td>
<td>provide the necessary documentation outlined below withing seven (7) days.</td>
<td rowspan="3">charges percentage with their February bill. Esta informacion se puede obtener en Espanol. Privacy Notice The DPU requires us to cross reference our residential customer database against the database of Transitional Assistance recipients to determine eligibility for our discounted delivery rate. If you do not want to be included in the automated matching process, please call us at the Customer Assistance number on the front. Arrearage Management Program The Arrearage Management Program (AMP) provides arrears forgiveness to income qualified residential customers. Participants must accept and stay current with monthly Budget Billing payments. For complete details,</td>
</tr>
<tr>
<td>Thermal Factor - The factor that converts the quantity of gas used (CCF) to a quality measurement (Therms).</td>
<td rowspan="2">Serious Illness and Financial Hardship Initially, your registered physician, physician assistant, nurse practitioner or Local Board of Health official must call us to let us know of this condition. Within seven days of this phone call, you must return the financial statement and your registered physician, physician assistant, nurse practitioner or Local Board of Health official must write to us and confirm the name and address of the seriously ill person and the business address and telephone of the doctor or agency. The statement must be renewed quarterly or semi-annually if certified to be chronic. Winter Protection and Financial Hardship</td>
</tr>
<tr>
<td>Minimum Charge - Fixed charge prorated for the number of days of service.</td>
</tr>
<tr>
<td>Gas Delivery Charge-The cost of operating and maintaining the National Grid distribution system.</td>
<td>If you heat your home with gas and cannot pay your overdue gas bill between November 15 and March 15 because of financial hardship, we will not shut off your gas. Contact us immediately and send in a financial statement. Infant Under the Age of 12 Months and Financial Hardship</td>
<td>visit www.nationalgridus.com.</td>
</tr>
<tr>
<td>Gas Supply Charge-The cost of purchase, storage, and interstate transmission of gas.</td>
<td>To qualify please call us immediately. Within seven days of the call, you must return the financial statement and send us the name, address, and birth date of the child and one of the following: -birth certificate</td>
<td rowspan="5"></td>
</tr>
<tr>
<td>Dist Adj - Energy Efficiency Portion of Distribution Adjustment recovering costs associated with local energy conservation programs.</td>
<td rowspan="4">-official records or a letter from a registered physician, physician assistant, nurse practitioner or Local Board of Health, hospital or government official -letter from the Department of Transitional Assistance -letter from clergyman or religious institution Notice about Electronic Check Conversion: By sending in your completed, signed check to us, you authorize us to use the account information from your check to make an electronic fund transfer from you account for the same amount of your check. If the electronic fund transfer cannot be processed for technical reasons, you authorize us to process a copy of your check Notice to Elderly Customers If all residents in your household are 65 or older, we wont shut off your gas service without prior consent of the Massachusetts Department of Public Utilities (DPU). If you cannot pay your bill, you may be able to work out a payment plan with us. If you have any questions,or want further information call us at the number printed on the</td>
</tr>
<tr>
<td>Distribution Adj - Other</td>
</tr>
<tr>
<td>Portion of Distribution Adjustment recovering cost of</td>
</tr>
<tr>
<td>various programs including accelerated remediation of aging infrastructure and residential assistance for income-eligible customers.</td>
</tr>
<tr>
<td>Questions About Your Bill</td>
<td rowspan="5">front of your bill. To protect yourself please call the Company immediately if all residents in your home are 65 years of age or older. Adults Over 65 Plus Minor Child and Financial Hardship To qualify, please contact us by phone immediately. Within seven days of the call you must return the financial hardship form and send us the name, address and birthdate of the adults over 65 and the birthdate of the minor.</td>
<td rowspan="5"></td>
</tr>
<tr>
<td>Please call the Customer</td>
</tr>
<tr>
<td>Assistance number on the front of your bill, or write to: National Grid</td>
</tr>
<tr>
<td>PO Box 1040</td>
</tr>
<tr>
<td>Northborough, MA 01532-4040 Please include your account number in all correspondence.</td>
</tr>
</table>
