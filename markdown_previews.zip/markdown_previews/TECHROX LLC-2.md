# TECHROX LLC-2.doc

|TECHROX LLC                 CELL: 407-967-5876                                       |P.O Number:                                        |INVOICE:                          |
|Wasi Pirzada                                                                         |OPTR-837                                           |1196                              |
|3592 Recker HWY,                                                                     |Invoice Date: 12/01/25                             |                                  |
|Winter Haven, FL. 33880                                                              |                                                   |                                  |
|Email: Wp897863@yahoo.com                                                            |                                                   |                                  |
|                                                                                     |SERVICE TECH:                                      |DUE DATE:                         |
|                                                                                     |NEAL                                               |1/30/2026                         |

|To:  Optimal Outsource                                                               |For: Supplies dt 6135                                                                 |
|Paul & Lenda Jarvi                                                                   |                                                                                      |
|1650 N. Hercules # G                                                                 |                                                                                      |
|Clearwater FL 33765                                                                  |                                                                                      |
|(949) 939-6512                                                                       |                                                                                      |
|Atten: payablesopt@osgconnect.com                                                    |                                                                                      |
|                                                                                     |Meter Total:                                                                          |
|                                                                                     |Date of Service:     12/01/25                                                         |
|                                                                                     |Start time:                                                                           |
|                                                                                     |Stop time:                                                                            |
|                                                                                     |Travel:                       :30                                                     |

|DESCRIPTION                                                                                                          |$Supplies          |Labor         |$ Labor Amount     |
|Supplies and Services                                                                                                |Amount             |Hrs.          |                   |
|Supplies for DT-6135:                                                                                                |                   |              |                   |
|4x cases of dt-6135 toners. $395ea                                                                                   |1580.00            |              |                   |
|6x dp180 Fuser oil.                                                                                                  |480.00             |              |                   |
|                                                                                                                     |                   |              |                   |
|D125 supplies:                                                                                                       |                   |              |                   |
|1x Fuser web                                                                                                         |85.00              |              |                   |
|1x D125 Developer                                                                                                    |125.00             |              |                   |
|3x fuser thermistors                                                                                                 |225.00             |              |                   |
|1x IBT KIT (belt, brush, cleaning blade, bias roller).                                                               |325.00             |              |                   |
|2x D125 black toner $145ea                                                                                           |290.00             |              |                   |
|2x Feed kit                                                                                                          |96.00              |              |                   |
|2x OHCF feed kit                                                                                                     |104.00             |              |                   |
|1x Suction filter.                                                                                                   |48.00              |              |                   |
|                                                                                                                     |                   |              |                   |
|V180 supplies:  2x color drums, 2x color toners.                                                                     |n/c                |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|Sub Totals.                                                                                                          |$3,358.00          |00:00         |$00.00             |
|Tax Exempt with current resale certificate.                                                                          | Supplies and Labor               |$3,358.00          |
|UPS Tracking                                                                                                         |Shipping                          |                   |
|                                                                                                                     |Sales Tax                         |                   |
|                                                                                                                     |Total Due                         |$3,358.00          |


Please note $190 service call charge per machine for the first hour, and $90 per hour for each additional hour.  Weekend service is available at $275 for the first hour and $135 for each additional hour.  Please make check payable to Techrox and mail to the address listed above.  Thank you for your business.