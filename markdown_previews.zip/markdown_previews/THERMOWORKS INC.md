# THERMOWORKS INC.html

ThermoWorks, Inc.741 E Utah Valley DrAmerican Fork UT 84003United States(801)756-7705www.thermoworks.comBill ToJENNIE-O R&DPO BOX 8599Saint Louis MO 63126United StatesShip ToPO#5440494JENNIE-O Turkey Store1530 30th ST SWWillmar MN 56201United StatesInvoiceDate1/15/2026Invoice #INV-12345267TermsNet 30Due Date2/14/2026PO #5440494Sales RepCharles J OwenShip ViaUSPS USA Priority MailShip Date1/15/2026Tracking #9405536109440274576807F.O.B.American Fork, UTMemoOrdered ByHormel Foods Corp. HQ (Austin, MN) : Jennie-O HQ : Jennie-O Turkey Store (Willmar) JENNIE-O R&D : Paula GehrtItemBackQtyDescriptionUnit PriceAmountTX-3015-BL04T-Grip, 24" length, Blue69.00276.00USPS USA Priority Mail1USPS Priority Mail, USA only, packages, (3-7 days).11.9511.95Subtotal287.95Tax22.68Total310.63Amount Due (USD)$310.63Thanks for your order!Package tracking may not be available for up to 24 hours.
ThermoWorks, Inc.741 E Utah Valley DrAmerican Fork UT 84003United States(801)756-7705www.thermoworks.comBill ToJENNIE-O R&DPO BOX 8599Saint Louis MO 63126United StatesShip ToPO#5440494JENNIE-O Turkey Store1530 30th ST SWWillmar MN 56201United StatesInvoiceDate1/15/2026Invoice #INV-12345267TermsNet 30Due Date2/14/2026PO #5440494Sales RepCharles J OwenShip ViaUSPS USA Priority MailShip Date1/15/2026Tracking #9405536109440274576807F.O.B.American Fork, UTMemoOrdered ByHormel Foods Corp. HQ (Austin, MN) : Jennie-O HQ : Jennie-O Turkey Store (Willmar) JENNIE-O R&D : Paula GehrtItemBackQtyDescriptionUnit PriceAmountTX-3015-BL04T-Grip, 24" length, Blue69.00276.00USPS USA Priority Mail1USPS Priority Mail, USA only, packages, (3-7 days).11.9511.95Subtotal287.95Tax22.68Total310.63Amount Due (USD)$310.63Thanks for your order!Package tracking may not be available for up to 24 hours.
ThermoWorks, Inc.741 E Utah Valley DrAmerican Fork UT 84003United States(801)756-7705www.thermoworks.comBill ToJENNIE-O R&DPO BOX 8599Saint Louis MO 63126United StatesShip ToPO#5440494JENNIE-O Turkey Store1530 30th ST SWWillmar MN 56201United StatesInvoiceDate1/15/2026Invoice #INV-12345267TermsNet 30Due Date2/14/2026PO #5440494Sales RepCharles J OwenShip ViaUSPS USA Priority MailShip Date1/15/2026Tracking #9405536109440274576807F.O.B.American Fork, UTMemoOrdered ByHormel Foods Corp. HQ (Austin, MN) : Jennie-O HQ : Jennie-O Turkey Store (Willmar) JENNIE-O R&D : Paula GehrtItemBackQtyDescriptionUnit PriceAmountTX-3015-BL04T-Grip, 24" length, Blue69.00276.00USPS USA Priority Mail1USPS Priority Mail, USA only, packages, (3-7 days).11.9511.95Subtotal287.95Tax22.68Total310.63Amount Due (USD)$310.63Thanks for your order!Package tracking may not be available for up to 24 hours.
| ThermoWorks, Inc.741 E Utah Valley DrAmerican Fork UT 84003United States(801)756-7705www.thermoworks.comBill ToJENNIE-O R&DPO BOX 8599Saint Louis MO 63126United StatesShip ToPO#5440494JENNIE-O Turkey Store1530 30th ST SWWillmar MN 56201United States | Bill ToJENNIE-O R&DPO BOX 8599Saint Louis MO 63126United States |  | Ship ToPO#5440494JENNIE-O Turkey Store1530 30th ST SWWillmar MN 56201United States | InvoiceDate1/15/2026Invoice #INV-12345267TermsNet 30Due Date2/14/2026PO #5440494Sales RepCharles J OwenShip ViaUSPS USA Priority MailShip Date1/15/2026Tracking #9405536109440274576807F.O.B.American Fork, UTMemoOrdered ByHormel Foods Corp. HQ (Austin, MN) : Jennie-O HQ : Jennie-O Turkey Store (Willmar) JENNIE-O R&D : Paula Gehrt | Invoice | Date |  | 1/15/2026 | Invoice # |  | INV-12345267 | Terms |  | Net 30 | Due Date |  | 2/14/2026 | PO # |  | 5440494 | Sales Rep |  | Charles J Owen | Ship Via |  | USPS USA Priority Mail | Ship Date |  | 1/15/2026 | Tracking # |  | 9405536109440274576807 | F.O.B. |  | American Fork, UT | Memo |  |  | Ordered By |  | Hormel Foods Corp. HQ (Austin, MN) : Jennie-O HQ : Jennie-O Turkey Store (Willmar) JENNIE-O R&D : Paula Gehrt |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Bill ToJENNIE-O R&DPO BOX 8599Saint Louis MO 63126United States |  | Ship ToPO#5440494JENNIE-O Turkey Store1530 30th ST SWWillmar MN 56201United States |
| Invoice |
| Date |  | 1/15/2026 |
| Invoice # |  | INV-12345267 |
| Terms |  | Net 30 |
| Due Date |  | 2/14/2026 |
| PO # |  | 5440494 |
| Sales Rep |  | Charles J Owen |
| Ship Via |  | USPS USA Priority Mail |
| Ship Date |  | 1/15/2026 |
| Tracking # |  | 9405536109440274576807 |
| F.O.B. |  | American Fork, UT |
| Memo |  |  |
| Ordered By |  | Hormel Foods Corp. HQ (Austin, MN) : Jennie-O HQ : Jennie-O Turkey Store (Willmar) JENNIE-O R&D : Paula Gehrt |

ThermoWorks, Inc.
Bill ToJENNIE-O R&DPO BOX 8599Saint Louis MO 63126United StatesShip ToPO#5440494JENNIE-O Turkey Store1530 30th ST SWWillmar MN 56201United States
| Bill ToJENNIE-O R&DPO BOX 8599Saint Louis MO 63126United States |  | Ship ToPO#5440494JENNIE-O Turkey Store1530 30th ST SWWillmar MN 56201United States |
|---|---|---|

| Invoice |
|---|
| Date |  | 1/15/2026 |
| Invoice # |  | INV-12345267 |
| Terms |  | Net 30 |
| Due Date |  | 2/14/2026 |
| PO # |  | 5440494 |
| Sales Rep |  | Charles J Owen |
| Ship Via |  | USPS USA Priority Mail |
| Ship Date |  | 1/15/2026 |
| Tracking # |  | 9405536109440274576807 |
| F.O.B. |  | American Fork, UT |
| Memo |  |  |
| Ordered By |  | Hormel Foods Corp. HQ (Austin, MN) : Jennie-O HQ : Jennie-O Turkey Store (Willmar) JENNIE-O R&D : Paula Gehrt |

Invoice
Net 30
Charles J Owen
USPS USA Priority Mail
Hormel Foods Corp. HQ (Austin, MN) : Jennie-O HQ : Jennie-O Turkey Store (Willmar) JENNIE-O R&D : Paula Gehrt
ItemBackQtyDescriptionUnit PriceAmountTX-3015-BL04T-Grip, 24" length, Blue69.00276.00USPS USA Priority Mail1USPS Priority Mail, USA only, packages, (3-7 days).11.9511.95Subtotal287.95Tax22.68Total310.63Amount Due (USD)$310.63Thanks for your order!Package tracking may not be available for up to 24 hours.
| Item | Back | Qty | Description | Unit Price | Amount |
|---|---|---|---|---|---|
| TX-3015-BL | 0 | 4 | T-Grip, 24" length, Blue | 69.00 | 276.00 |
| USPS USA Priority Mail |  | 1 | USPS Priority Mail, USA only, packages, (3-7 days). | 11.95 | 11.95 |
| Subtotal | 287.95 |
| Tax | 22.68 |
| Total | 310.63 |
| Amount Due (USD) | $310.63 |

| Thanks for your order!Package tracking may not be available for up to 24 hours. |
|---|