# SUNBELT RENTALS INC.PDF

<figure>

SUNBELT®
®
RENTALS

</figure>


Y

INVOICE TO

1oz - 2901 - 2970

MURPHY COMPANY

12789 EMERSON ST

THORNTON, CO 80241

JOB ADDRESS

MURPHY COMPANY

4049 75TH ST

BOULDER, CO 80301 4511

541-316-3325


# INVOICE

SEND ALL PAYMENTS TO:

SUNBELT RENTALS, INC.

PO BOX 409211

ATLANTA, GA 30384-9211


<table>
<tr>
<td>INVOICE NO.</td>
<td>177262529-0003</td>
</tr>
<tr>
<td>ACCOUNT NO.</td>
<td>1917638</td>
</tr>
<tr>
<td>INVOICE DATE</td>
<td>2/02/26</td>
</tr>
<tr>
<td></td>
<td>PAGE 1 of 1</td>
</tr>
</table>


<table>
<tr>
<th>RECEIVED BY</th>
<th>CONTRACT NO.</th>
</tr>
<tr>
<th>JOHNSTON, WES</th>
<th>177262529</th>
</tr>
<tr>
<td colspan="2">PURCHASE ORDER NO. 953734</td>
</tr>
<tr>
<td colspan="2">JOB NO. 4049</td>
</tr>
</table>


BRANCH
DENVER CO CC COMMERCIAL
220 S TAFT ST
LAKEWOOD, CO
80228 2202

303-352-0016


<table>
<tr>
<th>. QTY</th>
<th>EQUIPMENT #</th>
<th>Min</th>
<th>Day</th>
<th>Week</th>
<th>4 Week</th>
<th>Amount</th>
</tr>
<tr>
<td>. 1.00</td>
<td>500-700CFM AIR SCRUBBER/NEG AIR</td>
<td>185.00</td>
<td>185.00</td>
<td>315.00</td>
<td>810.00</td>
<td>810.00</td>
</tr>
<tr>
<td colspan="5">10489256 Make: ABATEMENT Model : PRED750 Ser #: A53321203377</td>
<td></td>
<td></td>
</tr>
<tr>
<td>1.00</td>
<td>12" X 15' DUCT</td>
<td>12.00</td>
<td>12.00</td>
<td>36.00</td>
<td>93.00</td>
<td>93.00</td>
</tr>
<tr>
<td>1.00</td>
<td>EXTENSION CORD</td>
<td>5.00</td>
<td>5.00</td>
<td>10.00</td>
<td>19.00</td>
<td>19.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">Rental Sub-total:</td>
<td></td>
<td>922.00</td>
</tr>
<tr>
<td rowspan="2"></td>
<td rowspan="2">BILLED FOR FOUR WEEKS 1/16/26 THRU</td>
<td colspan="2" rowspan="2">2/12/26.</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<figure>
</figure>


Equipment. Service. Guaranteed.

REMIT TO:

SUNBELT RENTALS, INC.

PO BOX 409211

ATLANTA, GA 30384-9211

NET 60

Invoices not paid within 30 days may be subject to a 1-1/2%

per month charge.


<table>
<tr>
<td>SUBTOTAL</td>
<td>922.00</td>
</tr>
<tr>
<td>SALES TAX</td>
<td>69.16</td>
</tr>
<tr>
<td>INVOICE TOTAL</td>
<td>991.16</td>
</tr>
</table>


4 WEEK BILL

STEPHANIE GROSSAINT stephanie.grossaint@sunbeltrentals.com
