# MICHAEL A BOHAC-NonPO.xls

## Sheet: Service Invoice

| Michael A Bohac |  |  | INVOICE |
|---|---|---|---|
| Here to serve |  |  |  |
|  |  |  |  |
| 42 Daniels St |  | DATE: | 2026-01-31 00:00:00 |
| Franklin, MA  02038 |  | INVOICE # | 2001 |
| Phone (508) 654-9010 |  |  |  |
|  |  |  |  |
| BILL TO: |  | FOR: | Project Mgmt - HighRadius Project |
| mSupply, Inc |  |  |  |
| A/P Processing (DataServ) |  |  |  |
| PO Box 270564 |  |  |  |
| St. Louis, MO  63127-0564 |  |  |  |
|  |  |  |  |
|  |  |  |  |
| DESCRIPTION | HOURS | RATE | AMOUNT |
| Week ending January 23rd | 10.5 | 95 | 997.5 |
| Week ending January 30th | 19.5 | 95 | 1852.5 |
|  |  |  | 0 |
|  |  |  | 0 |
|  |  |  | 0 |
|  |  |  | 0 |
|  |  |  | 0 |
|  |  |  | 0 |
|  |  |  | 0 |
|  |  |  | 0 |
|  |  |  | 0 |
|  |  |  | 0 |
|  | 30 |  | 0 |
|  |  | SUBTOTAL | 2850 |
|  |  | TAX RATE |  |
|  |  | SALES TAX | 0 |
|  |  | OTHER |  |
| *NOTE: 24 hours non-billable per prior agreement |  | TOTAL | 2850 |
|  |  |  |  |
|  |  |  |  |
| Make all checks payable to Michael A Bohac |  |  |  |
| Total due in 30 days. Overdue accounts subject to a service charge of 1% per month. |  |  |  |