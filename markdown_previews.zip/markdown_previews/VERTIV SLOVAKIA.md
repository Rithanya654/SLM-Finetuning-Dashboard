# VERTIV SLOVAKIA.pdf

<!-- PageNumber="Page 1 of 2" -->


# INVOICE

INVOICE NUMBER

26001383


<table>
<tr>
<td>Invoice date</td>
<td>02-FEB-26</td>
</tr>
<tr>
<td>Tax Date</td>
<td>02-FEB-26</td>
</tr>
<tr>
<td>Sales order number</td>
<td>60314322</td>
</tr>
<tr>
<td>Sales order date</td>
<td>30-OCT-24</td>
</tr>
<tr>
<td>Customer PO number</td>
<td>1470425831 Rev 1</td>
</tr>
</table>


<figure>

VERTIV

</figure>


<table>
<tr>
<th>SHIP TO</th>
<th>BILL TO</th>
</tr>
<tr>
<td>EQUINIX 4 CHEMIN DU PARTERRE BONNEUIL EN FRANCE BONNEUIL EN , , 95500, FR</td>
<td rowspan="4">VERTIV FRANCE SAS PARC ICADE IMMEUBLE TOLEDE 3 RUE LE CORBUSIER 94150 RUNGIS France Customer VAT number: FR43319468120</td>
</tr>
<tr>
<td>DOCUMENT TO 150245726</td>
</tr>
<tr>
<td>VERTIV FRANCE SAS PARC ICADE IMMEUBLE TOLEDE 3 RUE LE CORBUSIER 94150 RUNGIS</td>
</tr>
<tr>
<td>France</td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td>Salesrep ref</td>
<td>Customer service ref. PAUL_ROCAS</td>
</tr>
<tr>
<td>E-mail</td>
<td rowspan="2">E-mail Paul.Rocas@vertiv.com Telephone</td>
</tr>
<tr>
<td>Telephone</td>
</tr>
<tr>
<td>PAYMENT TERMS</td>
<td>SHIPPING TERMS</td>
</tr>
<tr>
<td>Payment terms 30 NET (30 days from date of invoice Payment method Citibank HUB SK (AC)</td>
<td rowspan="2">Incoterms /Location Inco2020: DAP/Aubervilliers Mode of transportation Delivery date: Ship From Vertiv Slovakia, a.s. Nove Mesto nad Vahom, Slovakia</td>
</tr>
<tr>
<td>Due date / Amount Due 04-MAR-26</td>
</tr>
</table>


<table>
<tr>
<th>LINE</th>
<th>ITEM CODE/DESCRIPTION</th>
<th>DELIVERY NUMBER/ DATE</th>
<th>UOM</th>
<th>QUANTITY</th>
<th>UNIT PRICE</th>
<th>VAT</th>
<th>TOTAL (EUR)</th>
</tr>
<tr>
<td>1.1</td>
<td>841981 UNIT AIR FILTRATION S08DC/2/00/0/2/0/0/0/2/0/F/X/$ 4A46201 028377210005 Commodity code/custom tariff:73269098 Country of origin: Slovakia Unit net weight:177.00 KG Oslobodené od dane § 43 ods. 1 zakona o DPH c. 222/2004 VAT exempted art. 138(1) Directive 2006/112</td>
<td>13417519/ 02-FEB-26</td>
<td>Each</td>
<td>1</td>
<td>3.464,28</td>
<td>0,00</td>
<td>3.464,28</td>
</tr>
<tr>
<td>2.2</td>
<td>841981 UNIT AIR FILTRATION S08DC/2/00/0/2/0/0/0/2/0/F/X/$ 4A46201 028377210001, 028377210002, 028377210003, 034035350001, 034035350002, 034035350003, 034035350004, 034035350005 Commodity code/custom tariff:73269098 Country of origin:Slovakia Unit net weight: 177.00 KG Oslobodené od dane § 43 ods. 1 zakona o DPH c. 222/2004 VAT exempted art. 138(1) Directive 2006/112</td>
<td>13417130/ 02-FEB-26</td>
<td>Each</td>
<td>3</td>
<td>3.464,28</td>
<td>0,00</td>
<td>10.392,84</td>
</tr>
<tr>
<td>3.2</td>
<td>841981 UNIT AIR FILTRATION S08DC/2/00/0/2/0/0/0/2/0/F/X/$ 4A46201 028377210001, 028377210002, 028377210003, 034035350001, 034035350002, 034035350003, 034035350004, 034035350005 Commodity code/custom tariff:73269098 Country of origin: Slovakia</td>
<td>13417130/ 02-FEB-26</td>
<td>Each</td>
<td>5</td>
<td>3.464,28</td>
<td>0,00</td>
<td>17.321,40</td>
</tr>
</table>


REGISTERED OFFICE

Vertiv Slovakia, a.s.

Piestanska 1202/44, 915 28 Nove Mesto nad Vahom, Slovakia

URL: https://www.vertiv.com/en-emea/

VAT registration number: SK2020380439

Spolocnost je zapisana v Obchodnom registri na Okresnom sude v Trencine, vlozka c.65 ICO: 31411606

Tel. +421 32 7700 343
Fax. +421 32 7700 408

BANK DETAILS

Bank: Citibank Europe plc

IBAN: SK2681300000002012200201

SWIFT/BIC: CITISKBA

reference to Terms and Conditions

<!-- PageFooter="XXARRSLSINV_INTER_HUB" -->
<!-- PageBreak -->

<!-- PageNumber="Page 2 of 2" -->


## INVOICE

INVOICE NUMBER
26001383


<table>
<tr>
<td>Invoice date</td>
<td>02-FEB-26</td>
</tr>
<tr>
<td>Tax Date</td>
<td>02-FEB-26</td>
</tr>
<tr>
<td>Sales order number</td>
<td>60314322</td>
</tr>
<tr>
<td>Sales order date</td>
<td>30-OCT-24</td>
</tr>
<tr>
<td>Customer PO number</td>
<td>1470425831 Rev 1</td>
</tr>
</table>


<figure>

VERTIV

</figure>


<table>
<tr>
<th>LINE</th>
<th>ITEM CODE/DESCRIPTION</th>
<th>DELIVERY NUMBER/ DATE</th>
<th>UOM</th>
<th>QUANTITY</th>
<th>UNIT PRICE</th>
<th>VAT</th>
<th>TOTAL (EUR)</th>
</tr>
<tr>
<td></td>
<td>Unit net weight:177.00 KG Oslobodené od dane § 43 ods. 1 zakona o DPH c. 222/2004 VAT exempted art. 138(1) Directive 2006/112</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>4.3</td>
<td>841981 UNIT AIR FILTRATION S08DC/2/00/0/2/0/0/0/2/0/F/X/$ 4A46201 028377210004 Commodity code/custom tariff:73269098 Country of origin: Slovakia Unit net weight: 177.00 KG Oslobodené od dane § 43 ods. 1 zakona o DPH c. 222/2004 VAT exempted art. 138(1) Directive 2006/112</td>
<td>13421490/ 02-FEB-26</td>
<td>Each</td>
<td>1</td>
<td>3.464,28</td>
<td>0,00</td>
<td>3.464,28</td>
</tr>
<tr>
<td>5.4</td>
<td>841981 UNIT AIR FILTRATION S08DC/2/00/0/2/0/0/0/2/0/F/X/$ 4A46201 034035340001, 034035340002, 034035340003, 034035340004, 034035340005 Commodity code/custom tariff:73269098 Country of origin: Slovakia Unit net weight:177.00 KG Oslobodené od dane § 43 ods. 1 zakona o DPH c. 222/2004 VAT exempted art. 138(1) Directive 2006/112</td>
<td>13422138/ 02-FEB-26</td>
<td>Each</td>
<td>5</td>
<td>3.464,28</td>
<td>0,00</td>
<td>17.321,40</td>
</tr>
<tr>
<td rowspan="2">6.1</td>
<td rowspan="2">456537 KIT REM. LARGE TOUCH SCREEN 7" PDXI Commodity code/custom tariff:85371091 Country of origin: Slovakia Unit net weight:2.00 KG Oslobodené od dane § 43 ods. 1 zakona o DPH c. 222/2004 VAT exempted art. 138(1) Directive 2006/112</td>
<td rowspan="2">13422285/ 02-FEB-26</td>
<td>Each</td>
<td>3</td>
<td rowspan="2">993,44</td>
<td rowspan="2">0,00</td>
<td rowspan="2">2.980,32</td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>COMMODITY CODE</th>
<th>NET WEIGHT TOTAL</th>
<th>QUANTITY TOTAL</th>
<th>LINE AMOUNT TOTAL</th>
</tr>
<tr>
<td>73269098</td>
<td>2655.00 KG</td>
<td>15</td>
<td>51.964,20</td>
</tr>
<tr>
<td>85371091</td>
<td>6.00 KG</td>
<td>3</td>
<td>2.980,32</td>
</tr>
</table>


### International Trade Compliance - Order Acceptance / Contract Statement - ITCE 30

The fulfilment of the present order/contract is subject to all current applicable import; export control and sanctions laws, regulations, orders and requirements, including those of the United States
where applicable. However, such laws and regulations may be amended from time to time including during the processing of an order/contract. If Vertiv Slovakia, a.s. (the Company) should fail to
receive any necessary or advisable licenses, authorisations or approvals, even arising from inaction by any relevant government authority, or if any such licenses, authorisations or approvals are
denied or revoked, or if there is a change in any applicable laws, regulations, orders or requirements that would prohibit the Company from fulfilling any order, or would in the reasonable judgement
of the Company otherwise expose the Company to a risk of liability under such laws, regulations, orders or requirements if it fulfilled the order, the Company shall be relieved without penalty of all
obligations under the present order/contract.


<table>
<tr>
<td>Subject to VAT</td>
<td>0,00</td>
</tr>
<tr>
<td>Not subject to VAT</td>
<td>54.944,52</td>
</tr>
<tr>
<td>VAT Amount</td>
<td>0,00</td>
</tr>
<tr>
<td>TOTAL AMOUNT EUR</td>
<td>54.944,52</td>
</tr>
</table>


<table>
<tr>
<th colspan="3">REGISTERED OFFICE</th>
</tr>
<tr>
<th colspan="3">Vertiv Slovakia, a.s. Piestanska 1202/44, 915 28 Nove Mesto nad Vahom, Slovakia Tel. +421 32 7700 343 URL: https://www.vertiv.com/en-emea/ Fax. +421 32 7700 408 VAT registration number: SK2020380439 Spolocnost je zapisana v Obchodnom registri na Okresnom sude v Trencine, vlozka c.65 ICO: 31411606</th>
</tr>
<tr>
<th></th>
<th colspan="2">BANK DETAILS</th>
</tr>
<tr>
<td>Bank: Citibank Europe plc</td>
<td>IBAN: SK2681300000002012200201</td>
<td>SWIFT/BIC: CITISKBA</td>
</tr>
<tr>
<td colspan="3">reference to Terms and Conditions</td>
</tr>
</table>


<!-- PageFooter="XXARRSLSINV_INTER_HUB" -->
