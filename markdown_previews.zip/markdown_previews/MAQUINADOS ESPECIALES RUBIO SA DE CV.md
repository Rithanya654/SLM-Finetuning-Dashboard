# MAQUINADOS ESPECIALES RUBIO SA DE CV.pdf

<figure>

RUBIO

</figure>


<table>
<tr>
<th>MAQUINADOS</th>
<th>ESTABLECIDO .</th>
</tr>
<tr>
<th>ESPECIALES</th>
<th>EN 1970</th>
</tr>
</table>


MAQUINADOS ESPECIALES RUBIO
DIRECCIÓN FISCAL:
LAGO ISEO No. 252 COLONIA ANAHUAC, C.P. 11320, MIGUEL
HIDALGO, CDMX

Telefono: 52-33-92-00
R.F.C. :
MER8807286C0

COMPROBANTE FISCAL DIGITAL


<table>
<tr>
<th colspan="3">Tipo Comprobante: (I)Ingreso</th>
</tr>
<tr>
<th>SERIE:</th>
<th></th>
<th>CFDI</th>
</tr>
<tr>
<td>FOLIO:</td>
<td colspan="2">63981</td>
</tr>
<tr>
<td>FECHA:</td>
<td colspan="2">2026-02-02T14:43:10</td>
</tr>
</table>


LUGAR DE EXPEDICIÓN:
11320

RÉGIMEN FISCAL:
(601)General de Ley Personas Morales

DATOS DE CLIENTE:

2105
VERTIV CORPORATION
NORTH CLEVELAND AVENUE No. 505, CP: 43082, WESTERVILLE, OHIO, Telefono:4402400517
RFC: XEXX010101000, Teléfono:4402400517

FORMA DE PAGO: (99)Por definir
MÉTODO DE PAGO: (PPD)Pago en parcialidades o diferido
Versión CFDI 4.0


<table>
<tr>
<td></td>
<td>SU PEDIDO:</td>
<td>130392401</td>
</tr>
<tr>
<td></td>
<td>CONDICIÓN:</td>
<td>120 DIAS MEXICALI</td>
</tr>
<tr>
<td></td>
<td>Uso de CFDI:</td>
<td>(S01)Sin efectos fiscales.</td>
</tr>
</table>


T.C. 17.2532

ENVIAR A: Calle: INDUSTRIA DE LA ELECTRONICA No. 44 Int: 70, CP: 21397, Mexicali, Mexicali, Baja California

<!-- PageBreak -->


<figure>

RUBIO

MAQUINADOS
ESPECIALES
EN 1970
.

ESTABLECIDO

</figure>


MAQUINADOS ESPECIALES RUBIO
DIRECCIÓN FISCAL:
LAGO ISEO No. 252 COLONIA ANAHUAC, C.P. 11320, MIGUEL
HIDALGO, CDMX

Telefono: 52-33-92-00
R.F.C. :
MER8807286C0

COMPROBANTE FISCAL DIGITAL


<table>
<tr>
<th colspan="3">Tipo Comprobante: (I)Ingreso</th>
</tr>
<tr>
<th>SERIE:</th>
<th></th>
<th>CFDI</th>
</tr>
<tr>
<td>FOLIO:</td>
<td colspan="2">63981</td>
</tr>
<tr>
<td>FECHA:</td>
<td colspan="2">2026-02-02T14:43:10</td>
</tr>
</table>


LUGAR DE EXPEDICIÓN:
11320

RÉGIMEN FISCAL:
(601)General de Ley Personas Morales

DATOS DE CLIENTE:

2105
VERTIV CORPORATION
NORTH CLEVELAND AVENUE No. 505, CP: 43082, WESTERVILLE, OHIO, Telefono:4402400517
RFC: XEXX010101000, Teléfono:4402400517

FORMA DE PAGO:
(99)Por definir

MÉTODO DE PAGO:
(PPD)Pago en parcialidades o diferido
Versión CFDI
4.0


<table>
<tr>
<td>SU PEDIDO:</td>
<td>130392401</td>
<td>T.C. 17.2532</td>
</tr>
<tr>
<td>CONDICIÓN:</td>
<td>120 DIAS MEXICALI</td>
<td></td>
</tr>
<tr>
<td>Uso de CFDI:</td>
<td>(S01)Sin efectos fiscales.</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Cantidad</th>
<th>Unidad Sat</th>
<th>Unidad</th>
<th>Clave Sat</th>
<th>No.Parte/Origen</th>
<th>Descripción/Peso Fracc.Aranc Tasa</th>
<th>%</th>
<th>Impuesto</th>
<th>Importe</th>
<th>P/U</th>
<th>IMPORTE</th>
</tr>
<tr>
<td>133.00</td>
<td>H87</td>
<td>pz</td>
<td>30262200</td>
<td>10036380P12/MEX 0014</td>
<td>BARRA CONDUCTORA/1.500 Kg/8536909999 0</td>
<td colspan="2">002</td>
<td>0.00</td>
<td>13.7000</td>
<td>1,822.10</td>
</tr>
</table>


OPERACIONES REALIZADAS DE CONFORMIDAD CON LAS REGLAS
5.2.5 FRACCION II Y 5.2.6 Y 4.3.21 DE LAS RGCE VIGENTES,
FACTURACION A TASA 0% DE IVA, DE CONFORMIDAD CON EL
ART.29 FRACC.I DE LA LEY DEL IVA.
TRANSFERIDO A: EMERMEX S.A. DE C.V IMMEX: 43462006
Régimen Fiscal
Receptor
(616)Sin obligaciones fiscales

SUBTOTAL
1,822.10


<table>
<tr>
<th>IVA</th>
<th>0</th>
</tr>
<tr>
<td>TOTAL</td>
<td>1,822.10</td>
</tr>
</table>


UN MIL OCHOCIENTOS VEINTIDOS DÓLARES 10/100 USD


# "ESTE DOCUMENTO ES UNA REPRESENTACIÓN IMPRESA DE UN CFDI"

FOLIO FISCAL: 0BD0B275-904E-4843-AE85-E41565ABAADD

FECHA Y HORA DE CERTIFICACIÓN:
2026-02-02T14:43:16

SELLO DIGITAL DEL CFDI:

CximcTs02nW82g1/TW8+Y1qSX/UNE5TpUxk5BNwW63q0lS5IgNogKe/MUZVvRIjw4K4FZWSRTJh1Oe5T78unEhVaqxDMNDqWDN2A
K0a22P2OjMh/Ur4+LwUJL3QyLlVYmHqSw8EAOWDU3p1QEWXgMQ5fw8VkvM+JVGjrS7ykQs7n6+dECGE/nqzL3Q79TbWIIYbk+9/K

NÚMERO DE SERIE DEL CERTIFICADO DE SELLO DIGITAL :
NÚMERO DE SERIE DEL CERTIFICADO DE SELLO DIGITAL DEL SAT:
00001000000711195752
00001000000702693654

SELLO DIGITAL DEL SAT:

A4Bp7qM4jLJCXfSTaEZfJzxFL1HgnI9X7jg6bzyVEhOZAN8P7mxLyf+xGU5+7o+xWsjybNuxgPU8IjXZf/wWhJlKozhTXp6PjyFi
EBLIoDfvyQ19vmbFr/S2SR3UHszc/EIzXGoQ9NB6IqoYrm72gsITplNPgxqxBakAlVsfTkhxiuETYWQpaZ/SyScHnFYjSopf1eqs


## CADENA ORIGINAL DEL COMPLEMENTO DE CERTIFICACIÓN DIGITAL DEL SAT:

||1.1|0BD0B275-904E-4843-AE85-E41565ABAADD|2026-02-02T14:43:16|TSP080724QW6|

CximcTs02nW82g1/TW8+Y1qSX/UNE5TpUxk5BNwW63q0lS5IgNogKe/MUZVvRIjw4K4FZWSRTJh1Oe5T78unEhVaqxDMNDqWDN2A
K0a22P2OjMh/Ur4+LwUJL3QyLlVYmHqSw8EAOWDU3p1QEWXgMQ5fw8VkvM+JVGjrS7ykQs7n6+dECGE/nqzL3Q79TbWIIYbk+9/K
aDuSTMSe1HTshRhUMBsZzatvAoFIMdkVweGMogLbgiJKXVA/KiuZszbxrm13qo9/t5G+ASv/YWuwXAmr5FJTBYos2yJ/Qqgl6SET
Nnx7sHuE3EXMYNNQM5I7Yes7XT+avuRJRaPSx2/OTg==|00001000000702693654||
