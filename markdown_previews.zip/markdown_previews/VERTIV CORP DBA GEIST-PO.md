# VERTIV CORP DBA GEIST-PO.PDF

Vertiv Corporation
dba Geist
29755 Network Place
Chicago, IL 60673-1297
800-432-3219 Fax: 402-474-4369


# INVOICE

275822-02

1/16/2026

BILL TO:

VERTIV CORPORATION HFM43US0LDE
VERTIV-NP-INVOICES@DATASERV-STL.COM
P.O BOX 8629
ST. LOUIS MO 63126

SHIP TO:

BASS PRO SHOPS
1500 E TUCSON MARKETPLACE BLVD
PO# 25-064814TC
JOB # 1008570
TUCSON AZ 85713
UNITED STATES OF AMERICA
Ship Via: FEDEX GROUND
FOB: PREPAY&ADD

Terms:

Net 30 Days

Due Date:

2/15/2026


<table>
<tr>
<th>Item Number</th>
<th>Description</th>
<th>Pack Slip #</th>
<th>PO #</th>
<th>Order Date</th>
<th>Ship Date</th>
<th>Quantity</th>
<th>Price</th>
<th>Extension</th>
</tr>
<tr>
<td>FS-15</td>
<td></td>
<td>291985-02</td>
<td>130396632</td>
<td>1/5/2026</td>
<td>1/16/2026</td>
<td>1</td>
<td>16.080000</td>
<td>16.08</td>
</tr>
</table>


SENSOR, FLOOD, 15FT

Commodity Code:

9025900090

Tracking #: 397839984423

Note to Supplier: 1500 E TUCSON
MARKETPLACE BLVD
TUCSON, AZ 85713
TAG: PO# 25-064814TC/ PO
JOB # 1008570/ VENDOR
ID. 0527

Note to Supplier: TAG:
1407852; VERTIV PAYS FREIGHT
USE RXO PORTAL

Sales Order #: 1407852
Thank You
All Payments in US Dollars Only


<table>
<tr>
<td>Subtotal:</td>
<td>16.08</td>
</tr>
<tr>
<td>Tax:</td>
<td>0.00</td>
</tr>
<tr>
<td>Freight:</td>
<td>6.10</td>
</tr>
<tr>
<td>Total:</td>
<td>22.18</td>
</tr>
</table>


All Prices Are Shown in USD

INFORMATION TO BUYER This order between the Buyer and Seller is limited to Seller's Terms and Conditions located at termsconditions vertiv.com unless a formal
agreement governing this Purchase Order/transaction has been executed by the parties, in which case the Terms and Conditions of the signed agreement shall govern Seller
hereby objects to all Buyer's terms and conditions received by Seller and/or issued by Buyer.

Remit To Information:
. Payee can be either Geist or Vertiv Corporation
. Email remittance copies should be sent to accountsreceivable@geistglobal.com

Vertiv Corporation Banking Instructions:

Entity Name: Vertiv Corporation

Account: 192864806

Account Name: Vertiv Corporation

Lockbox No .: 29755

Bank: JPMorgan Chase Bank, NA (IL)

ABA/Routing: 071000013

Overnight Mail (overnight/courier delivery packages)
JPMorgan Chase - Lockbox Processing
Attn: VERTIV CORPORATION Box# 29755
131 S Dearborn, 6th Floor

Residents of California are encouraged to read Seller's Privacy Notice for Customers and Suppliers- California available at
www.vertiv.com/ca-privacy <http://www.vertiv.com/ca-privacy>.
