# TVH PARTS CO-Credit.pdf

<figure>

TVHILL
®

</figure>


<!-- PageNumber="1/1" -->

CREDIT NOTE 1787668
DATE 01/28/2026

BILL TO

ACCOUNT NO .: 00547698

WIESE USA INC (KANSAS CITY)

5900 DERAMUS

KANSAS CITY, MO 64120

Missouri

USA

REMIT TO:

TVH Parts Co

PO Box 675394

Dallas, TX 75267-5394

USA

VAT-NO .:


<table>
<tr>
<th>Part no.</th>
<th>Weight(lb)</th>
<th>Ordered</th>
<th>Shipped</th>
<th>Back Order</th>
<th>Unit Price</th>
<th>Total Gross Price</th>
</tr>
<tr>
<td>Description</td>
<td>Unit</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Your Reference</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


OUR INVOICE NO .: 24375445

DATED: 01/15/2026

OUR RETURNS NOTE NO .: 8159258/00 DATED: 01/22/2026

ATTN: : Colton Coldren

SHIP TO (DESTINATION):

WIESE USA INC

5900 DERAMUS

KANSAS CITY, MO 64120

Usa

OUR ORDER NO .: 435996298/00 YOUR PO NO .: 578228 DATED: 01/14/2026
ATTN: : Colton Coldren


<table>
<tr>
<th>TSA/SJ160931</th>
<th>15.0000</th>
<th>1</th>
<th>-1</th>
<th rowspan="2">0</th>
<th rowspan="2">475.18</th>
<th>-475.18</th>
</tr>
<tr>
<td>CHARGER - 24V 25A ON BOARD</td>
<td>piece</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


The ownership of the sold articles is only transferred at the moment of the complete payment of the sales price and the costs
(among other things possible outstanding interests, and other additional costs). (Art. 6,2 of the General Terms and Conditions of
Sale).

All sales of TVH Parts Co. are subject to the terms and conditions of sale at https://www.tvh.com/en-us/terms-conditions

Return authorizations must be requested within 90 days of invoice.
No parts returned without authorization. All returns subject to 25% restocking fee.

PAYMENT DETAILS:

\* TERMS OF PAYMENT:

30 DAYS (FROM DATE OF INVOICE)

Due date: 02/27/2026


<table>
<tr>
<td>TOTAL GOODS</td>
<td>-475.18</td>
</tr>
<tr>
<td>HANDLING CHARGE</td>
<td>71.28</td>
</tr>
<tr>
<td>TOTAL</td>
<td>USD -403.90</td>
</tr>
</table>
