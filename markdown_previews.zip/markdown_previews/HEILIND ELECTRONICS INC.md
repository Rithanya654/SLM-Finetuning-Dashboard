# HEILIND ELECTRONICS INC.pdf

<figure>

1

1

HEILIND
Performance. Trust. Innovation.

</figure>


Heilind Electronics, Inc.
8425 Pulsar Place, Suite 140
Columbus, OH 43240
Phone: 614-987-1700

SHIPPED FROM
6240 Tin Man Road
Mentor, OH 44060


# Original Invoice


## INVOICE

<!-- PageNumber="Page 1 of 1" -->

VERTIV NORTH AMERICA INC
PO BOX 8629
SAINT LOUIS MO 63126-0629

SHIPPED TO
VERTIV
1749 GATEWAY RD
STE 100
CALEXICO CA 92231-9555


<table>
<tr>
<th>Invoice Number</th>
<th>Invoice Date</th>
<th>Order No</th>
<th>Ship Date</th>
<th>Terms Ship From Mentor, OH 44060</th>
</tr>
<tr>
<td>GLPSA3</td>
<td>01/30/26</td>
<td>GHUM83-5</td>
<td>01/30/26</td>
<td>NET 120 FOB: DE</td>
</tr>
</table>


<table>
<tr>
<th>Order Date</th>
<th>Customer</th>
<th>Shipped VIA Tracking No: 490629954477</th>
<th>Customer P.O. Number</th>
</tr>
<tr>
<td>10/28/25</td>
<td>TS2571</td>
<td>FEDX COLLECT GROUND</td>
<td>130374674</td>
</tr>
</table>


<table>
<tr>
<th>Item</th>
<th>Mfr</th>
<th>Part Number / U/M Ordered Customer Part Number</th>
<th>Shipped</th>
<th>Price</th>
<th>CPM</th>
<th>Extension USD</th>
</tr>
<tr>
<td>5</td>
<td>AMP</td>
<td>6-1415034-1 E 350 10188405P1</td>
<td>350</td>
<td>5.060000</td>
<td>E</td>
<td>1,771.00</td>
</tr>
</table>


NET SALES: USD

1,771.00

Credit Questions Please Contact:
Sharon Cullinan


<table>
<tr>
<td>Phone :</td>
<td>978-988-3489</td>
</tr>
<tr>
<td>Fax:</td>
<td>978-658-9942</td>
</tr>
<tr>
<td>Email:</td>
<td>scullinan@heilind.com</td>
</tr>
</table>


REMIT TO :

Heilind Electronics, Inc.

C/O Bank Of America

PO BOX 99682

CHICAGO IL 60696

1,771.00

USD

This transaction is subject to our terms and conditions, which can be found at https://www.heilind.com/about/compliance-programs
