# CREATIVE TAG & LABEL.xlsx

## Sheet: Sheet1

|  |  |  |  |  |  |  |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |
|  | CREATIVE TAG & LABEL COMPANY |  |  |  |  | INVOICE |
|  | 13405 B Street |  |  |  |  | ##### |
|  | OMAHA, NEBRASKA 68144 |  |  |  |  |  |
|  | (800) 682-0831  FAX (402) 330-5561 |  |  |  |  |  |
|  | www.creativetag.com |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  | Sold To: |  |  |  |  | Invoice |
|  | Name |  |  |  |  | Date |
|  | Address 1 |  |  |  |  | xx/xx/xx |
|  | Address 2 |  |  |  |  |  |
|  | City, State, ZIP |  |  |  |  |  |

## Sheet: Sheet2

|  |  |  |  |  |  |  |  |  |  |  |
|---|---|---|---|---|---|---|---|---|---|---|
|  | CREATIVE TAG & LABEL COMPANY |  |  |  |  |  |  |  |  | INVOICE # |
|  | 13405 B STREET |  |  |  |  |  |  |  |  | 22573 |
|  | OMAHA, NEBRASKA 68144 |  |  |  |  |  |  |  |  |  |
|  | (800) 682-8031 FAX (402) 330-5561 |  |  |  |  |  |  |  |  |  |
|  | www.creativetag.com |  |  |  |  |  | Invoice |  |  |  |
|  |  |  |  |  |  |  | Date | 2026-01-23 00:00:00 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |
|  | Sold To | BPD RIVERSIDE (89-001) |  |  |  | Shipped | BPD RIVERSIDE (89-001) |  |  |  |
|  |  | P O BOX 270417 |  |  |  | To | 5710 NW 41 ST |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |
|  |  | ST LOUIS, MO 63127 |  |  |  |  | RIVERSIDE, MO 64150 |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |
|  | ACCT # |  | 1102 |  |  |  | Terms: | 2%20,NET30 |  |  |
|  | PO # |  | 353548 |  |  |  | FOB: | PLANT |  |  |
|  | SALES PERSON |  | CATHLEEN HOULE |  |  |  | Shipper: | UPS-NC |  |  |
|  |  |  |  |  |  |  | Shipped: | 2026-01-23 00:00:00 |  |  |
|  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |
|  |  | QTY | QTY |  |  |  |  |  | UNIT |  |
|  | ITEM ID | ORDERED | SHIPPED | DESCRIPTION |  |  |  |  | PRICE | AMOUNT |
|  |  |  |  |  |  |  |  |  |  | 0 |
|  | 449414925 | 40 | 40 | 11-492 #2 MANILA TAGS |  |  |  |  | 12.58 | 503.2 |
|  | 476513895 | 10 | 10 | 11-363 #3 DK GREEN TAGS |  |  |  |  | 19.48 | 194.8 |
|  | 476514005 | 5 | 5 | 11-348 #8 RED TAGS |  |  |  |  | 36.95 | 184.75 |
|  |  |  |  |  |  |  |  |  |  | 0 |
|  |  |  |  |  |  |  |  |  |  | 0 |
|  |  |  |  |  |  |  |  |  |  | 0 |
|  |  |  |  |  |  |  |  |  |  | 0 |
|  |  |  |  |  |  |  |  |  |  | 0 |
|  |  |  |  |  |  |  |  |  |  | 0 |
|  |  |  |  |  |  |  |  |  |  | 0 |
|  |  |  |  |  |  |  |  |  |  | 0 |
|  |  |  |  |  |  |  |  |  |  | 0 |
|  |  |  |  |  |  |  |  |  |  | 0 |
|  |  |  |  |  |  |  |  |  |  | 0 |
|  |  |  |  |  |  |  |  |  |  | 0 |
|  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  | SUB TOTAL | 882.75 |
|  |  |  |  |  |  |  |  |  | DISCOUNT | 0 |
|  |  | A SERVICE CHARGE OF 1.5% PER MONTH, WILL BE ADDED |  |  |  |  |  |  | TAX | 0 |
|  |  | TO ALL OVERDUE ACCOUNTS.  ALSO, LIABLE FOR ALL |  |  |  |  |  |  | SER. CHG. | 0 |
|  |  | LEGAL & COLLECTION FEES |  |  |  |  |  |  | MISC.CHG. | 0 |
|  |  |  |  |  |  |  |  |  | DEPOSIT | 0 |
|  |  |  |  |  |  |  |  |  | TOTAL | 882.75 |