# MICHAEL S RIZZO.png

MSR Services
9 The Spur
Williamsville, NY 14221


# Invoice


<table>
<tr>
<th>Date</th>
<th>Invoice #</th>
</tr>
<tr>
<td>2/1/2026</td>
<td>1099</td>
</tr>
</table>


Bill To

E.W. Scripps
7 Broadcast Plaza
Buffalo, NY 14202

Mike 716-560-7807
Billing Barb 716-633-7842
msr.services.mike.rizzo@gmail.com


<table>
<tr>
<th>P.O. No.</th>
<th>Terms</th>
<th>Project</th>
</tr>
<tr>
<td>169042</td>
<td>Due 2/28/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Quantity</th>
<th>Description</th>
<th>Rate</th>
<th>Amount</th>
</tr>
<tr>
<td></td>
<td>Snow Plowing February 2026</td>
<td>1,300.00</td>
<td>1,300.00T</td>
</tr>
<tr>
<td></td>
<td>Sales Tax</td>
<td>8.75%</td>
<td>113.75</td>
</tr>
</table>


Thank you for your business.

Total

$1,413.75
