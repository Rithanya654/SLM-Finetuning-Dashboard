# DENTALAIRE PRODUCTS.pdf

<figure>

DENTALAIRE =

17742 Mitchell North, STE B
Irvine, CA 92614
E-Mail: customerservice@dentalaire.com
www.dentalaire.com

Ph. 714-540-9969
Fax 714-540-9947

</figure>


# Invoice


<table>
<tr>
<td></td>
<td>Invoice No.</td>
<td>I261618</td>
</tr>
<tr>
<td></td>
<td>Invoice Date</td>
<td>1/29/2026</td>
</tr>
</table>


<!-- PageNumber="Page 1" -->

Bill To: COVETRUS NORTH AMERICA

Kasey Cradlebaugh (AP)

P.O. BOX 7153

DUBLIN, OH 43017-0753

Ship To: ANIMAL CARE CENTER OF

QUINT JONATHAN T DVM

562 CASTLE PINES PKWY STE C5

PINES

CASTLE ROCK, CO 80108


<table>
<tr>
<td>Ship Via</td>
<td>GROUND</td>
</tr>
<tr>
<td>Ship Date</td>
<td></td>
</tr>
<tr>
<td>Due Date</td>
<td>4/29/2026</td>
</tr>
<tr>
<td>Terms</td>
<td>Net 90 Days</td>
</tr>
<tr>
<td>Tracking No:</td>
<td>FEDEX# 492524073970</td>
</tr>
</table>


<table>
<tr>
<td>PO -</td>
<td>N573854</td>
</tr>
<tr>
<td>Customer</td>
<td>1034</td>
</tr>
<tr>
<td>P.O. Number</td>
<td>N573854</td>
</tr>
<tr>
<td>P.O. Date</td>
<td>1/27/2026</td>
</tr>
<tr>
<td>Our Order No.</td>
<td>434253</td>
</tr>
<tr>
<td>Sales Person</td>
<td>YESLLENTH CARTER</td>
</tr>
</table>


<table>
<tr>
<th>Number</th>
<th>Description</th>
<th>Unit</th>
<th>Order Qty</th>
<th>Inv Qty</th>
<th>Unit Price</th>
<th>Disc %</th>
<th>Sale Price</th>
<th>Total Price</th>
</tr>
<tr>
<td>DTP0450</td>
<td>DURA-WHITE STONE FG</td>
<td>Each</td>
<td>1</td>
<td>1</td>
<td>25.60</td>
<td>30</td>
<td>17.92</td>
<td>17.92</td>
</tr>
<tr>
<td>DTP835-014</td>
<td>FLAT END CYLINDRICAL BUR "FELINE" PK OF 5</td>
<td>Each</td>
<td>1</td>
<td>1</td>
<td>17.00</td>
<td>30</td>
<td>11.90</td>
<td>11.90</td>
</tr>
<tr>
<td></td>
<td>Under Minimum Processing Fee</td>
<td></td>
<td>1</td>
<td>1</td>
<td>7.00</td>
<td></td>
<td>7.00</td>
<td>7.00</td>
</tr>
<tr>
<td></td>
<td>Freight - Shipping</td>
<td></td>
<td>1</td>
<td>1</td>
<td>18.54</td>
<td></td>
<td>18.54</td>
<td>18.54</td>
</tr>
</table>


Balances not paid withing 30 days from Invoice Date will
accrue a service charge of 1.5% monthly - an 18% annual rate


<table>
<tr>
<td>Subtotal</td>
<td>55.36</td>
</tr>
<tr>
<td>Tax:</td>
<td>0.00</td>
</tr>
<tr>
<td>Total:</td>
<td>55.36</td>
</tr>
</table>
