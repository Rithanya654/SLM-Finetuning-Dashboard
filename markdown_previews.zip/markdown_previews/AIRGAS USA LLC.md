# AIRGAS USA LLC.pdf

Airgas®
an Air Liquide company

AIRGAS USA, LLC
6055 Rockside Woods Blvd
Independence, OH 44131

SOLD BY

AIRGAS USA, LLC (N266)

579 MARKET ST

KINGSTON PA 18704-4536

570-288-3828

BILL TO

BILFINGER INDUSTRIAL SERVICES INC

1800 HUGHES LANDING BLVD STE 450

SPRING TX 77380-1684

05


<table>
<tr>
<th>INVOICE DATE</th>
<th>PAYER</th>
<th>INVOICE NO.</th>
<th>DUE DATE</th>
<th>PAY THIS AMOUNT</th>
</tr>
<tr>
<td>02/02/2026</td>
<td>2885365</td>
<td>9168896759</td>
<td>03/19/2026</td>
<td>$ 122.29</td>
</tr>
</table>


Manage Your Account Online 24/7
Access order history, view cylinder balances, get proofs of delivery,
pay invoices and more -- visit Airgas.com today
For all information about returns, please visit us online at Airgas.com/terms-of-sale.
Please send new or updated blanket purchase orders to: ndiv.customerpo@airgas.com

PLEASE MAKE CHECKS PAYABLE AND REMIT TO:

Airgas USA, LLC

PO BOX 734445

CHICAGO IL 60673-4445

28853651916889675900000122292

TO ENSURE PROPER CREDIT, PLEASE RETURN THE UPPER PORTION WITH YOUR REMITTANCE. FOR QUESTIONS ON YOUR ACCOUNT PLEASE CALL: 216-520-6000


<table>
<tr>
<th>ORDER NO.</th>
<th>INVOICE NO.</th>
<th>INVOICE DATE</th>
<th>SOLD TO NO.</th>
<th>SOLD TO NAME</th>
</tr>
<tr>
<td>1146010599</td>
<td>9168896759</td>
<td>02/02/2026</td>
<td>2885365</td>
<td>BILFINGER INDUSTRIAL SERVICES INC</td>
</tr>
</table>


<table>
<tr>
<th>PO / RELEASE</th>
<th>ORDERED BY</th>
<th>SHIP VIA</th>
<th>PAYMENT TERMS</th>
<th>ORDER DATE</th>
</tr>
<tr>
<td>5802106131</td>
<td>Barb Rockwell 570-833-6366</td>
<td>BESTWY</td>
<td>NET 45</td>
<td>02/02/2026</td>
</tr>
</table>


<table>
<tr>
<th rowspan="2">DELIVERY NO. / DESCRIPTION</th>
<th rowspan="2">MATERIAL NUMBER</th>
<th rowspan="2">QTY SHIP'D</th>
<th rowspan="2">UOM</th>
<th rowspan="2">QTY B/O</th>
<th colspan="2">CYLINDER</th>
<th rowspan="2">UNIT PRICE</th>
<th rowspan="2">UOM</th>
<th rowspan="2">AMOUNT</th>
</tr>
<tr>
<th>SHP'D</th>
<th>RET'D</th>
</tr>
<tr>
<td>8160094635</td>
<td>SI0370GFKLL</td>
<td>6</td>
<td>PR</td>
<td></td>
<td></td>
<td></td>
<td>17.89</td>
<td>PR</td>
<td>107.34 N</td>
</tr>
<tr>
<td colspan="3">GLV GRAIN GTSN LG</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Sale</td>
<td>subtotal:</td>
<td>107.34</td>
</tr>
<tr>
<td colspan="3">Effective 9/15/2025, we may impose a for credit card transactions on account, acceptance. We do not impose a surcharge</td>
<td colspan="2">surcharge of which is on debit</td>
<td>3% on not cards</td>
<td colspan="4">the transaction amount greater than our cost of or auto-pay transactions.</td>
</tr>
<tr>
<td colspan="3">For customers with a Billing Zip Code in or visit www. airgas. com/terms-of-sale.</td>
<td></td>
<td>Colorado,</td>
<td>see</td>
<td>terms</td>
<td colspan="2">of payment on</td>
<td>reverse</td>
</tr>
<tr>
<td colspan="3">Carrier Name Tracking Number UPS 1Z1749720343145324</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Shipping &amp;</td>
<td>Handling:</td>
<td>14.95</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>AMOUNT</td>
<td>122.29</td>
</tr>
</table>


SHIP TO: 2885365

Airgas®
an Air Liquide company

AIRGAS USA, LLC
6055 Rockside Woods Blvd
Independence, OH 44131

BWI BIS ---

PROCTER AND GAMBLE PAPER

BILFINGER INDUSTRIAL SERVICES INC

BLDG# 97

5188 STATE ROUTE 87

MEHOOPANY PA 18629

FOR WIRE TRANSFER PAYMENTS
Airgas USA, LLC
Acct No 550372228
JPMC Bank, ABA No 021000021
ww-global-remits@airgas.com

FOR CHANGE Email: ndiv.customerdata@airgas.com
OF ADDRESS Phone: 216-520-6020

<!-- PageNumber="Page 1 of 1" -->


# STANDARD INVOICE

1
