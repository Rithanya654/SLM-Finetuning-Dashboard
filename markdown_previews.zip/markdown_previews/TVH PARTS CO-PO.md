# TVH PARTS CO-PO.pdf

<figure>

TVHILL
®

</figure>


<!-- PageNumber="1/1" -->

INVOICE NO. 24428482
DATE 01/28/2026

BILL TO

ACCOUNT NO .: 00538132

WIESE USA INC (LA CROSSE)

6470 FLYING CLOUD DR

EDEN PRAIRIE, MN 55344

Minnesota

USA

REMIT TO:

TVH Parts Co

PO Box 675394

Dallas, TX 75267-5394

USA

VAT-NO .:


<table>
<tr>
<th>Part no. Description Your Reference</th>
<th>Weight(lb) Unit</th>
<th>Ordered</th>
<th>Shipped</th>
<th>Back Order</th>
<th>Unit Price</th>
<th>Total Gross Price</th>
</tr>
<tr>
<td colspan="4">OUR ORDER NO .: 436260113/00 YOUR PO NO .: 113032 DATED: 01/28/2026 SHIP TO (DESTINATION):</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2">WIESE USA INC 2636 LARSON ST LA CROSSE, WI 54603 Usa</td>
<td rowspan="2"></td>
<td></td>
<td rowspan="2"></td>
<td colspan="3" rowspan="2"></td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td>TSA/CTRT00291971 BEARING - MAST ROLLER</td>
<td>4.4500 piece</td>
<td>14</td>
<td>14</td>
<td>0</td>
<td>26.02</td>
<td>364.28</td>
</tr>
<tr>
<td>TSA/CT3C9432-THO WHEEL - POLY 13.50 X 5.50</td>
<td>51.9650 piece</td>
<td>1</td>
<td>1</td>
<td>0</td>
<td>351.10</td>
<td>351.10</td>
</tr>
<tr>
<td colspan="6" rowspan="2">TRANSPORT: UPS Ground Service - TRACKING NO .: 1Z6224910315666713, 1Z6224910315666722</td>
<td>0.00</td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td colspan="5">DATE: 01/28/2026 SHIPPING UNIT: 2 PARCELS: 2 TOTAL WEIGHT OF THE PARCEL: 119.00 lb (436260113/00)</td>
<td></td>
<td></td>
</tr>
</table>


The ownership of the sold articles is only transferred at the moment of the complete payment of the sales price and the costs
(among other things possible outstanding interests, and other additional costs). (Art. 6,2 of the General Terms and Conditions of
Sale).

All sales of TVH Parts Co. are subject to the terms and conditions of sale at https://www.tvh.com/en-us/terms-conditions

Return authorizations must be requested within 90 days of invoice.
No parts returned without authorization. All returns subject to 25% restocking fee.


<table>
<tr>
<th>PAYMENT DETAILS:</th>
<th></th>
</tr>
<tr>
<td>* TERMS OF PAYMENT:</td>
<td>30 DAYS (FROM DATE OF INVOICE) Due date: 02/27/2026</td>
</tr>
</table>


<table>
<tr>
<td>TOTAL GOODS</td>
<td>715.38</td>
</tr>
<tr>
<td>TOTAL FREIGHT</td>
<td>0.00</td>
</tr>
<tr>
<td>TOTAL</td>
<td>USD 715.38</td>
</tr>
</table>
