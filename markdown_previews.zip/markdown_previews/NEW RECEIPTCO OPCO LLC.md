# NEW RECEIPTCO OPCO LLC.pdf

<figure>

Domtar

</figure>


New Receiptco Opco LLC
A Domtar Business
Inquiries: 1-800-821-5484
www.domtar.com


# INVOICE


<table>
<tr>
<th>Invoice no</th>
<th>Invoice date</th>
<th>Due date</th>
</tr>
<tr>
<td>216011484</td>
<td>2/2/26</td>
<td>3/5/26</td>
</tr>
</table>


Customer

RUS0000043

Invoice address

SCHWARZ /BUNZL SHARED SERVICES
PO BOX 270417
ST LOUIS MO 63127
US


<table>
<tr>
<th>Order number</th>
<th>Order date</th>
</tr>
<tr>
<td>0011486998</td>
<td>12/17/25</td>
</tr>
<tr>
<td>Customer PO no</td>
<td>Your dt</td>
</tr>
<tr>
<td>1299300</td>
<td>12/17/25</td>
</tr>
</table>


Payer

MUSK011905

Delivery Address

BRS GRAND RAPIDS
1040 40TH ST SE
GRAND RAPIDS MI 49508
US


<table>
<tr>
<th>Payment terms</th>
<th>Cash disc term</th>
</tr>
<tr>
<td>Net 31 Days</td>
<td>2% 30 Days</td>
</tr>
<tr>
<td>Delivery number</td>
<td>Departure date</td>
</tr>
<tr>
<td>2077199</td>
<td>2/2/26</td>
</tr>
<tr>
<td>Delivery terms</td>
<td>Delivery method</td>
</tr>
<tr>
<td>Freight included in pricing</td>
<td>Standard Freight</td>
</tr>
</table>


<table>
<tr>
<th>Line</th>
<th>Item number</th>
<th>Description</th>
<th>Invd qty</th>
<th>U/M</th>
<th>Sales price</th>
<th>Disc</th>
<th>Amount</th>
</tr>
<tr>
<td rowspan="2">1</td>
<td>9091-0551</td>
<td>281929-02 3 1/8 X 273 NP FSC MIX 70% BV-COC-127863 50/CTN- TJMAXX/HG</td>
<td>102.00</td>
<td>CT</td>
<td>80.86</td>
<td>0.00</td>
<td>8,247.72</td>
</tr>
<tr>
<td>Alias number</td>
<td>281929-02</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2">2</td>
<td>9091-5789</td>
<td>281930-01 3 1/8 X 273 NP FSC MIX 70% BV-COC-127863 50/CTN -MAR/TJX</td>
<td>204.00</td>
<td>CT</td>
<td>78.73</td>
<td>0.00</td>
<td rowspan="2">16,060.92</td>
</tr>
<tr>
<td>Alias number</td>
<td>281930-01</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2">3</td>
<td>9091-5788</td>
<td>281934-01 3 1/8 X 273 NP FSC MIX BV-COC-127863 50/CTN -TJMAXX</td>
<td>204.00</td>
<td>CT</td>
<td>78.73</td>
<td>0.00</td>
<td>16,060.92</td>
</tr>
<tr>
<td>Alias number</td>
<td>281934-01</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2">4</td>
<td>9091-0550</td>
<td>281938-02 3 1/8 X 273 NP FSC MIX 70% BV-COC-127863 50/CTN -MAR/HG</td>
<td>102.00</td>
<td>CT</td>
<td>80.86</td>
<td>0.00</td>
<td>8,247.72</td>
</tr>
<tr>
<td>Alias number</td>
<td>281938-02</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2">5</td>
<td>9091-5794</td>
<td>513635-00 3 1/8 X 273 NP FSC MIX BV-COC-127863 50/CTN-SIERRA TP</td>
<td>204.00</td>
<td>CT</td>
<td>87.16</td>
<td>0.00</td>
<td>17,780.64</td>
</tr>
<tr>
<td>Alias number</td>
<td>513635-00</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2">6</td>
<td>9091-5793</td>
<td>513636-00 3 1/8 X 273 NP FSC MIX BV-COC-127863 50/CTN -MAR/PR</td>
<td>51.00</td>
<td>CT</td>
<td>87.58</td>
<td>0.00</td>
<td>4,466.58</td>
</tr>
<tr>
<td>Alias number</td>
<td>513636-00</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<table>
<tr>
<td>Item value</td>
<td>USD</td>
<td>70,864.50</td>
</tr>
<tr>
<td>Order total</td>
<td>USD</td>
<td>70,864.50</td>
</tr>
<tr>
<td colspan="3"></td>
</tr>
<tr>
<td>Sales tax</td>
<td>USD</td>
<td>0.00</td>
</tr>
<tr>
<td>Invoice total</td>
<td>USD</td>
<td>70,864.50</td>
</tr>
<tr>
<td>To pay</td>
<td>USD</td>
<td>70,864.50</td>
</tr>
</table>


Please send Remittance Details to: us.remittances.pos@domtar.com

REMIT
PAYMENT
TO

New Receiptco Opco LLC
Bank Name: JP Morgan Chase, N.A.

ABA/Routing Number: 072000326
Account Number: 609082758

For US Lockbox
Payments via US Postal
Service:
New Receiptco Opco LLC
PO Box 738903
Dallas, TX 75373-8903

Please send Deduction Backup to: deductions.ar.pos@domtar.com

Please report any damages, shortages, or returns to Domtar within 3
business days. Please see our Fines and Deductions Policy for more
information at https://domtarposstore.com/BusinessDocs/NRO-
Business-Policies-Rev2-6.17.25.pdf

** WARNING: Your shipment may contain thermal paper using the developer Bisphenol S (BPS). Effective December 29, 2024, California
Proposition 65 mandates that all consumers exposed to products containing BPS be provided a warning prior to exposure. If your
shipment contains BPS, New Receiptco Opco LLC dba Domtar will apply the warning label below to the outer packaging. Please consult
your legal advisors for any additional warnings that may be required. New Receiptco Opco LLC dba Domtar will not indemnify non-
compliance .**

<!-- PageBreak -->


<figure>

Domtar

</figure>


New Receiptco Opco LLC
A Domtar Business
Inquiries: 1-800-821-5484
www.domtar.com


# INVOICE


<table>
<tr>
<th>Invoice no</th>
<th>Invoice date</th>
<th>Due date</th>
</tr>
<tr>
<td>216011484</td>
<td>2/2/26</td>
<td>3/5/26</td>
</tr>
</table>


WARNING: This product can expose you to chemicals including Bisphenol S, which is known to the State of
California to cause birth defects or other reproductive harm.
For more information go to www.P65Warnings.ca.gov.
