# MEGA TECHWAY INC.pdf

<figure>

MEGA
TECHWAY

</figure>


Mega Techway, Inc.
760 BETA DRIVE SUITE F
MAYFIELD VILLAGE, OH 44143-2234

Sold to:

VERTIV CORPORATION
P.O. BOX 8629
Email Invoices:Vertiv-NP-invoices@dataserv-
STL.com
ST. LOUIS, MO 63126-8629
UNITED STATES


# INVOICE

522776


<table>
<tr>
<th>DATE:</th>
<th>1/30/2026</th>
</tr>
<tr>
<td>ORDER NO:</td>
<td>SO143777</td>
</tr>
</table>


PAGE NO: 1

Ship To:

VERTIV IRONTON
3040 SOUTH 9TH STREET

IRONTON, OH45638
UNITED STATES


<table>
<tr>
<th>CUSTOMER ID</th>
<th>CUSTOMER PO</th>
<th>PAYMENT TERMS</th>
<th>FREIGHT TERMS</th>
</tr>
<tr>
<td>C1212</td>
<td>130382840</td>
<td>NET 90 DAYS</td>
<td>FREIGHT: COLLECT</td>
</tr>
</table>


<table>
<tr>
<th>PACKLIST ID</th>
<th>SHIPPING METHOD</th>
<th>SHIPPING DATE</th>
<th>F.O.B.</th>
</tr>
<tr>
<td>A307257</td>
<td>SEE ROUTING GUIDE</td>
<td>1/30/2026</td>
<td>ORIGIN</td>
</tr>
</table>


<table>
<tr>
<th>SHIP QTY</th>
<th>Ln #</th>
<th>PART NUMBER</th>
<th>DESCRIPTION</th>
<th>TX</th>
<th>REV</th>
<th>Unit Price</th>
<th>EXT. PRICE</th>
</tr>
<tr>
<td>20</td>
<td>12</td>
<td>179844G6</td>
<td>IPC NA L6-30P 3M</td>
<td></td>
<td>DR14BOM4</td>
<td>$80.5800</td>
<td>$1,611.60</td>
</tr>
</table>


SUB TOTAL:

$1,611.60

TOTAL AMOUNT DUE:

$1,611.60

IF YOU HAVE ANY QUESTIONS ON HOW THIS INVOICE WAS CALCULATED, OR QUESTIONS ABOUT ANY OF OUR OTHER PRODUCTS,
PLEASE CONTACT OUR SALES OFFICE AT +1 440-605-0700 OR EMAIL TO: ar@megatechway.com

PLEASE REFERENCE THIS INVOICE NUMBER ON YOUR CHECK AND REMIT TO:
MEGA TECHWAY INC.
760 BETA DRIVE SUITE F
MAYFIELD VILLAGE, OH 44143 - 2234
EVR
