# LIVINGSTON INTERNATIONAL INC.pdf

<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-577160</td>
</tr>
<tr>
<td>Date :</td>
<td>01/20/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>232325M</td>
<td>01/17/2026</td>
<td>01/17/2026</td>
<td>300-34569833</td>
<td>192354.00</td>
<td>192354.00 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>JUNYUE FOAM EARPLUG CO</td>
<td>KANSAS CITY, MO</td>
<td>YANTIAN, CHINA</td>
<td>881 CTNS</td>
<td>8726 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>MSC ROSA M</td>
<td>MEDURH965721</td>
<td></td>
<td>MSDU4657760</td>
<td>12/30/2025</td>
</tr>
</table>


Description of Goods: EARPLUGS


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>63984.07</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

64,058.57 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


# U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-577389</td>
</tr>
<tr>
<td>Date :</td>
<td>01/25/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>232484</td>
<td>01/27/2026</td>
<td>01/27/2026</td>
<td>300-34590334</td>
<td>32254.24</td>
<td>32254.24 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>PAC HK COMPANY LIMITED</td>
<td>NEW YORK/NEWARK AREA</td>
<td>COLOMBO, SRI LANKA</td>
<td>1363 CTNS</td>
<td>18896 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No. House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>ONE MILANO</td>
<td>ONEYCMBF22079600</td>
<td>DRYU4271580</td>
<td>12/27/2025</td>
</tr>
</table>


Description of Goods: POLYETHYLENE SHEETS


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>7957.76</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

8,032.26 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-577391</td>
</tr>
<tr>
<td>Date :</td>
<td>01/20/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>233400</td>
<td>01/24/2026</td>
<td>01/20/2026</td>
<td>300-34590359</td>
<td>22368.00</td>
<td>22368.00 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>SOURCING SOLUTIONS</td>
<td>DALLAS/FT WORTH TX</td>
<td>HAI PHONG; HAIPHONG,</td>
<td>1068 CTNS</td>
<td>8605 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT Carrier</th>
<th>Master BOL No. House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER EVER MILD</td>
<td>EGLV236500608525</td>
<td>TGBU4295712</td>
<td>12/26/2025</td>
</tr>
</table>


Description of Goods: PLASTIC HANGERS


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>5250.08</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

5,324.58 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-577397</td>
</tr>
<tr>
<td>Date :</td>
<td>01/20/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>233468</td>
<td>01/19/2026</td>
<td>01/19/2026</td>
<td>300-34590417</td>
<td>26926.00</td>
<td>26926.00 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>MASTERMAX PLASTICS HUI</td>
<td>LOS ANGELES, CA</td>
<td>YANTIAN, CHINA</td>
<td>4905 CTNS</td>
<td>16350 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>GUDRUN MAERSK</td>
<td>MAEU262580677</td>
<td>HNLTZS25QA0425</td>
<td>MRSU4776869</td>
<td>12/25/2025</td>
</tr>
</table>


Description of Goods: PLASTIC BAGS


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>515</td>
<td>PIER PASS SERVICE FEE</td>
<td>15.00</td>
</tr>
<tr>
<td>550</td>
<td>PORT CHECK FEE</td>
<td>20.00</td>
</tr>
<tr>
<td>882</td>
<td>PIER PASS</td>
<td>77.56</td>
</tr>
<tr>
<td>726</td>
<td>FDA ADMISSIBILITY</td>
<td>5.00</td>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>6319.91</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

6,511.97 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td>Invoice No .:</td>
<td>651-577412</td>
</tr>
<tr>
<td>Date :</td>
<td>01/24/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>232431</td>
<td>01/31/2026</td>
<td>01/19/2026</td>
<td>300-34590763</td>
<td>39988.80</td>
<td>39988.80 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>HUALU TRADING CO LTD</td>
<td>CINCINNATI, OH</td>
<td>PUSAN; BUSAN, REP. OF</td>
<td>1440 CTNS</td>
<td>18704 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>MSC LUCIANA</td>
<td>MEDUHW483810</td>
<td></td>
<td>MSNU8448141</td>
<td>01/04/2026</td>
</tr>
</table>


Description of Goods: WOODEN STICKS


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>551</td>
<td>APHIS LACEY ACT</td>
<td>5.00</td>
</tr>
<tr>
<td>726</td>
<td>FDA ADMISSIBILITY</td>
<td>5.00</td>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>10225.75</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

10,310.25 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-577577</td>
</tr>
<tr>
<td>Date :</td>
<td>01/21/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>233751</td>
<td>01/21/2026</td>
<td>01/21/2026</td>
<td>300-34611304</td>
<td>18585.00</td>
<td>18585.00 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>MEITELIER INTERNATIONAL</td>
<td>LOS ANGELES, CA</td>
<td>TSINGTAO; QUINGDAO,</td>
<td>1770 CTNS</td>
<td>18500 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>GERNER MAERSK</td>
<td>HLCUTA12512DRSR1</td>
<td>DWCHSQINS0047936</td>
<td>HLBU1976440</td>
<td>12/28/2025</td>
</tr>
</table>


Description of Goods: PAPER TOILET SEAT COVERS


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>882</td>
<td>PIER PASS</td>
<td>97.56</td>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>5198.49</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

5,370.55 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-577578</td>
</tr>
<tr>
<td>Date :</td>
<td>01/21/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>233753</td>
<td>01/21/2026</td>
<td>01/21/2026</td>
<td>300-34611312</td>
<td>18585.00</td>
<td>18585.00 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>MEITELIER INTERNATIONAL</td>
<td>LOS ANGELES, CA</td>
<td>TSINGTAO; QUINGDAO,</td>
<td>1770 CTNS</td>
<td>18580 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>GERNER MAERSK</td>
<td>HLCUTA12512DRSM7</td>
<td>DWCHSQINS0047934</td>
<td>HAMU3624767</td>
<td>12/28/2025</td>
</tr>
</table>


Description of Goods: PAPER TOILET SEAT COVERS


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>515</td>
<td>PIER PASS SERVICE FEE</td>
<td>15.00</td>
</tr>
<tr>
<td>550</td>
<td>PORT CHECK FEE</td>
<td>20.00</td>
</tr>
<tr>
<td>882</td>
<td>PIER PASS</td>
<td>77.56</td>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>5198.49</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

5,385.55 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-577579</td>
</tr>
<tr>
<td>Date :</td>
<td>01/21/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>233754</td>
<td>01/21/2026</td>
<td>01/21/2026</td>
<td>300-34611320</td>
<td>18585.00</td>
<td>18585.00 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>MEITELIER INTERNATIONAL</td>
<td>LOS ANGELES, CA</td>
<td>TSINGTAO; QUINGDAO,</td>
<td>1770 CTNS</td>
<td>18850 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>GERNER MAERSK</td>
<td>HLCUTA12512DRSQ0</td>
<td>DWCHSQINS0047935</td>
<td>FFAU1661266</td>
<td>12/28/2025</td>
</tr>
</table>


Description of Goods: PAPER TOILET SEAT COVERS


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>515</td>
<td>PIER PASS SERVICE FEE</td>
<td>15.00</td>
</tr>
<tr>
<td>550</td>
<td>PORT CHECK FEE</td>
<td>20.00</td>
</tr>
<tr>
<td>882</td>
<td>PIER PASS</td>
<td>77.56</td>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>5198.49</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

5,385.55 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-577601</td>
</tr>
<tr>
<td>Date :</td>
<td>01/20/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>233446</td>
<td>01/22/2026</td>
<td>01/22/2026</td>
<td>300-34611809</td>
<td>31724.00</td>
<td>31724.00 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>BYTECH MEDICAL SUPPLIES</td>
<td>LOS ANGELES, CA</td>
<td>TSINGTAO; QUINGDAO,</td>
<td>3605 CTNS</td>
<td>18864 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT Carrier</th>
<th>Master BOL No. House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER HMM PEARL</td>
<td>ONEYTAOFP6126700</td>
<td>TRHU7645839</td>
<td>12/26/2025</td>
</tr>
</table>


Description of Goods: DISPOSABLE VINYL GLOVES


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>515</td>
<td>PIER PASS SERVICE FEE</td>
<td>15.00</td>
</tr>
<tr>
<td>550</td>
<td>PORT CHECK FEE</td>
<td>20.00</td>
</tr>
<tr>
<td>882</td>
<td>PIER PASS</td>
<td>77.56</td>
</tr>
<tr>
<td>726</td>
<td>FDA ADMISSIBILITY</td>
<td>5.00</td>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>6494.35</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

6,686.41 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


# U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-577602</td>
</tr>
<tr>
<td>Date :</td>
<td>01/25/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>230724</td>
<td>01/25/2026</td>
<td>01/25/2026</td>
<td>300-34611825</td>
<td>10716.07</td>
<td>10716.07 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>NINGBO CHANGYA PLASTIC</td>
<td>TACOMA, WA</td>
<td>PUSAN; BUSAN, REP. OF</td>
<td>1098 CTNS</td>
<td>8174 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No. Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>MAERSK SARNIA</td>
<td>HLCUHA3251213438</td>
<td>DWCHSSGNS0035285 HAMU4462629</td>
<td>12/23/2025</td>
</tr>
</table>


Description of Goods: PAPER BOX & PLASTIC STRAWS & PLASTIC CUTLERY


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>726</td>
<td>FDA ADMISSIBILITY</td>
<td>5.00</td>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>2245.51</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

2,325.01 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-577605</td>
</tr>
<tr>
<td>Date :</td>
<td>01/25/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>230630</td>
<td>01/25/2026</td>
<td>01/25/2026</td>
<td>300-34611858</td>
<td>9957.10</td>
<td>9957.10 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>NINGBO CHANGYA PLASTIC</td>
<td>TACOMA, WA</td>
<td>PUSAN; BUSAN, REP. OF</td>
<td>765 CTNS</td>
<td>7646 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No. Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>MAERSK SARNIA</td>
<td>HLCUHA3251213449</td>
<td>DWCHSSGNS0035284 MTSU9671015</td>
<td>12/23/2025</td>
</tr>
</table>


Description of Goods: PAPER BOX


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>726</td>
<td>FDA ADMISSIBILITY</td>
<td>5.00</td>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>2038.34</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

2,117.84 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-577606</td>
</tr>
<tr>
<td>Date :</td>
<td>01/19/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>231523</td>
<td>01/16/2026</td>
<td>01/16/2026</td>
<td>300-34611866</td>
<td>12433.40</td>
<td>12433.40 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>NINGBO CHANGYA PLASTIC</td>
<td>LOS ANGELES, CA</td>
<td>VUNG TAU VIETNAM</td>
<td>1836 CTNS</td>
<td>8636 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT Carrier</th>
<th>Master BOL No. House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER YM WORTH</td>
<td>ONEYSGNFBU585800</td>
<td>ONEU6010316</td>
<td>12/22/2025</td>
</tr>
</table>


Description of Goods: PAPER BOX, PLASTIC CUTLERY


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>515</td>
<td>PIER PASS SERVICE FEE</td>
<td>15.00</td>
</tr>
<tr>
<td>550</td>
<td>PORT CHECK FEE</td>
<td>20.00</td>
</tr>
<tr>
<td>882</td>
<td>PIER PASS</td>
<td>77.56</td>
</tr>
<tr>
<td>726</td>
<td>FDA ADMISSIBILITY</td>
<td>5.00</td>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>2744.63</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

2,936.69 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-577764</td>
</tr>
<tr>
<td>Date :</td>
<td>01/20/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>233117</td>
<td>01/19/2026</td>
<td>01/19/2026</td>
<td>300-34628498</td>
<td>19571.82</td>
<td>19571.82 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>LOPIE INTERNATIONAL HK</td>
<td>LOS ANGELES, CA</td>
<td>YANTIAN, CHINA</td>
<td>1436 CTNS</td>
<td>13640 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>GUDRUN MAERSK</td>
<td>MAEU262413598</td>
<td>HNLTZS25QA0463</td>
<td>MRSU6293772</td>
<td>12/25/2025</td>
</tr>
</table>


Description of Goods: PAPER NAPKIN, FACIAL TISSUE


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>515</td>
<td>PIER PASS SERVICE FEE</td>
<td>15.00</td>
</tr>
<tr>
<td>550</td>
<td>PORT CHECK FEE</td>
<td>20.00</td>
</tr>
<tr>
<td>882</td>
<td>PIER PASS</td>
<td>77.56</td>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>3810.95</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

3,998.01 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-577786</td>
</tr>
<tr>
<td>Date :</td>
<td>01/25/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>230628</td>
<td>01/27/2026</td>
<td>01/27/2026</td>
<td>300-34628845</td>
<td>9970.02</td>
<td>9970.02 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>NINGBO CHANGYA PLASTIC</td>
<td>SEATTLE, WA</td>
<td>HO CHI MINH/SAIGON,</td>
<td>784 CTNS</td>
<td>7659 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT Carrier</th>
<th>Master BOL No. House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER SM MUMBAI</td>
<td>SMLMSGN5A9530700</td>
<td>CAIU4533170</td>
<td>12/22/2025</td>
</tr>
</table>


Description of Goods: PAPER BOX


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>726</td>
<td>FDA ADMISSIBILITY</td>
<td>5.00</td>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>2041.19</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

2,120.69 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-577789</td>
</tr>
<tr>
<td>Date :</td>
<td>01/25/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>230360</td>
<td>01/27/2026</td>
<td>01/27/2026</td>
<td>300-34628886</td>
<td>9711.60</td>
<td>9711.60 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>NINGBO CHANGYA PLASTIC</td>
<td>SEATTLE, WA</td>
<td>HO CHI MINH/SAIGON,</td>
<td>775 CTNS</td>
<td>7598 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT Carrier</th>
<th>Master BOL No. House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER SM MUMBAI</td>
<td>SMLMSGN5A9528700</td>
<td>SMCU1216058</td>
<td>12/22/2025</td>
</tr>
</table>


Description of Goods: PAPER BOX


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>726</td>
<td>FDA ADMISSIBILITY</td>
<td>5.00</td>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>1988.20</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

2,067.70 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


# U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td>Invoice No .:</td>
<td>651-577818</td>
</tr>
<tr>
<td>Date :</td>
<td>01/24/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>232680</td>
<td>01/30/2026</td>
<td>01/19/2026</td>
<td>300-34629504</td>
<td>29994.00</td>
<td>29994.00 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>KANGLONGDA SPECIAL</td>
<td>KANSAS CITY, MO</td>
<td>NING BO/NINGPO, NINGBO</td>
<td>586 CTNS</td>
<td>14972 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>MSC LUCIANA</td>
<td>MEDUKY173669</td>
<td></td>
<td>MEDU8689157</td>
<td>01/01/2026</td>
</tr>
</table>


Description of Goods: WORKING GLOVES


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>13990.63</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

14,065.13 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-578057</td>
</tr>
<tr>
<td>Date :</td>
<td>01/20/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>233071</td>
<td>01/20/2026</td>
<td>01/20/2026</td>
<td>300-34655939</td>
<td>18638.75</td>
<td>18638.75 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>LOPIE INTERNATIONAL HK</td>
<td>TACOMA, WA</td>
<td>YANTIAN, CHINA</td>
<td>1195 CTNS</td>
<td>14336 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No. House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>HYUNDAI JUPITER</td>
<td>ONEYHKGFK3124400</td>
<td>ONEU5949824</td>
<td>12/27/2025</td>
</tr>
</table>


Description of Goods: PAPER NAPKIN, FACIAL TISSUE, TOILET PAPER


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>3629.49</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

3,703.99 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-578058</td>
</tr>
<tr>
<td>Date :</td>
<td>01/20/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>233261</td>
<td>01/20/2026</td>
<td>01/20/2026</td>
<td>300-34655947</td>
<td>17921.20</td>
<td>17921.20 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>LOPIE INTERNATIONAL HK</td>
<td>TACOMA, WA</td>
<td>YANTIAN, CHINA</td>
<td>1202 CTNS</td>
<td>13101 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No. House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>HYUNDAI JUPITER</td>
<td>ONEYHKGFK3126600</td>
<td>TCNU4322910</td>
<td>12/26/2025</td>
</tr>
</table>


Description of Goods: PAPER NAPKIN


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>3492.60</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

3,567.10 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td>Invoice No .:</td>
<td>651-578060</td>
</tr>
<tr>
<td>Date :</td>
<td>01/25/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>233305</td>
<td>01/26/2026</td>
<td>01/25/2026</td>
<td>300-34655962</td>
<td>14040.00</td>
<td>14040.00 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>PHONG NGUYEN PLASTIC</td>
<td>SAN FRANCISCO, CA</td>
<td>ALL OTHER VIETNAM PORTS</td>
<td>1200 CTNS</td>
<td>16260 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>WAN HAI A06</td>
<td>WHLC039FY19683</td>
<td></td>
<td>WHSU5057324</td>
<td>12/28/2025</td>
</tr>
</table>


Description of Goods: CUP CARRIERS


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>482</td>
<td>GATE FEES</td>
<td>52.00</td>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>2874.18</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

3,000.68 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td>Invoice No .:</td>
<td>651-578076</td>
</tr>
<tr>
<td>Date :</td>
<td>01/25/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>233325</td>
<td>01/27/2026</td>
<td>01/27/2026</td>
<td>300-34656432</td>
<td>13580.10</td>
<td>13580.10 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>AHCOF NEOCHAINS</td>
<td>TACOMA, WA</td>
<td>AMOY,XIAMEN;HSIA MEN,</td>
<td>1254 CTNS</td>
<td>5431 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No. House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>YM COSMOS</td>
<td>ONEYXMNFF8493400</td>
<td>ONEU5309004</td>
<td>01/01/2026</td>
</tr>
</table>


Description of Goods: PLASTIC LID


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>726</td>
<td>FDA ADMISSIBILITY</td>
<td>5.00</td>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>6362.64</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

6,442.14 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-578296</td>
</tr>
<tr>
<td>Date :</td>
<td>01/25/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>233499</td>
<td>02/01/2026</td>
<td>01/27/2026</td>
<td>300-34675903</td>
<td>20160.30</td>
<td>20160.30 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>LOPIE INTERNATIONAL HK</td>
<td>CHICAGO, IL</td>
<td>YANTIAN, CHINA</td>
<td>1310 CTNS</td>
<td>13178 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT Carrier</th>
<th>Master BOL No. House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER SM NINGBO</td>
<td>SMLMSZP5K6342200</td>
<td>SELU4021403</td>
<td>12/31/2025</td>
</tr>
</table>


Description of Goods: FACIAL TISSUE, PAPER NAPKIN


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>3926.81</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

4,001.31 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


## U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-578346</td>
</tr>
<tr>
<td>Date :</td>
<td>01/19/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>233878</td>
<td>01/15/2026</td>
<td>01/10/2026</td>
<td>300-34677941</td>
<td>66060.80</td>
<td>66060.80 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>NIEDERWIESER GMBH</td>
<td>KANSAS CITY, MO</td>
<td>BREMERHAVEN; BERHN, FR</td>
<td>26 CTNS</td>
<td>18617 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>OOCL CHONGQING</td>
<td>EGLV560500267843</td>
<td></td>
<td>EMCU8236664</td>
<td>12/29/2025</td>
</tr>
</table>


Description of Goods: PACKAGING MATERIAL


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>10220.57</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

10,295.07 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-578355</td>
</tr>
<tr>
<td>Date :</td>
<td>01/19/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>232626</td>
<td>01/12/2026</td>
<td>01/12/2026</td>
<td>300-34678162</td>
<td>9461.76</td>
<td>10861.76 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>RAINCO SAS</td>
<td>CHICAGO, IL</td>
<td></td>
<td>2 CTNS</td>
<td>1112 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>AIR NON-</td>
<td>FEDERAL EXPRESS</td>
<td>02340572766</td>
<td>887276123626</td>
<td></td>
<td>12/21/2025</td>
</tr>
</table>


Description of Goods: NITRILE APRON W/BELLY BAND


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>946.20</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

1,015.70 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


## U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-578510</td>
</tr>
<tr>
<td>Date :</td>
<td>01/19/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>233216</td>
<td>01/17/2026</td>
<td>01/17/2026</td>
<td>300-34698384</td>
<td>19223.61</td>
<td>19223.61 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>LOPIE INTERNATIONAL HK</td>
<td>DALLAS/FT WORTH TX</td>
<td>YANTIAN, CHINA</td>
<td>1354 CTNS</td>
<td>12185 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>MSC ROSA M</td>
<td>MEDURH922425</td>
<td></td>
<td>MSNU7868828</td>
<td>01/01/2026</td>
</tr>
</table>


Description of Goods: FACIAL TISSUE PAPER


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>3733.82</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

3,808.32 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-578525</td>
</tr>
<tr>
<td>Date :</td>
<td>01/19/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>232323</td>
<td>01/16/2026</td>
<td>01/16/2026</td>
<td>300-34699069</td>
<td>9558.88</td>
<td>9558.88 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>PAC COMPANY LIMITED</td>
<td>CHICAGO, IL</td>
<td>SHANGHAI, CHINA</td>
<td>184 CTNS</td>
<td>1373 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>COSCO ITALY</td>
<td>CMDUCHN2993291</td>
<td>GBWQ6041190846</td>
<td>CGMU5108731</td>
<td>01/01/2026</td>
</tr>
</table>


Description of Goods:

PVC BACKPACK BAG, PVC INSULATED LUNCH BAG,

PVC DUFFEL BAG


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>6048.23</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

6,122.73 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->
<!-- PageFooter="www.livingstonintl.com" -->
<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-578539</td>
</tr>
<tr>
<td>Date :</td>
<td>01/21/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>231896</td>
<td>01/21/2026</td>
<td>01/18/2026</td>
<td>300-34699432</td>
<td>39108.50</td>
<td>39108.50 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>POLYWEL INTERNATIONAL</td>
<td>LOS ANGELES, CA</td>
<td>SHANGHAI, CHINA</td>
<td>5350 CTNS</td>
<td>16050 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No. Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>KMTC MANILA</td>
<td>SJHHSLSUAD00999</td>
<td>DWCHSSHAS0170551 SLVU6055156</td>
<td>01/03/2026</td>
</tr>
</table>


Description of Goods: POLY GLOVES


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>515</td>
<td>PIER PASS SERVICE FEE</td>
<td>15.00</td>
</tr>
<tr>
<td>550</td>
<td>PORT CHECK FEE</td>
<td>20.00</td>
</tr>
<tr>
<td>882</td>
<td>PIER PASS</td>
<td>77.56</td>
</tr>
<tr>
<td>726</td>
<td>FDA ADMISSIBILITY</td>
<td>5.00</td>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>10547.98</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

10,740.04 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-578769</td>
</tr>
<tr>
<td>Date :</td>
<td>01/20/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>232010</td>
<td>01/17/2026</td>
<td>01/17/2026</td>
<td>300-34712094</td>
<td>41127.00</td>
<td>41127.00 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>MEGASAFE PRODUCTS, INC.</td>
<td>KANSAS CITY, MO</td>
<td>AMOY,XIAMEN;HSIA MEN,</td>
<td>263 CTNS</td>
<td>2897 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>MSC ROSA M</td>
<td>MEDUWB120295</td>
<td></td>
<td>TGBU3897084</td>
<td>12/28/2025</td>
</tr>
</table>


Description of Goods: SAFEY GLASES


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>726</td>
<td>FDA ADMISSIBILITY</td>
<td>5.00</td>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>9447.47</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

9,526.97 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-578821</td>
</tr>
<tr>
<td>Date :</td>
<td>01/25/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>232645</td>
<td>01/31/2026</td>
<td>01/21/2026</td>
<td>300-34715089</td>
<td>10161.80</td>
<td>10161.80 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>NINGBO CHANGYA PLASTIC</td>
<td>DENVER, CO</td>
<td>VUNG TAU VIETNAM</td>
<td>766 CTNS</td>
<td>7728 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>MSC MARTINA MARIA</td>
<td>MEDUKE207601</td>
<td></td>
<td>MSDU6840600</td>
<td>01/03/2026</td>
</tr>
</table>


Description of Goods: PAPER BOX


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>726</td>
<td>FDA ADMISSIBILITY</td>
<td>5.00</td>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>2080.31</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

2,159.81 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td>Invoice No .:</td>
<td>651-579080</td>
</tr>
<tr>
<td>Date :</td>
<td>01/23/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>232369</td>
<td>01/23/2026</td>
<td>01/23/2026</td>
<td>300-34733116</td>
<td>46537.14</td>
<td>46537.14 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>TERCIADOS Y ELABORACION</td>
<td>TAMPA, FL</td>
<td>SAN VICENTE, CHILE</td>
<td>1096 CTNS</td>
<td>16986 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>AS SAMANTA</td>
<td>HLCUSCL251279029</td>
<td>KFUNSANORD279029</td>
<td>SLSU8032915</td>
<td>12/31/2025</td>
</tr>
</table>


Description of Goods: SAWN PAINT PADDLES


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>551</td>
<td>APHIS LACEY ACT</td>
<td>5.00</td>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>4711.87</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

4,791.37 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-579424</td>
</tr>
<tr>
<td>Date :</td>
<td>01/25/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>233870</td>
<td>02/07/2026</td>
<td>01/24/2026</td>
<td>300-34768229</td>
<td>67206.56</td>
<td>67206.56 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>NIEDERWIESER GMBH</td>
<td>KANSAS CITY, MO</td>
<td>BREMERHAVEN; BERHN, FR</td>
<td>23 PKGS</td>
<td>18099 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>OOCL SEOUL</td>
<td>EGLV560500267878</td>
<td></td>
<td>EGHU9540297</td>
<td>01/15/2026</td>
</tr>
</table>


Description of Goods: PACKAGING MATERIAL


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>10397.71</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

10,472.21 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-579425</td>
</tr>
<tr>
<td>Date :</td>
<td>01/25/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>233872</td>
<td>02/07/2026</td>
<td>01/24/2026</td>
<td>300-34768237</td>
<td>66480.50</td>
<td>66480.50 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>NIEDERWIESER GMBH</td>
<td>KANSAS CITY, MO</td>
<td>BREMERHAVEN; BERHN, FR</td>
<td>28 PKGS</td>
<td>18613 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>OOCL SEOUL</td>
<td>EGLV560500267886</td>
<td></td>
<td>EGSU9753336</td>
<td>01/10/2026</td>
</tr>
</table>


Description of Goods: PACKAGING MATERIAL


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>10285.55</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

10,360.05 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-579427</td>
</tr>
<tr>
<td>Date :</td>
<td>01/25/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>233880</td>
<td>02/07/2026</td>
<td>01/24/2026</td>
<td>300-34768260</td>
<td>66060.80</td>
<td>66060.80 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>NIEDERWIESER GMBH</td>
<td>KANSAS CITY, MO</td>
<td>BREMERHAVEN; BERHN, FR</td>
<td>26 CTNS</td>
<td>18404 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>OOCL SEOUL</td>
<td>EGLV560500267835</td>
<td></td>
<td>EMCU8873913</td>
<td>01/10/2026</td>
</tr>
</table>


Description of Goods: PACKAGING MATERIAL


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>10220.57</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

10,295.07 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td colspan="2">Invoice No .: 651-579428</td>
</tr>
<tr>
<td>Date :</td>
<td>01/25/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>233881</td>
<td>02/07/2026</td>
<td>01/24/2026</td>
<td>300-34768286</td>
<td>65480.48</td>
<td>65480.48 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>NIEDERWIESER GMBH</td>
<td>KANSAS CITY, MO</td>
<td>BREMERHAVEN; BERHN, FR</td>
<td>26 CTNS</td>
<td>18130 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>VESSEL, CONTAINER</td>
<td>OOCL SEOUL</td>
<td>EGLV560500267908</td>
<td></td>
<td>EISU8383312</td>
<td>01/19/2026</td>
</tr>
</table>


Description of Goods: PACKAGING MATERIAL


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>544</td>
<td>INSIGHT ISF (SELF-FILING)</td>
<td>5.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>10130.67</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

10,205.17 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td>Invoice No .:</td>
<td>651-580600</td>
</tr>
<tr>
<td>Date :</td>
<td>01/20/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>234631</td>
<td>01/11/2026</td>
<td>01/11/2026</td>
<td>300-34897036</td>
<td>299250.00</td>
<td>299250.00 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>MANUFACTURING DE ROPA</td>
<td>LAREDO, TX</td>
<td></td>
<td>25 BDL</td>
<td>27113 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier Master BOL No. House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>TRUCK NON-</td>
<td>TEXAS CARRIERS LLC TXCB30034897036</td>
<td>522-7610</td>
<td>01/09/2026</td>
</tr>
</table>


Description of Goods: HD FIFA ENGLISH APRON COTTON S/MD ORG
M910001


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>15.00</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>398.63</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

413.63 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com

<!-- PageBreak -->


<figure>

Livingston

</figure>


U.S. Invoice

Livingston International, Inc.
FMC LIC# 021216NF

Bill To:

BUNZL INTERNATIONAL SERVICES INC

11973 WESTLINE INDUSTRIAL DR

SAINT LOUIS, MO 63146

Attn: JERRY FOLEY

Questions on your invoice?
clientserviceus@livingstonintl.com
855-225-5548
Team : 13

Invoice Information:


<table>
<tr>
<td>Invoice No .:</td>
<td>651-581634</td>
</tr>
<tr>
<td>Date :</td>
<td>01/23/2026</td>
</tr>
<tr>
<td>Due Date :</td>
<td>On Receipt</td>
</tr>
<tr>
<td>Client No .:</td>
<td>583785</td>
</tr>
</table>


<table>
<tr>
<th>Reference / PO No.</th>
<th>Arrival Date</th>
<th>Release Date</th>
<th>Entry No.</th>
<th>Entered Value (USD)</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>234498</td>
<td>01/17/2026</td>
<td>01/17/2026</td>
<td>300-35015919</td>
<td>259.80</td>
<td>259.80 USD</td>
</tr>
</table>


<table>
<tr>
<th>Shipper/Exporter</th>
<th>Port of Entry</th>
<th>Port of Lading</th>
<th>Manifest Qty &amp; UOM</th>
<th>Gross Weight &amp; UOM</th>
</tr>
<tr>
<td>GLOVES N GLOVES</td>
<td>CHICAGO, IL</td>
<td></td>
<td>13 CTNS</td>
<td>105 KG</td>
</tr>
</table>


<table>
<tr>
<th>MOT</th>
<th>Carrier</th>
<th>Master BOL No.</th>
<th>House BOL No.</th>
<th>Container No.</th>
<th>Date of Export</th>
</tr>
<tr>
<td>AIR NON-</td>
<td>EMIRATES AIRLINES</td>
<td>17604539426</td>
<td>KHIV26010530</td>
<td></td>
<td>01/16/2026</td>
</tr>
</table>


Description of Goods: POLY-COTTON DYED KNITTED GLOVES


<table>
<tr>
<th>Code</th>
<th>Service</th>
<th>Amount</th>
</tr>
<tr>
<td>700</td>
<td>US CUSTOMS ENTRY SERVICE</td>
<td>62.00</td>
</tr>
<tr>
<td>558</td>
<td>DELIVERY ORDER (PROCESS)</td>
<td>7.50</td>
</tr>
<tr>
<td>500</td>
<td>US CUSTOMS DUTY</td>
<td>131.49</td>
</tr>
</table>


Message/Information:

NOTWITHSTANDING ANY PAYMENT MADE TO BROKER PER STANDARD TERMS AND CONDITIONS, CLIENT REMAINS LIABLE
FOR ALL DUTIES, TAXES, OR OTHER DEBTS OWED CBP.

Remit

Total Due / Funds

P.O. BOX 7410166
CHICAGO, IL 60674-0166

200.99 USD

If you are the importer of record, payment to the broker will not relieve you of liability for duties, taxes or other debts owed CBP in the event charges are not paid. If you pay by check, customs charges may
be paid with a separate check payable to "U.S. Customs and Border Protection" which will be delivered to CBP by the broker. The importer must furnish missing documents within the time period required by
regulations to avoid penalties. Upon request, we provide a breakdown of all charges assessed and a copy of each document relating to these charges (46CFR515.32d). Livingston's services and this invoice
are governed by our standard terms and conditions as may be amended through general notice posted on our web site at www.livingstonintl.com. The charges herein are consistent with applicable FMC rules
with respect to detention and demurrage. LI,I's performance did not cause or contribute to the underlying invoiced charges. Livingston will never ask you to change remittance information via email.

<!-- PageFooter="L-001 USA (05/08) KEC" -->
<!-- PageFooter="Invoice Original" -->
<!-- PageNumber="Page 1 of 1" -->

www.livingstonintl.com
