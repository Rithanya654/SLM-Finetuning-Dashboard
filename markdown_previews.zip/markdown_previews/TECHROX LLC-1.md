# TECHROX LLC-1.doc

|TECHROX LLC                 CELL: 407-967-5876                                       |P.O Number:                                        |INVOICE:                          |
|Wasi Pirzada                                                                         |OPTR-764                                           |1217                              |
|3592 Recker HWY,                                                                     |Invoice Date: 12/01/25                             |                                  |
|Winter Haven, FL. 33880                                                              |                                                   |                                  |
|Email: Wp897863@yahoo.com                                                            |                                                   |                                  |
|                                                                                     |SERVICE TECH:                                      |DUE DATE:                         |
|                                                                                     |NEAL PALMER                                        |                                  |
|                                                                                     |                                                   |1/25/2026                         |

|To:                                                                                  |For: D125 Rent                                                                        |
|Optimal Outsource                                                                    |                                                                                      |
|1650 N. Hercules # G                                                                 |                                                                                      |
|Clearwater FL 33765                                                                  |                                                                                      |
|(949) 939-6512                                                                       |                                                                                      |
|Atten: Paul & Lenda Jarvi                                                            |                                                                                      |
|                                                                                     |Meter Total:  1,877,165                                                               |
|                                                                                     |Date of Service: 12/01/25                                                             |
|                                                                                     |Start time:  1st of month                                                             |
|                                                                                     |Stop time:  End of month                                                              |
|                                                                                     |Travel:                                                                               |

|DESCRIPTION                                                                                                          |$Supplies          |Labor         |$ Labor Amount     |
|Supplies and Services                                                                                                |Amount             |Hrs.          |                   |
|                                                                                                                     |                   |              |                   |
|Serial Numbers:                                                                                                      |                   |              |                   |
|IOT: BGO:966991                                                                                                      |                   |              |                   |
|Server: LOA734685                                                                                                    |                   |              |                   |
|Monthly Renewable Contract. Rent 12-2025                                                                             |                   |              |$190.00            |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|                                                                                                                     |                   |              |                   |
|Sub Totals.                                                                                                          |$0.00              |0:00          |$190.00            |
|Tax Exempt with current resale certificate.                                                                          | Supplies and Labor               |$190.00            |
|UPS Tracking                                                                                                         |Shipping                          |                   |
|                                                                                                                     |Sales Tax                         |                   |
|                                                                                                                     |Total Due                         |$190.00            |


Please note $190 service call charge per machine for the first hour, and $90 per hour for each additional hour.  Weekend service is available at $275 for the first hour and $135 for each additional hour.  Please make check payable to Techrox and mail to the address listed above.  Thank you for your business.