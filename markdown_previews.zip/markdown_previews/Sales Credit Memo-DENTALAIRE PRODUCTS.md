# Sales Credit Memo-DENTALAIRE PRODUCTS.pdf

DENTALAIRE =

17742 Mitchell North, STE B
Irvine, CA 92614
E-Mail: customerservice@dentalaire.com
www.dentalaire.com

Ph. 714-540-9969
Fax 714-540-9947


# CREDIT MEMO


<table>
<tr>
<td>Credit Memo No.</td>
<td>116554</td>
</tr>
<tr>
<td>Credit Memo Date</td>
<td>1/28/2026</td>
</tr>
</table>


Credit

To:

COVETRUS NORTH AMERICA

Kasey Cradlebaugh (AP)

P.O. BOX 7153

DUBLIN, OH 43017-0753


<table>
<tr>
<th>Ship</th>
<th>DENTALAIRE</th>
</tr>
<tr>
<td>To:</td>
<td>17742 MITCHELL NORTH, STE B IRVINE, 92614</td>
</tr>
</table>


Ship Date
Apply to Type
Apply to Number


<table>
<tr>
<td>Customer ID</td>
<td>1034</td>
</tr>
<tr>
<td>P.O. Number</td>
<td>N472528</td>
</tr>
<tr>
<td>SalesPerson</td>
<td>YESLLENTH CARTER</td>
</tr>
</table>


<table>
<tr>
<th>Item No.</th>
<th>Description</th>
<th>Unit</th>
<th>Quantity</th>
<th>Unit Price</th>
<th>Total Price</th>
</tr>
<tr>
<td></td>
<td rowspan="2">Invoice No. I254728: F/O PUSH BUTTON H/P</td>
<td rowspan="2">Each</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>DA400AFOPB</td>
<td>1</td>
<td>231.52</td>
<td>231.52</td>
</tr>
<tr>
<td></td>
<td>ST: PART RETURNED TO STOCK - DA400AFOPB, S/N 21497. 25% RESTOCKING FEE APPLIED.</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Amount Subject to</td>
<td>Amount Exempt from</td>
<td></td>
<td></td>
<td>Subtotal:</td>
<td>231.52</td>
</tr>
<tr>
<td>Sales Tax</td>
<td>Sales Tax</td>
<td></td>
<td></td>
<td>Invoice Discount:</td>
<td>0</td>
</tr>
<tr>
<td>0.00</td>
<td>231.52</td>
<td></td>
<td></td>
<td>Tax:</td>
<td>0.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Total:</td>
<td>231.52</td>
</tr>
</table>
