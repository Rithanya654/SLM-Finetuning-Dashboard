# WESTBURNE ELECTRIC-NonInv.pdf

WESTBURNE ELECTRIC SUPPLY (MIDWEST)
DIVISION OF REXEL CANADA ELECTRICAL INC.
PO BOX 1220 STN B MISSISSAUGA ON L4Y 3W5
CREDIT DEPT 1-888-712-4020 / 905-712-4040

NEW FLYER INDUSTRIES LIMITED
PO BOX 245 TRANSCONA PO
711 KERNAGHAN AVENUE
WINNIPEG MB
R2C 1E4

BR. 04 PAGE
1

Last Payment Received
Dernier Paiement Reçu
10-24-2025|
1079.00


<table>
<tr>
<th rowspan="2">Customer No. | No Du Client</th>
<th></th>
</tr>
<tr>
<th>| Date</th>
</tr>
<tr>
<td>70049</td>
<td>|01-31-2026</td>
</tr>
</table>


:

:

:
Return With Remittance
Retourner Avec Votre
Paiement
:
:
:
WESTBURNE ELECTRIC SUPPLY
DIVISION OF REXEL CANADA E
PO BOX 1220 STN B MISSISS
CREDIT DEPT 1-888-712-4020
:
:
:
:

:

:

:

:
BR. 04

:
Customer Name
Nom Du Client
:
:
NEW FLYER INDUSTRIES LIMI
:

:

:
:

:

:

:

:

Total

Discount Amount
Montant Descompte
:
:
118433.65

:

:


<table>
<tr>
<th>DATE</th>
<th>: INVOICE : REF : FACTURE : REF</th>
<th># / PURCHASE ORDER # / # DE COMMANDE</th>
<th>#: : NET PAY : : CD: DATE :</th>
<th>BR. : :</th>
<th>AMOUNT : MONTANT : :</th>
<th>: : INVOICE : : FACTURE :</th>
<th>AMOUNT : : MONTANT : :</th>
</tr>
<tr>
<td></td>
<td colspan="2">_ : : OPEN ITEMS</td>
<td>_ _ _ : : :</td>
<td>_ :</td>
<td>_ :</td>
<td>_ : : :</td>
<td>: :</td>
</tr>
<tr>
<td>022125</td>
<td>: 9173181 : PO#</td>
<td>1430028</td>
<td>: IN : 05012025:</td>
<td>04:</td>
<td>3398.06: :</td>
<td>: 9173181 :</td>
<td>3398.06: :</td>
</tr>
<tr>
<td>022525</td>
<td>: 9175181 : PO#</td>
<td>1430028</td>
<td>: IN : 05012025:</td>
<td>04:</td>
<td>2835.00: :</td>
<td>: 9175181 :</td>
<td>2835.00: :</td>
</tr>
<tr>
<td>022625</td>
<td>: 9175701 : PO#</td>
<td>1430028</td>
<td>: IN : 05012025:</td>
<td>04:</td>
<td>1586.81: :</td>
<td>: 9175701 :</td>
<td>1586.81: :</td>
</tr>
<tr>
<td>031125</td>
<td>: 9183501 : PO#</td>
<td>1431595</td>
<td>: IN : 06012025:</td>
<td>04:</td>
<td>462.84: :</td>
<td>: 9183501 :</td>
<td>462.84: :</td>
</tr>
<tr>
<td>031225</td>
<td>: 9184586 : PO#</td>
<td>1430891</td>
<td>: IN : 06012025:</td>
<td>04:</td>
<td>113.40: :</td>
<td>: 9184586:</td>
<td>113.40: :</td>
</tr>
<tr>
<td>032825</td>
<td>: 9194170 : PO#</td>
<td>1433491</td>
<td>: IN : 06012025:</td>
<td>04:</td>
<td>61.95: :</td>
<td>: 9194170 :</td>
<td>61.95: :</td>
</tr>
<tr>
<td>033125</td>
<td>: 9194756 : PO#</td>
<td>1433958</td>
<td>: IN : 06012025:</td>
<td>04:</td>
<td>298.94: :</td>
<td>: 9194756:</td>
<td>298.94: :</td>
</tr>
<tr>
<td>033125</td>
<td>: 9194796 : PO#</td>
<td>1433931</td>
<td>: IN: 06012025:</td>
<td>04:</td>
<td>892.50: :</td>
<td>: 9194796:</td>
<td>892.50 : :</td>
</tr>
<tr>
<td>040125</td>
<td>: 9195486 : PO#</td>
<td>1433952</td>
<td>: IN : 07012025:</td>
<td>04:</td>
<td>514.92: :</td>
<td>: 9195486:</td>
<td>514.92: :</td>
</tr>
<tr>
<td>040325</td>
<td>: 9197040 : PO#</td>
<td>1433952</td>
<td>: IN : 07012025:</td>
<td>04:</td>
<td>31.61: :</td>
<td>: 9197040 :</td>
<td>31.61: :</td>
</tr>
<tr>
<td>040425</td>
<td>: 9198456: PO#</td>
<td>1434358</td>
<td>: IN : 07012025:</td>
<td>06:</td>
<td>179.55: :</td>
<td>: 9198456:</td>
<td>179.55: :</td>
</tr>
<tr>
<td>040425</td>
<td>: 9198457 : PO#</td>
<td>1434334</td>
<td>: IN : 07012025:</td>
<td>06:</td>
<td>88.20: :</td>
<td>: 9198457:</td>
<td>88.20: :</td>
</tr>
<tr>
<td>040725</td>
<td>: 9198880 : PO#</td>
<td>1433930</td>
<td>: IN : 07012025:</td>
<td>04:</td>
<td>4147.50: :</td>
<td>: 9198880 :</td>
<td>4147.50: :</td>
</tr>
<tr>
<td>040725</td>
<td>: 9199505 : PO#</td>
<td>1434334</td>
<td>: IN : 07012025:</td>
<td>86:</td>
<td>3363.36: :</td>
<td>: 9199505 :</td>
<td>3363.36: :</td>
</tr>
<tr>
<td>040725</td>
<td>: 9199507 : PO#</td>
<td>1434358</td>
<td>: IN : 07012025:</td>
<td>86:</td>
<td>325.92: :</td>
<td>: 9199507:</td>
<td>325.92: :</td>
</tr>
<tr>
<td>040825</td>
<td>: 9199988 :</td>
<td>2025-0033</td>
<td>: IN : 07012025:</td>
<td>04:</td>
<td>399.00: :</td>
<td>: 9199988 :</td>
<td>399.00: :</td>
</tr>
<tr>
<td>040925</td>
<td>: 9200332 : PO#</td>
<td>1434358</td>
<td>: IN : 07012025:</td>
<td>04:</td>
<td>21.63: :</td>
<td>: 9200332:</td>
<td>21.63: :</td>
</tr>
<tr>
<td>050725</td>
<td>: 9216657 : PO#</td>
<td>1433492</td>
<td>: IN : 08012025:</td>
<td>04:</td>
<td>4121.25: :</td>
<td>: 9216657:</td>
<td>4121.25: :</td>
</tr>
<tr>
<td>082125</td>
<td>: 9280299 : PO#</td>
<td>1447264</td>
<td>: IN : 11012025:</td>
<td>04:</td>
<td>708.75: :</td>
<td>: 9280299 :</td>
<td>708.75: :</td>
</tr>
<tr>
<td>112625</td>
<td>: 9343187 : PO#</td>
<td>1459552</td>
<td>: IN : 02012026:</td>
<td>04:</td>
<td>624.65: :</td>
<td>: 9343187:</td>
<td>624.65: :</td>
</tr>
<tr>
<td>112725</td>
<td>: 9344131 : PO#</td>
<td>1459175</td>
<td>: IN : 02012026:</td>
<td>04:</td>
<td>354.59: :</td>
<td>: 9344131:</td>
<td>354.59: :</td>
</tr>
<tr>
<td>120425</td>
<td>: 9348845 : PO#</td>
<td>1459926</td>
<td>: IN : 03012026:</td>
<td>04:</td>
<td>399.00: :</td>
<td>: 9348845:</td>
<td>399.00: :</td>
</tr>
</table>


AJ Adjustment
DD Discount Not Allowed

Rectification
SC Service Charge

Escompte non Accordé
CN Credit Note

Insuffisance de fonds
IN Invoice
Facture

Frais D'Interets

PP Partial Payment
Paiement part.

Note de Credit
UC Unapplied Cash
Inapplique

NS NSF Cheque

Please Check X
:

||

Invoices Being Paid.
Veuillez Cocher X Les
:
:
Factures Incluses Dans
Votre Paiement.
:
:

:

:

:
Payment Att
Paiement
Ci-joint
:
:

:

:

:

:

:

:
:

: Con't
:

:

TOTAL
:
:

:
:


<table>
<tr>
<th>CURRENT :</th>
<th>31-60 DAYS :</th>
<th>61-90 DAYS : 91-120 DAYS :</th>
<th>120 + DAYS :</th>
</tr>
<tr>
<td>: 1505.34:</td>
<td>: 92397.88 :</td>
<td>: : 979.24: :</td>
<td>: 23551.19 :</td>
</tr>
</table>


:

Service Charges on overdue Accounts - 2% per Mo.
Frais D'Administration sur tout compte passe du 2% par mois

:

:

Customer NO. |
No Du Client | Date
70049
|01-31-2026

STATEMENT REPRINT
REIMPRESSION D'ÉTAT
DE COMPTE

<!-- PageBreak -->

STATEMENT REPRINT
REIMPRESSION D'ÉTAT
DE COMPTE

WESTBURNE ELECTRIC SUPPLY (MIDWEST)
DIVISION OF REXEL CANADA ELECTRICAL INC.
PO BOX 1220 STN B MISSISSAUGA ON L4Y 3W5
CREDIT DEPT 1-888-712-4020 / 905-712-4040

NEW FLYER INDUSTRIES LIMITED
PO BOX 245 TRANSCONA PO
711 KERNAGHAN AVENUE
WINNIPEG MB
R2C 1E4

BR. 04 PAGE
2

Last Payment Received
Dernier Paiement Reçu
10-24-2025|
1079.00


<table>
<tr>
<th>Customer No. |</th>
<th rowspan="2">| Date</th>
</tr>
<tr>
<th>No Du Client</th>
</tr>
<tr>
<td>70049</td>
<td>|01-31-2026</td>
</tr>
</table>


Total
118433.65

Return With Remittance
Retourner Avec Votre
Paiement

WESTBURNE ELECTRIC SUPPLY
DIVISION OF REXEL CANADA E
PO BOX 1220 STN B MISSISS
CREDIT DEPT 1-888-712-4020

BR. 04

Customer Name
Nom Du Client
NEW FLYER INDUSTRIES LIMI

Customer NO. |
No Du Client | Date
70049
|01-31-2026

Discount Amount
Montant Descompte


<table>
<tr>
<th rowspan="2">DATE</th>
<th rowspan="2">: INVOICE : REF : FACTURE : REF</th>
<th rowspan="2"># / PURCHASE ORDER # / # DE COMMANDE</th>
<th rowspan="2">#: : NET PAY : : : CD: DATE : BR. :</th>
<th rowspan="2">AMOUNT : MONTANT :</th>
<th rowspan="2">: INVOICE : FACTURE :</th>
<th>: AMOUNT :</th>
<th>:</th>
</tr>
<tr>
<th>MONTANT :</th>
<th>:</th>
</tr>
<tr>
<td>121025</td>
<td>: 9352785 : PO#</td>
<td>1461474</td>
<td>: IN : 03012026: 04:</td>
<td>38.09:</td>
<td>: 9352785 :</td>
<td>38.09:</td>
<td>:</td>
</tr>
<tr>
<td>122225</td>
<td>: 9359556:1460957</td>
<td></td>
<td>: IN : 03012026: 05:</td>
<td>82599.83:</td>
<td>: 9359556:</td>
<td>82599.83:</td>
<td>:</td>
</tr>
<tr>
<td>122425</td>
<td>: 9360733:</td>
<td>1460957</td>
<td>: IN : 03012026: 05:</td>
<td>5027.99:</td>
<td>: 9360733:</td>
<td>5027.99:</td>
<td>:</td>
</tr>
<tr>
<td>122925</td>
<td>:9360885 : PO#</td>
<td>1462113</td>
<td>: IN : 03012026: 04:</td>
<td>382.41:</td>
<td>: 9360885 :</td>
<td>382.41:</td>
<td>:</td>
</tr>
<tr>
<td>122925</td>
<td>: 9361187:</td>
<td>1460957</td>
<td>: IN : 03012026: 05:</td>
<td>3950.56:</td>
<td>: 9361187:</td>
<td>3950.56:</td>
<td></td>
</tr>
<tr>
<td>011926</td>
<td>: 9371577 : PO#</td>
<td>1463579</td>
<td>: IN : 04012026: 04:</td>
<td>1303.68:</td>
<td>: 9371577:</td>
<td>1303.68:</td>
<td></td>
</tr>
<tr>
<td>012726</td>
<td>: 9376330 : PO#</td>
<td>1464731</td>
<td>: IN : 04012026: 04:</td>
<td>201.66:</td>
<td>: 9376330 :</td>
<td>201.66:</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">"THIS STATEMENT REFLECTS 30 DAY TERMS"</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>CURRENT</td>
<td>GST</td>
<td>64.86</td>
<td>TOTAL GST</td>
<td>5639.71:</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>:</td>
<td></td>
<td>: : :</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>: :</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


AJ Adjustment
Rectification
SC Service Charge
Frais D'Interets
Note de Credit
UC Unapplied Cash
Inapplique
PP Partial Payment
Paiement part.
Service Charges on overdue Accounts - 2% per Mo.
Frais D'Administration sur tout compte passé du 2% par mois

DD Discount Not Allowed
Escompte non Accordé
CN Credit Note

NS NSF Cheque
Insuffisance de fonds
IN Invoice
Facture

Please Check X
Invoices Being Paid.
Veuillez Cocher X Les
Factures Incluses Dans
Votre Paiement.

Payment Att
Paiement
Ci-joint


<table>
<tr>
<th>CURRENT</th>
<th>31-60 DAYS :</th>
<th>61-90 DAYS</th>
<th>: 91-120 DAYS</th>
<th>: 120 + DAYS : :</th>
<th>: TOTAL</th>
</tr>
<tr>
<td>1505.34:</td>
<td>92397.88 :</td>
<td>979.24:</td>
<td>:</td>
<td>: 23551.19 : :</td>
<td>: 118433.65:</td>
</tr>
</table>
