# CENTRAL SUPPLY CO.  INC.-PO.pdf

<figure>

CENTRAL SUPPLY COMPANY

</figure>


Central Supply Company - AND
6628 PRODUCTION DRIVE
ANDERSON IPh N 46013
765-770-0520 Fax N/A

BILL TO:

RT MOORE CO INC

6340 LA PAS TRAIL

INDIANAPOLIS IN 46268


# INVOICE


<table>
<tr>
<th>INVOICE DATE</th>
<th>INVOICE NUMBER</th>
</tr>
<tr>
<td>01/30/26</td>
<td>S101335551.001</td>
</tr>
<tr>
<td colspan="2">PAGE NO.</td>
</tr>
<tr>
<td colspan="2">Page 1 of 1</td>
</tr>
<tr>
<td colspan="2">PLEASE REMIT PAYMENT TO:</td>
</tr>
<tr>
<td colspan="2">CENTRAL SUPPLY COMPANY - IND PO BOX 1982</td>
</tr>
<tr>
<td colspan="2">INDIANAPOLIS IN 46206</td>
</tr>
</table>


SHIP TO:

RT Moore Showers

139 SUMMERTON RANCH

5461 FOSTER PLACE

MC CORDSVILLE IN 46055


<table>
<tr>
<th>CUSTOMER NUMBER</th>
<th>CUSTOMER PO NUMBER</th>
<th>JOB NAME/RELEASE NUMBER</th>
<th>SALESPERSON</th>
</tr>
<tr>
<td>323</td>
<td>PO0413718</td>
<td>D1SMER139.2</td>
<td>House Account</td>
</tr>
</table>


<table>
<tr>
<th>WRITER</th>
<th>SHIP VIA</th>
<th>TERMS</th>
<th>SHIP DATE</th>
<th>ORDER DATE</th>
</tr>
<tr>
<td>Nathan Koch</td>
<td>OUR TRUCK</td>
<td>2% 10th Net 30th</td>
<td>01/30/2026</td>
<td>12/03/2025</td>
</tr>
</table>


<table>
<tr>
<th>ORDER QTY</th>
<th>SHIP QTY</th>
<th>DESCRIPTION</th>
<th>UNIT PRICE</th>
<th>EXT PRICE</th>
</tr>
<tr>
<td>1ea</td>
<td>1ea</td>
<td>FRONTLINE TB603377 LH WHITE TUB/SHOWER ABOVE THE FLOOR ROUGH BUILDER 60X33X77 123313LA Your # 0324282 Bg left Pn: 1158</td>
<td>405.120E</td>
<td>405.12</td>
</tr>
<tr>
<td>2ea</td>
<td>2ea</td>
<td>FRONTLINE TB603377 RH WHITE TUB/SHOWER ABOVE THE FLOOR ROUGH BUILDER 60X33X77 123313RA Your # 0324283 Bg left Pn: 1160</td>
<td>405.120E</td>
<td>810.24</td>
</tr>
<tr>
<td>1ea</td>
<td>1ea</td>
<td>FLORESTONE 6034-1 WHITE SHOWER BASE W/ INTEGRAL DRAIN Your # 0324289 Bg left Pn: 33117</td>
<td>217.760E</td>
<td>217.76</td>
</tr>
</table>


If paid by 02/10/2026 you may deduct $28.66
Invoice is due by 03/02/2026
Past Due invoices may be subject to 1.50% late charge

01-30-2026 09:20:44 AM
S101335551.001

Left

Bg


<table>
<tr>
<td>Subtotal</td>
<td>1433.12</td>
</tr>
<tr>
<td>S&amp;H Charges</td>
<td>0.00</td>
</tr>
<tr>
<td>Tax</td>
<td>0.00</td>
</tr>
<tr>
<td>Discount</td>
<td>0.00</td>
</tr>
<tr>
<td>Amount Due</td>
<td>1433.12</td>
</tr>
</table>


TO VIEW & PAY ONLINE GO TO:
https://www.centralsupplycompany.com/

AND CLICK BILLTRUST INVOICE GATEWAY
