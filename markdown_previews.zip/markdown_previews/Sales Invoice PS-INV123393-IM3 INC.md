# Sales Invoice PS-INV123393-IM3 INC.pdf

# Invoice

PS-INV123393

IM3
®


<table>
<tr>
<th>Covetrus North America</th>
<th>SHIP-TO ADDRESS WRIGHT VETERINARY SERVICE</th>
<th rowspan="2">Distributors 12414 NE 95th Street Vancouver, WA 98682</th>
</tr>
<tr>
<th>PO Box 7153</th>
<th>W2796 HWY 67</th>
</tr>
<tr>
<td>DUBLIN, OH 43017</td>
<td>CAMPBELLSPORT, WI 53010</td>
<td>USA</td>
</tr>
<tr>
<td>USA</td>
<td>USA</td>
<td></td>
</tr>
</table>


Department :

DISTRIBUTOR

Document Date

Due Date

January 28, 2026

April 28, 2026

Package Tracking No.

Shipping Agent Code

1Z8E94410396142705

UPS


<table>
<tr>
<td>External Document No.</td>
<td>Payment Terms</td>
</tr>
<tr>
<td>N576123</td>
<td>Net 90 Days</td>
</tr>
<tr>
<td>Shipment Method</td>
<td>Order No.</td>
</tr>
<tr>
<td>Cost and Freight</td>
<td>S-ORD125121</td>
</tr>
</table>


<table>
<tr>
<th>No.</th>
<th>Cust Ref #</th>
<th>Description</th>
<th>Item Tracking</th>
<th>Quantity Unit</th>
<th>Unit Price</th>
<th>Disc %</th>
<th>Line Amount</th>
</tr>
<tr>
<td>D7916</td>
<td></td>
<td>Bur #1/2 Round FG Surgical Length 5 pk</td>
<td></td>
<td>0 Each</td>
<td>35.00</td>
<td>25.00</td>
<td>0.00</td>
</tr>
</table>


Home Page
https://www.im3vet.com/

Phone No.

3602542981

Email

info@im3usa.com

<!-- PageBreak -->

<!-- PageHeader="Invoice PS-INV123393 January 28, 2026" -->
<!-- PageNumber="Page 2 / 2" -->


<table>
<tr>
<th>D7915</th>
<th>Bur #1/4 Round Surgical Length FG bur 5pk</th>
<th>2 Each</th>
<th>35.00</th>
<th>25.00</th>
<th>52.50</th>
</tr>
<tr>
<td></td>
<td>Freight - Shipping Charges 42705</td>
<td>1</td>
<td>19.50</td>
<td>0.00</td>
<td>19.50</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Subtotal</td>
<td></td>
<td>72.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Tax</td>
<td></td>
<td>0.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total $</td>
<td></td>
<td>72.00</td>
</tr>
</table>


Goods are intended for Veterinary Dental Use Only
All damage claims, discrepancies, or return authorizations must be notified within two weeks of
delivery. To review our Returns & Shipping policy in full please visit our website at
www.im3vet.com


<table>
<tr>
<td>Amount Subject to Sales</td>
<td>0.00</td>
</tr>
<tr>
<td>Tax</td>
<td></td>
</tr>
<tr>
<td>Amount Exempt from Sales</td>
<td>72.00</td>
</tr>
<tr>
<td>Tax</td>
<td></td>
</tr>
</table>
