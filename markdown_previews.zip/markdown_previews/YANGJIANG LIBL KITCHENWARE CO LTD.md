# YANGJIANG LIBL KITCHENWARE CO LTD.xlsx

## Sheet: Sheet1

| Exporter(name & address):
YANGJIANG LIBL KITCHENWARE CO., LTD
YONGXING 3RD ROAD, YANGDONG INDUSTRIAL ZONE,
YANGJIANG,GUANGDONG, CHINA |  | 商业发票
COMMERCIAL INVOICE |  |  |
|---|---|---|---|---|
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |
| Buyer (Name):
Bunzl International Services, Inc.

One City Place Drive, Suite 200
St. Louis, MO 63141 
TEL:  314-997-5959   FAX: 314-991-4892 |  | Invoice Number:
LB260127 | PO# 
142417 | Date:
2026/01/27 |
|  |  |  |  |  |
|  |  | From:
Ningbo,
CHINA | Ningbo, WAREHOUSE |  |
| Manufacturer Name: YANGJIANG LIBL KITCHENWARE CO., LTD |  |  |  | Country of origin : China |
| Manufacturer Address: YONGXING 3RD ROAD, YANGDONG INDUSTRIAL ZONE,
YANGJIANG,GUANGDONG, CHINA |  |  |  |  |
| Shipping Marks | Description of Goods | Quantity
(CTNS) | Unit Price
(IN USD/CTN) | Amount(USD) |
|  | Bunzl Sub Vendor Number: |  |  |  |
| N/M | Steak knife | 23 | 170 | 3910 |
|  | Item No. 76000546 |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |
|  | TOTAL: | 23 |  | 3910 |
| THIS SHIPMENT DOES NOT CONTAIN ANY WOODEN |  |  |  |  |
| CRATES,PALLETS OR WOODEN PACKING MATERALS. |  |  |  |  |
| SAY TOTAL US DOLLARS THREE THOUSAND NINE HUNDRED AND TEN USD ONLY |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |
| New Bank information of |  |  |  |  |
| BENEFICIARY NAME: Yangjiang Libl Kitchenware Co., LTD
Account Number: 79969000163487
Beneficiary Address: Yongxing 3rd Road, Yangdong Industrial Zone, Yangjiang, Guangdong, China
Bank name: DBS Bank (Hong Kong) Limited
Bank address: 11th Floor, The Center, 99 Queen's Road Central, Central, Hong Kong
SWIFT code: DHBKHKHH |  |  |  |  |