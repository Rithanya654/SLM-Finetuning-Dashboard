# VALIN_1226454_1226454-DIGIKEY CORPORATION.xls

## Sheet: USD

|  |  |  |  | STATEMENT OF ACCOUNT |  |  |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |
|  |  |  |  |  | Payment Terms: | NET30 |
|  |  |  |  |  | Date: | 01-Feb-2026 |
|  |  |  |  |  | Account #: | 1226454 |
|  |  |  |  |  | Balance Due: | 5,045.97 |
| 701 Brooks Ave. South |  |  |  |  |  |  |
| P.O. Box 677 |  |  |  |  |  |  |
| Thief River Falls, MN 56701-0677 USA |  |  |  |  |  |  |
| accounting@digikey.com |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
| Bill To: |  |  |  | Remit To: |  |  |
| VALIN |  |  |  |  | Bank Name: | NORTHERN STATE BANK |
| ACCOUNTS PAYABLE |  |  |  |  | Account Number: | 115967 |
| PO BOX 270420 |  |  |  |  | Bank Code Number: |  |
| SAINT LOUIS MO 63127 United States |  |  |  |  | IBAN: |  |
|  |  |  |  |  | IFSC/SORT/ABA: | 091216146 |
|  |  |  |  |  | BIC/SWIFT: |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
| Date of Transaction | Transaction Type | MSC# | Invoice/ | Customer PO/Check # | Transaction Amount | Transaction Balance |
|  |  |  | Memo # |  |  |  |
| 30-Dec-2025 | Invoice | 0 | 119387200 | 1616415 | 98.13 | 98.13 |
| 31-Dec-2025 | Invoice | 0 | 119418739 | JOELC-SHOP SUPPLIES | 264.97 | 264.97 |
| 06-Jan-2026 | Invoice | 0 | 119556926 | 1612820 | 15.92 | 15.92 |
| 07-Jan-2026 | Invoice | 0 | 119597017 | JOELC-SHOP SUPPLIES | 369.96 | 369.96 |
| 09-Jan-2026 | Invoice | 0 | 119652751 | 1614083 | 197.98 | 197.98 |
| 10-Jan-2026 | Invoice | 0 | 119692000 | 1612672 | 86.24 | 86.24 |
| 12-Jan-2026 | Invoice | 0 | 119707717 | 1612672 | 5.33 | 5.33 |
| 20-Jan-2026 | Invoice | 0 | 119951207 | 1614723 | 172.48 | 172.48 |
| 20-Jan-2026 | Invoice | 0 | 119988917 | 1614722 | 262.91 | 262.91 |
| 23-Jan-2026 | Invoice | 0 | 119929316 | 1614638 | 758.89 | 758.89 |
| 26-Jan-2026 | Invoice | 0 | 120153096 | 1614722 | 75.98 | 75.98 |
| 28-Jan-2026 | Invoice | 0 | 120241896 | 1615012 | 450.78 | 450.78 |
| 30-Jan-2026 | Invoice | 0 | 120369845 | 1615345 | 2286.4 | 2286.4 |
| Balance Due: |  |  |  |  |  |  |
|  |  |  |  |  |  | 5,045.97 |
|  |  |  |  |  |  | USD $ |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
| Total Amount for USD Currency |  |  |  |  |  |  |
| 91+ Days | 61-90 Days | 31-60 Days | 1-30 Days | Current | Unapplied Payments |  |
| 0 | 0 | 0 | 363.10 | 4,682.87 |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
| Payment must be received in the Invoice currency.
All bank fees are the responsibility of the customer. |  |  |  |  |  |  |

## Sheet: XDO_METADATA

| Version |  |  |
|---|---|---|
| ARU-dbdrv |  |  |
| Extractor Version |  |  |
| Template Code |  |  |
| Template Type | TYPE_EXCEL_TEMPLATE |  |
| Preprocess XSL File |  |  |
| Last Modified Date |  |  |
| Last Modified By |  |  |
|  |  |  |
| Data Constraints: |  |  |
| XDO_GROUP_?XDOG1? | <xsl:for-each select=".//G_LINE_CLUSTER[string-length(.//REFERENCE) = 0 or (.//TRANSACTION = 'Invoice')]"> | </xsl:for-each> |
| XDO_?SEND_CUSTOMER_NAME? | <?SEND_CUSTOMER_NAME?> |  |
| XDO_?SEND_ADDRESS1? | <?SEND_ADDRESS1?> |  |
| XDO_?SEND_ADDRESS? | <?concat(.//SEND_ADDRESS2,' ',.//SEND_ADDRESS3,' ',.//SEND_ADDRESS4)?> |  |
| XDO_?CITY_CONCAT? | <?concat(.//SEND_CITY,' ',.//SEND_STATE,' ',.//SEND_POSTAL_CODE,' ',.//SEND_COUNTRY_DESC)?> |  |
| XDO_?REMIT_CUSTOMER_NAME? | <?REMIT_CUSTOMER_NAME?> |  |
| XDO_?REMIT_ADDRESS1? | <?REMIT_ADDRESS1?> |  |
| XDO_?REMIT_ADDRESS? | <?concat(.//REMIT_ADDRESS2,' ',.//REMIT_ADDRESS3,' ',.//REMIT_ADDRESS4)?> |  |
| XDO_?REMIT_CITY_CONCAT? | <?concat(.//REMIT_CITY,' ',.//REMIT_STATE,' ',.//REMIT_POSTAL_CODE,' ',.//REMIT_COUNTRY_DESC)?> |  |
| XDO_?HEADING? | <?concat('Total Amount for ',.//CURRENCY_CODE,' Currency')?> |  |
| XDO_?BALANCE? | <?concat(.//CURRENCY_CODE,' Balance: ')?> |  |
| XDO_?TOTAL_BALANCE? | <?sum(..//CS_1) + sum(..//AMOUNT_DUE)?> |  |
| XDO_?XDOFIELD1? | <?TRX_AMOUNT?> |  |
| XDO_?XDOFIELD1? | <?CD_TRX_AMOUNT?> |  |
| XDO_PARAM_?1? | ?param@begin:.//AMOUNT_DUE;.//AMOUNT_DUE + .//AMOUNT_DUE? |  |
| XDO_SHEET_? | <?.//G_STATEMENT?> |  |
| XDO_SHEET_NAME_? | <?.//CURRENCY_CODE?> |  |
| XDO_?XDOFIELD1? | <?TRX_AMOUNT?> |  |
| XDO_?XDOFIELD2? | <?CF_AMOUNT_DUE?> |  |
| XDO_?XDOFIELD3? | <?TOTAL_AMOUNT_DUE?> |  |
| XDO_?XDOFIELD4? | <?INVOICE_NUMBER?> |  |
| XDO_GROUP_?XDOG1? | <xsl:for-each select=".//G_LINE_CLUSTER[string-length(.//REFERENCE) = 0 or (.//TRANSACTION = 'Invoice')]"> | </xsl:for-each> |
| XDO_?XDOFIELD5? | <?CUST_NUM?> |  |
| XDO_?XDOFIELD7? | <?INVOICE_NUMBER1?> |  |
| XDO_?XDOFIELD8? | <?AMOUNT_DUE1?> |  |
| XDO_?XDOFIELD9? | <?TRX_AMOUNT1?> |  |
| XDO_GROUP_?XDOG2? | <xsl:for-each select=".//G_9"> | </xsl:for-each> |
| XDO_GROUP_?XDOG2? | <xsl:for-each select=".//G_10"> | </xsl:for-each> |
| XDO_?XDOFIELD3? | <?C_TOTAL_BALANCE?> |  |
| XDO_?XDOFIELD10? | <?C_TOTAL_BALANCE?> |  |
| XDO_SKIPROW_?REFERENCE? | <?xsl:if test="string-length(.//REFERENCE) != 0"?><xsl:value-of select=".//REFERENCE"/> |  |
| XDO_?XDOFIELD10? | <?STATEMENT_DATE?> |  |
| XDO_?XDOFIELD16? | <?.//C_TOTAL_BALANCE?> |  |
| XDO_?XDOFIELD6? | <?REMIT_BANK_ACCOUNTS?> |  |
| XDO_?XDOFIELD11? | <?BANK_NUMBER?> |  |
| XDO_?XDOFIELD12? | <?IBAN_NUMBER?> |  |
| XDO_?XDOFIELD13? | <?EFT_SWIFT_CODE?> |  |
| XDO_?XDOFIELD14? | <?BRANCH_NUMBER?> |  |
| XDO_?XDOFIELD17? | <?LEGAL?> |  |
| XDO_?XDOFIELD1? | <?PAYMENT_TERMS?> |  |
| XDO_?CUSTOMER_ACCOUNT_DESC? | <?CUSTOMER_ACCOUNT_DESC?> |  |
| XDO_?XDOFIELD18? | <xsl:choose>
<xsl:when test="CURRENCY_CODE='EUR'"><xsl:value-of select="(.//CURRENCY_CODE)"/> €</xsl:when>
<xsl:when test="CURRENCY_CODE='USD'"><xsl:value-of select="(.//CURRENCY_CODE)"/> $</xsl:when>
<xsl:when test="CURRENCY_CODE='GBP'"><xsl:value-of select="(.//CURRENCY_CODE)"/> £</xsl:when>
<xsl:when test="CURRENCY_CODE='KRW'"><xsl:value-of select="(.//CURRENCY_CODE)"/> ₩</xsl:when>
<xsl:when test="CURRENCY_CODE='ZAR'"><xsl:value-of select="(.//CURRENCY_CODE)"/> L</xsl:when>
<xsl:when test="CURRENCY_CODE='SEK'"><xsl:value-of select="(.//CURRENCY_CODE)"/> kr</xsl:when>
<xsl:when test="CURRENCY_CODE='INR'"><xsl:value-of select="(.//CURRENCY_CODE)"/> ₹</xsl:when>
<xsl:when test="CURRENCY_CODE='CHF'"><xsl:value-of select="(.//CURRENCY_CODE)"/> ₣</xsl:when>
<xsl:when test="CURRENCY_CODE='NZD'"><xsl:value-of select="(.//CURRENCY_CODE)"/> $</xsl:when>
<xsl:when test="CURRENCY_CODE='RON'"><xsl:value-of select="(.//CURRENCY_CODE)"/> lei</xsl:when>
<xsl:when test="CURRENCY_CODE='HUF'"><xsl:value-of select="(.//CURRENCY_CODE)"/> Ft</xsl:when>
<xsl:when test="CURRENCY_CODE='NOK'"><xsl:value-of select="(.//CURRENCY_CODE)"/> kr</xsl:when>
<xsl:when test="CURRENCY_CODE='AUD'"><xsl:value-of select="(.//CURRENCY_CODE)"/> $</xsl:when>
<xsl:when test="CURRENCY_CODE='ILS'"><xsl:value-of select="(.//CURRENCY_CODE)"/> ₪</xsl:when>
<xsl:when test="CURRENCY_CODE='CAD'"><xsl:value-of select="(.//CURRENCY_CODE)"/> $</xsl:when>
<xsl:when test="CURRENCY_CODE='JPY'"><xsl:value-of select="(.//CURRENCY_CODE)"/> ¥</xsl:when>
<xsl:when test="CURRENCY_CODE='HKD'"><xsl:value-of select="(.//CURRENCY_CODE)"/> $</xsl:when>
<xsl:when test="CURRENCY_CODE='CZK'"><xsl:value-of select="(.//CURRENCY_CODE)"/> Kč</xsl:when>
<xsl:when test="CURRENCY_CODE='MYR'"><xsl:value-of select="(.//CURRENCY_CODE)"/> RM</xsl:when>
<xsl:when test="CURRENCY_CODE='PLN'"><xsl:value-of select="(.//CURRENCY_CODE)"/> zł</xsl:when>
</xsl:choose> |  |
| XDO_?XDOFIELD19? | <?.//C_TOTAL_BALANCE?> |  |
| XDO_?XDOFIELD1? | <?MSC?> |  |
| XDO_?XDOFIELD3? | <?BRANCH_NUMBER?> |  |
| XDO_?XDOFIELD3? | <?BRANCH_NUMBER?> |  |