# MANUFACTURERA DE ROPA LA GACELA.xlsx

## Sheet: INVOICE

|  |  |  |  |  |  |  |  |
|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |
|  | COMMERCIAL INVOICE |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  | INVOICE NUMBER: | MRG-025071105 |  |  | INVOICE DATE: | 2026-01-22 00:00:00 |  |
|  |  |  |  |  | INVOICE NUMBER | 11638 |  |
|  |  |  |  |  |  |  |  |
|  | SHIPPER/ EXPORTER: |  |  |  | CONSIGNEE/ SHIP TO: |  |  |
|  | MANUFACTURERA DE ROPA LA GACELA SA DE CV |  |  |  | BUNZL INTERNATIONAL SERVICES, INC |  |  |
|  | 401 PUEBLA, ARBIDE |  |  |  | BUNZL R3 DALLAS STREET: 2005 VALLEY VIEW LN STE 120 |  |  |
|  | 37360,  LEON GTO, MEXICO |  |  |  | TEL  314 9975959 |  |  |
|  | TAX ID (RFC): MRG900406M6A |  |  |  | CP 75234 |  |  |
|  |  |  |  |  |  |  |  |
|  | PRODUCT DETAILS |  |  |  |  |  |  |
|  | QTY | PRODUCT DESCRIPTION |  | SIZE | PO# | UNIT PRICE | TOTAL |
|  | 610 | HD FIFA ENGLISH APRON COTTON S/MD ORG M910001 |  | S/M | 143092 | 199.5 | 121695 |
|  | 650 | HD FIFA ENGLISH APRON COTTON S/MD ORG M910002 |  | L/XL | 143092 | 199.5 | 129675 |
|  | 130 | HD FIFA SPANISH APRON COTTON S/MD ORG M910005 |  | S/M | 143092 | 199.5 | 25935 |
|  | 110 | HD FIFA SPANISH APRON COTTON S/MD ORG M910006 |  | L/XL | 143092 | 199.5 | 21945 |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  | SUBTOTAL | 299250 |
|  |  |  |  |  |  | TAX 0% | 0 |
|  | Two Hundred Ninety-Nine Thousand Two Hundred Fifty 00/100 DOLARS |  |  |  |  | TOTAL | 299250 |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  | Country of Origin: | MEXICO |  |  |  |  |  |