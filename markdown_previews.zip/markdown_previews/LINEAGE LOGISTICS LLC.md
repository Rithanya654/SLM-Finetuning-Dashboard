# LINEAGE LOGISTICS LLC.pdf

<figure>

Lineage®
®
Lineage Logistics, LLC

</figure>


1500 DAKOTA ROAD
LUVERNE, MN 56156-
,
(507)935-9050

INVOICE
AND
NON NEGOTIABLE
WAREHOUSE
RECEIPT

<!-- PageNumber="Page 1 of 1" -->

DATE 01/24/2026

** TEMPERATURE

InvBatch:

0042934

Po Number:

55915


<table>
<tr>
<th>STORAGE DATES FROM</th>
<th>TO</th>
<th>INVOICE #</th>
</tr>
<tr>
<td>01/23/2026</td>
<td>see below</td>
<td>760015245</td>
</tr>
</table>


<table>
<tr>
<td colspan="2">Received 0011821</td>
</tr>
<tr>
<td>For</td>
<td>APPLEGATE FARMS, LLC</td>
</tr>
<tr>
<td>Account</td>
<td>PO # 5382318</td>
</tr>
<tr>
<td>Of</td>
<td>750 RTE 202 STE BRIDGEWATER. NJ - US ,</td>
</tr>
</table>


DELIVERING CARRIER

SHIPPERS NO.

NOCARRIER

229933

CAR INITIAL & NO

SEAL NOS.

5353

F8954873

RECEIVED FROM

The Goods stored and serviced pursuant to this Non-Negotiable Warehouse Receipt ("Receipt") are subject to the General Terms and
Conditions found at: http://lineagelogistics.com/general-terms ("General Terms?). The General Terms are incorporated by reference and
made a part of this Receipt. The General Terms on the website supersede any pre-printed versions of General Terms and Conditions or
similar statements that may be printed on this Raraint


<table>
<tr>
<th rowspan="2">Lot Number</th>
<th rowspan="2">Quantity</th>
<th rowspan="2">Said to Be or Contain</th>
<th rowspan="2">Net Weight</th>
<th rowspan="2">Gross/Unit Weight</th>
<th colspan="2">Per Cwt or Case</th>
<th rowspan="2">TOTAL</th>
</tr>
<tr>
<th>Handling</th>
<th>Storage</th>
</tr>
<tr>
<td>62254</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>12</td>
<td>133769 Bill To 01/22/2026</td>
<td>640.40</td>
<td>669.80</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td rowspan="3">ABF GAP PK BELLY 13 SL FZ CW 01/22/2026 Supplier Prod: 12106 Ref#: PO#: 55915</td>
<td>Cube: 16.04</td>
<td>Pal:</td>
<td>1</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>HANDLING IN</td>
<td></td>
<td></td>
<td>23.4900</td>
<td></td>
<td>23.49</td>
</tr>
<tr>
<td></td>
<td></td>
<td>INITIAL STORAGE</td>
<td></td>
<td></td>
<td>19.6700</td>
<td></td>
<td>19.67</td>
</tr>
<tr>
<td></td>
<td></td>
<td>BLAST FREEZE</td>
<td>131P0</td>
<td></td>
<td>17.3100</td>
<td></td>
<td>34.62</td>
</tr>
<tr>
<td></td>
<td></td>
<td>ORDER ENTRY</td>
<td>141E0</td>
<td></td>
<td>44.2900</td>
<td></td>
<td>44.29</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Temp: 0.00 PUT IN FREEZER</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>62254</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>28</td>
<td>116561 Bill To 01/22/2026</td>
<td>1680.00</td>
<td>1730.40</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td rowspan="3">ABF GAP PK PICNIC BLC FZ CW 01/22/2026 Supplier Prod: 12053 Ref#: PO#: 55915</td>
<td>Cube: 32.09</td>
<td>Pal:</td>
<td>1</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>HANDLING IN</td>
<td></td>
<td></td>
<td>23.4900</td>
<td></td>
<td>23.49</td>
</tr>
<tr>
<td></td>
<td></td>
<td>INITIAL STORAGE</td>
<td></td>
<td></td>
<td>19.6700</td>
<td></td>
<td>19.67</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Temp: 0.00 PUT IN FREEZER</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


40

2320.40
2400.20

PLEASE MAIL REMITTANCE TO:Lineage Logistics, LLC 27626 Network Place Chicago, IL 60673
ELECTRONIC PAYMENTS JP MORGAN CHASE BANK N.A. ACCT# 223183528 ACH: ABA# 325070760
TERMS: NET CASH UPON RECEIPT OF THE INVOICE. 1 1/2% per month, may be charged for unpaid balances after the 30th of each month.

$165.23

Amount Due

You are hereby notified that the rights, duties and obligations relating to the provision of any and all services to you at the facility (other
provision of storage space, freezing and handling services) have been assigned to Lineage Logistics Services, LLC or its subsidiary (th
"Transferee") by the warehouse owner and/or operator ("Transferor"). The portion of the fees collected by Transferor related to the assi
services will be received by Transferor as agent for Transferee and will be remitted to the Transferee after collection by Transferor.

Temperature same on all lots except as noted.
BY

<!-- PageFooter="For a complete listing of our warehouse locations please visit our website at www.lineagelogistics.com" -->
<!-- PageFooter="ORIGINAL" -->
