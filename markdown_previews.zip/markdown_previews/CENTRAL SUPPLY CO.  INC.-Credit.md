# CENTRAL SUPPLY CO.  INC.-Credit.pdf

<figure>

CENTRAL SUPPLY COMPANY

</figure>


Central Supply Company - IND
8900 East 30th Street
INDIANAPOLIS IN 46219
Ph 317-898-2411 Fax 317-899-6421

BILL TO:

RT MOORE CO INC

6340 LA PAS TRAIL

INDIANAPOLIS IN 46268


# INVOICE


<table>
<tr>
<th>INVOICE DATE</th>
<th>INVOICE NUMBER</th>
</tr>
<tr>
<td>01/30/26</td>
<td>S101350807.005</td>
</tr>
<tr>
<td colspan="2">PAGE NO.</td>
</tr>
<tr>
<td colspan="2">Page 1 of 1</td>
</tr>
<tr>
<td colspan="2">PLEASE REMIT PAYMENT TO:</td>
</tr>
<tr>
<td colspan="2">CENTRAL SUPPLY COMPANY - IND PO BOX 1982</td>
</tr>
<tr>
<td colspan="2">INDIANAPOLIS IN 46206</td>
</tr>
</table>


SHIP TO:

RT MOORE COLUMBUS

8205 BUSINESS WAY

PLAIN CITY OH 43064


<table>
<tr>
<th>CUSTOMER NUMBER</th>
<th>CUSTOMER PO NUMBER</th>
<th>JOB NAME/RELEASE NUMBER</th>
<th>SALESPERSON</th>
</tr>
<tr>
<td>323</td>
<td>Ohio Returns 1/9/26</td>
<td></td>
<td>House Account</td>
</tr>
</table>


<table>
<tr>
<th>WRITER</th>
<th>SHIP VIA</th>
<th>TERMS</th>
<th>SHIP DATE</th>
<th>ORDER DATE</th>
</tr>
<tr>
<td>Nathan Koch</td>
<td>RETURN</td>
<td>2% 10th Net 30th</td>
<td>01/30/2026</td>
<td>01/09/2026</td>
</tr>
</table>


<table>
<tr>
<th>ORDER QTY</th>
<th>SHIP QTY</th>
<th>DESCRIPTION</th>
<th>UNIT PRICE</th>
<th>EXT PRICE</th>
</tr>
<tr>
<td rowspan="2">-1ea</td>
<td>-1ea</td>
<td rowspan="2">MOEN 7882SRS 1H GENTA PULLDOWN SRS SPOT RESIST STAINLESS ONE-HANDLE PULLDOWN KITCHEN FAUCET ** Nonstock Item ** Your # 0324430 G-01-03-A-02 No longer needed. Pn: 164659</td>
<td rowspan="2">281.170E</td>
<td>-281.17</td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
</table>


<table>
<tr>
<td>Subtotal</td>
<td>-281.17</td>
</tr>
<tr>
<td>S&amp;H Charges</td>
<td>0.00</td>
</tr>
<tr>
<td>Tax</td>
<td>-19.68</td>
</tr>
<tr>
<td>Amount Due</td>
<td>-300.85</td>
</tr>
</table>


Past Due invoices may be subject to 1.50% late charge
Discount
5.62

TO VIEW & PAY ONLINE GO TO:

https://www.centralsupplycompany.com/

AND CLICK BILLTRUST INVOICE GATEWAY
