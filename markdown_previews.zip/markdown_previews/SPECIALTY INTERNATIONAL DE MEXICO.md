# SPECIALTY INTERNATIONAL DE MEXICO.pdf

<figure>

SIM

Specialty
INTERNATIONAL
DE MEXICO S.A. DE C.V.

</figure>


SPECIALTY INTERNATIONAL DE MEXICO
Avenida Industria de Autopartes No 100, Parque Industrial Stiva
Ciudad Apodaca , Nuevo León , C.P .: 66626
SIM0302216S2
Regimen Fiscal : 601 General de Ley Personas Morales
Lugar de Expedicion: 66626

FACTURA

83673

FECHA

2026-01-29T09:40:07

CLIENTE
VERTIVCORP

VERTIV CORPORATION
N Cleveland Avenue 505
WESTERVILLE C.P .: 43082
, Ohio, Estados Unidos (los)
R.F.C .: XEXX010101000


<table>
<tr>
<td>Tipo de Comprobante :</td>
<td>I Ingreso</td>
</tr>
<tr>
<td>Uso de CFDi :</td>
<td>S01 Sin efectos fiscales</td>
</tr>
<tr>
<td>Forma de Pago :</td>
<td>99 Por definir</td>
</tr>
<tr>
<td>Metodo de Pago :</td>
<td>PPD Pago en parcialidades o diferido</td>
</tr>
<tr>
<td>Pedidos:</td>
<td>R:16667</td>
</tr>
<tr>
<td>Orden de Compra:</td>
<td>130399642</td>
</tr>
</table>


<table>
<tr>
<th>Cantidad</th>
<th>Unidad</th>
<th>Clave SAT</th>
<th>Clave Prod</th>
<th>Descripción</th>
<th>Valor unitario</th>
<th>Importe</th>
</tr>
<tr>
<td>1.00000</td>
<td>H87</td>
<td>31261503</td>
<td>563656</td>
<td>BRKT,SEISMIC,BOTTOM,REAR</td>
<td>$49.11</td>
<td>$49.11</td>
</tr>
</table>


Importe con Letra
cuarenta y nueve Dólares 11/100 USD.

Entregado a IMMEX: 836-2006 por parte
IMMEX 3377-2006 Operación que se efectúa en los
términos del Artículo 29 Fracción I LIVA, Regla 5.2.4 Fracción II, de las Reglas Generales de Comercio
Exterior vigentes.

Tipo Relación: -


<table>
<tr>
<td colspan="2">SubTotal : $49.11</td>
</tr>
<tr>
<td>IVA 16% :</td>
<td>$0.00</td>
</tr>
<tr>
<td colspan="2">Total : $49.11</td>
</tr>
</table>


Este documento es una representación impresa de un CFDI
Serie del Certificado del emisor: 00001000000703854983

Folio Fiscal: 36CE8B7B-2713-4313-8AE0-F786F3640611
No. de serie del Certificado del SAT: 00001000000709182898
Fecha y hora de certificación: 2026-01-29T09:40:10


# Sello digital del CFDI

hN76MD/vslbTre2BJKIPL+xvhqWBwSiveqL+KHO4nH2dr8fw71FlqRzxoeLb7au5UHiVpz0xj2iZBmCWX5TO4TnYAbBsy8IE2EmwvNc3AguYLOgdeTMCRdE8j6WSRXmXn0zztFKKRbf6tpahoAf0pCL7uPx
fM4xZOEEln3Prc3XJfc8Jfn2j0wIDCuTpXSWKUQsTgMzU2OSMyOoZ5ofFKhE724/dg5eWM6Bq7yoOF8TbQu7E978cGOJOU6qUqIP885aYzmVgTYoLP2ASHyPVIHsOw6WOUGbiL49YgBj9YZH3VP64gtVVv
WvPfDqnCCspyttirqGqMjFfg1G2KOOYg ==


# Sello del SAT

gDKRgbBKP8BI0UEcSW5durvQGhIjLSErDWQu4+iRgmY3icBRo4wI/B4mmNEkwgP5oYTIR/bIyDLV4KtaZXGy7XF0JZNtzpUE4r62n3SF9pnZNL1cD3OeshW0AUASfK0Gf9Uz87qggXRWq8ydsDH4kFFQk
PTQeČj34Qv1XzIL7ibrCGM2naMxFQgrHXsXgJhiOBoi7K2nPryzVxtX+FO0oF8sG4VUcwMuWaM5zhQ+P9TEWfadr1+69TxZIcuAekG3bAr5iWcOViiwSFRGbyGPb9QQOIXUMLONJ+FM9SMW8m8eBYgla1
ED6HRNCCj35FI8cRAECLv6TGiG/zNBmenXFQ ==


# Cadena original del complemento del certificación digital del SAT

|1.1|36CE8B7B-2713-4313-8AE0-F786F3640611|2026-01-29T09:40:10|MAS0810247C0|hN76MD/vslbTre2BJKIPL+xvhqWBwSiveqL+KHO4nH2dr8fw71FlqRzxoeLb7au5UHiVpz0xj2iZBmCWX5
TO4TnYAbBsy8IE2EmwvNc3AguYLOgdeTMCRdE8j6WSRXmXn0zztFKKRbf6tpahoAf0pCL7uPxfM4xZOEEIn3Prc3XJfc8Jfn2j0wIDCuTpXSWKUQsTgMzU2OSMyOoZ5ofFKhE724/dg5eWM6Bq7yoOF8TbQu7E
978cGOJOU6qUqIP885aYzmVgTYoLP2ASHyPVIHsOw6WOUGbiL49YgBj9YZH3VP64gtVVvWvPfDqnCCspyttirqGqMjFfg1G2KOOYg == |00001000000709182898||

Versión del comprobante:

4.0

Hoja

1
