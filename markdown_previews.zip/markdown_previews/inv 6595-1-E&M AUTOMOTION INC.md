# inv 6595-1-E&M AUTOMOTION INC.xlsx

## Sheet: Sheet1

| E&M Automotion Inc. |  |  |  |  |  | INVOICE |  |
|---|---|---|---|---|---|---|---|
| P.O Box 372, 28 Grea Street |  |  |  |  |  |  |  |
| Notre-Dame de Lourdes, |  |  |  |  |  |  |  |
| Manitoba, Canada |  |  |  |  |  | INVOICE #: | 6595-1 |
| R0G1M0 |  |  |  |  |  | DATE: | 2025-11-03 00:00:00 |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
| SOLD TO: |  |  |  |  |  | PURCHASE ORDER |  |
|  |  |  |  |  |  |  |  |
| Carfair Composites Inc. |  |  |  |  |  |  |  |
| 692 Mission Street, |  |  |  |  |  | 60017832 |  |
| Winnipeg, Manitoba |  |  |  |  |  |  |  |
| R2J0A3 |  |  |  |  |  |  |  |
|  |  |  |  | GST# R870984622 |  |  |  |
| NET 60 DAYS            2%  MONTHLY LATE FEE |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
| ITEM # | QUANTITY | UNIT | DESCRIPTION |  | LINE | UNIT PRICE | AMOUNT |
|  |  |  |  |  |  |  |  |
| 955261 | 2 |  | RETAINER-FENDER SHORT |  | Line 7(1) | 16 | 32 |
|  |  |  | J3500 |  |  |  |  |
|  |  |  |  |  |  |  |  |
| 955262 | 1 |  | RETAINER-FENDER LONG RH |  | Line 8(1) | 51 | 51 |
|  |  |  | J3500 |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  | SUBTOTAL | 83 |
|  |  |  |  |  |  |  |  |
|  |  |  | PST# 222215-9 |  |  | PST 7% |  |
|  |  |  |  |  |  | GST 5% | 4.15 |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  | TOTAL | 87.15 |