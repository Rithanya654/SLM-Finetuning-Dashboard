# Ameren Invoice 2-2-26.pdf

<figure>

Ameren
MISSOURI

</figure>


Pay by phone: 1.866.268.3729

Pay by mail: PO Box 88068, Chicago, IL 60680-1068

Pay online or manage your account: AmerenMissouri.com

Customer Service: 1.877.426.3736

PO: 40109364


<figure>

FOCUSED ENERGY.
For Life.

</figure>


Account Number 0486102026

Customer Name
CONCRETE STRATEGIES
Service Address
506 WILLOW, TEMP
CAPE GIRARDEAU, MO 63703

Current Detail for Statement 02/02/2026


<table>
<tr>
<td>Total Electric Charges</td>
<td>$273.64</td>
</tr>
<tr>
<td>Total Amount Due</td>
<td>$273.64</td>
</tr>
</table>


<table>
<tr>
<td>AMOUNT DUE</td>
<td>$273.64</td>
</tr>
<tr>
<td>Due Date</td>
<td>02/24/2026</td>
</tr>
<tr>
<td>Amount After Due Date</td>
<td>$276.52</td>
</tr>
<tr>
<td>Previous Statement</td>
<td>$244.86</td>
</tr>
<tr>
<td>Total Payments</td>
<td>$244.86</td>
</tr>
<tr>
<td>Payment Received. Thank You.</td>
<td></td>
</tr>
</table>


# Electric Usage History


## Electric Usage in Kilowatt Hours (kWh)


<figure>

3000

2500

2000

1500

1000

500

0

JAN

FEB

MAR

APR

MAY
66ºF

JUN
76ºF

JUL
81ºF

AUG
77ºF

SEP
71ºF

OCT

NOV
50ºF

DEC

JAN
32ºF

63ºF

38ºF

</figure>


Average Monthly Temperature (ºF)


## Electric Usage Summary (kWh)

This shows how much electric energy you've used at this
address so far this year.


<figure>

2025

7,617 kWh

2026

4,944 kWh

</figure>


<!-- PageFooter="02340 2461449 004654 009307 0001/0002" -->

13073

Electric Service Details

Service from 12/30/2025 - 01/29/2026 (30 days)

Electric Meter Read


<table>
<tr>
<th>METER NUMBER</th>
<th>SERVICE FROM - TO</th>
<th>NO. DAYS</th>
<th>USAGE TYPE</th>
<th>READING TYPE</th>
<th>CURRENT READING</th>
<th>PREVIOUS READING</th>
<th>READING DIFFERENCE</th>
<th>MULTIPLIER</th>
<th>USAGE</th>
</tr>
<tr>
<td>96011324</td>
<td>12/30 - 01/29</td>
<td>30</td>
<td>Total kWh</td>
<td>Actual</td>
<td>12561.0000</td>
<td>9899.0000</td>
<td>2662.0000</td>
<td>1.0000</td>
<td>2662.0000</td>
</tr>
</table>


<!-- PageNumber="Page 1 of 4" -->

» See next page for service details.


<figure>

Ameren
MISSOURI

</figure>


☐
Check if you have address changes on back.

Keep this portion for your records.

Please return this portion with your payment.


<table>
<tr>
<th>Amount Due</th>
<th>Due Date</th>
</tr>
<tr>
<td>$273.64</td>
<td>February 24, 2026</td>
</tr>
<tr>
<td>Delinquent Amount After Due Date</td>
<td>Account Number</td>
</tr>
<tr>
<td>$276.52</td>
<td>0486102026</td>
</tr>
<tr>
<td>Amount Enclosed $</td>
<td></td>
</tr>
</table>


\>002340 2461449 0006 092139 10Z
CONCRETE STRATEGIES
8640 EVANS AVE
SAINT LOUIS, MO 63134-2903

AMEREN MISSOURI
P.O. BOX 88068
CHICAGO, IL 60680-1068

<!-- PageFooter="40633000 0004861020206 000000273640 000000273640" -->
<!-- PageBreak -->


<figure>

Ameren
MISSOURI

</figure>


Pay by phone: 1.866.268.3729
Pay by mail: PO Box 88068, Chicago, IL 60680-1068

Pay online or manage your account: AmerenMissouri.com
Customer Service: 1.877.426.3736


<figure>

<!-- PageHeader="FOCUSED ENERGY. For life." -->

</figure>


Electric Service Details (Continued)

Usage Summary


<table>
<tr>
<td>Total kWh</td>
<td>2662.0000</td>
<td>Non-Summer kWh</td>
<td>2662.0000</td>
</tr>
<tr>
<td>Winter Base kWh</td>
<td>1168.0000</td>
<td>Current Base kWh</td>
<td>1168.0000</td>
</tr>
<tr>
<td>Winter Cur Base kWh</td>
<td>1168.0000</td>
<td>Seasonal kWh</td>
<td>1494.0000</td>
</tr>
<tr>
<td>Winter Seasonal kWh</td>
<td>1494.0000</td>
<td></td>
<td></td>
</tr>
</table>


Rate 2M Sm Gen Svc - 1 Ph - No Dmd


<table>
<tr>
<th>DESCRIPTION</th>
<th>USAGE</th>
<th>UNIT</th>
<th></th>
<th>RATE</th>
<th>CHARGE</th>
</tr>
<tr>
<td>Base Energy Charge</td>
<td>1,168.00</td>
<td>kWh</td>
<td>@</td>
<td>$ 0.10050000</td>
<td>$117.38</td>
</tr>
<tr>
<td>Seasonal Energy Charge</td>
<td>1,494.00</td>
<td>kWh</td>
<td>@</td>
<td>$ 0.05810000</td>
<td>$86.80</td>
</tr>
<tr>
<td>Customer Charge</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>$ 13.72</td>
</tr>
<tr>
<td>Fuel Adjustment Charge</td>
<td>2,662.00</td>
<td>kWh</td>
<td>@</td>
<td>$ 0.00330000</td>
<td>$8.78</td>
</tr>
<tr>
<td>Energy Efficiency Investment Charge</td>
<td>2,662.00</td>
<td>kWh</td>
<td>@</td>
<td>$ 0.00281900</td>
<td>$7.50</td>
</tr>
<tr>
<td>Renewable Energy Adjustment</td>
<td>2,662.00</td>
<td>kWh</td>
<td>@</td>
<td>$ 0.00133000</td>
<td>$3.54</td>
</tr>
<tr>
<td>Rush Island Retirement Cost</td>
<td>2,662.00</td>
<td>kWh</td>
<td>@</td>
<td>$ 0.00108000</td>
<td>$2.87</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total Service Amount</td>
<td>$240.59</td>
</tr>
<tr>
<td>DESCRIPTION</td>
<td>USAGE</td>
<td>UNIT</td>
<td></td>
<td>RATE</td>
<td>CHARGE</td>
</tr>
<tr>
<td>Missouri State Sales Tax</td>
<td>$240.59</td>
<td></td>
<td>@</td>
<td>$ 0.04225000</td>
<td>$ 10.16</td>
</tr>
<tr>
<td>Missouri Local Sales Tax</td>
<td>$240.59</td>
<td></td>
<td>@</td>
<td>$ 0.04250000</td>
<td>$ 10.23</td>
</tr>
<tr>
<td>Cape Gir-Cape Gir Co Municipal Charge - Service</td>
<td>$240.59</td>
<td></td>
<td>@</td>
<td>$ 0.05263000</td>
<td>$12.66</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total Tax Related Charges</td>
<td>$33.05</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total Electric Charges</td>
<td>$273.64</td>
</tr>
</table>


Payments Since Previous Statement


<table>
<tr>
<th>DATE RECEIVED</th>
<th>AMOUNT</th>
</tr>
<tr>
<td>January 20, 2026</td>
<td>$244.86</td>
</tr>
</table>


Questions? Contact Ameren Missouri at 1.877.426.3736 or visit AmerenMissouri.com.

<!-- PageNumber="Page 2 of 4" -->

Address Changes or Corrections

Name

Address

City, State, Zip
Phone Number

AmerenMissouri.com/WaysToPay


<figure>

ONLINE
E-CHECK

PHONE
866.268.3729

IN PERSON
FIND A PAY STATION AT
AMERENMISSOURI.COM/
PAYSTATION

$

ONLINE
CREDIT CARD

MAIL
STUB & CHECK

</figure>


<!-- PageBreak -->


<figure>

Ameren
MISSOURI

</figure>


<!-- PageHeader="Pay by phone: 1.866.268.3729" -->

Pay by mail: PO Box 88068, Chicago, IL 60680-1068

Pay online or manage your account: AmerenMissouri.com

Customer Service: 1.877.426.3736


<table>
<tr>
<td>AMOUNT DUE</td>
<td>$273.64</td>
</tr>
<tr>
<td>Due Date</td>
<td>02/24/2026</td>
</tr>
<tr>
<td>Account Number</td>
<td>0486102026</td>
</tr>
<tr>
<td>Service Address</td>
<td>506 WILLOW, TEMP</td>
</tr>
</table>


### Account Messages

A late payment charge of 1% will be added for any unpaid balance on all accounts after the due date.

Renewable Energy Standard Rate Adjustment Mechanism: Your electric rate includes costs and certain benefits associated with
complying with Renewable Energy Standard incurred by Ameren Missouri. For more information go to
AmerenMissouri.com/Statement.

Summer Electric Rates - June through September; Winter Electric Rates - October through May.

Please note: If your billing period for this statement spans both Summer and Winter seasons, you will see prorated charges that
reflect the different rates for each season.


<figure>
</figure>


Rush Island Retirement Cost

Ameren Missouri is acting as the servicer for this Public Service Commission-approved charge for an assignee, who owns the
rights to the securitized utility tariff charges related to the Rush Island Energy Center retirement. Based on projections, customers
are expected to save about $85 million over a 15-year period versus standard rates.

Ameren Missouri's Community Solar program enables your home or small business to support renewable energy in Missouri
through an easy monthly subscription. Learn more at AmerenMissouri.com/CommunitySolar.
Auto Pay Makes Paying Bills Easier. To enroll, go to AmerenMissouri.com or call 1.800.552.7583 to request an enrollment form.


<figure>

$

START 2026
With Energy Savings.

Use the BizSavers® program to save money and
energy. Upgrade to energy-efficient equipment
and get a cash incentive - it's that easy.
AmerenMissouri.com/BizSavers

Enroll in Budget Billing ROLLOVER to spread
out your energy costs over 12 months.
Roll over any difference to the next year.
AmerenMissouri.com/Budget

MAKE YOUR YEAR
PREDICTABLE

</figure>


<!-- PageFooter="02340 2461449 004655 009309 0002/0002" -->
<!-- PageFooter="Questions? Contact Ameren Missouri at 1.877.426.3736 or visit AmerenMissouri.com." -->
<!-- PageNumber="Page 3 of 4" -->
<!-- PageBreak -->


<figure>

Ameren
MISSOURI

</figure>


Pay by phone: 1.866.268.3729
Pay by mail: PO Box 88068, Chicago, IL 60680-1068

Pay online or manage your account: AmerenMissouri.com
Customer Service: 1.877.426.3736


<figure>

<!-- PageHeader="FOCUSED ENERGY. For life." -->

</figure>


Page Left Blank Intentionally

<!-- PageFooter="Questions? Contact Ameren Missouri at 1.877.426.3736 or visit AmerenMissouri.com." -->
<!-- PageNumber="Page 4 of 4" -->
