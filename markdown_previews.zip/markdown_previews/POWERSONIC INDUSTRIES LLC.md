# POWERSONIC INDUSTRIES LLC.PDF

<figure>

4

</figure>


Powersonic Industries LLC
2344 Kemper Ln, #6506
Cincinnati, Ohio 45206
United States
Phone: 513-429-2329 Fax: 513-510-4329


# INVOICE

Invoice Number: IN060538

Invoice Date: 1/31/2026

Order Number: SO020005

Pack List Number: PL061044

BILL TO ADDRESS
Vertiv Corporation
PO Box 8629,
St Louis, MO 63126-8629
USA

SHIP TO ADDRESS

VERTIV CORPORATION
AV. LUIS GUADALUPE FERNANDEZ TALAMANTE
#3502, PARQUE FINSA
SANTA CATARINA 66380
MX - MEXICO


<table>
<tr>
<th>CUSTOMER ID</th>
<th>CUSTOMER PO NUMBER</th>
<th>PAYMENT TERMS</th>
<th>FREIGHT TERMS</th>
</tr>
<tr>
<td>VERCOR</td>
<td>130386116</td>
<td>Net 90</td>
<td>Freight: Prepaid</td>
</tr>
<tr>
<th>SALESPERSON</th>
<th>SHIPPING METHOD</th>
<th>SHIPMENT DATE</th>
<th>FREE ON BOARD</th>
</tr>
<tr>
<td>ZR</td>
<td>Our Truck</td>
<td>1/31/2026</td>
<td>FOB Origin</td>
</tr>
</table>


<table>
<tr>
<th>L.No</th>
<th>PART NUMBER</th>
<th>DESCRIPTION</th>
<th>QTY</th>
<th>UOM</th>
<th>PRICE</th>
<th>EXTENSION</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1</td>
<td>VERTIV-10079108</td>
<td>XDU1350 CDU WD 65KA 10079108 Customer PO Line # : 3</td>
<td>11</td>
<td>EA</td>
<td>$138.57</td>
<td>$1,524.27</td>
</tr>
<tr>
<td colspan="2" rowspan="2"></td>
<td></td>
<td>SUB</td>
<td>TOTAL:</td>
<td colspan="2" rowspan="2">$1,524.27 USD $1,524.27 USD</td>
</tr>
<tr>
<td></td>
<td colspan="2">TOTAL AMOUNT DUE:</td>
</tr>
</table>


*** NOTE TO CUSTOMER : PLEASE NOTE THE CHANGES ***
(A) BILLING ADDRESS

Should there be any questions or concerns regarding this invoice or any of our products,
please do not hesitate to contact our office at 513-429-2329.

POWERsonic Industries
Canada | United States | China | India | Europe | Mexico
Powerful innovations and solutions delivered at high speeds.
