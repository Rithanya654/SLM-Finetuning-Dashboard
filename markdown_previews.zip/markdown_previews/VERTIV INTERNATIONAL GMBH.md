# VERTIV INTERNATIONAL GMBH.pdf

<!-- PageNumber="Page 1 of 1" -->


# INVOICE

INVOICE NUMBER

26000953


<table>
<tr>
<td>Invoice date</td>
<td>30-JAN-26</td>
</tr>
<tr>
<td>Sales order number</td>
<td>77362590</td>
</tr>
<tr>
<td>Sales order date</td>
<td>28-JAN-26</td>
</tr>
<tr>
<td>Customer PO number</td>
<td>Mattia Giraldo , 28.1. 392PADO</td>
</tr>
</table>


<figure>

VERTIV.

</figure>


<table>
<tr>
<th>SHIP TO</th>
<th colspan="2">35349001</th>
<th>DOCUMENT TO</th>
<th></th>
<th>155389438</th>
</tr>
<tr>
<td colspan="3">VERTIV ITALIA SRL VIA LEONARDO DA VINCI 16-18 35028 PIOVE DI SACCO Italy</td>
<td colspan="2">VERTIV ITALIA SRL VIA LEONARDO DA VINCI 16</td>
<td></td>
</tr>
<tr>
<td>BILL TO</td>
<td colspan="2">35210237</td>
<td colspan="2">VENETO</td>
<td></td>
</tr>
<tr>
<td colspan="2" rowspan="2">VERTIV ITALIA SRL VIA LEONARDO DA VINCI 16</td>
<td rowspan="2"></td>
<td colspan="2" rowspan="2">35028 PIOVE DI SACCO Italy</td>
<td></td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td>VENETO</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
</tr>
<tr>
<td>35028 PIOVE DI SACCO</td>
<td></td>
<td></td>
<td colspan="2" rowspan="2"></td>
<td></td>
</tr>
<tr>
<td>Italy</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Customer VAT number:</td>
<td>IT05688630283</td>
<td></td>
<td colspan="2"></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
</tr>
<tr>
<td>Salesrep ref</td>
<td>Fordinalova, Lubica</td>
<td></td>
<td colspan="2">Customer service ref. JOBS_ICVIG_MAIN</td>
<td></td>
</tr>
<tr>
<td>E-mail</td>
<td>Lubica.Fordinalova@vertiv.com</td>
<td></td>
<td colspan="2">E-mail</td>
<td></td>
</tr>
<tr>
<td>Telephone</td>
<td colspan="2"></td>
<td colspan="2">Telephone</td>
<td></td>
</tr>
<tr>
<td>PAYMENT TERMS</td>
<td colspan="2"></td>
<td colspan="2">SHIPPING TERMS</td>
<td></td>
</tr>
<tr>
<td>Payment terms Payment method</td>
<td colspan="2" rowspan="2">30gg d.f. 01-MAR-26</td>
<td colspan="2" rowspan="2">Incoterms /Location Inco2020: CPT/Piove di Sacco (PD) Mode of transportati Carrier Service Levels Delivery date: Ship From Location Vertiv S.r.l. Piove di Sacco (PD), Italy</td>
<td rowspan="2"></td>
</tr>
<tr>
<td>Due date / Amount Due</td>
</tr>
</table>


<table>
<tr>
<th>LINE</th>
<th>ITEM CODE/DESCRIPTION</th>
<th>DELIVERY NUMBER/DATE</th>
<th>UOM</th>
<th>QUANTITY</th>
<th>UNIT PRICE</th>
<th>VAT</th>
<th>TOTAL (EUR)</th>
</tr>
<tr>
<td rowspan="2">1.1</td>
<td>10067496 MICROCHIP SST39SF040-70- 4C-PHE Commodity code/custom tariff:85423219 Country of origin: Taiwan Unit net weight:0.20 KG Inversione Contabile art. 7-bis e art. 17, co. 2 DPR 633/72 / Reverse Charge art. 194 Directive 2006/112</td>
<td>13426633/ 30-GEN-26</td>
<td>Each</td>
<td>10</td>
<td>120,16</td>
<td>0,00</td>
<td>1.201,60</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>COMMODITY CODE</th>
<th>NET WEIGHT TOTAL</th>
<th>QUANTITY TOTAL</th>
<th>LINE AMOUNT TOTAL</th>
</tr>
<tr>
<td>85423219</td>
<td>2.00 KG</td>
<td>10</td>
<td>1.201,60</td>
</tr>
</table>


International Trade Compliance - Order Acceptance / Contract Statement - ITCE 30

The fulfilment of the present order/contract is subject to all current applicable import; export control and sanctions laws, regulations, orders and requirements, including those of the United States
where applicable. However, such laws and regulations may be amended from time to time including during the processing of an order/contract. If Vertiv International GmbH (the Company) should
fail to receive any necessary or advisable licenses, authorisations or approvals, even arising from inaction by any relevant government authority, or if any such licenses, authorisations or approvals
are denied or revoked, or if there is a change in any applicable laws, regulations, orders or requirements that would prohibit the Company from fulfilling any order, or would in the reasonable
judgement of the Company otherwise expose the Company to a risk of liability under such laws, regulations, orders or requirements if it fulfilled the order, the Company shall be relieved without
penalty of all obligations under the present order/contract.

No. of packages

1


<table>
<tr>
<td>Subject to VAT @ 0%</td>
<td>0,00</td>
</tr>
<tr>
<td>Not subject to VAT</td>
<td>1.201,60</td>
</tr>
<tr>
<td>VAT Amount</td>
<td>0,00</td>
</tr>
<tr>
<td>TOTAL AMOUNT EUR</td>
<td>1.201,60</td>
</tr>
</table>


<table>
<tr>
<td></td>
<td colspan="2">REGISTERED OFFICE</td>
</tr>
<tr>
<td>Vertiv International GmbH Victor-von-Bruns Str. 21 8212 Neuhausen am Rheinfall Switzerland</td>
<td></td>
<td>Commercial register No: CHE-293.902.351 EORI Code: ITCH0000000000787 Selling VAT ID: IT05663350287 VAT Representative: Vertiv Srl IT00230510281</td>
</tr>
<tr>
<td></td>
<td>BANK DETAILS</td>
<td></td>
</tr>
<tr>
<td>Bank: CITIBANK</td>
<td>IBAN: GB21CITI18500815232813</td>
<td>SWIFT/BIC: CITIGB2LXXX</td>
</tr>
<tr>
<td></td>
<td colspan="2">reference to Terms and Conditions</td>
</tr>
</table>


<!-- PageFooter="XXARRSLSINV_INTER_HUBCH" -->
