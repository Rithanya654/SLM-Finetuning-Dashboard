# WHITE CAP LP.pdf

<figure>

WHITE CAP®
®

</figure>


White Cap, L.P.
PO Box 4944
Orlando, FL 32802-4944

ACCOUNT # 64480000

CONCRETE STRATEGIES
PO BOX 270209
SAINT LOUIS MO 63127

BRANCH ADDRESS
785 - SOUTH BEND IN (CW)

(574) 231-9000
910 W. IRELAND RD.
SOUTH BEND IN 46614
ST. JOSEPH


# INVOICE

INVOICE NUMBER

50035241817

INVOICE DATE

02/02/2026

CUSTOMER PO NUMBER

40109036

TO VIEW AND PAY ONLINE GO TO:

http://whitecap.billtrust.com

ENROLLMENT TOKEN:

ZXF FGZ MXK


<table>
<tr>
<th rowspan="2">TERRITORY: SHIP TO: 10004920698</th>
<th></th>
</tr>
<tr>
<th>MAKE CHECKS PAYABLE TO:</th>
</tr>
<tr>
<td>AMAZON NEW CARLISILE 55250 WALNUT RD</td>
<td>White Cap, L.P. P.O. Box 4852 ORLANDO,FL 32802-4852</td>
</tr>
</table>


NEW CARLISLE IN 46552


<table>
<tr>
<th>ORDER DATE</th>
<th>ORDER NO.</th>
<th>ORDERED BY</th>
<th>ACCOUNT MANAGER</th>
<th>TAKEN BY</th>
</tr>
<tr>
<td>02/02/2026</td>
<td>70785509</td>
<td>JAMES SCANTLIN</td>
<td>MCFATRIDGE, SCOTT</td>
<td>HUFFER, BENJAMIN</td>
</tr>
</table>


BRANCH

ACCT JOB NO.

TERMS

SHIP VIA / ROUTING

CUSTOMER JOB NO.


<table>
<tr>
<th colspan="3">785 10004920698 NET 30 DAYS</th>
<th></th>
<th colspan="5">0. WILL CALL AMAZON NEW</th>
</tr>
<tr>
<th>LINE</th>
<th>PART NUMBER</th>
<th>DESCRIPTION</th>
<th>QTY ORD</th>
<th>UNIT PRICE</th>
<th>QTY BKO</th>
<th>QTY SHP</th>
<th>EXTENDED PRICE</th>
<th>TAX AMT</th>
</tr>
<tr>
<td>0</td>
<td>HDRDESC</td>
<td></td>
<td>1</td>
<td>0</td>
<td>0</td>
<td>1</td>
<td>0.00</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>DELIVERY TAG#: 38727238</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>2</td>
<td>257RX101</td>
<td>1"X3/4" RX101 WATERSTOP 100'/BOX 6 ROLLS CETCO</td>
<td>4</td>
<td>315.55 BOX</td>
<td>0</td>
<td>4</td>
<td>1,262.20</td>
<td>88.35</td>
</tr>
<tr>
<td>3</td>
<td>505VC12</td>
<td>1/2"X10' TOP VOID CAP SOLD/FOOT</td>
<td>1000</td>
<td>0.58 FT</td>
<td>0</td>
<td>1000</td>
<td>580.00</td>
<td>40.60</td>
</tr>
<tr>
<td>4</td>
<td>7073GCS10BK</td>
<td>9X3" 10LB T25 CONSTRUCTIONN SCREW</td>
<td>1</td>
<td>60.11 PL</td>
<td>0</td>
<td>1</td>
<td>60.11</td>
<td>4.21</td>
</tr>
<tr>
<td></td>
<td></td>
<td>YELLOW ZINC GRIP-RITE</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


The White Cap Family of Brands includes All-Tex Waterproofing Solutions, Crimson Steel Supply, Harmac, Kenseal, National Ladder & Scaffold,
Marvel Building & Masonry Supply, MASONPRO, Site Supply, Williams Equipment & Supply, Valley Supply Co, and Diamond Tool. Learn more
at About. WhiteCap.com

Pay your invoices online by visiting: https://whitecap.billtrust.com
Sales Tax Exemption Questions or Certificates: TaxExemptCredit@whitecap.com

THESE ITEMS ARE CONTROLLED BY THE U.S. GOVERNMENT AND AUTHORIZED FOR EXPORT ONLY TO THE COUNTRY OF
ULTIMATE DESTINATION FOR USE BY THE ULTIMATE CONSIGNEE OR END-USER(S) HEREIN IDENTIFIED. THEY MAY NOT BE
RESOLD, TRANSFERRED OR OTHERWISE DISPOSED OF TO ANY OTHER COUNTRY OR ANY PERSON OTHER THAN THE
AUTHORIZED ULTIMATE CONSIGNEE OR END-USER(S), EITHER IN THEIR ORIGINAL FORM OR AFTER BEING INCORPORATED INTO

For questions regarding this invoice please call (844) 418-8341

NO REFUNDS OR EXCHANGES ON NON STOCK MERCHANDISE
Visit https://www.whitecap.com/terms/terms-conditions-of-sale-terms to view
complete terms and conditions.

RECEIVED BY: JAMES

SIGNATURE COPY ON FILE


<table>
<tr>
<td>TOTAL GROSS</td>
<td>1,902.31</td>
</tr>
<tr>
<td>TOTAL TAX</td>
<td>133.16</td>
</tr>
<tr>
<td>TOTAL SHIPPING AND HANDLING</td>
<td>0.00</td>
</tr>
<tr>
<td>TOTAL INVOICE</td>
<td>2,035.47</td>
</tr>
</table>


<!-- PageNumber="Page 1 of 1" -->
