# DISENOS METALICOS DEL NORTE S DE CV.pdf

<figure>

DIMET

</figure>


# DISEÑOS METALICOS DEL NORTE S.A. DE C.V. RFC: DMN020730TV6

Factura


<table>
<tr>
<th>Fecha</th>
<th>Folio</th>
</tr>
<tr>
<td>19/ene./2026 17:30:05</td>
<td>DIM70709</td>
</tr>
</table>


MATRIZ PLANTA 1
BLVD. VITO ALESSIO ROBLES 5900
ZONA INDUSTRIAL
SALTILLO, COAHUILA CP: 25107

ESTABLECIMIENTO PLANTA II
BLVD. NAZARIO ORTIZ GARZA Nº5491
COLONIA VIRREYES INDUSTRIAL
SALTILLO COAHUILA, C.P 25225

ESTABLECIMIENTO PLANTA ARTEAGA
CALLE DR GONZALO VALDEZ Nº640
COLONIA SAN ISIDRO
ARTEAGA COAHUILA, C.P. 25353


## Cliente

VERTIV CORPORATION.
505 N Cleveland Avenue
WESTERVILLE, OH CP: 43082
RFC: XEXX010101000

Domicilio fiscal: 25107
Régimen fiscal: 616/Sin obligaciones fiscales


<table>
<tr>
<th>Orden de compra</th>
<th>Condiciones</th>
<th>Vendedor</th>
<th>Vía de embarque</th>
</tr>
<tr>
<td>130286877</td>
<td>CREDITO 90 DIAS</td>
<td>ING. ALEJANDRO MONTALVO</td>
<td>DIMET</td>
</tr>
</table>


<table>
<tr>
<th>Artículo</th>
<th>Nombre</th>
<th>U.med.</th>
<th>Unidades</th>
<th>Precio</th>
<th>Descto.</th>
<th>Importe</th>
</tr>
<tr>
<td>60068797P1</td>
<td>60068797P1 31281507/Componentes de acero al carbono estampados</td>
<td>Pieza H87/Pieza</td>
<td>1</td>
<td>89.34</td>
<td></td>
<td>89.34</td>
</tr>
</table>


ITEM 1
Entrega
Vertiv Monterrey
Av. Luis Guadalupe Fernandez Talamantes 3502
C.P. 66380
Santa Catarina, N.L

Línea: Cepeda
Op. Edgar Cepeda

Cadena original del complemento de certificación digital del SAT:

||1.1|064E79B4-CB91-0242-963C-4352B81A6C56|2026-01-19T17:32:09|SCD110105654|LW7DBvul7mETgEd/YJO/V7pjWxiON/oaNDDa]wu5YU/Qh4KaDDgd9hHSqRY0048ALqSrRm9S3U5C3n0/kdAOMbhqcW9/i2Twy2P857pJEGZYfxstT2ORO/y/ff2ulSXw
9qZyvkVEiFF0Sbm++yTqPO/pyv/UQCcpsbEOOyA9xAUh+AOEEkDnhPalid9pD1vk8xFkDZcnxszo097LUxFhNRsf94TihPJDIVrOnHQXYZ4g6wPoIIAQLEQ/K2B00VpaxRHCNsaWnSXQA4Yv2bI7VM89KZDtebf/1KUiXGNQCJIr1DCqgMMLGhkMmqxKkJGyZbo+rR6
QRSkoEaurDFIYhA == |00001000000702501858||


### Sello digital del CFDI:

LW7DBvul7mETgEd/YJO/V7pjWxiON/oaNDDaJwu5YU/Qh4KaDDgd9hHSqRYoO48ALqSrRm9S3U5C3n0/kdAOMbhqcW9/i2Twy2P857pJEGZYfxstT2ORO/y/ff2ulSXw9qZyvkVEiFF0Sbm++yTqPO/pyv/UQCcpsbEOOyA9xAUh+AOEEkDnhPalid9pD1vk8xFkDZcn
xszo097LUxFhNRsf94TihPJDIVrOnHQXYZ4g6wPoIIAQLEQ/K2B00VpaxRHCNsaWnSXQA4Yv2bI7VM89KZDtebf/1KUiXGNQCJIr1DCqgMMLGhkMmqxKkJGyZbo+rR6QRSkoEaurDFIYhA ==


### Sello digital del SAT:

MmTRCh5C3S4TDWXE1QD55ISDyvpSmD/seYQUmbG84Tgj9kVUawsyujsqY/WgMkCUG8gu3q6avDWE1dp1VD/nJSLNKRxPekw+PtjTqxfkNbNaAAJLkX3CSgdAinnqqImrzOZ5pWPFSGokMAyBkVwPfrscgm5LCcV4Lz7ZnffqxNl3cb0p9OtWJzqSAiA46A7irfU/wbN
XInIzdwTTUQdDSplu+sCluDGs52igmWhgNNrLjJI0/mLCIPMbo7XkCyilWOVXPYPpXyZQAVavifFzFLwDyLW6u5h3ofX162UHqWwGYWoq9m9A4Dzjviz0jbCYoYFDrOYs4nb6KY/RhAvZRw ==

Leyendas Fiscales

Leyenda: Esta operación se realiza al amparo del artículo 29 fracción I

de la LIVA; artículo 122 de la Ley Aduanera y de las

Reglas 5.2.4 fracción II, 5.2.6 y 4.3.21 fracción I;

de las Reglas Generales en Materia de Comercio Exterior Vigentes,

Recibe la empresa EMERMEX SA DE CV con numero de IMMEX 4346-2006 Y RFC EME8409145T2

Transfiere la empresa DISEÑOS METÁLICOS DEL NORTE S.A DE C.V. con número de IMMEX 654/2008 Y RFC DMN020730TV6

Norma: LEY DEL IVA ART.29º FRACCION I
LEY ADUANERA ARTÍCULO 112
REGLAS GENERALES DE COMERCIO EXTERIOR

5.2.4. FRACCION II, 5.2.6. Y 4.3.21

Disposición fiscal: ART. 29º LIVA Y ART. 112º RLA

(Ochenta y nueve usd 34/100)

Método de pago: PPD/Pago en parcialidades o diferido

Forma de pago: 99/Por definir

Uso del CFDI: S01/Sin efectos fiscales


<table>
<tr>
<td>Subtotal</td>
<td>89.34</td>
</tr>
<tr>
<td>Total (USD)</td>
<td>89.34</td>
</tr>
</table>


Este documento es una representación impresa de un CFDI. Folio del SAT: 064E79B4-CB91-0242-963C-4352B81A6C56
Fecha de certificación: 19/ene./2026 17:32:09 Certificado del emisor: 00001000000710404884 Certificado del SAT: 00001000000702501858

Régimen fiscal del emisor: 601/General de Ley Personas Morales Lugar de expedición: 25107

<!-- PageFooter="CFDI 4.0/Ingreso" -->
