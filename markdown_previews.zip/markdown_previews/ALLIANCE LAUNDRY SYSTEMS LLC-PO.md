# ALLIANCE LAUNDRY SYSTEMS LLC-PO.pdf

<!-- PageNumber="Page 1 of 5" -->


# INVOICE


<figure>

I
Alliance®
Laundry Systems

</figure>


Genuine Parts

Ship To : 2001687
MARCONE APPLIANCE PARTS CO
15 INDUSTRIAL PARK RD
ALBANY NY 12206

PO Box 990, Shepard Street
Ripon, WI 54971, USA
T | +1 920 748 3121

Invoice To : 100675

MARCONE APPLIANCE PARTS CO

PO BOX 411520

SAINT LOUIS MO

63141


<table>
<tr>
<th>Due Date</th>
<th>Invoice No.</th>
</tr>
<tr>
<td>02/27/2026</td>
<td>6002176309</td>
</tr>
</table>


Please Include Account No. & Invoice No. on Your Remittance. Payable in
USD Funds. Please remit to:
ALLIANCE LAUNDRY SYSTEMS, LLC
PO BOX 775826
CHICAGO IL 60677-5826

Terms

VIA

NET-30

UPS Ground

Parts (SP)

PARTS MANAGER


<table>
<tr>
<th>Order No.</th>
<th>Order Date</th>
<th>Sales No.</th>
<th>Incoterms 2010</th>
<th>B/L #</th>
<th>Date</th>
</tr>
<tr>
<td>AL0127F26SPE</td>
<td>01/27/2026</td>
<td>31304668</td>
<td>Prepaid</td>
<td></td>
<td>01/28/2026</td>
</tr>
</table>


<table>
<tr>
<th colspan="2">Quantity</th>
<th rowspan="2">Model Number / Description</th>
<th rowspan="2">List</th>
<th colspan="2">Prices USD</th>
</tr>
<tr>
<th>Ordered</th>
<th>Shipped</th>
<th>Net</th>
<th>Extended</th>
</tr>
<tr>
<td>155.00</td>
<td>155.00</td>
<td>RB150003 KIT BELT&amp;PUMP MODEL M/N</td>
<td>66.37</td>
<td>33.18</td>
<td>5,143.67</td>
</tr>
<tr>
<td>1.00</td>
<td>1.00</td>
<td>M400991 WASHER, FLAT (.565 ID X</td>
<td>2.14</td>
<td>1.07</td>
<td>1.07</td>
</tr>
<tr>
<td>1.00</td>
<td>1.00</td>
<td>M400080 WASHER, FLAT (5/16 STD TYPE</td>
<td>5.39</td>
<td>2.69</td>
<td>2.69</td>
</tr>
<tr>
<td>1.00</td>
<td>1.00</td>
<td>H96409156P GASKET LOADING DOOR</td>
<td>65.00</td>
<td>32.50</td>
<td>32.50</td>
</tr>
<tr>
<td>1.00</td>
<td>1.00</td>
<td>D519163 PANEL, GRAPHIC DRY - SQ</td>
<td>72.87</td>
<td>36.43</td>
<td>36.43</td>
</tr>
<tr>
<td>5.00</td>
<td>5.00</td>
<td>D518839P ASSY, HEATER-RED 5000W PKG' D</td>
<td>81.17</td>
<td>40.58</td>
<td>202.92</td>
</tr>
<tr>
<td>633.00</td>
<td>633.00</td>
<td>D518649 ASSY, THERMAL FUSE</td>
<td>6.09</td>
<td>3.04</td>
<td>1,927.48</td>
</tr>
<tr>
<td>1.00</td>
<td>1.00</td>
<td>D517585 ASSY, BLUE H4 DRYER CNTRL</td>
<td>265.28</td>
<td>132.64</td>
<td>132.64</td>
</tr>
<tr>
<td rowspan="2">4.00</td>
<td rowspan="2">4.00</td>
<td rowspan="2">D515544WP ASSY FRT</td>
<td rowspan="2">196.83</td>
<td>98.42</td>
<td rowspan="2">393.66</td>
</tr>
<tr>
<td></td>
</tr>
</table>


<!-- PageFooter="*Customer agrees that past due receivables may incur interest at a rate of 1% per month or the highest amount allowable under applicable law" -->
<!-- PageBreak -->

<!-- PageNumber="Page 2 of 5" -->


# INVOICE


<figure>

I
Alliance®
Laundry Systems

</figure>


Genuine Parts

Ship To : 2001687
MARCONE APPLIANCE PARTS CO
15 INDUSTRIAL PARK RD
ALBANY NY 12206

PO Box 990, Shepard Street
Ripon, WI 54971, USA
T | +1 920 748 3121

Invoice To : 100675

MARCONE APPLIANCE PARTS CO

PO BOX 411520

SAINT LOUIS MO

63141


<table>
<tr>
<th>Due Date</th>
<th>Invoice No.</th>
</tr>
<tr>
<td>02/27/2026</td>
<td>6002176309</td>
</tr>
</table>


Please Include Account No. & Invoice No. on Your Remittance. Payable in
USD Funds. Please remit to:
ALLIANCE LAUNDRY SYSTEMS, LLC
PO BOX 775826
CHICAGO IL 60677-5826

Terms

VIA

NET-30

UPS Ground

Parts (SP)

PARTS MANAGER


<table>
<tr>
<th>Order No.</th>
<th>Order Date</th>
<th>Sales No.</th>
<th>Incoterms 2010</th>
<th>B/L #</th>
<th>Date</th>
</tr>
<tr>
<td>AL0127F26SPE</td>
<td>01/27/2026</td>
<td>31304668</td>
<td>Prepaid</td>
<td></td>
<td>01/28/2026</td>
</tr>
</table>


<table>
<tr>
<th colspan="2">Quantity</th>
<th rowspan="2">Model Number / Description</th>
<th rowspan="2">List</th>
<th colspan="2">Prices USD</th>
</tr>
<tr>
<th>Ordered</th>
<th>Shipped</th>
<th>Net</th>
<th>Extended</th>
</tr>
<tr>
<td>1.00</td>
<td>1.00</td>
<td>D512304 SHIELD CONTROL-NATURAL</td>
<td>2.59</td>
<td>1.29</td>
<td>1.29</td>
</tr>
<tr>
<td>53.00</td>
<td>53.00</td>
<td>D510177 ASSY DOOR CATCH</td>
<td>6.05</td>
<td>3.02</td>
<td>160.32</td>
</tr>
<tr>
<td>1.00</td>
<td>1.00</td>
<td>D510029WP KIT TOP PANEL</td>
<td>344.03</td>
<td>172.01</td>
<td>172.01</td>
</tr>
<tr>
<td>5.00</td>
<td>5.00</td>
<td>D510002WP PANEL CABINET SIDE-RH</td>
<td>196.04</td>
<td>98.02</td>
<td>490.10</td>
</tr>
<tr>
<td>143.00</td>
<td>143.00</td>
<td>959P3 KIT, IDLER LEVER AND BELT</td>
<td>40.19</td>
<td>20.09</td>
<td>2,873.58</td>
</tr>
<tr>
<td>1.00</td>
<td>1.00</td>
<td>808390 ASSY, BLU FLW CNTL HOME H6</td>
<td>194.15</td>
<td>97.07</td>
<td>97.07</td>
</tr>
<tr>
<td>15.00</td>
<td>15.00</td>
<td>807875 KIT ASSY, SHOCK</td>
<td>61.62</td>
<td>30.81</td>
<td>462.15</td>
</tr>
<tr>
<td>1.00</td>
<td>1.00</td>
<td>806547 PANEL, KNOB SUPPORT</td>
<td>32.21</td>
<td>16.10</td>
<td>16.10</td>
</tr>
<tr>
<td>1.00</td>
<td>1.00</td>
<td>804849 OVERLAY, CNTRL FLW SQ H7S</td>
<td>38.75</td>
<td>19.37</td>
<td>19.37</td>
</tr>
</table>


<!-- PageFooter="*Customer agrees that past due receivables may incur interest at a rate of 1% per month or the highest amount allowable under applicable law" -->
<!-- PageBreak -->

<!-- PageNumber="Page 3 of 5" -->


## INVOICE


<figure>

I
Alliance®
Laundry Systems

</figure>


Genuine Parts

Ship To : 2001687
MARCONE APPLIANCE PARTS CO
15 INDUSTRIAL PARK RD
ALBANY NY 12206

PO Box 990, Shepard Street
Ripon, WI 54971, USA
T | +1 920 748 3121

Invoice To : 100675

MARCONE APPLIANCE PARTS CO

PO BOX 411520

SAINT LOUIS MO

63141


<table>
<tr>
<th>Due Date</th>
<th>Invoice No.</th>
</tr>
<tr>
<td>02/27/2026</td>
<td>6002176309</td>
</tr>
</table>


Please Include Account No. & Invoice No. on Your Remittance. Payable in
USD Funds. Please remit to:
ALLIANCE LAUNDRY SYSTEMS, LLC
PO BOX 775826
CHICAGO IL 60677-5826

Terms

VIA

NET-30

UPS Ground

Parts (SP)

PARTS MANAGER


<table>
<tr>
<th>Order No.</th>
<th>Order Date</th>
<th>Sales No.</th>
<th>Incoterms 2010</th>
<th>B/L #</th>
<th>Date</th>
</tr>
<tr>
<td>AL0127F26SPE</td>
<td>01/27/2026</td>
<td>31304668</td>
<td>Prepaid</td>
<td></td>
<td>01/28/2026</td>
</tr>
</table>


<table>
<tr>
<th colspan="2">Quantity</th>
<th rowspan="2">Model Number / Description</th>
<th rowspan="2">List</th>
<th colspan="2">Prices USD</th>
</tr>
<tr>
<th>Ordered</th>
<th>Shipped</th>
<th>Net</th>
<th>Extended</th>
</tr>
<tr>
<td>59.00</td>
<td>59.00</td>
<td>802803 ASSY DOOR CATCH</td>
<td>6.05</td>
<td>3.02</td>
<td>178.47</td>
</tr>
<tr>
<td>1.00</td>
<td>1.00</td>
<td>70564803 KIT TRUNNION AND SEAL</td>
<td>168.85</td>
<td>84.42</td>
<td>84.42</td>
</tr>
<tr>
<td>1.00</td>
<td>1.00</td>
<td>70529301 SWITCH, ROCKER, SILVER, MOM, SP</td>
<td>7.12</td>
<td>3.56</td>
<td>3.56</td>
</tr>
<tr>
<td>1.00</td>
<td>1.00</td>
<td>685430 CATCH LOCKING-DOOR</td>
<td>15.69</td>
<td>7.84</td>
<td>7.84</td>
</tr>
<tr>
<td>17.00</td>
<td>17.00</td>
<td>649P3 KIT CONV-DRYER-NG TO</td>
<td>45.29</td>
<td>22.64</td>
<td>384.96</td>
</tr>
<tr>
<td>1.00</td>
<td>1.00</td>
<td>60353P ASSY VALVE-GAS 60HZ 25M</td>
<td>361.75</td>
<td>180.87</td>
<td>180.87</td>
</tr>
<tr>
<td>12.00</td>
<td>12.00</td>
<td>39508P KIT DRIVE BELL-SEAL</td>
<td>35.60</td>
<td>17.80</td>
<td>213.60</td>
</tr>
<tr>
<td>1.00</td>
<td>1.00</td>
<td>38034P KIT MOTOR 120V/60-2SP CAP</td>
<td>329.40</td>
<td>164.70</td>
<td>164.70</td>
</tr>
<tr>
<td>6.00</td>
<td>6.00</td>
<td>38008 HELIX, PLASTIC</td>
<td>6.25</td>
<td>3.13</td>
<td>18.75</td>
</tr>
</table>


<!-- PageFooter="*Customer agrees that past due receivables may incur interest at a rate of 1% per month or the highest amount allowable under applicable law" -->
<!-- PageBreak -->

<!-- PageNumber="Page 4 of 5" -->


## INVOICE


<figure>

I
Alliance"
Laundry Systems

</figure>


Genuine Parts

Ship To : 2001687
MARCONE APPLIANCE PARTS CO
15 INDUSTRIAL PARK RD
ALBANY NY 12206

PO Box 990, Shepard Street
Ripon, WI 54971, USA
T | +1 920 748 3121

Invoice To : 100675

MARCONE APPLIANCE PARTS CO

PO BOX 411520

SAINT LOUIS MO

63141


<table>
<tr>
<th>Due Date</th>
<th>Invoice No.</th>
</tr>
<tr>
<td>02/27/2026</td>
<td>6002176309</td>
</tr>
</table>


Please Include Account No. & Invoice No. on Your Remittance. Payable in
USD Funds. Please remit to:
ALLIANCE LAUNDRY SYSTEMS, LLC
PO BOX 775826
CHICAGO IL 60677-5826

Terms

VIA

NET-30

UPS Ground

Parts (SP)

PARTS MANAGER


<table>
<tr>
<th>Order No.</th>
<th>Order Date</th>
<th>Sales No.</th>
<th>Incoterms 2010</th>
<th>B/L #</th>
<th>Date</th>
</tr>
<tr>
<td>AL0127F26SPE</td>
<td>01/27/2026</td>
<td>31304668</td>
<td>Prepaid</td>
<td></td>
<td>01/28/2026</td>
</tr>
</table>


<table>
<tr>
<th colspan="2">Quantity</th>
<th rowspan="2">Model Number / Description</th>
<th rowspan="2">List</th>
<th colspan="2">Prices USD</th>
</tr>
<tr>
<th>Ordered</th>
<th>Shipped</th>
<th>Net</th>
<th>Extended</th>
</tr>
<tr>
<td>49.00</td>
<td rowspan="2">49.00</td>
<td rowspan="2">34318 FOOT, RUBBER</td>
<td rowspan="2">3.28</td>
<td>1.64</td>
<td>80.36</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>2.00</td>
<td>2.00</td>
<td>29786 NUT HEX KEPS 1/4-20 STL</td>
<td>5.39</td>
<td>2.70</td>
<td>5.39</td>
</tr>
<tr>
<td>649.00</td>
<td>645.00</td>
<td>205547P VALVE, MIXING 4.4GPM 120V</td>
<td>33.05</td>
<td>16.52</td>
<td>10,658.62</td>
</tr>
<tr>
<td>2.00</td>
<td>2.00</td>
<td>205546P ASSY, BRAKE PKG</td>
<td>46.06</td>
<td>23.03</td>
<td>46.06</td>
</tr>
<tr>
<td>8.00</td>
<td>8.00</td>
<td>204870 KIT, PANEL FRONT W/ PADS &amp;</td>
<td>141.99</td>
<td>71.00</td>
<td>567.96</td>
</tr>
<tr>
<td>2.00</td>
<td>2.00</td>
<td>204074P ASSY, CNTRL &amp; OVRLY H4 STD</td>
<td>409.52</td>
<td>204.76</td>
<td>409.52</td>
</tr>
<tr>
<td>53.00</td>
<td>53.00</td>
<td>203968 ASSY, TUB COVER-RES</td>
<td>15.79</td>
<td>7.89</td>
<td>418.43</td>
</tr>
<tr>
<td>82.00</td>
<td>82.00</td>
<td>203643 BEZEL, LID LOCK</td>
<td>5.39</td>
<td>2.70</td>
<td>220.99</td>
</tr>
<tr>
<td>1.00</td>
<td>1.00</td>
<td>203632BP ASSY, TOP PANEL (HOME,</td>
<td>141.99</td>
<td>70.99</td>
<td>70.99</td>
</tr>
<tr>
<td>Pro Number</td>
<td>:</td>
<td>Seal Number:</td>
<td colspan="2">Container ID:</td>
<td></td>
</tr>
</table>


<!-- PageFooter="*Customer agrees that past due receivables may incur interest at a rate of 1% per month or the highest amount allowable under applicable law" -->
<!-- PageBreak -->

<!-- PageNumber="Page 5 of 5" -->


## INVOICE


<figure>

I
Alliance"
Laundry Systems

</figure>


Genuine Parts

PO Box 990, Shepard Street
Ripon, WI 54971, USA
T | +1 920 748 3121

Invoice To : 100675

MARCONE APPLIANCE PARTS CO

PO BOX 411520

SAINT LOUIS MO

63141

Ship To : 2001687
MARCONE APPLIANCE PARTS CO
15 INDUSTRIAL PARK RD
ALBANY NY 12206


<table>
<tr>
<th>Due Date</th>
<th>Invoice No.</th>
</tr>
<tr>
<td>02/27/2026</td>
<td>6002176309</td>
</tr>
</table>


Please Include Account No. & Invoice No. on Your Remittance. Payable in
USD Funds. Please remit to:
ALLIANCE LAUNDRY SYSTEMS, LLC
PO BOX 775826
CHICAGO IL 60677-5826

Terms

VIA

NET-30

UPS Ground

Parts (SP)

PARTS MANAGER


<table>
<tr>
<th>Order No.</th>
<th>Order Date</th>
<th>Sales No.</th>
<th>Incoterms 2010</th>
<th>B/L #</th>
<th>Date</th>
</tr>
<tr>
<td>AL0127F26SPE</td>
<td>01/27/2026</td>
<td>31304668</td>
<td>Prepaid</td>
<td></td>
<td>01/28/2026</td>
</tr>
</table>


<table>
<tr>
<th colspan="2">Quantity</th>
<th rowspan="2">Model Number /</th>
<th rowspan="2">Description</th>
<th rowspan="2">List</th>
<th colspan="2">Prices USD</th>
</tr>
<tr>
<th>Ordered</th>
<th>Shipped</th>
<th>Net</th>
<th>Extended</th>
</tr>
<tr>
<td>0</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>425745725</td>
<td>-</td>
<td>0.000 LB</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>425745725</td>
<td>-</td>
<td>0.000 LB</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>425745725</td>
<td>-</td>
<td>0.000 LB</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="4" rowspan="2">Replacement Parts : Part D518839 is replaced by Part D518839P</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
</tr>
</table>


0
1,970.0 1,966.0
0

25,880.54 USD

Net Amount

<!-- PageFooter="*Customer agrees that past due receivables may incur interest at a rate of 1% per month or the highest amount allowable under applicable law" -->
