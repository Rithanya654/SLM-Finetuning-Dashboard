# Graphic Packaging Inv 95228429 Dt. 01162026.pdf

Page:

1

REMIT TO: Graphic Packaging International LLC

Acct: 3756203501 Swift: BOFAUS3NXXX

ACHABA: 111000012 WireABA: 026009593

PO Box 404170

Atlanta, GA-30384-4170

Shipping Plant
Stone Mountain Folding Carton Plant
5853 E PONCE DE LEON AVE
Stone Mountain GA 30083-1503


<figure>

Graphic
Packaging
INTERNATIONAL

</figure>


<table>
<tr>
<th>INVOICE DT</th>
<th>SHIPPING NO.</th>
<th>SLSRP</th>
<th>CUSTOMER ORDER NO.</th>
<th>CUSTOMER REQ.NO.</th>
<th>CUSTOMER ACCT.NO.</th>
<th>INVOICE NO.</th>
</tr>
<tr>
<td>JAN 16,2026</td>
<td>4076444</td>
<td></td>
<td>934906</td>
<td></td>
<td>23390</td>
<td>95228429</td>
</tr>
</table>


SALES REP

BILL TO 23134

SHIP TO 22901

B
I

T

O
BUNZL USA INC
BUNZL PAPERCRAFT SAN ANTONIO
ATTN SHARED SERVICES
P.O. Box 270417
SAINT LOUIS MO 63127-0417
L
L

S

I

P

T

O

BUNZL USA INC

BUNZL SAN ANTONIO

4030 BINZ ENGLEMAN RD

SAN ANTONIO TX 78219-2213

ORIGINAL


<table>
<tr>
<th>TERMS</th>
<th>WEIGHT</th>
</tr>
<tr>
<td>2% 15 days Net 30 days</td>
<td>27,556.450 LB</td>
</tr>
</table>


<table>
<tr>
<th>CARRIER</th>
<th>CAR NO.</th>
<th>B/L NO.</th>
<th>DATE SHIPPED</th>
<th>FREIGHT AMOUNT</th>
</tr>
<tr>
<td>ARRIVE LOG</td>
<td>35683</td>
<td>88673086</td>
<td>JAN 16,2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<td colspan="5">FREIGHT TERMS</td>
</tr>
<tr>
<td>PPF - CIP</td>
<td>Carriage/Ins Pd</td>
<td>To</td>
<td>(PPF)</td>
<td>- CIP Carriage/ Ins Pd To (PPF)</td>
</tr>
</table>


<table>
<tr>
<th>ORDERS</th>
<th>PRODUCTS/QUANTITY</th>
<th></th>
<th>DESCRIPTION/PRICE</th>
<th>AMOUNT</th>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2"></td>
<td>Currency USD</td>
</tr>
<tr>
<td>4076444</td>
<td>100566695 BZW</td>
<td colspan="2">12CT WALMART DONUTS/UNPRTED-COATING</td>
<td>(IP)</td>
</tr>
<tr>
<td></td>
<td>Item 10</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>150 CAS</td>
<td>42.27</td>
<td>USD 1 CAS</td>
<td>6,340.50</td>
</tr>
<tr>
<td>4076444</td>
<td>100534884 BZW</td>
<td colspan="2">2CT SINGLE SERVE DONUT/UNPRTD-COAT.</td>
<td>(IP)</td>
</tr>
<tr>
<td></td>
<td>Item 20</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>280 CAS</td>
<td>27.70</td>
<td>USD 1 CAS</td>
<td>7,756.00</td>
</tr>
<tr>
<td>4076444</td>
<td>100511719 BZW</td>
<td>WALMART FULL</td>
<td>SHEET BOX NO INK/CTG</td>
<td>WEB</td>
</tr>
<tr>
<td></td>
<td>Item 30</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Patent Numbers: WALMART FULL SHEET BOX NO INK/CTG</td>
<td>WEB</td>
</tr>
<tr>
<td rowspan="2"></td>
<td>15 CAS</td>
<td rowspan="2">43.40</td>
<td rowspan="2">USD 1 CAS</td>
<td rowspan="2">651.00</td>
</tr>
<tr>
<td></td>
</tr>
</table>


CONTACT INFORMATION: Credit Department (credit@graphicpkg.com)
1500 Riveredge Pkwy, Ste 100, Atlanta, GA 30328

We Certify that the goods covered hereby have been produced in compliance with applicable requirements of Section 6, 7 and 12 of the
Fair Labor Standards Act as amended, and the regulations and orders of the U.S. Department of Labor issued under Section 14 thereof.
\* is a registered trademark of Graphic Packaging International, LLC

<!-- PageBreak -->

Page:

2


<figure>

Graphic
Packaging
INTERNATIONAL

</figure>


Shipping Plant
Stone Mountain Folding Carton Plant
5853 E PONCE DE LEON AVE
Stone Mountain GA 30083-1503

REMIT TO: Graphic Packaging International LLC

Acct: 3756203501 Swift: BOFAUS3NXXX

ACHABA: 111000012 WireABA: 026009593

PO Box 404170

Atlanta, GA-30384-4170


<table>
<tr>
<th>INVOICE DT</th>
<th>SHIPPING NO.</th>
<th>SLSRP</th>
<th>CUSTOMER ORDER NO.</th>
<th>CUSTOMER REQ.NO.</th>
<th>CUSTOMER ACCT.NO.</th>
<th>INVOICE NO.</th>
</tr>
<tr>
<td>JAN 16,2026</td>
<td>4076444</td>
<td></td>
<td>934906</td>
<td></td>
<td>23390</td>
<td>95228429</td>
</tr>
</table>


SALES REP

BILL TO 23134

SHIP TO 22901

B
I

T

O
BUNZL USA INC
BUNZL PAPERCRAFT SAN ANTONIO
ATTN SHARED SERVICES
P.O. Box 270417
SAINT LOUIS MO 63127-0417
L
L

S
H
T
O
P

BUNZL USA INC
BUNZL SAN ANTONIO
4030 BINZ ENGLEMAN RD
SAN ANTONIO TX 78219-2213

ORIGINAL


<table>
<tr>
<th>ORDERS</th>
<th>PRODUCTS/QUANTITY</th>
<th></th>
<th colspan="2">DESCRIPTION/PRICE</th>
<th>AMOUNT</th>
</tr>
<tr>
<td>4076444</td>
<td>100511717 BZW</td>
<td>12"</td>
<td>ROUND</td>
<td>CAKE BOX NO INK/CTG WEB</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Item 40</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Patent Numbers:</td>
<td>12"</td>
<td colspan="2">ROUND CAKE BOX NO INK/CTG WEB</td>
<td></td>
</tr>
<tr>
<td></td>
<td>84 CAS</td>
<td></td>
<td>33.90</td>
<td>USD 1 CAS</td>
<td>2,847.60</td>
</tr>
<tr>
<td>4076444</td>
<td>100625345 BZW</td>
<td>6CT</td>
<td>WALMART</td>
<td>DONUTS NEW DESIGN (IP)</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Item 50</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>196 CAS</td>
<td></td>
<td>48.80</td>
<td>USD 1 CAS</td>
<td>9,564.80</td>
</tr>
<tr>
<td>4076444</td>
<td>100625346 BZW</td>
<td>13CT</td>
<td>WALMART</td>
<td>DONUTS NEW DESIGN</td>
<td>(IP)</td>
</tr>
<tr>
<td></td>
<td>Item 60</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>135 CAS</td>
<td></td>
<td>50.82</td>
<td>USD 1 CAS</td>
<td>6,860.70</td>
</tr>
<tr>
<td>4076444</td>
<td>100479820 BZW</td>
<td>WALMART</td>
<td colspan="2">1/2 SHT BOTTOM NO INK/CTG</td>
<td>WEB</td>
</tr>
<tr>
<td></td>
<td>Item 70</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Patent Numbers:</td>
<td colspan="3">WALMART 1/2 SHT BOTTOM NO INK/CTG</td>
<td>WEB</td>
</tr>
<tr>
<td rowspan="2"></td>
<td>48 CAS</td>
<td></td>
<td colspan="2" rowspan="2">26.16 USD 1 CAS</td>
<td>1,255.68</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
</tr>
</table>


CONTACT INFORMATION: Credit Department (credit@graphicpkg.com)
1500 Riveredge Pkwy, Ste 100, Atlanta, GA 30328

We Certify that the goods covered hereby have been produced in compliance with applicable requirements of Section 6, 7 and 12 of the
Fair Labor Standards Act as amended, and the regulations and orders of the U.S. Department of Labor issued under Section 14 thereof.
\* is a registered trademark of Graphic Packaging International, LLC

<!-- PageBreak -->


<figure>

Graphic
Packaging
INTERNATIONAL

</figure>


Shipping Plant
Stone Mountain Folding Carton Plant
5853 E PONCE DE LEON AVE
Stone Mountain GA 30083-1503

REMIT TO: Graphic Packaging International LLC

Acct: 3756203501 Swift: BOFAUS3NXXX

ACHABA: 111000012 WireABA: 026009593
PO Box 404170
Atlanta, GA-30384-4170

Page:

3


<table>
<tr>
<th>INVOICE DT</th>
<th>SHIPPING NO.</th>
<th>SLSRP</th>
<th>CUSTOMER ORDER NO.</th>
<th>CUSTOMER REQ.NO.</th>
<th>CUSTOMER ACCT.NO.</th>
<th>INVOICE NO.</th>
</tr>
<tr>
<td>JAN 16,2026</td>
<td>4076444</td>
<td></td>
<td>934906</td>
<td></td>
<td>23390</td>
<td>95228429</td>
</tr>
</table>


SALES REP

BILL TO 23134

SHIP TO 22901

B
I

L
L

T

O

BUNZL USA INC
BUNZL PAPERCRAFT SAN ANTONIO
ATTN SHARED SERVICES
P.O. Box 270417
SAINT LOUIS MO 63127-0417

S

I

P

T

O

BUNZL USA INC
BUNZL SAN ANTONIO
4030 BINZ ENGLEMAN RD
SAN ANTONIO TX 78219-2213

ORIGINAL


<table>
<tr>
<th>ORDERS PRODUCTS/QUANTITY DESCRIPTION/PRICE</th>
<th>AMOUNT</th>
</tr>
<tr>
<td>Final Amount Cash Discount Amount (Applicable if paid within term)</td>
<td>35,276.28 -705.53</td>
</tr>
</table>


CONTACT INFORMATION: Credit Department (credit@graphicpkg.com)
1500 Riveredge Pkwy, Ste 100, Atlanta, GA 30328

We Certify that the goods covered hereby have been produced in compliance with applicable requirements of Section 6, 7 and 12 of the
Fair Labor Standards Act as amended, and the regulations and orders of the U.S. Department of Labor issued under Section 14 thereof.
\* is a registered trademark of Graphic Packaging International, LLC
