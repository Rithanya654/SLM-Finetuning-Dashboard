# FLEETPARTNERS PTY LIMITED.pdf

Fleet Partners Pty Limited
Level 20, 101 Miller Street, North Sydney, NSW 2060
E: receivables@fleetpartners.com.au


<figure>

P
FleetPartners

</figure>


fleetpartners.com.au | 1300 666 001


# TAX INVOICE

Incidental costs

Vertiv (Australia) Pty Ltd

Suite 408 Level 4 7-9 Irvine Place
Bella Vista
NSW 2153

TOTAL AMOUNT DUE
$25,126.35

DATE DUE

01 April 2026


<table>
<tr>
<th>Customer ABN</th>
<th>Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
</tr>
<tr>
<td>53 003 469 654</td>
<td>AU1166479</td>
<td>31 January 2026</td>
<td>AIN00014651</td>
</tr>
</table>


<table>
<tr>
<th>Net</th>
<th>GST</th>
<th>Total</th>
</tr>
<tr>
<td>$22,840.16</td>
<td>$2,286.19</td>
<td>$25,126.35</td>
</tr>
</table>


\> Payment may be deposited to:


<table>
<tr>
<th>Bank name</th>
<th>Account name</th>
<th>BSB</th>
<th>Account</th>
<th>Payment reference</th>
</tr>
<tr>
<td>ANZ</td>
<td>Fleet Partners Pty Limited</td>
<td>013 030</td>
<td>838 440 763</td>
<td>AU1166479</td>
</tr>
</table>


## Cost type analysis


<figure>

20000

17500

15000

12500

10000

7500

5000

2500

0

-2500

Management Fees

Repair & Maintenance

Tyre Costs

Accident Management

Toll Management

</figure>


<!-- PageFooter="Fleet Partners Pty Limited ABN : 63 006 706 832" -->
<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 1 of 121" -->
<!-- PageBreak -->


<table>
<tr>
<th>Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
</tr>
<tr>
<td>AU1166479</td>
<td>31 January 2026</td>
<td>AIN00014651</td>
</tr>
</table>


<figure>

P

</figure>


<table>
<tr>
<th colspan="2">State Reg No. Accident Management</th>
<th>Vehicle Description</th>
<th>Driver</th>
<th colspan="2">Line Ref. Contract - Description</th>
<th>Net</th>
<th>GST</th>
<th>Total</th>
</tr>
<tr>
<td></td>
<td rowspan="2">1IGC368</td>
<td rowspan="2">ISUZU RG MY23 D-MAX SX CR</td>
<td></td>
<td colspan="2">Cost Centre: Thermal</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>WA</td>
<td>Adrian Mccormack</td>
<td colspan="2">4843549503 302289-C-00606926 Misc-Accident on 26/11/25</td>
<td>-35.47</td>
<td>-3.55</td>
<td>-39.02</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">Total for Cost Centre: Thermal</td>
<td>-35.47</td>
<td>-3.55</td>
<td>-39.02</td>
</tr>
<tr>
<td colspan="3">Total for Accident Management</td>
<td></td>
<td></td>
<td></td>
<td>-$35.47</td>
<td>-$3.55</td>
<td>-$39.02</td>
</tr>
<tr>
<td colspan="4">Management Fees</td>
<td colspan="5"></td>
</tr>
<tr>
<td colspan="2" rowspan="2">NSW DJW39Q</td>
<td></td>
<td></td>
<td>Cost Centre:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4841411201</td>
<td>212794-C-Management Fee-06/02/2026 to 05/03/2026</td>
<td>5.00</td>
<td>0.50</td>
<td>5.50</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">Total for Cost Centre:</td>
<td>5.00</td>
<td>0.50</td>
<td>5.50</td>
</tr>
<tr>
<td colspan="3">Total for Management Fees</td>
<td></td>
<td></td>
<td></td>
<td>$5.00</td>
<td>$0.50</td>
<td>$5.50</td>
</tr>
<tr>
<td colspan="4">Repair &amp; Maintenance</td>
<td colspan="5"></td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">Cost Centre: Power</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td colspan="2">4843545618 256892-C-FLM4W-Fleet Managed-4 Wheel Align on</td>
<td>61.00</td>
<td>6.10</td>
<td>67.10</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total for Cost Centre: Power</td>
<td>61.00</td>
<td>6.10</td>
<td>67.10</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">Cost Centre: Supervisor</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>ACT</td>
<td>YRH 13F</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Anthony Dyer</td>
<td>4843549301</td>
<td>302287-C-Transmission-Fit CV/Drive Shaft Boot on</td>
<td>965.72</td>
<td>96.57</td>
<td>1,062.29</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total for Cost Centre: Supervisor</td>
<td>965.72</td>
<td>96.57</td>
<td>1,062.29</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">Cost Centre: Thermal</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>WA</td>
<td>1IGC368</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Adrian Mccormack</td>
<td>4843549501</td>
<td>302289-C-SP08 Sundry-Execute on 02/09/25</td>
<td>100.72</td>
<td>10.07</td>
<td>110.79</td>
</tr>
<tr>
<td>WA</td>
<td>1IGC368</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Adrian Mccormack</td>
<td>4843549502</td>
<td>302289-C-Fitted hella Taillights on 02/09/25</td>
<td>911.02</td>
<td>91.10</td>
<td>1,002.12</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total for Cost Centre: Thermal</td>
<td>1,011.74</td>
<td>101.17</td>
<td>1,112.91</td>
</tr>
<tr>
<td colspan="3">Total for Repair &amp; Maintenance</td>
<td></td>
<td></td>
<td></td>
<td>$2,038.46</td>
<td>$203.84</td>
<td>$2,242.30</td>
</tr>
<tr>
<td colspan="3">Toll Management</td>
<td></td>
<td colspan="5"></td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">Cost Centre:</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">NSW DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544901</td>
<td>212794-C-WestLink M7 : 2025-12-16 05:38:21</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544902</td>
<td>212794-C-WestLink M7 : 2025-12-17 05:48:07</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544903</td>
<td>212794-C-WestLink M7 : 2025-12-18 15:08:39</td>
<td>7.62</td>
<td>0.76</td>
<td>8.38</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544904</td>
<td>212794-C-WestLink M7 : 2025-12-18 05:28:19</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 2 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th colspan="2"></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544905</td>
<td>212794-C-Lane Cove Tunnel : 2025-12-19 10:41:54</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544906</td>
<td>212794-C-WestConnex : 2025-12-19 13:07:38</td>
<td>4.16</td>
<td>0.42</td>
<td>4.58</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544907</td>
<td>212794-C-M5 South West Motorway : 2025-12-19</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544908</td>
<td>212794-C-M5 South West Motorway : 2025-12-19</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544909</td>
<td>212794-C-Hills M2 : 2025-12-19 10:45:00</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544910</td>
<td>212794-C-WestConnex : 2025-12-19 05:32:38</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544911</td>
<td>212794-C-M5 South West Motorway : 2025-12-20</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544912</td>
<td>212794-C-M5 South West Motorway : 2025-12-20</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544913</td>
<td>212794-C-WestConnex : 2025-12-20 11:30:52</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544914</td>
<td>212794-C-WestConnex : 2025-12-20 17:36:40</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544915</td>
<td>212794-C-M5 South West Motorway : 2025-12-22</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544916</td>
<td>212794-C-M5 South West Motorway : 2025-12-22</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544917</td>
<td>212794-C-WestConnex : 2025-12-22 13:11:45</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544918</td>
<td>212794-C-WestConnex : 2025-12-22 04:27:59</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544919</td>
<td>212794-C-M5 South West Motorway : 2025-12-24</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544920</td>
<td>212794-C-WestConnex : 2025-12-27 11:02:46</td>
<td>4.54</td>
<td>0.45</td>
<td>4.99</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544921</td>
<td>212794-C-M5 South West Motorway : 2025-12-27</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544922</td>
<td>212794-C-M5 South West Motorway : 2025-12-27</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544923</td>
<td>212794-C-WestConnex : 2025-12-27 11:39:17</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544924</td>
<td>212794-C-WestConnex : 2025-12-27 07:13:35</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544925</td>
<td>212794-C-M5 South West Motorway : 2025-12-29</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544926</td>
<td>212794-C-M5 South West Motorway : 2025-12-29</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544927</td>
<td>212794-C-WestConnex : 2025-12-29 12:57:45</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544928</td>
<td>212794-C-WestConnex : 2025-12-29 05:23:28</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544929</td>
<td>212794-C-M5 South West Motorway:2026-01-01 07:57:40</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544930</td>
<td>212794-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-02</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544931</td>
<td>212794-C-M5 South West Motorway:2026-01-02 09:56:46</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544932</td>
<td>212794-C-M5 South West Motorway:2026-01-02 12:05:02</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544933</td>
<td>212794-C-WestConnex:2026-01-02 10:02:34</td>
<td>11.40</td>
<td>1.14</td>
<td>12.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544934</td>
<td>212794-C-WestConnex:2026-01-02 11:48:15</td>
<td>11.40</td>
<td>1.14</td>
<td>12.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544935</td>
<td>212794-C-Lane Cove Tunnel:2026-01-05 10:01:17</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544936</td>
<td>212794-C-WestConnex:2026-01-05 11:39:03</td>
<td>5.00</td>
<td>0.50</td>
<td>5.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544937</td>
<td>212794-C-M5 South West Motorway:2026-01-05 05:14:40</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 3 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th colspan="2" rowspan="2"></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544938</td>
<td>212794-C-M5 South West Motorway:2026-01-05 14:02:54</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544939</td>
<td>212794-C-WestConnex:2026-01-05 13:17:43</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544940</td>
<td>212794-C-WestConnex:2026-01-05 13:51:32</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544941</td>
<td>212794-C-Hills M2:2026-01-05 10:04:27</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544942</td>
<td>212794-C-WestLink M7:2026-01-06 13:51:55</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544943</td>
<td>212794-C-M5 South West Motorway:2026-01-06 05:10:03</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544944</td>
<td>212794-C-WestLink M7:2026-01-06 15:06:36</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544945</td>
<td>212794-C-Hills M2:2026-01-06 11:44:43</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544946</td>
<td>212794-C-Hills M2:2026-01-06 13:43:13</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544947</td>
<td>212794-C-WestConnex:2026-01-06 10:47:38</td>
<td>11.36</td>
<td>1.14</td>
<td>12.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544948</td>
<td>212794-C-Hills M2:2026-01-08 12:42:39</td>
<td>4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544949</td>
<td>212794-C-WestLink M7:2026-01-08 12:56:44</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544950</td>
<td>212794-C-North Connex:2026-01-08 12:42:29</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544951</td>
<td>212794-C-M5 South West Motorway:2026-01-12 04:33:02</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544952</td>
<td>212794-C-Hills M2:2026-01-12 06:22:19</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544953</td>
<td>212794-C-Hills M2:2026-01-12 10:47:08</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544954</td>
<td>212794-C-WestLink M7:2026-01-13 14:39:45</td>
<td>1.05</td>
<td>0.11</td>
<td>1.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544955</td>
<td>212794-C-WestLink M7:2026-01-13 14:52:53</td>
<td>1.47</td>
<td>0.15</td>
<td>1.62</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544956</td>
<td>212794-C-Lane Cove Tunnel:2026-01-13 10:41:45</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544957</td>
<td>212794-C-M5 South West Motorway:2026-01-13 04:11:04</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544958</td>
<td>212794-C-Hills M2:2026-01-13 10:44:56</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544959</td>
<td>212794-C-M5 South West Motorway:2026-01-15 14:45:53</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544960</td>
<td>212794-C-M5 South West Motorway:2026-01-15 05:10:19</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DJW39Q</td>
<td>FORD RANGER UTE</td>
<td>Ali Dandachli</td>
<td>4843544961</td>
<td>212794-C-WestLink M7:2026-01-15 11:15:28</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total for Cost Centre:</td>
<td>431.37</td>
<td>43.18</td>
<td>474.55</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">Cost Centre: 0759 352 3900 SSS</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549201</td>
<td>301011-C-Video Matching Fee : 2025-12-17 06:29:44</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549202</td>
<td>301011-C-Video Matching Fee : 2025-12-17 16:02:52</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549203</td>
<td>301011-C-WestLink M7 : 2025-12-17 16:02:52</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549204</td>
<td>301011-C-WestLink M7 : 2025-12-17 06:29:44</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549205</td>
<td>301011-C-Video Matching Fee : 2025-12-18 16:42:00</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549206</td>
<td>301011-C-Video Matching Fee : 2025-12-18 06:27:20</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549207</td>
<td>301011-C-WestLink M7 : 2025-12-18 16:42:00</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 4 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th></th>
<th></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549208</td>
<td>301011-C-WestLink M7 : 2025-12-18 06:27:20</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549209</td>
<td>301011-C-Video Matching Fee : 2025-12-26 14:27:42</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549210</td>
<td>301011-C-Video Matching Fee : 2025-12-26 14:35:21</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549211</td>
<td>301011-C-Video Matching Fee : 2025-12-26 15:02:51</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549212</td>
<td>301011-C-Video Matching Fee : 2025-12-26 09:24:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549213</td>
<td>301011-C-Video Matching Fee : 2025-12-26 09:30:25</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549214</td>
<td>301011-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-26</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549215</td>
<td>301011-C-M5 South West Motorway : 2025-12-26</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549216</td>
<td>301011-C-M5 South West Motorway : 2025-12-26</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549217</td>
<td>301011-C-WestConnex : 2025-12-26 14:35:21</td>
<td>7.69</td>
<td>0.77</td>
<td>8.46</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549218</td>
<td>301011-C-WestConnex : 2025-12-26 09:30:25</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549219</td>
<td>301011-C-Video Matching Fee : 2025-12-31 08:19:53</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549220</td>
<td>301011-C-WestLink M7 : 2025-12-31 08:19:53</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549221</td>
<td>301011-C-Video Matching Fee:2026-01-02 08:01:01</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549222</td>
<td>301011-C-Video Matching Fee:2026-01-02 08:07:25</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549223</td>
<td>301011-C-Video Matching Fee:2026-01-02 16:13:10</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549224</td>
<td>301011-C-Video Matching Fee:2026-01-02 16:29:41</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549225</td>
<td>301011-C-M5 South West Motorway:2026-01-02 08:01:01</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549226</td>
<td>301011-C-M5 South West Motorway:2026-01-02 16:29:41</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549227</td>
<td>301011-C-WestConnex:2026-01-02 08:07:25</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549228</td>
<td>301011-C-WestConnex:2026-01-02 16:13:10</td>
<td>11.40</td>
<td>1.14</td>
<td>12.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549229</td>
<td>301011-C-Video Matching Fee:2026-01-04 09:16:46</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549230</td>
<td>301011-C-Video Matching Fee:2026-01-04 10:42:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549231</td>
<td>301011-C-M5 South West Motorway:2026-01-04 09:16:46</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549232</td>
<td>301011-C-M5 South West Motorway:2026-01-04 10:42:18</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549233</td>
<td>301011-C-Video Matching Fee:2026-01-05 07:20:32</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549234</td>
<td>301011-C-Video Matching Fee:2026-01-05 16:22:31</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549235</td>
<td>301011-C-WestLink M7:2026-01-05 07:20:32</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549236</td>
<td>301011-C-WestLink M7:2026-01-05 16:22:31</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549237</td>
<td>301011-C-Video Matching Fee:2026-01-06 06:33:23</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549238</td>
<td>301011-C-Video Matching Fee:2026-01-06 16:28:52</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549239</td>
<td>301011-C-WestLink M7:2026-01-06 06:33:23</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549240</td>
<td>301011-C-WestLink M7:2026-01-06 16:28:52</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 5 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th></th>
<th></th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549241</td>
<td>301011-C-Video Matching Fee:2026-01-07 16:12:09</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549242</td>
<td>301011-C-Video Matching Fee:2026-01-07 06:28:06</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549243</td>
<td>301011-C-WestLink M7:2026-01-07 16:12:09</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549244</td>
<td>301011-C-WestLink M7:2026-01-07 06:28:06</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549245</td>
<td>301011-C-Video Matching Fee:2026-01-08 06:28:56</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549246</td>
<td>301011-C-Video Matching Fee:2026-01-08 16:26:51</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549247</td>
<td>301011-C-WestLink M7:2026-01-08 06:28:56</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549248</td>
<td>301011-C-WestLink M7:2026-01-08 16:26:51</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549249</td>
<td>301011-C-Video Matching Fee:2026-01-09 06:34:20</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549250</td>
<td>301011-C-Video Matching Fee:2026-01-09 15:48:51</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549251</td>
<td>301011-C-WestLink M7:2026-01-09 15:48:51</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549252</td>
<td>301011-C-WestLink M7:2026-01-09 06:34:20</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549253</td>
<td>301011-C-Video Matching Fee:2026-01-12 16:24:05</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549254</td>
<td>301011-C-Video Matching Fee:2026-01-12 06:37:06</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549255</td>
<td>301011-C-WestLink M7:2026-01-12 06:37:06</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549256</td>
<td>301011-C-WestLink M7:2026-01-12 16:24:05</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549257</td>
<td>301011-C-Video Matching Fee:2026-01-14 16:45:51</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549258</td>
<td>301011-C-Video Matching Fee:2026-01-14 06:31:19</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549259</td>
<td>301011-C-WestLink M7:2026-01-14 16:45:51</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549260</td>
<td>301011-C-WestLink M7:2026-01-14 06:31:19</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549261</td>
<td>301011-C-Video Matching Fee:2026-01-15 17:27:44</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549262</td>
<td>301011-C-Video Matching Fee:2026-01-15 06:23:43</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549263</td>
<td>301011-C-WestLink M7:2026-01-15 17:27:44</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DI34GQ</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Robert Hardman</td>
<td>4843549264</td>
<td>301011-C-WestLink M7:2026-01-15 06:23:43</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550601</td>
<td>305033-C-Video Matching Fee : 2025-12-11 08:07:09</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550602</td>
<td>305033-C-Video Matching Fee : 2025-12-11 16:58:46</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550603</td>
<td>305033-C-WestLink M7 : 2025-12-11 16:58:46</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550604</td>
<td>305033-C-Lane Cove Tunnel : 2025-12-11 08:07:09</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550605</td>
<td>305033-C-Video Matching Fee : 2025-12-15 08:02:29</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550606</td>
<td>305033-C-Video Matching Fee : 2025-12-15 08:14:12</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550607</td>
<td>305033-C-Video Matching Fee : 2025-12-15 15:20:47</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550608</td>
<td>305033-C-Lane Cove Tunnel : 2025-12-15 08:02:29</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550609</td>
<td>305033-C-Lane Cove Tunnel : 2025-12-15 15:20:47</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 6 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2" rowspan="2">Customer No. AU1166479</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td colspan="2">Net GST Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550610</td>
<td>305033-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-15</td>
<td colspan="2">4.01 0.40 4.41</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550611</td>
<td>305033-C-Video Matching Fee : 2025-12-17 13:39:42</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550612</td>
<td>305033-C-Video Matching Fee : 2025-12-17 07:50:30</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550613</td>
<td>305033-C-Video Matching Fee : 2025-12-17 07:50:40</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550614</td>
<td>305033-C-Video Matching Fee : 2025-12-17 11:39:18</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550615</td>
<td>305033-C-Video Matching Fee : 2025-12-17 11:55:37</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550616</td>
<td>305033-C-Video Matching Fee : 2025-12-17 07:56:41</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550617</td>
<td>305033-C-Video Matching Fee : 2025-12-17 11:29:42</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550618</td>
<td>305033-C-WestLink M7 : 2025-12-17 07:56:41</td>
<td>0.79 0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550619</td>
<td>305033-C-WestLink M7 : 2025-12-17 11:29:42</td>
<td colspan="2">0.79 0.08 0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550620</td>
<td>305033-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-17</td>
<td colspan="2">3.00 0.30 3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550621</td>
<td>305033-C-Lane Cove Tunnel : 2025-12-17 11:55:37</td>
<td colspan="2">3.78 0.38 4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550622</td>
<td>305033-C-Hills M2 : 2025-12-17 07:50:40</td>
<td colspan="2">4.66 0.47 5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550623</td>
<td>305033-C-North Connex : 2025-12-17 07:50:30</td>
<td colspan="2">9.32 0.93 10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550624</td>
<td>305033-C-Hills M2 : 2025-12-17 11:39:18</td>
<td colspan="2">9.32 0.93 10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550625</td>
<td>305033-C-Video Matching Fee : 2025-12-18 07:47:54</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550626</td>
<td>305033-C-Video Matching Fee : 2025-12-18 07:48:03</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550627</td>
<td>305033-C-Video Matching Fee : 2025-12-18 14:35:58</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550628</td>
<td>305033-C-Video Matching Fee : 2025-12-18 14:39:18</td>
<td>0.50 0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550629</td>
<td>305033-C-Video Matching Fee : 2025-12-18 07:53:38</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550630</td>
<td>305033-C-Video Matching Fee : 2025-12-18 14:27:18</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550631</td>
<td>305033-C-WestLink M7 : 2025-12-18 07:53:38</td>
<td colspan="2">0.79 0.08 0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550632</td>
<td>305033-C-WestLink M7 : 2025-12-18 14:27:18</td>
<td colspan="2">0.79 0.08 0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550633</td>
<td>305033-C-Lane Cove Tunnel : 2025-12-18 14:39:18</td>
<td colspan="2">3.78 0.38 4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550634</td>
<td>305033-C-Hills M2 : 2025-12-18 07:48:03</td>
<td colspan="2">4.66 0.47 5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550635</td>
<td>305033-C-North Connex : 2025-12-18 07:47:54</td>
<td colspan="2">9.32 0.93 10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550636</td>
<td>305033-C-Hills M2 : 2025-12-18 14:35:58</td>
<td colspan="2">9.32 0.93 10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550637</td>
<td>305033-C-Video Matching Fee : 2025-12-19 06:14:31</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550638</td>
<td>305033-C-Video Matching Fee : 2025-12-19 06:19:05</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550639</td>
<td>305033-C-Video Matching Fee : 2025-12-19 06:22:50</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550640</td>
<td>305033-C-Lane Cove Tunnel : 2025-12-19 06:22:50</td>
<td colspan="2">3.78 0.38 4.16</td>
</tr>
<tr>
<td colspan="2">NSW DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550641</td>
<td>305033-C-North Connex : 2025-12-19 06:14:31</td>
<td colspan="2">9.32 0.93 10.25</td>
</tr>
<tr>
<td colspan="2">NSW DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550642</td>
<td>305033-C-Hills M2 : 2025-12-19 06:19:05</td>
<td colspan="2">9.32 0.93 10.25</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 7 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2" rowspan="2">Customer No. AU1166479</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2">P</th>
</tr>
<tr>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net GST Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550643</td>
<td>305033-C-Video Matching Fee:2026-01-05 11:47:57</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550644</td>
<td>305033-C-Video Matching Fee:2026-01-05 11:51:25</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550645</td>
<td>305033-C-Video Matching Fee:2026-01-05 07:48:54</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550646</td>
<td>305033-C-Video Matching Fee:2026-01-05 07:49:04</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550647</td>
<td>305033-C-Video Matching Fee:2026-01-05 11:37:51</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550648</td>
<td>305033-C-Video Matching Fee:2026-01-05 07:54:37</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550649</td>
<td>305033-C-WestLink M7:2026-01-05 07:54:37</td>
<td>0.80 0.08 0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550650</td>
<td>305033-C-WestLink M7:2026-01-05 11:37:51</td>
<td>0.80 0.08 0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550651</td>
<td>305033-C-Lane Cove Tunnel:2026-01-05 11:51:25</td>
<td>3.84 0.38 4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550652</td>
<td>305033-C-Hills M2:2026-01-05 07:49:04</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550653</td>
<td>305033-C-North Connex:2026-01-05 07:48:54</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550654</td>
<td>305033-C-Hills M2:2026-01-05 11:47:57</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550655</td>
<td>305033-C-Video Matching Fee:2026-01-06 07:30:56</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550656</td>
<td>305033-C-Video Matching Fee:2026-01-06 07:35:41</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550657</td>
<td>305033-C-Video Matching Fee:2026-01-06 07:39:21</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550658</td>
<td>305033-C-Lane Cove Tunnel:2026-01-06 07:39:21</td>
<td>3.84 0.38 4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550659</td>
<td>305033-C-North Connex:2026-01-06 07:30:56</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550660</td>
<td>305033-C-Hills M2:2026-01-06 07:35:41</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550661</td>
<td>305033-C-Video Matching Fee:2026-01-07 07:39:35</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550662</td>
<td>305033-C-Video Matching Fee:2026-01-07 07:44:12</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550663</td>
<td>305033-C-Video Matching Fee:2026-01-07 07:47:56</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550664</td>
<td>305033-C-Lane Cove Tunnel:2026-01-07 07:47:56</td>
<td>3.84 0.38 4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550665</td>
<td>305033-C-North Connex:2026-01-07 07:39:35</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550666</td>
<td>305033-C-Hills M2:2026-01-07 07:44:12</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550667</td>
<td>305033-C-Video Matching Fee:2026-01-08 06:05:27</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550668</td>
<td>305033-C-Video Matching Fee:2026-01-08 06:09:50</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550669</td>
<td>305033-C-Video Matching Fee:2026-01-08 06:13:29</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550670</td>
<td>305033-C-Video Matching Fee:2026-01-08 06:21:53</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550671</td>
<td>305033-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-08</td>
<td>2.51 0.25 2.76</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550672</td>
<td>305033-C-Lane Cove Tunnel:2026-01-08 06:13:29</td>
<td>3.84 0.38 4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550673</td>
<td>305033-C-North Connex:2026-01-08 06:05:27</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550674</td>
<td>305033-C-Hills M2:2026-01-08 06:09:50</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td colspan="2">NSW DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550675</td>
<td>305033-C-Video Matching Fee:2026-01-09 08:15:07</td>
<td>0.50 0.05 0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 8 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2" rowspan="2">Customer No. AU1166479</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2">P</th>
</tr>
<tr>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net GST Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550676</td>
<td>305033-C-Video Matching Fee:2026-01-09 08:15:16</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550677</td>
<td>305033-C-Video Matching Fee:2026-01-09 08:55:14</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550678</td>
<td>305033-C-Hills M2:2026-01-09 08:15:16</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550679</td>
<td>305033-C-North Connex:2026-01-09 08:15:07</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550680</td>
<td>305033-C-WestConnex:2026-01-09 08:55:14</td>
<td>9.80 0.98 10.78</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550681</td>
<td>305033-C-Video Matching Fee:2026-01-12 14:32:57</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550682</td>
<td>305033-C-Video Matching Fee:2026-01-12 07:40:31</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550683</td>
<td>305033-C-North Connex:2026-01-12 07:40:31</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550684</td>
<td>305033-C-North Connex:2026-01-12 14:32:57</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550685</td>
<td>305033-C-Video Matching Fee:2026-01-13 06:29:54</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550686</td>
<td>305033-C-North Connex:2026-01-13 06:29:54</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550687</td>
<td>305033-C-Video Matching Fee:2026-01-14 06:45:21</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550688</td>
<td>305033-C-North Connex:2026-01-14 06:45:21</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550689</td>
<td>305033-C-Video Matching Fee:2026-01-15 07:53:47</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550690</td>
<td>305033-C-Video Matching Fee:2026-01-15 07:58:54</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550691</td>
<td>305033-C-Video Matching Fee:2026-01-15 16:34:04</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550692</td>
<td>305033-C-North Connex:2026-01-15 07:53:47</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550693</td>
<td>305033-C-Hills M2:2026-01-15 16:34:04</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK42LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Cody Davis</td>
<td>4843550694</td>
<td>305033-C-Hills M2:2026-01-15 07:58:54</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550501</td>
<td>305032-C-Video Matching Fee : 2025-12-10 22:03:26</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550502</td>
<td>305032-C-Video Matching Fee : 2025-12-10 20:13:26</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550503</td>
<td>305032-C-WestLink M7 : 2025-12-10 20:13:26</td>
<td>0.79 0.08 0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550504</td>
<td>305032-C-Lane Cove Tunnel : 2025-12-10 22:03:26</td>
<td>3.78 0.38 4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550505</td>
<td>305032-C-Video Matching Fee : 2025-12-16 15:37:54</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550506</td>
<td>305032-C-Video Matching Fee : 2025-12-16 15:41:57</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550507</td>
<td>305032-C-Video Matching Fee : 2025-12-16 14:00:18</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550508</td>
<td>305032-C-Video Matching Fee : 2025-12-16 14:03:51</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550509</td>
<td>305032-C-Video Matching Fee : 2025-12-16 13:50:45</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550510</td>
<td>305032-C-WestLink M7 : 2025-12-16 13:50:45</td>
<td>0.79 0.08 0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550511</td>
<td>305032-C-Lane Cove Tunnel : 2025-12-16 14:03:51</td>
<td>3.78 0.38 4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550512</td>
<td>305032-C-Lane Cove Tunnel : 2025-12-16 15:37:54</td>
<td>3.78 0.38 4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550513</td>
<td>305032-C-Hills M2 : 2025-12-16 14:00:18</td>
<td>9.32 0.93 10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550514</td>
<td>305032-C-Hills M2 : 2025-12-16 15:41:57</td>
<td>9.32 0.93 10.25</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 9 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550515</td>
<td>305032-C-Video Matching Fee : 2025-12-19 12:01:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550516</td>
<td>305032-C-Video Matching Fee : 2025-12-19 13:25:37</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550517</td>
<td>305032-C-WestConnex : 2025-12-19 13:25:37</td>
<td>7.28</td>
<td>0.73</td>
<td>8.01</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550518</td>
<td>305032-C-WestConnex : 2025-12-19 12:01:02</td>
<td>9.44</td>
<td>0.94</td>
<td>10.38</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550519</td>
<td>305032-C-Video Matching Fee : 2025-12-21 21:16:21</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550520</td>
<td>305032-C-Video Matching Fee : 2025-12-21 15:21:07</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550521</td>
<td>305032-C-WestConnex : 2025-12-21 15:21:07</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550522</td>
<td>305032-C-WestConnex : 2025-12-21 21:16:21</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550523</td>
<td>305032-C-Video Matching Fee : 2025-12-22 08:16:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550524</td>
<td>305032-C-Video Matching Fee : 2025-12-22 09:01:38</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550525</td>
<td>305032-C-Video Matching Fee : 2025-12-22 10:04:59</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550526</td>
<td>305032-C-WestConnex : 2025-12-22 08:16:20</td>
<td>3.79</td>
<td>0.38</td>
<td>4.17</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550527</td>
<td>305032-C-WestConnex : 2025-12-22 09:01:38</td>
<td>6.85</td>
<td>0.69</td>
<td>7.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550528</td>
<td>305032-C-WestConnex : 2025-12-22 10:04:59</td>
<td>9.44</td>
<td>0.94</td>
<td>10.38</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550529</td>
<td>305032-C-Video Matching Fee : 2025-12-27 16:29:00</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550530</td>
<td>305032-C-Video Matching Fee : 2025-12-27 17:56:45</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550531</td>
<td>305032-C-Video Matching Fee : 2025-12-27 21:27:12</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550532</td>
<td>305032-C-Video Matching Fee : 2025-12-27 21:41:54</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550533</td>
<td>305032-C-WestConnex : 2025-12-27 21:27:12</td>
<td>4.88</td>
<td>0.49</td>
<td>5.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550534</td>
<td>305032-C-WestConnex : 2025-12-27 21:41:54</td>
<td>4.88</td>
<td>0.49</td>
<td>5.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550535</td>
<td>305032-C-WestConnex : 2025-12-27 16:29:00</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550536</td>
<td>305032-C-WestConnex : 2025-12-27 17:56:45</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550537</td>
<td>305032-C-Video Matching Fee : 2025-12-28 10:48:45</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550538</td>
<td>305032-C-Video Matching Fee : 2025-12-28 11:08:10</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550539</td>
<td>305032-C-Video Matching Fee : 2025-12-28 06:36:38</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550540</td>
<td>305032-C-Video Matching Fee : 2025-12-28 09:03:24</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550541</td>
<td>305032-C-WestConnex : 2025-12-28 10:48:45</td>
<td>4.88</td>
<td>0.49</td>
<td>5.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550542</td>
<td>305032-C-WestConnex : 2025-12-28 11:08:10</td>
<td>4.88</td>
<td>0.49</td>
<td>5.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550543</td>
<td>305032-C-WestConnex : 2025-12-28 06:36:38</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550544</td>
<td>305032-C-WestConnex : 2025-12-28 09:03:24</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550545</td>
<td>305032-C-Video Matching Fee : 2025-12-29 11:10:12</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550546</td>
<td>305032-C-Video Matching Fee : 2025-12-29 11:12:41</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550547</td>
<td>305032-C-Video Matching Fee : 2025-12-29 13:02:55</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 10 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2" rowspan="2">Customer No. AU1166479</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td colspan="2">Net GST Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550548</td>
<td>305032-C-Hills M2 : 2025-12-29 11:10:12</td>
<td colspan="2">3.30 0.33 3.63</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550549</td>
<td>305032-C-WestLink M7 : 2025-12-29 13:02:55</td>
<td colspan="2">3.56 0.36 3.92</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550550</td>
<td>305032-C-WestLink M7 : 2025-12-29 11:12:41</td>
<td colspan="2">5.53 0.55 6.08</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550551</td>
<td>305032-C-Video Matching Fee : 2025-12-30 09:54:49</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550552</td>
<td>305032-C-WestLink M7 : 2025-12-30 09:42:07</td>
<td colspan="2">0.63 0.06 0.69</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550553</td>
<td>305032-C-Video Matching Fee : 2025-12-30 09:42:07</td>
<td>0.68 0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550554</td>
<td>305032-C-WestConnex : 2025-12-30 09:54:49</td>
<td colspan="2">2.66 0.27 2.93</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550555</td>
<td>305032-C-Video Matching Fee : 2025-12-31 12:15:56</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550556</td>
<td>305032-C-Video Matching Fee : 2025-12-31 08:00:42</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550557</td>
<td>305032-C-WestConnex : 2025-12-31 12:15:56</td>
<td colspan="2">4.16 0.42 4.58</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550558</td>
<td>305032-C-WestConnex : 2025-12-31 08:00:42</td>
<td colspan="2">4.16 0.42 4.58</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550559</td>
<td>305032-C-Video Matching Fee:2026-01-02 15:41:44</td>
<td>0.50 0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550560</td>
<td>305032-C-Video Matching Fee:2026-01-02 08:16:32</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550561</td>
<td>305032-C-Video Matching Fee:2026-01-02 11:07:55</td>
<td>0.50 0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550562</td>
<td>305032-C-Video Matching Fee:2026-01-02 12:14:45</td>
<td>0.50 0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550563</td>
<td>305032-C-WestConnex:2026-01-02 11:07:55</td>
<td colspan="2">4.34 0.43 4.77</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550564</td>
<td>305032-C-WestConnex:2026-01-02 15:41:44</td>
<td colspan="2">5.07 0.51 5.58</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550565</td>
<td>305032-C-WestConnex:2026-01-02 12:14:45</td>
<td colspan="2">5.07 0.51 5.58</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550566</td>
<td>305032-C-WestConnex:2026-01-02 08:16:32</td>
<td colspan="2">6.14 0.61 6.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550567</td>
<td>305032-C-Video Matching Fee:2026-01-03 07:04:46</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550568</td>
<td>305032-C-Video Matching Fee:2026-01-03 09:36:40</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550569</td>
<td>305032-C-WestConnex:2026-01-03 07:04:46</td>
<td colspan="2">5.07 0.51 5.58</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550570</td>
<td>305032-C-WestConnex:2026-01-03 09:36:40</td>
<td colspan="2">5.07 0.51 5.58</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550571</td>
<td>305032-C-Video Matching Fee:2026-01-08 15:05:26</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550572</td>
<td>305032-C-WestConnex:2026-01-08 15:05:26</td>
<td colspan="2">2.77 0.28 3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550573</td>
<td>305032-C-Video Matching Fee:2026-01-09 18:32:24</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550574</td>
<td>305032-C-Video Matching Fee:2026-01-09 21:53:11</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550575</td>
<td>305032-C-WestConnex:2026-01-09 18:32:24</td>
<td colspan="2">4.34 0.43 4.77</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550576</td>
<td>305032-C-WestConnex:2026-01-09 21:53:11</td>
<td colspan="2">4.34 0.43 4.77</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550577</td>
<td>305032-C-Video Matching Fee:2026-01-13 15:44:49</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550578</td>
<td>305032-C-WestConnex:2026-01-13 15:44:49</td>
<td colspan="2">2.77 0.28 3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550579</td>
<td>305032-C-Video Matching Fee:2026-01-14 16:18:22</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Nitin Jambhale</td>
<td>4843550580</td>
<td>305032-C-WestConnex:2026-01-14 16:18:22</td>
<td colspan="2">2.77 0.28 3.05</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 11 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2" rowspan="2">Customer No. AU1166479</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td colspan="2">Net GST Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550201</td>
<td>305029-C-Video Matching Fee:2026-01-05 06:42:06</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550202</td>
<td>305029-C-Video Matching Fee:2026-01-05 13:52:35</td>
<td>0.68 0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550203</td>
<td>305029-C-WestLink M7:2026-01-05 13:52:35</td>
<td>9.36 0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550204</td>
<td>305029-C-WestLink M7:2026-01-05 06:42:06</td>
<td colspan="2">9.36 0.94 10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550205</td>
<td>305029-C-Video Matching Fee:2026-01-06 16:06:45</td>
<td>0.68 0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550206</td>
<td>305029-C-Video Matching Fee:2026-01-06 05:37:24</td>
<td>0.68 0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550207</td>
<td>305029-C-WestLink M7:2026-01-06 05:37:24</td>
<td>7.17 0.72</td>
<td>7.89</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550208</td>
<td>305029-C-WestLink M7:2026-01-06 16:06:45</td>
<td colspan="2">8.65 0.87 9.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550209</td>
<td>305029-C-Video Matching Fee:2026-01-07 05:42:48</td>
<td>0.68 0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550210</td>
<td>305029-C-Video Matching Fee:2026-01-07 14:54:24</td>
<td>0.68 0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550211</td>
<td>305029-C-Video Matching Fee:2026-01-07 11:24:09</td>
<td>0.68 0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550212</td>
<td>305029-C-WestLink M7:2026-01-07 11:24:09</td>
<td>4.25 0.43</td>
<td>4.68</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550213</td>
<td>305029-C-WestLink M7:2026-01-07 05:42:48</td>
<td colspan="2">7.17 0.72 7.89</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550214</td>
<td>305029-C-WestLink M7:2026-01-07 14:54:24</td>
<td colspan="2">9.36 0.94 10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550215</td>
<td>305029-C-Video Matching Fee:2026-01-08 11:37:04</td>
<td>0.68 0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550216</td>
<td>305029-C-Video Matching Fee:2026-01-08 12:52:57</td>
<td>0.68 0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550217</td>
<td>305029-C-Video Matching Fee:2026-01-08 14:43:58</td>
<td>0.68 0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550218</td>
<td>305029-C-Video Matching Fee:2026-01-08 05:40:39</td>
<td>0.68 0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550219</td>
<td>305029-C-WestLink M7:2026-01-08 11:37:04</td>
<td colspan="2">4.25 0.43 4.68</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550220</td>
<td>305029-C-WestLink M7:2026-01-08 12:52:57</td>
<td colspan="2">4.25 0.43 4.68</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550221</td>
<td>305029-C-WestLink M7:2026-01-08 05:40:39</td>
<td colspan="2">7.17 0.72 7.89</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550222</td>
<td>305029-C-WestLink M7:2026-01-08 14:43:58</td>
<td colspan="2">8.65 0.87 9.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550223</td>
<td>305029-C-Video Matching Fee:2026-01-09 15:41:42</td>
<td>0.50 0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550224</td>
<td>305029-C-WestLink M7:2026-01-09 15:54:20</td>
<td>0.64 0.06</td>
<td>0.70</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550225</td>
<td>305029-C-Video Matching Fee:2026-01-09 15:54:20</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550226</td>
<td>305029-C-Video Matching Fee:2026-01-09 15:09:05</td>
<td>0.68 0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550227</td>
<td>305029-C-Video Matching Fee:2026-01-09 12:37:43</td>
<td>0.68 0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550228</td>
<td>305029-C-Video Matching Fee:2026-01-09 18:00:36</td>
<td>0.68 0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550229</td>
<td>305029-C-Video Matching Fee:2026-01-09 05:40:29</td>
<td>0.68 0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550230</td>
<td>305029-C-WestConnex:2026-01-09 15:41:42</td>
<td colspan="2">2.77 0.28 3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550231</td>
<td>305029-C-WestLink M7:2026-01-09 15:09:05</td>
<td colspan="2">3.61 0.36 3.97</td>
</tr>
<tr>
<td colspan="2">NSW DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550232</td>
<td>305029-C-WestLink M7:2026-01-09 12:37:43</td>
<td colspan="2">4.25 0.43 4.68</td>
</tr>
<tr>
<td colspan="2">NSW DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550233</td>
<td>305029-C-WestLink M7:2026-01-09 05:40:29</td>
<td colspan="2">7.17 0.72 7.89</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 12 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550234</td>
<td>305029-C-WestLink M7:2026-01-09 18:00:36</td>
<td>8.65</td>
<td>0.87</td>
<td>9.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550235</td>
<td>305029-C-Video Matching Fee:2026-01-12 15:32:44</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550236</td>
<td>305029-C-Video Matching Fee:2026-01-12 05:44:10</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550237</td>
<td>305029-C-WestLink M7:2026-01-12 05:44:10</td>
<td>7.17</td>
<td>0.72</td>
<td>7.89</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550238</td>
<td>305029-C-WestLink M7:2026-01-12 15:32:44</td>
<td>8.65</td>
<td>0.87</td>
<td>9.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550239</td>
<td>305029-C-Video Matching Fee:2026-01-13 15:28:18</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550240</td>
<td>305029-C-Video Matching Fee:2026-01-13 05:41:46</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550241</td>
<td>305029-C-WestLink M7:2026-01-13 05:41:46</td>
<td>7.17</td>
<td>0.72</td>
<td>7.89</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550242</td>
<td>305029-C-WestLink M7:2026-01-13 15:28:18</td>
<td>8.65</td>
<td>0.87</td>
<td>9.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550243</td>
<td>305029-C-Video Matching Fee:2026-01-14 05:41:15</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550244</td>
<td>305029-C-Video Matching Fee:2026-01-14 14:01:46</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550245</td>
<td>305029-C-WestLink M7:2026-01-14 14:01:46</td>
<td>7.17</td>
<td>0.72</td>
<td>7.89</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550246</td>
<td>305029-C-WestLink M7:2026-01-14 05:41:15</td>
<td>7.17</td>
<td>0.72</td>
<td>7.89</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550247</td>
<td>305029-C-Video Matching Fee:2026-01-15 05:42:09</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550248</td>
<td>305029-C-Video Matching Fee:2026-01-15 16:04:09</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550249</td>
<td>305029-C-WestLink M7:2026-01-15 05:42:09</td>
<td>7.17</td>
<td>0.72</td>
<td>7.89</td>
</tr>
<tr>
<td>NSW</td>
<td>DK47LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Travis Thomson</td>
<td>4843550250</td>
<td>305029-C-WestLink M7:2026-01-15 16:04:09</td>
<td>8.65</td>
<td>0.87</td>
<td>9.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550701</td>
<td>305034-C-Video Matching Fee : 2025-12-16 05:55:03</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550702</td>
<td>305034-C-Video Matching Fee : 2025-12-16 05:55:56</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550703</td>
<td>305034-C-Video Matching Fee : 2025-12-16 13:04:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550704</td>
<td>305034-C-Video Matching Fee : 2025-12-16 13:09:48</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550705</td>
<td>305034-C-WestConnex : 2025-12-16 13:04:36</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550706</td>
<td>305034-C-M5 South West Motorway : 2025-12-16</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550707</td>
<td>305034-C-Cross City Tunnel : 2025-12-16 05:55:56</td>
<td>6.52</td>
<td>0.65</td>
<td>7.17</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550708</td>
<td>305034-C-Eastern Distributor : 2025-12-16 05:55:03</td>
<td>9.24</td>
<td>0.92</td>
<td>10.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550709</td>
<td>305034-C-M5 South West Motorway : 2025-12-17</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550710</td>
<td>305034-C-Eastern Distributor : 2025-12-17 08:11:24</td>
<td>9.24</td>
<td>0.92</td>
<td>10.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550711</td>
<td>305034-C-WestConnex : 2025-12-17 16:14:16</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550712</td>
<td>305034-C-WestLink M7 : 2025-12-18 14:25:18</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550713</td>
<td>305034-C-Hills M2 : 2025-12-18 14:27:44</td>
<td>3.30</td>
<td>0.33</td>
<td>3.63</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550714</td>
<td>305034-C-M5 South West Motorway : 2025-12-18</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550715</td>
<td>305034-C-WestLink M7 : 2025-12-18 07:25:37</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550716</td>
<td>305034-C-WestConnex : 2025-12-18 14:41:28</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 13 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th colspan="2"></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550717</td>
<td>305034-C-Video Matching Fee : 2025-12-19 07:53:46</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550718</td>
<td>305034-C-M5 South West Motorway : 2025-12-19</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550719</td>
<td>305034-C-Cross City Tunnel : 2025-12-19 07:53:46</td>
<td>6.52</td>
<td>0.65</td>
<td>7.17</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550720</td>
<td>305034-C-Cross City Tunnel : 2025-12-19 15:10:38</td>
<td>6.52</td>
<td>0.65</td>
<td>7.17</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550721</td>
<td>305034-C-WestConnex : 2025-12-19 15:37:01</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550722</td>
<td>305034-C-Eastern Distributor : 2025-12-19 07:52:51</td>
<td>9.24</td>
<td>0.92</td>
<td>10.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550723</td>
<td>305034-C-Video Matching Fee : 2025-12-29 13:12:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550724</td>
<td>305034-C-M5 South West Motorway : 2025-12-29</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550725</td>
<td>305034-C-Video Matching Fee:2026-01-05 11:37:11</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550726</td>
<td>305034-C-Video Matching Fee:2026-01-05 11:44:58</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550727</td>
<td>305034-C-Video Matching Fee:2026-01-05 11:33:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550728</td>
<td>305034-C-Video Matching Fee:2026-01-05 11:22:32</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550729</td>
<td>305034-C-WestLink M7:2026-01-05 11:22:32</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550730</td>
<td>305034-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-05</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550731</td>
<td>305034-C-Lane Cove Tunnel:2026-01-05 11:37:11</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550732</td>
<td>305034-C-Hills M2:2026-01-05 11:33:31</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550733</td>
<td>305034-C-Video Matching Fee:2026-01-06 07:46:56</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550734</td>
<td>305034-C-Video Matching Fee:2026-01-06 07:39:50</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550735</td>
<td>305034-C-M5 South West Motorway:2026-01-06 07:39:50</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550736</td>
<td>305034-C-WestConnex:2026-01-06 07:46:56</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550737</td>
<td>305034-C-Video Matching Fee:2026-01-08 17:32:52</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550738</td>
<td>305034-C-WestConnex:2026-01-08 17:32:52</td>
<td>6.97</td>
<td>0.70</td>
<td>7.67</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550739</td>
<td>305034-C-Video Matching Fee:2026-01-09 10:52:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550740</td>
<td>305034-C-Video Matching Fee:2026-01-09 10:59:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550741</td>
<td>305034-C-Video Matching Fee:2026-01-09 16:47:42</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550742</td>
<td>305034-C-Video Matching Fee:2026-01-09 16:36:07</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550743</td>
<td>305034-C-M5 South West Motorway:2026-01-09 10:52:32</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550744</td>
<td>305034-C-M5 South West Motorway:2026-01-09 16:47:42</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550745</td>
<td>305034-C-WestConnex:2026-01-09 10:59:18</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550746</td>
<td>305034-C-WestConnex:2026-01-09 16:36:07</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550747</td>
<td>305034-C-Video Matching Fee:2026-01-14 14:29:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550748</td>
<td>305034-C-M5 South West Motorway:2026-01-14 14:39:42</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK48LZ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>John Di Giacomo</td>
<td>4843550749</td>
<td>305034-C-WestConnex:2026-01-14 14:29:36</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 14 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th colspan="2"></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550901</td>
<td>305226-C-Video Matching Fee : 2025-12-08 17:05:42</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550902</td>
<td>305226-C-WestLink M7 : 2025-12-08 17:05:42</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550903</td>
<td>305226-C-Video Matching Fee : 2025-12-11 17:23:37</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550904</td>
<td>305226-C-WestLink M7 : 2025-12-11 17:23:37</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550905</td>
<td>305226-C-Video Matching Fee : 2025-12-13 09:36:57</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550906</td>
<td>305226-C-Video Matching Fee : 2025-12-13 10:45:35</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550907</td>
<td>305226-C-WestLink M7 : 2025-12-13 09:36:57</td>
<td>2.15</td>
<td>0.22</td>
<td>2.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550908</td>
<td>305226-C-WestLink M7 : 2025-12-13 10:45:35</td>
<td>2.15</td>
<td>0.22</td>
<td>2.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550909</td>
<td>305226-C-Video Matching Fee : 2025-12-15 15:54:24</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550910</td>
<td>305226-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-15</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550911</td>
<td>305226-C-Video Matching Fee : 2025-12-16 09:02:04</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550912</td>
<td>305226-C-Video Matching Fee : 2025-12-16 15:58:14</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550913</td>
<td>305226-C-Video Matching Fee : 2025-12-16 16:09:57</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550914</td>
<td>305226-C-Video Matching Fee : 2025-12-16 15:31:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550915</td>
<td>305226-C-Video Matching Fee : 2025-12-16 15:20:59</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550916</td>
<td>305226-C-WestLink M7 : 2025-12-16 15:20:59</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550917</td>
<td>305226-C-Lane Cove Tunnel : 2025-12-16 15:58:14</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550918</td>
<td>305226-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-16</td>
<td>4.01</td>
<td>0.40</td>
<td>4.41</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550919</td>
<td>305226-C-Hills M2 : 2025-12-16 15:31:34</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550920</td>
<td>305226-C-WestConnex : 2025-12-16 09:02:04</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550921</td>
<td>305226-C-Video Matching Fee : 2025-12-17 08:14:41</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550922</td>
<td>305226-C-Video Matching Fee : 2025-12-17 08:17:52</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550923</td>
<td>305226-C-Video Matching Fee : 2025-12-17 16:47:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550924</td>
<td>305226-C-Video Matching Fee : 2025-12-17 16:33:22</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550925</td>
<td>305226-C-Video Matching Fee : 2025-12-17 16:36:35</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550926</td>
<td>305226-C-Video Matching Fee : 2025-12-17 08:26:48</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550927</td>
<td>305226-C-Video Matching Fee : 2025-12-17 16:24:13</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550928</td>
<td>305226-C-WestLink M7 : 2025-12-17 08:26:48</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550929</td>
<td>305226-C-WestLink M7 : 2025-12-17 16:24:13</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550930</td>
<td>305226-C-Lane Cove Tunnel : 2025-12-17 08:14:41</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550931</td>
<td>305226-C-Lane Cove Tunnel : 2025-12-17 16:36:35</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550932</td>
<td>305226-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-17</td>
<td>4.01</td>
<td>0.40</td>
<td>4.41</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550933</td>
<td>305226-C-Hills M2 : 2025-12-17 16:33:22</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 15 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550934</td>
<td>305226-C-Hills M2 : 2025-12-17 08:17:52</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550935</td>
<td>305226-C-Video Matching Fee : 2025-12-18 09:50:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550936</td>
<td>305226-C-Video Matching Fee : 2025-12-18 09:53:05</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550937</td>
<td>305226-C-Video Matching Fee : 2025-12-18 17:46:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550938</td>
<td>305226-C-Video Matching Fee : 2025-12-18 17:49:39</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550939</td>
<td>305226-C-Video Matching Fee : 2025-12-18 18:04:49</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550940</td>
<td>305226-C-Video Matching Fee : 2025-12-18 10:01:38</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550941</td>
<td>305226-C-Video Matching Fee : 2025-12-18 17:38:06</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550942</td>
<td>305226-C-WestLink M7 : 2025-12-18 10:01:38</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550943</td>
<td>305226-C-WestLink M7 : 2025-12-18 17:38:06</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550944</td>
<td>305226-C-Lane Cove Tunnel : 2025-12-18 17:49:39</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550945</td>
<td>305226-C-Lane Cove Tunnel : 2025-12-18 09:50:16</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550946</td>
<td>305226-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-18</td>
<td>4.01</td>
<td>0.40</td>
<td>4.41</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550947</td>
<td>305226-C-Hills M2 : 2025-12-18 09:53:05</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550948</td>
<td>305226-C-Hills M2 : 2025-12-18 17:46:31</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550949</td>
<td>305226-C-Video Matching Fee : 2025-12-20 09:05:11</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550950</td>
<td>305226-C-Video Matching Fee : 2025-12-20 14:35:27</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550951</td>
<td>305226-C-Video Matching Fee : 2025-12-20 14:47:23</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550952</td>
<td>305226-C-Video Matching Fee : 2025-12-20 16:34:54</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550953</td>
<td>305226-C-Video Matching Fee : 2025-12-20 19:18:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550954</td>
<td>305226-C-Video Matching Fee : 2025-12-20 10:25:49</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550955</td>
<td>305226-C-Video Matching Fee : 2025-12-20 14:25:55</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550956</td>
<td>305226-C-Video Matching Fee : 2025-12-20 12:37:16</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550957</td>
<td>305226-C-WestLink M7 : 2025-12-20 14:25:55</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550958</td>
<td>305226-C-WestLink M7 : 2025-12-20 10:25:49</td>
<td>2.15</td>
<td>0.22</td>
<td>2.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550959</td>
<td>305226-C-WestLink M7 : 2025-12-20 12:37:16</td>
<td>2.15</td>
<td>0.22</td>
<td>2.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550960</td>
<td>305226-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-20</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550961</td>
<td>305226-C-Lane Cove Tunnel : 2025-12-20 14:38:46</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550962</td>
<td>305226-C-WestConnex : 2025-12-20 16:34:54</td>
<td>6.31</td>
<td>0.63</td>
<td>6.94</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550963</td>
<td>305226-C-WestConnex : 2025-12-20 19:18:31</td>
<td>6.31</td>
<td>0.63</td>
<td>6.94</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550964</td>
<td>305226-C-Hills M2 : 2025-12-20 14:35:27</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550965</td>
<td>305226-C-WestConnex : 2025-12-20 09:05:11</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550966</td>
<td>305226-C-Video Matching Fee : 2025-12-23 18:54:04</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 16 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th colspan="2"></th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550967</td>
<td>305226-C-Video Matching Fee : 2025-12-23 20:11:22</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550968</td>
<td>305226-C-WestConnex : 2025-12-23 18:54:04</td>
<td>9.43</td>
<td>0.94</td>
<td>10.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550969</td>
<td>305226-C-WestConnex : 2025-12-23 20:11:22</td>
<td>9.43</td>
<td>0.94</td>
<td>10.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550970</td>
<td>305226-C-Video Matching Fee : 2025-12-27 09:42:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550971</td>
<td>305226-C-Video Matching Fee : 2025-12-27 11:51:44</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550972</td>
<td>305226-C-WestConnex : 2025-12-27 11:51:44</td>
<td>9.43</td>
<td>0.94</td>
<td>10.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550973</td>
<td>305226-C-WestConnex : 2025-12-27 09:42:18</td>
<td>9.43</td>
<td>0.94</td>
<td>10.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550974</td>
<td>305226-C-Video Matching Fee : 2025-12-30 14:09:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550975</td>
<td>305226-C-Video Matching Fee : 2025-12-30 14:12:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550976</td>
<td>305226-C-Video Matching Fee : 2025-12-30 14:17:37</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550977</td>
<td>305226-C-Lane Cove Tunnel : 2025-12-30 14:09:02</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550978</td>
<td>305226-C-North Connex : 2025-12-30 14:17:37</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550979</td>
<td>305226-C-Hills M2 : 2025-12-30 14:12:18</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550980</td>
<td>305226-C-Video Matching Fee:2026-01-01 15:28:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550981</td>
<td>305226-C-Video Matching Fee:2026-01-01 15:32:46</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550982</td>
<td>305226-C-Video Matching Fee:2026-01-01 15:56:13</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550983</td>
<td>305226-C-Video Matching Fee:2026-01-01 15:58:53</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550984</td>
<td>305226-C-Video Matching Fee:2026-01-01 16:07:25</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550985</td>
<td>305226-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-01</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550986</td>
<td>305226-C-Lane Cove Tunnel:2026-01-01 15:58:53</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550987</td>
<td>305226-C-Hills M2:2026-01-01 15:56:13</td>
<td>4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550988</td>
<td>305226-C-North Connex:2026-01-01 15:28:34</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550989</td>
<td>305226-C-Hills M2:2026-01-01 15:32:46</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550990</td>
<td>305226-C-Video Matching Fee:2026-01-03 11:05:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550991</td>
<td>305226-C-Video Matching Fee:2026-01-03 22:45:06</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550992</td>
<td>305226-C-WestConnex:2026-01-03 11:05:36</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550993</td>
<td>305226-C-WestConnex:2026-01-03 22:45:06</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550994</td>
<td>305226-C-Video Matching Fee:2026-01-04 09:47:26</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550995</td>
<td>305226-C-Video Matching Fee:2026-01-04 08:52:10</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550996</td>
<td>305226-C-WestConnex:2026-01-04 08:52:10</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550997</td>
<td>305226-C-WestConnex:2026-01-04 09:47:26</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550998</td>
<td>305226-C-Video Matching Fee:2026-01-05 08:00:05</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843550999</td>
<td>305226-C-Video Matching Fee:2026-01-05 08:03:06</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 17 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th colspan="2"></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551000</td>
<td>305226-C-Video Matching Fee:2026-01-05 16:45:14</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551001</td>
<td>305226-C-Video Matching Fee:2026-01-05 17:11:22</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551002</td>
<td>305226-C-Video Matching Fee:2026-01-05 17:14:00</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551003</td>
<td>305226-C-Video Matching Fee:2026-01-05 17:22:51</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551004</td>
<td>305226-C-Video Matching Fee:2026-01-05 08:11:41</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551005</td>
<td>305226-C-Video Matching Fee:2026-01-05 16:36:05</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551006</td>
<td>305226-C-WestLink M7:2026-01-05 08:11:41</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551007</td>
<td>305226-C-WestLink M7:2026-01-05 16:36:05</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551008</td>
<td>305226-C-Lane Cove Tunnel:2026-01-05 17:14:00</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551009</td>
<td>305226-C-Lane Cove Tunnel:2026-01-05 08:00:05</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551010</td>
<td>305226-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-05</td>
<td>4.01</td>
<td>0.40</td>
<td>4.41</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551011</td>
<td>305226-C-Hills M2:2026-01-05 17:11:22</td>
<td>4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551012</td>
<td>305226-C-Hills M2:2026-01-05 08:03:06</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551013</td>
<td>305226-C-Hills M2:2026-01-05 16:45:14</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551014</td>
<td>305226-C-Video Matching Fee:2026-01-06 09:13:53</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551015</td>
<td>305226-C-Video Matching Fee:2026-01-06 09:17:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551016</td>
<td>305226-C-Video Matching Fee:2026-01-06 17:25:54</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551017</td>
<td>305226-C-Video Matching Fee:2026-01-06 17:29:17</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551018</td>
<td>305226-C-Video Matching Fee:2026-01-06 17:37:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551019</td>
<td>305226-C-Video Matching Fee:2026-01-06 09:26:20</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551020</td>
<td>305226-C-WestLink M7:2026-01-06 09:26:20</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551021</td>
<td>305226-C-Lane Cove Tunnel:2026-01-06 17:29:17</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551022</td>
<td>305226-C-Lane Cove Tunnel:2026-01-06 09:13:53</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551023</td>
<td>305226-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-06</td>
<td>4.01</td>
<td>0.40</td>
<td>4.41</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551024</td>
<td>305226-C-Hills M2:2026-01-06 09:17:18</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551025</td>
<td>305226-C-Hills M2:2026-01-06 17:25:54</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551026</td>
<td>305226-C-Video Matching Fee:2026-01-07 17:11:57</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551027</td>
<td>305226-C-Video Matching Fee:2026-01-07 17:15:17</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551028</td>
<td>305226-C-Video Matching Fee:2026-01-07 08:24:27</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551029</td>
<td>305226-C-Video Matching Fee:2026-01-07 08:27:24</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551030</td>
<td>305226-C-Video Matching Fee:2026-01-07 17:39:42</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551031</td>
<td>305226-C-Video Matching Fee:2026-01-07 08:35:32</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551032</td>
<td>305226-C-WestLink M7:2026-01-07 08:35:32</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 18 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th colspan="2"></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551033</td>
<td>305226-C-Lane Cove Tunnel:2026-01-07 08:24:27</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551034</td>
<td>305226-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-07</td>
<td>4.01</td>
<td>0.40</td>
<td>4.41</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551035</td>
<td>305226-C-Lane Cove Tunnel:2026-01-07 17:15:17</td>
<td>5.75</td>
<td>0.58</td>
<td>6.33</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551036</td>
<td>305226-C-Hills M2:2026-01-07 17:11:57</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551037</td>
<td>305226-C-Hills M2:2026-01-07 08:27:24</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551038</td>
<td>305226-C-Video Matching Fee:2026-01-08 22:31:39</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551039</td>
<td>305226-C-Video Matching Fee:2026-01-08 22:38:04</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551040</td>
<td>305226-C-Video Matching Fee:2026-01-08 22:52:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551041</td>
<td>305226-C-Video Matching Fee:2026-01-08 09:56:45</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551042</td>
<td>305226-C-Video Matching Fee:2026-01-08 09:59:44</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551043</td>
<td>305226-C-Video Matching Fee:2026-01-08 10:08:18</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551044</td>
<td>305226-C-WestLink M7:2026-01-08 10:08:18</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551045</td>
<td>305226-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-08</td>
<td>2.51</td>
<td>0.25</td>
<td>2.76</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551046</td>
<td>305226-C-Lane Cove Tunnel:2026-01-08 09:56:45</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551047</td>
<td>305226-C-Lane Cove Tunnel:2026-01-08 22:38:04</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551048</td>
<td>305226-C-Hills M2:2026-01-08 09:59:44</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551049</td>
<td>305226-C-Hills M2:2026-01-08 22:31:39</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551050</td>
<td>305226-C-Video Matching Fee:2026-01-12 06:40:50</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551051</td>
<td>305226-C-Video Matching Fee:2026-01-12 06:46:37</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551052</td>
<td>305226-C-Video Matching Fee:2026-01-12 06:55:28</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551053</td>
<td>305226-C-Video Matching Fee:2026-01-12 20:53:43</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551054</td>
<td>305226-C-Video Matching Fee:2026-01-12 21:22:38</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551055</td>
<td>305226-C-Video Matching Fee:2026-01-12 07:03:43</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551056</td>
<td>305226-C-WestLink M7:2026-01-12 07:03:43</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551057</td>
<td>305226-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-12</td>
<td>2.51</td>
<td>0.25</td>
<td>2.76</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551058</td>
<td>305226-C-Lane Cove Tunnel:2026-01-12 06:46:37</td>
<td>5.75</td>
<td>0.58</td>
<td>6.33</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551059</td>
<td>305226-C-Eastern Distributor:2026-01-12 06:40:50</td>
<td>9.33</td>
<td>0.93</td>
<td>10.26</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551060</td>
<td>305226-C-Hills M2:2026-01-12 20:53:43</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551061</td>
<td>305226-C-Hills M2:2026-01-12 06:55:28</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551062</td>
<td>305226-C-Video Matching Fee:2026-01-13 10:13:57</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551063</td>
<td>305226-C-Eastern Distributor:2026-01-13 10:13:57</td>
<td>9.33</td>
<td>0.93</td>
<td>10.26</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551064</td>
<td>305226-C-Video Matching Fee:2026-01-15 07:43:43</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551065</td>
<td>305226-C-Video Matching Fee:2026-01-15 07:47:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 19 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th colspan="2" rowspan="2"></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551066</td>
<td>305226-C-Video Matching Fee:2026-01-15 20:15:35</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">NSW DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551067</td>
<td>305226-C-Video Matching Fee:2026-01-15 07:55:55</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td colspan="2">NSW DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551068</td>
<td>305226-C-Video Matching Fee:2026-01-15 20:06:04</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td colspan="2">NSW DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551069</td>
<td>305226-C-WestLink M7:2026-01-15 07:55:55</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td colspan="2">NSW DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551070</td>
<td>305226-C-WestLink M7:2026-01-15 20:06:04</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td colspan="2">NSW DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551071</td>
<td>305226-C-Lane Cove Tunnel:2026-01-15 07:43:43</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td colspan="2">NSW DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551072</td>
<td>305226-C-Hills M2:2026-01-15 07:47:02</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td colspan="2">NSW DL63KU</td>
<td>ISUZU RG MY24 D-MAX LS-U</td>
<td>Robert Dredge</td>
<td>4843551073</td>
<td>305226-C-Hills M2:2026-01-15 20:15:35</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total for Cost Centre: 0759 352 3900 SSS</td>
<td>1,777.18</td>
<td>178.12</td>
<td>1,955.30</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">Cost Centre: 0759 353 3901 965</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547801</td>
<td>295355-C-Video Matching Fee : 2025-12-11 14:52:35</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547802</td>
<td>295355-C-CityLink : 2025-12-11 14:52:35</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547803</td>
<td>295355-C-Video Matching Fee : 2025-12-12 07:40:33</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547804</td>
<td>295355-C-Video Matching Fee : 2025-12-12 13:06:19</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547805</td>
<td>295355-C-Video Matching Fee : 2025-12-12 19:09:15</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547806</td>
<td>295355-C-CityLink : 2025-12-12 07:40:33</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547807</td>
<td>295355-C-CityLink : 2025-12-12 13:06:19</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547808</td>
<td>295355-C-CityLink : 2025-12-12 19:09:15</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547809</td>
<td>295355-C-Video Matching Fee : 2025-12-13 13:16:48</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547810</td>
<td>295355-C-Video Matching Fee : 2025-12-13 18:21:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547811</td>
<td>295355-C-Video Matching Fee : 2025-12-13 19:33:35</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547812</td>
<td>295355-C-CityLink : 2025-12-13 19:33:35</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547813</td>
<td>295355-C-CityLink : 2025-12-13 13:16:48</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547814</td>
<td>295355-C-CityLink : 2025-12-13 18:21:34</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547815</td>
<td>295355-C-Video Matching Fee : 2025-12-16 07:49:23</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547816</td>
<td>295355-C-Video Matching Fee : 2025-12-16 16:02:43</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547817</td>
<td>295355-C-CityLink : 2025-12-16 07:49:23</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547818</td>
<td>295355-C-CityLink : 2025-12-16 16:02:43</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547819</td>
<td>295355-C-Video Matching Fee : 2025-12-17 16:30:47</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547820</td>
<td>295355-C-CityLink : 2025-12-17 16:30:47</td>
<td>16.65</td>
<td>1.67</td>
<td>18.32</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547821</td>
<td>295355-C-Video Matching Fee : 2025-12-19 08:32:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547822</td>
<td>295355-C-Video Matching Fee : 2025-12-19 14:23:22</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">VIC 1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547823</td>
<td>295355-C-CityLink : 2025-12-19 08:32:34</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 20 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th colspan="2"></th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547824</td>
<td>295355-C-CityLink : 2025-12-19 14:23:22</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547825</td>
<td>295355-C-Video Matching Fee : 2025-12-20 15:31:23</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547826</td>
<td>295355-C-West Gate Tunnel : 2025-12-20 15:31:23</td>
<td>5.95</td>
<td>0.60</td>
<td>6.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547827</td>
<td>295355-C-Video Matching Fee : 2025-12-29 17:38:48</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547828</td>
<td>295355-C-Video Matching Fee : 2025-12-29 11:45:27</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547829</td>
<td>295355-C-CityLink : 2025-12-29 11:45:27</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547830</td>
<td>295355-C-CityLink : 2025-12-29 17:38:48</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547831</td>
<td>295355-C-Video Matching Fee:2026-01-03 11:03:26</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547832</td>
<td>295355-C-Video Matching Fee:2026-01-03 15:40:07</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547833</td>
<td>295355-C-CityLink:2026-01-03 11:03:26</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR7YV</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rhys Burgess</td>
<td>4843547834</td>
<td>295355-C-CityLink:2026-01-03 15:40:07</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total for Cost Centre: 0759 353 3901 965</td>
<td>204.71</td>
<td>20.49</td>
<td>225.20</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Cost Centre: 352 3901 965</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546401</td>
<td>264262-C-WestConnex : 2025-12-16 14:53:10</td>
<td>7.69</td>
<td>0.77</td>
<td>8.46</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546402</td>
<td>264262-C-WestConnex : 2025-12-16 07:27:35</td>
<td>8.71</td>
<td>0.87</td>
<td>9.58</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546403</td>
<td>264262-C-WestConnex : 2025-12-18 09:31:07</td>
<td>4.88</td>
<td>0.49</td>
<td>5.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546404</td>
<td>264262-C-WestConnex : 2025-12-18 12:14:31</td>
<td>4.88</td>
<td>0.49</td>
<td>5.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546405</td>
<td>264262-C-WestConnex : 2025-12-18 07:24:36</td>
<td>9.20</td>
<td>0.92</td>
<td>10.12</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546406</td>
<td>264262-C-WestConnex : 2025-12-18 08:01:49</td>
<td>9.20</td>
<td>0.92</td>
<td>10.12</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546407</td>
<td>264262-C-WestConnex : 2025-12-22 18:03:32</td>
<td>4.54</td>
<td>0.45</td>
<td>4.99</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546408</td>
<td>264262-C-WestConnex : 2025-12-22 15:49:55</td>
<td>5.11</td>
<td>0.51</td>
<td>5.62</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546409</td>
<td>264262-C-WestConnex : 2025-12-22 21:10:19</td>
<td>5.11</td>
<td>0.51</td>
<td>5.62</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546410</td>
<td>264262-C-WestConnex : 2025-12-23 19:09:52</td>
<td>9.20</td>
<td>0.92</td>
<td>10.12</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546411</td>
<td>264262-C-WestConnex : 2025-12-23 20:42:34</td>
<td>9.20</td>
<td>0.92</td>
<td>10.12</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546412</td>
<td>264262-C-Lane Cove Tunnel : 2025-12-25 12:13:40</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546413</td>
<td>264262-C-Lane Cove Tunnel : 2025-12-25 14:36:26</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546414</td>
<td>264262-C-Hills M2 : 2025-12-25 12:09:42</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546415</td>
<td>264262-C-Cross City Tunnel : 2025-12-26 13:22:04</td>
<td>6.52</td>
<td>0.65</td>
<td>7.17</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546416</td>
<td>264262-C-Cross City Tunnel : 2025-12-26 17:56:45</td>
<td>6.52</td>
<td>0.65</td>
<td>7.17</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546417</td>
<td>264262-C-WestConnex : 2025-12-26 18:01:45</td>
<td>7.69</td>
<td>0.77</td>
<td>8.46</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546418</td>
<td>264262-C-WestConnex : 2025-12-26 13:08:15</td>
<td>9.43</td>
<td>0.94</td>
<td>10.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546419</td>
<td>264262-C-WestLink M7 : 2025-12-28 18:21:21</td>
<td>3.56</td>
<td>0.36</td>
<td>3.92</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546420</td>
<td>264262-C-WestConnex : 2025-12-28 18:36:35</td>
<td>4.16</td>
<td>0.42</td>
<td>4.58</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 21 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No. AU1166479</th>
<th>Invoice Date 31 January 2026</th>
<th>Invoice No. AIN00014651</th>
<th></th>
<th></th>
<th></th>
<th colspan="2">P</th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546421</td>
<td>264262-C-WestConnex : 2025-12-28 07:07:10</td>
<td>4.88</td>
<td>0.49</td>
<td>5.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546422</td>
<td>264262-C-WestConnex : 2025-12-29 16:15:10</td>
<td>9.20</td>
<td>0.92</td>
<td>10.12</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546423</td>
<td>264262-C-WestConnex : 2025-12-29 15:47:17</td>
<td>10.22</td>
<td>1.02</td>
<td>11.24</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546424</td>
<td>264262-C-WestConnex : 2025-12-31 10:17:10</td>
<td>3.79</td>
<td>0.38</td>
<td>4.17</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546425</td>
<td>264262-C-WestConnex : 2025-12-31 12:19:32</td>
<td>4.88</td>
<td>0.49</td>
<td>5.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546426</td>
<td>264262-C-WestConnex : 2025-12-31 12:58:04</td>
<td>4.88</td>
<td>0.49</td>
<td>5.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546427</td>
<td>264262-C-WestConnex : 2025-12-31 15:04:08</td>
<td>5.90</td>
<td>0.59</td>
<td>6.49</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546428</td>
<td>264262-C-WestConnex:2026-01-01 22:42:49</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546429</td>
<td>264262-C-WestConnex:2026-01-02 00:58:59</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546430</td>
<td>264262-C-WestConnex:2026-01-02 19:00:53</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546431</td>
<td>264262-C-WestConnex:2026-01-02 13:22:27</td>
<td>9.80</td>
<td>0.98</td>
<td>10.78</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546432</td>
<td>264262-C-WestConnex:2026-01-03 06:12:43</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546433</td>
<td>264262-C-WestConnex:2026-01-03 12:51:39</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546434</td>
<td>264262-C-WestConnex:2026-01-04 07:42:14</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546435</td>
<td>264262-C-WestConnex:2026-01-04 11:46:08</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546436</td>
<td>264262-C-WestConnex:2026-01-06 12:15:39</td>
<td>4.34</td>
<td>0.43</td>
<td>4.77</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546437</td>
<td>264262-C-WestConnex:2026-01-06 13:00:17</td>
<td>4.34</td>
<td>0.43</td>
<td>4.77</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546438</td>
<td>264262-C-WestConnex:2026-01-07 17:11:23</td>
<td>5.00</td>
<td>0.50</td>
<td>5.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546439</td>
<td>264262-C-WestConnex:2026-01-07 00:01:46</td>
<td>5.07</td>
<td>0.51</td>
<td>5.58</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546440</td>
<td>264262-C-WestConnex:2026-01-07 04:12:59</td>
<td>5.07</td>
<td>0.51</td>
<td>5.58</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546441</td>
<td>264262-C-WestConnex:2026-01-08 14:07:48</td>
<td>4.34</td>
<td>0.43</td>
<td>4.77</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546442</td>
<td>264262-C-WestConnex:2026-01-09 09:36:24</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546443</td>
<td>264262-C-WestConnex:2026-01-09 13:08:18</td>
<td>9.80</td>
<td>0.98</td>
<td>10.78</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546444</td>
<td>264262-C-WestConnex:2026-01-12 08:33:19</td>
<td>5.07</td>
<td>0.51</td>
<td>5.58</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546445</td>
<td>264262-C-WestConnex:2026-01-13 13:23:56</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546446</td>
<td>264262-C-WestConnex:2026-01-13 17:05:45</td>
<td>3.94</td>
<td>0.39</td>
<td>4.33</td>
</tr>
<tr>
<td>NSW</td>
<td>DD50MV</td>
<td>NISSAN D23 MY21.5 NAVARA</td>
<td>Ehsan Janakipour</td>
<td>4843546447</td>
<td>264262-C-WestConnex:2026-01-14 17:43:11</td>
<td>5.07</td>
<td>0.51</td>
<td>5.58</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total for Cost Centre: 352 3901 965</td>
<td>304.84</td>
<td>30.49</td>
<td>335.33</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Cost Centre: Other</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>NSW</td>
<td>DI73FR</td>
<td>KIA NQ5 MY23 SPORTAGE S A</td>
<td>Clint Phillips</td>
<td>4843548301</td>
<td>296315-C-WestLink M7 : 2025-12-24 10:42:38</td>
<td>0.63</td>
<td>0.06</td>
<td>0.69</td>
</tr>
<tr>
<td>NSW</td>
<td>DI73FR</td>
<td>KIA NQ5 MY23 SPORTAGE S A</td>
<td>Clint Phillips</td>
<td>4843548302</td>
<td>296315-C-Video Matching Fee : 2025-12-24 10:42:38</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DI73FR</td>
<td>KIA NQ5 MY23 SPORTAGE S A</td>
<td>Clint Phillips</td>
<td>4843548303</td>
<td>296315-C-Video Matching Fee : 2025-12-28 11:59:08</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DI73FR</td>
<td>KIA NQ5 MY23 SPORTAGE S A</td>
<td>Clint Phillips</td>
<td>4843548304</td>
<td>296315-C-Video Matching Fee : 2025-12-28 09:14:10</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 22 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No. AU1166479</th>
<th>Invoice Date 31 January 2026</th>
<th>Invoice No. AIN00014651</th>
<th colspan="2"></th>
<th></th>
<th colspan="2">P</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DI73FR</td>
<td>KIA NQ5 MY23 SPORTAGE S A</td>
<td>Clint Phillips</td>
<td>4843548305</td>
<td>296315-C-WestConnex : 2025-12-28 11:59:08</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DI73FR</td>
<td>KIA NQ5 MY23 SPORTAGE S A</td>
<td>Clint Phillips</td>
<td>4843548306</td>
<td>296315-C-WestConnex : 2025-12-28 09:14:10</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DI73FR</td>
<td>KIA NQ5 MY23 SPORTAGE S A</td>
<td>Clint Phillips</td>
<td>4843548307</td>
<td>296315-C-Video Matching Fee : 2025-12-29 14:31:41</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DI73FR</td>
<td>KIA NQ5 MY23 SPORTAGE S A</td>
<td>Clint Phillips</td>
<td>4843548308</td>
<td>296315-C-Video Matching Fee : 2025-12-29 10:10:27</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DI73FR</td>
<td>KIA NQ5 MY23 SPORTAGE S A</td>
<td>Clint Phillips</td>
<td>4843548309</td>
<td>296315-C-WestConnex : 2025-12-29 10:10:27</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td colspan="2">NSW DI73FR</td>
<td>KIA NQ5 MY23 SPORTAGE S A</td>
<td>Clint Phillips</td>
<td>4843548310</td>
<td>296315-C-WestConnex : 2025-12-29 14:31:41</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td colspan="2">NSW DI73FR</td>
<td>KIA NQ5 MY23 SPORTAGE S A</td>
<td>Clint Phillips</td>
<td>4843548311</td>
<td>296315-C-Video Matching Fee:2026-01-06 18:08:42</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">NSW DI73FR</td>
<td>KIA NQ5 MY23 SPORTAGE S A</td>
<td>Clint Phillips</td>
<td>4843548312</td>
<td>296315-C-Video Matching Fee:2026-01-06 20:53:49</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">NSW DI73FR</td>
<td>KIA NQ5 MY23 SPORTAGE S A</td>
<td>Clint Phillips</td>
<td>4843548313</td>
<td>296315-C-WestConnex:2026-01-06 20:53:49</td>
<td>4.34</td>
<td>0.43</td>
<td>4.77</td>
</tr>
<tr>
<td colspan="2">NSW DI73FR</td>
<td>KIA NQ5 MY23 SPORTAGE S A</td>
<td>Clint Phillips</td>
<td>4843548314</td>
<td>296315-C-WestConnex:2026-01-06 18:08:42</td>
<td>5.07</td>
<td>0.51</td>
<td>5.58</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total for Cost Centre: Other</td>
<td>58.28</td>
<td>5.81</td>
<td>64.09</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">Cost Centre: Power</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">QLD 105AG2</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Ramesh Undhad</td>
<td>4843545701</td>
<td>256894-C-Logan Motorway : 2025-12-16 08:01:43</td>
<td>4.65</td>
<td>0.47</td>
<td>5.12</td>
</tr>
<tr>
<td colspan="2">QLD 105AG2</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Ramesh Undhad</td>
<td>4843545702</td>
<td>256894-C-Logan Motorway : 2025-12-16 08:43:15</td>
<td>4.91</td>
<td>0.49</td>
<td>5.40</td>
</tr>
<tr>
<td>QLD</td>
<td>105AG2</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Ramesh Undhad</td>
<td>4843545703</td>
<td>256894-C-Toowoomba Second Range Crossing :</td>
<td>6.49</td>
<td>0.65</td>
<td>7.14</td>
</tr>
<tr>
<td>QLD</td>
<td>105AG2</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Ramesh Undhad</td>
<td>4843545704</td>
<td>256894-C-Toowoomba Second Range Crossing :</td>
<td>6.49</td>
<td>0.65</td>
<td>7.14</td>
</tr>
<tr>
<td>QLD</td>
<td>105AG2</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Ramesh Undhad</td>
<td>4843545705</td>
<td>256894-C-Gateway Motorway : 2025-12-25 08:01:03</td>
<td>7.89</td>
<td>0.79</td>
<td>8.68</td>
</tr>
<tr>
<td>QLD</td>
<td>105AG2</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Ramesh Undhad</td>
<td>4843545706</td>
<td>256894-C-Gateway Motorway : 2025-12-25 08:19:53</td>
<td>7.89</td>
<td>0.79</td>
<td>8.68</td>
</tr>
<tr>
<td>QLD</td>
<td>105AG2</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Ramesh Undhad</td>
<td>4843545707</td>
<td>256894-C-Gateway Motorway : 2025-12-30 06:32:54</td>
<td>7.89</td>
<td>0.79</td>
<td>8.68</td>
</tr>
<tr>
<td>QLD</td>
<td>105AG2</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Ramesh Undhad</td>
<td>4843545708</td>
<td>256894-C-Gateway Motorway : 2025-12-30 06:50:41</td>
<td>7.89</td>
<td>0.79</td>
<td>8.68</td>
</tr>
<tr>
<td>QLD</td>
<td>105AG2</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Ramesh Undhad</td>
<td>4843545709</td>
<td>256894-C-Gateway Motorway:2026-01-03 05:04:39</td>
<td>7.89</td>
<td>0.79</td>
<td>8.68</td>
</tr>
<tr>
<td>QLD</td>
<td>105AG2</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Ramesh Undhad</td>
<td>4843545710</td>
<td>256894-C-Gateway Motorway:2026-01-03 05:21:24</td>
<td>7.89</td>
<td>0.79</td>
<td>8.68</td>
</tr>
<tr>
<td>QLD</td>
<td>105AG2</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Ramesh Undhad</td>
<td>4843545711</td>
<td>256894-C-Gateway Motorway:2026-01-14 07:34:56</td>
<td>7.89</td>
<td>0.79</td>
<td>8.68</td>
</tr>
<tr>
<td>QLD</td>
<td>1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547201</td>
<td>295190-C-Video Matching Fee : 2025-12-12 06:45:48</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547202</td>
<td>295190-C-Video Matching Fee : 2025-12-12 10:41:51</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547203</td>
<td>295190-C-Gateway Motorway : 2025-12-12 06:45:48</td>
<td>7.89</td>
<td>0.79</td>
<td>8.68</td>
</tr>
<tr>
<td>QLD</td>
<td>1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547204</td>
<td>295190-C-Gateway Motorway : 2025-12-12 10:41:51</td>
<td>7.89</td>
<td>0.79</td>
<td>8.68</td>
</tr>
<tr>
<td>QLD</td>
<td>1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547205</td>
<td>295190-C-Video Matching Fee : 2025-12-15 19:49:52</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547206</td>
<td>295190-C-Video Matching Fee : 2025-12-15 23:25:46</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547207</td>
<td>295190-C-Video Matching Fee : 2025-12-15 23:37:11</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td colspan="2">QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547208</td>
<td>295190-C-Video Matching Fee : 2025-12-15 10:45:17</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td colspan="2">QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547209</td>
<td>295190-C-Video Matching Fee : 2025-12-15 11:28:03</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td colspan="2">QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547210</td>
<td>295190-C-Logan Motorway : 2025-12-15 23:37:11</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 23 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th>Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th>AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td>State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547211</td>
<td>295190-C-Logan Motorway : 2025-12-15 11:28:03</td>
<td>4.91</td>
<td>0.49</td>
<td>5.40</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547212</td>
<td>295190-C-Logan Motorway : 2025-12-15 19:49:52</td>
<td>4.91</td>
<td>0.49</td>
<td>5.40</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547213</td>
<td>295190-C-Logan Motorway : 2025-12-15 23:25:46</td>
<td>4.91</td>
<td>0.49</td>
<td>5.40</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547214</td>
<td>295190-C-AirportlinkM7 : 2025-12-15 10:45:17</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547215</td>
<td>295190-C-Video Matching Fee : 2025-12-16 12:01:49</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547216</td>
<td>295190-C-Video Matching Fee : 2025-12-16 06:43:25</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547217</td>
<td>295190-C-Gateway Motorway : 2025-12-16 06:43:25</td>
<td>7.89</td>
<td>0.79</td>
<td>8.68</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547218</td>
<td>295190-C-Gateway Motorway : 2025-12-16 12:01:49</td>
<td>7.89</td>
<td>0.79</td>
<td>8.68</td>
</tr>
<tr>
<td>QLD 108IY5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547219</td>
<td>295190-C-Video Matching Fee : 2025-12-17 12:08:05</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547220</td>
<td>295190-C-Video Matching Fee : 2025-12-17 07:35:06</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547221</td>
<td>295190-C-Gateway Motorway : 2025-12-17 07:35:06</td>
<td>7.89</td>
<td>0.79</td>
<td>8.68</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547222</td>
<td>295190-C-Gateway Motorway : 2025-12-17 12:08:05</td>
<td>7.89</td>
<td>0.79</td>
<td>8.68</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547223</td>
<td>295190-C-Video Matching Fee : 2025-12-19 14:45:36</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547224</td>
<td>295190-C-Video Matching Fee : 2025-12-19 12:19:32</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD 108IY5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547225</td>
<td>295190-C-Gateway Motorway : 2025-12-19 12:19:32</td>
<td>7.89</td>
<td>0.79</td>
<td>8.68</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547226</td>
<td>295190-C-Gateway Motorway : 2025-12-19 14:45:36</td>
<td>7.89</td>
<td>0.79</td>
<td>8.68</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547227</td>
<td>295190-C-Video Matching Fee:2026-01-10 08:37:28</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547228</td>
<td>295190-C-Video Matching Fee:2026-01-10 10:56:34</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547229</td>
<td>295190-C-Logan Motorway:2026-01-10 10:56:34</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547230</td>
<td>295190-C-Logan Motorway:2026-01-10 08:37:28</td>
<td>4.65</td>
<td>0.47</td>
<td>5.12</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547231</td>
<td>295190-C-Video Matching Fee:2026-01-12 05:22:49</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547232</td>
<td>295190-C-Video Matching Fee:2026-01-12 14:26:13</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547233</td>
<td>295190-C-Video Matching Fee:2026-01-12 14:36:49</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547234</td>
<td>295190-C-Logan Motorway:2026-01-12 14:36:49</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547235</td>
<td>295190-C-Logan Motorway:2026-01-12 05:22:49</td>
<td>4.65</td>
<td>0.47</td>
<td>5.12</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547236</td>
<td>295190-C-Logan Motorway:2026-01-12 14:26:13</td>
<td>4.91</td>
<td>0.49</td>
<td>5.40</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547237</td>
<td>295190-C-Video Matching Fee:2026-01-13 12:58:12</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547238</td>
<td>295190-C-Video Matching Fee:2026-01-13 05:11:13</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547239</td>
<td>295190-C-Logan Motorway:2026-01-13 12:58:12</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547240</td>
<td>295190-C-Logan Motorway:2026-01-13 05:11:13</td>
<td>4.65</td>
<td>0.47</td>
<td>5.12</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547241</td>
<td>295190-C-Video Matching Fee:2026-01-14 05:17:41</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547242</td>
<td>295190-C-Video Matching Fee:2026-01-14 14:34:35</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547243</td>
<td>295190-C-Logan Motorway:2026-01-14 05:17:41</td>
<td>4.65</td>
<td>0.47</td>
<td>5.12</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 24 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2" rowspan="2">Customer No. AU1166479</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>QLD</td>
<td>1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547244</td>
<td>295190-C-Logan Motorway:2026-01-14 14:34:35</td>
<td>4.65</td>
<td>0.47</td>
<td>5.12</td>
</tr>
<tr>
<td colspan="2">QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547245</td>
<td>295190-C-Video Matching Fee:2026-01-15 05:10:29</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547246</td>
<td>295190-C-Video Matching Fee:2026-01-15 14:18:26</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td colspan="2">QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547247</td>
<td>295190-C-Logan Motorway:2026-01-15 14:18:26</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
<tr>
<td colspan="2">QLD 1081Y5</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mark Harris</td>
<td>4843547248</td>
<td>295190-C-Logan Motorway:2026-01-15 05:10:29</td>
<td>4.65</td>
<td>0.47</td>
<td>5.12</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545201</td>
<td>252691-C-CityLink : 2025-12-16 07:45:43</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545202</td>
<td>252691-C-CityLink : 2025-12-16 11:09:34</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545203</td>
<td>252691-C-CityLink : 2025-12-16 12:58:42</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545204</td>
<td>252691-C-CityLink : 2025-12-19 16:12:22</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545205</td>
<td>252691-C-CityLink : 2025-12-19 18:18:13</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545206</td>
<td>252691-C-CityLink : 2025-12-19 12:10:48</td>
<td>12.48</td>
<td>1.25</td>
<td>13.73</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545207</td>
<td>252691-C-CityLink : 2025-12-19 07:34:54</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545208</td>
<td>252691-C-CityLink : 2025-12-19 14:54:53</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545209</td>
<td>252691-C-CityLink : 2025-12-22 14:24:51</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td colspan="2">VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545210</td>
<td>252691-C-CityLink : 2025-12-22 07:18:08</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545211</td>
<td>252691-C-CityLink : 2025-12-22 15:18:54</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545212</td>
<td>252691-C-CityLink : 2025-12-23 13:04:49</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545213</td>
<td>252691-C-CityLink : 2025-12-23 07:34:37</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545214</td>
<td>252691-C-CityLink : 2025-12-24 07:21:53</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545215</td>
<td>252691-C-CityLink : 2025-12-24 14:43:21</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545216</td>
<td>252691-C-CityLink : 2025-12-25 21:48:42</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545217</td>
<td>252691-C-CityLink : 2025-12-25 17:20:06</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td colspan="2">VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545218</td>
<td>252691-C-CityLink : 2025-12-26 15:33:42</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545219</td>
<td>252691-C-CityLink : 2025-12-29 07:30:30</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545220</td>
<td>252691-C-CityLink : 2025-12-29 14:57:36</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545221</td>
<td>252691-C-CityLink : 2025-12-30 07:30:39</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545222</td>
<td>252691-C-CityLink : 2025-12-30 14:17:27</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td colspan="2">VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545223</td>
<td>252691-C-CityLink : 2025-12-31 07:38:39</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td colspan="2">VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545224</td>
<td>252691-C-CityLink : 2025-12-31 13:23:15</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545225</td>
<td>252691-C-CityLink:2026-01-02 07:33:55</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td colspan="2">VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545226</td>
<td>252691-C-CityLink:2026-01-02 14:52:04</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td colspan="2">VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545227</td>
<td>252691-C-CityLink:2026-01-05 11:18:46</td>
<td>9.60</td>
<td>0.96</td>
<td>10.56</td>
</tr>
<tr>
<td colspan="2">VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545228</td>
<td>252691-C-CityLink:2026-01-05 12:18:45</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 25 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th>Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th>AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td>State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td colspan="2">GST Total</td>
</tr>
<tr>
<td>VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545229</td>
<td>252691-C-CityLink:2026-01-05 07:38:13</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545230</td>
<td>252691-C-CityLink:2026-01-06 07:39:49</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545231</td>
<td>252691-C-CityLink:2026-01-06 14:44:52</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545232</td>
<td>252691-C-CityLink:2026-01-07 09:36:16</td>
<td>9.60</td>
<td>0.96</td>
<td>10.56</td>
</tr>
<tr>
<td>VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545233</td>
<td>252691-C-CityLink:2026-01-07 15:51:51</td>
<td>9.60</td>
<td>0.96</td>
<td>10.56</td>
</tr>
<tr>
<td>VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545234</td>
<td>252691-C-CityLink:2026-01-08 07:47:27</td>
<td>9.60</td>
<td>0.96</td>
<td>10.56</td>
</tr>
<tr>
<td>VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545235</td>
<td>252691-C-CityLink:2026-01-08 11:30:58</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545236</td>
<td>252691-C-CityLink:2026-01-09 07:36:22</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545237</td>
<td>252691-C-CityLink:2026-01-09 15:15:14</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545238</td>
<td>252691-C-CityLink:2026-01-12 06:24:27</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545239</td>
<td>252691-C-CityLink:2026-01-12 16:45:34</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545240</td>
<td>252691-C-CityLink:2026-01-13 06:33:15</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545241</td>
<td>252691-C-CityLink:2026-01-13 16:12:16</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545242</td>
<td>252691-C-CityLink:2026-01-14 06:14:25</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545243</td>
<td>252691-C-CityLink:2026-01-14 15:56:46</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC 1QW4MA</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hieu Nguyen</td>
<td>4843545244</td>
<td>252691-C-CityLink:2026-01-15 15:33:44</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC 1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547001</td>
<td>279937-C-CityLink : 2025-12-14 12:23:50</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
<tr>
<td>VIC 1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547002</td>
<td>279937-C-West Gate Tunnel : 2025-12-14 12:16:57</td>
<td>5.95</td>
<td>0.60</td>
<td>6.55</td>
</tr>
<tr>
<td>VIC 1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547003</td>
<td>279937-C-CityLink : 2025-12-14 10:53:54</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC 1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547004</td>
<td>279937-C-CityLink : 2025-12-14 14:34:29</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC 1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547005</td>
<td>279937-C-CityLink : 2025-12-17 16:13:36</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC 1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547006</td>
<td>279937-C-CityLink : 2025-12-17 07:52:34</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC 1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547007</td>
<td>279937-C-CityLink : 2025-12-19 07:33:46</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC 1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547008</td>
<td>279937-C-CityLink : 2025-12-19 14:57:48</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC 1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547009</td>
<td>279937-C-CityLink : 2025-12-21 07:43:03</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC 1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547010</td>
<td>279937-C-CityLink : 2025-12-22 14:23:34</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
<tr>
<td>VIC 1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547011</td>
<td>279937-C-CityLink : 2025-12-22 07:36:39</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC 1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547012</td>
<td>279937-C-CityLink : 2025-12-22 11:06:46</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC 1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547013</td>
<td>279937-C-CityLink : 2025-12-22 15:22:58</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC 1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547014</td>
<td>279937-C-CityLink : 2025-12-23 07:18:49</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC 1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547015</td>
<td>279937-C-CityLink : 2025-12-23 15:18:56</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC 1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547016</td>
<td>279937-C-CityLink : 2025-12-24 08:44:49</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
<tr>
<td>VIC 1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547017</td>
<td>279937-C-CityLink : 2025-12-24 07:48:03</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 26 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547018</td>
<td>279937-C-CityLink : 2025-12-24 14:40:51</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547019</td>
<td>279937-C-CityLink : 2025-12-29 10:30:42</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547020</td>
<td>279937-C-CityLink : 2025-12-31 11:49:05</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547021</td>
<td>279937-C-CityLink : 2025-12-31 17:38:16</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547022</td>
<td>279937-C-CityLink : 2025-12-31 12:46:37</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547023</td>
<td>279937-C-CityLink:2026-01-01 01:59:23</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547024</td>
<td>279937-C-CityLink:2026-01-02 18:23:19</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547025</td>
<td>279937-C-West Gate Tunnel:2026-01-02 18:26:43</td>
<td>6.01</td>
<td>0.60</td>
<td>6.61</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547026</td>
<td>279937-C-CityLink:2026-01-02 18:18:23</td>
<td>10.80</td>
<td>1.08</td>
<td>11.88</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547027</td>
<td>279937-C-CityLink:2026-01-02 08:39:59</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547028</td>
<td>279937-C-CityLink:2026-01-02 11:30:47</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547029</td>
<td>279937-C-CityLink:2026-01-02 15:50:49</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547030</td>
<td>279937-C-CityLink-West Gate Tunnel:2026-01-02 18:34:41</td>
<td>15.61</td>
<td>1.56</td>
<td>17.17</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547031</td>
<td>279937-C-CityLink:2026-01-05 15:45:59</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547032</td>
<td>279937-C-CityLink:2026-01-05 08:01:44</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547033</td>
<td>279937-C-CityLink:2026-01-06 12:32:05</td>
<td>10.80</td>
<td>1.08</td>
<td>11.88</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547034</td>
<td>279937-C-CityLink-West Gate Tunnel:2026-01-06 13:28:03</td>
<td>10.81</td>
<td>1.08</td>
<td>11.89</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547035</td>
<td>279937-C-CityLink:2026-01-06 15:27:22</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547036</td>
<td>279937-C-CityLink:2026-01-06 08:00:42</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547037</td>
<td>279937-C-CityLink:2026-01-08 10:31:28</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547038</td>
<td>279937-C-CityLink:2026-01-09 13:24:57</td>
<td>6.00</td>
<td>0.60</td>
<td>6.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547039</td>
<td>279937-C-CityLink:2026-01-09 15:15:01</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547040</td>
<td>279937-C-CityLink:2026-01-09 07:28:51</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1VY3QR</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Louie Contos</td>
<td>4843547041</td>
<td>279937-C-CityLink:2026-01-12 14:23:04</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548801</td>
<td>296347-C-Video Matching Fee : 2025-12-12 07:19:39</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548802</td>
<td>296347-C-Video Matching Fee : 2025-12-12 17:07:27</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548803</td>
<td>296347-C-Video Matching Fee : 2025-12-12 21:13:42</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548804</td>
<td>296347-C-CityLink : 2025-12-12 07:19:39</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548805</td>
<td>296347-C-CityLink : 2025-12-12 17:07:27</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548806</td>
<td>296347-C-CityLink : 2025-12-12 21:13:42</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548807</td>
<td>296347-C-Video Matching Fee : 2025-12-15 07:24:19</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548808</td>
<td>296347-C-Video Matching Fee : 2025-12-15 07:30:48</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548809</td>
<td>296347-C-Video Matching Fee : 2025-12-15 15:31:51</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 27 of 121" -->
<!-- PageBreak -->

Customer No.

Invoice Date

Invoice No.

AU1166479

31 January 2026

AIN00014651


<figure>

P

</figure>


<table>
<tr>
<th>State</th>
<th>Reg No.</th>
<th>Vehicle Description</th>
<th>Driver</th>
<th>Line Ref.</th>
<th>Contract - Description</th>
<th>Net</th>
<th>GST</th>
<th>Total</th>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548810</td>
<td>296347-C-West Gate Tunnel : 2025-12-15 07:30:48</td>
<td>5.95</td>
<td>0.60</td>
<td>6.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548811</td>
<td>296347-C-CityLink : 2025-12-15 07:24:19</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548812</td>
<td>296347-C-CityLink-West Gate Tunnel : 2025-12-15</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548813</td>
<td>296347-C-Video Matching Fee : 2025-12-16 08:11:19</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548814</td>
<td>296347-C-Video Matching Fee : 2025-12-16 11:07:29</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548815</td>
<td>296347-C-Video Matching Fee : 2025-12-16 07:31:46</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548816</td>
<td>296347-C-EastLink : 2025-12-16 08:11:19</td>
<td>8.67</td>
<td>0.87</td>
<td>9.54</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548817</td>
<td>296347-C-EastLink : 2025-12-16 11:07:29</td>
<td>11.30</td>
<td>1.13</td>
<td>12.43</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548818</td>
<td>296347-C-CityLink : 2025-12-16 07:31:46</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548819</td>
<td>296347-C-Video Matching Fee : 2025-12-17 12:01:40</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548820</td>
<td>296347-C-Video Matching Fee : 2025-12-17 08:13:18</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548821</td>
<td>296347-C-EastLink : 2025-12-17 08:13:18</td>
<td>5.19</td>
<td>0.52</td>
<td>5.71</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548822</td>
<td>296347-C-EastLink : 2025-12-17 12:01:40</td>
<td>5.19</td>
<td>0.52</td>
<td>5.71</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548823</td>
<td>296347-C-Video Matching Fee : 2025-12-18 11:40:47</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548824</td>
<td>296347-C-Video Matching Fee : 2025-12-18 07:24:41</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548825</td>
<td>296347-C-CityLink : 2025-12-18 07:24:41</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548826</td>
<td>296347-C-CityLink : 2025-12-18 11:40:47</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548827</td>
<td>296347-C-Video Matching Fee : 2025-12-19 07:25:52</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548828</td>
<td>296347-C-Video Matching Fee : 2025-12-19 14:26:49</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548829</td>
<td>296347-C-CityLink : 2025-12-19 14:26:49</td>
<td>10.70</td>
<td>1.07</td>
<td>11.77</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548830</td>
<td>296347-C-CityLink : 2025-12-19 07:25:52</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548831</td>
<td>296347-C-Video Matching Fee : 2025-12-22 14:51:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548832</td>
<td>296347-C-Video Matching Fee : 2025-12-22 07:02:40</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548833</td>
<td>296347-C-CityLink : 2025-12-22 14:51:20</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548834</td>
<td>296347-C-CityLink : 2025-12-22 07:02:40</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548835</td>
<td>296347-C-Video Matching Fee : 2025-12-23 07:08:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548836</td>
<td>296347-C-Video Matching Fee : 2025-12-23 16:08:11</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548837</td>
<td>296347-C-CityLink : 2025-12-23 16:08:11</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548838</td>
<td>296347-C-CityLink : 2025-12-23 07:08:02</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548839</td>
<td>296347-C-Video Matching Fee : 2025-12-24 07:12:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548840</td>
<td>296347-C-Video Matching Fee : 2025-12-24 10:11:17</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548841</td>
<td>296347-C-CityLink : 2025-12-24 10:11:17</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548842</td>
<td>296347-C-CityLink : 2025-12-24 07:12:20</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 28 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th rowspan="2"></th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548843</td>
<td>296347-C-Video Matching Fee : 2025-12-26 13:58:38</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548844</td>
<td>296347-C-CityLink-West Gate Tunnel : 2025-12-26</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548845</td>
<td>296347-C-Video Matching Fee : 2025-12-30 13:24:44</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548846</td>
<td>296347-C-CityLink-West Gate Tunnel : 2025-12-30</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548847</td>
<td>296347-C-Video Matching Fee:2026-01-06 14:00:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548848</td>
<td>296347-C-Video Matching Fee:2026-01-06 07:04:59</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548849</td>
<td>296347-C-CityLink:2026-01-06 14:00:18</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548850</td>
<td>296347-C-CityLink:2026-01-06 07:04:59</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548851</td>
<td>296347-C-Video Matching Fee:2026-01-09 07:06:21</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548852</td>
<td>296347-C-Video Matching Fee:2026-01-09 14:32:10</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548853</td>
<td>296347-C-CityLink:2026-01-09 14:32:10</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1XV9CJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Robert Massimino</td>
<td>4843548854</td>
<td>296347-C-CityLink:2026-01-09 07:06:21</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549401</td>
<td>302288-C-Video Matching Fee : 2025-12-15 16:09:08</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549402</td>
<td>302288-C-CityLink : 2025-12-15 16:09:08</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549403</td>
<td>302288-C-Video Matching Fee : 2025-12-17 18:34:27</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549404</td>
<td>302288-C-Video Matching Fee : 2025-12-17 20:33:57</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549405</td>
<td>302288-C-CityLink : 2025-12-17 18:34:27</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549406</td>
<td>302288-C-CityLink : 2025-12-17 20:33:57</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549407</td>
<td>302288-C-Video Matching Fee : 2025-12-18 07:08:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549408</td>
<td>302288-C-Video Matching Fee : 2025-12-18 17:23:39</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549409</td>
<td>302288-C-CityLink : 2025-12-18 07:08:34</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549410</td>
<td>302288-C-CityLink : 2025-12-18 17:23:39</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549411</td>
<td>302288-C-Video Matching Fee : 2025-12-19 14:34:38</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549412</td>
<td>302288-C-Video Matching Fee : 2025-12-19 10:08:28</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549413</td>
<td>302288-C-CityLink : 2025-12-19 10:08:28</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549414</td>
<td>302288-C-CityLink : 2025-12-19 14:34:38</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549415</td>
<td>302288-C-Video Matching Fee : 2025-12-28 16:50:56</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549416</td>
<td>302288-C-Video Matching Fee : 2025-12-28 19:16:40</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549417</td>
<td>302288-C-CityLink : 2025-12-28 16:50:56</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549418</td>
<td>302288-C-CityLink : 2025-12-28 19:16:40</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549419</td>
<td>302288-C-Video Matching Fee:2026-01-06 14:47:11</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549420</td>
<td>302288-C-Video Matching Fee:2026-01-06 16:29:01</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549421</td>
<td>302288-C-CityLink:2026-01-06 14:47:11</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 29 of 121" -->
<!-- PageBreak -->

Customer No.

Invoice Date

Invoice No.

AU1166479

31 January 2026

AIN00014651


<figure>

P

</figure>


<table>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549422</td>
<td>302288-C-CityLink:2026-01-06 16:29:01</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549423</td>
<td>302288-C-Video Matching Fee:2026-01-08 08:02:44</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549424</td>
<td>302288-C-Video Matching Fee:2026-01-08 08:50:41</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549425</td>
<td>302288-C-Video Matching Fee:2026-01-08 07:18:39</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549426</td>
<td>302288-C-Video Matching Fee:2026-01-08 16:15:08</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549427</td>
<td>302288-C-Video Matching Fee:2026-01-08 15:44:00</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549428</td>
<td>302288-C-CityLink:2026-01-08 08:02:44</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549429</td>
<td>302288-C-CityLink:2026-01-08 08:50:41</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549430</td>
<td>302288-C-CityLink:2026-01-08 07:18:39</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549431</td>
<td>302288-C-CityLink:2026-01-08 15:44:00</td>
<td>10.80</td>
<td>1.08</td>
<td>11.88</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549432</td>
<td>302288-C-CityLink:2026-01-08 16:15:08</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549433</td>
<td>302288-C-Video Matching Fee:2026-01-09 06:57:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549434</td>
<td>302288-C-Video Matching Fee:2026-01-09 04:55:44</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549435</td>
<td>302288-C-Video Matching Fee:2026-01-09 15:21:05</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549436</td>
<td>302288-C-CityLink:2026-01-09 04:55:44</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549437</td>
<td>302288-C-CityLink:2026-01-09 06:57:55</td>
<td>10.80</td>
<td>1.08</td>
<td>11.88</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549438</td>
<td>302288-C-CityLink:2026-01-09 15:21:05</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549439</td>
<td>302288-C-Video Matching Fee:2026-01-12 22:36:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549440</td>
<td>302288-C-CityLink:2026-01-12 22:36:20</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549441</td>
<td>302288-C-Video Matching Fee:2026-01-13 03:56:52</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549442</td>
<td>302288-C-CityLink:2026-01-13 03:56:52</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549443</td>
<td>302288-C-Video Matching Fee:2026-01-15 16:30:08</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YR8DJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Scott Long</td>
<td>4843549444</td>
<td>302288-C-CityLink:2026-01-15 16:30:08</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551201</td>
<td>305504-C-Video Matching Fee : 2025-12-12 07:23:57</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551202</td>
<td>305504-C-CityLink : 2025-12-12 07:23:57</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551203</td>
<td>305504-C-Video Matching Fee : 2025-12-15 16:23:53</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551204</td>
<td>305504-C-West Gate Tunnel : 2025-12-15 16:23:53</td>
<td>5.95</td>
<td>0.60</td>
<td>6.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551205</td>
<td>305504-C-Video Matching Fee : 2025-12-16 11:02:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551206</td>
<td>305504-C-Video Matching Fee : 2025-12-16 08:04:05</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551207</td>
<td>305504-C-CityLink : 2025-12-16 08:04:05</td>
<td>2.97</td>
<td>0.30</td>
<td>3.27</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551208</td>
<td>305504-C-West Gate Tunnel : 2025-12-16 11:02:32</td>
<td>5.95</td>
<td>0.60</td>
<td>6.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551209</td>
<td>305504-C-Video Matching Fee : 2025-12-22 07:12:28</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551210</td>
<td>305504-C-Video Matching Fee : 2025-12-22 14:23:10</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 30 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td colspan="2">GST Total</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551211</td>
<td>305504-C-CityLink-West Gate Tunnel : 2025-12-22</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551212</td>
<td>305504-C-CityLink-West Gate Tunnel : 2025-12-22</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551213</td>
<td>305504-C-Video Matching Fee : 2025-12-23 07:18:06</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551214</td>
<td>305504-C-Video Matching Fee : 2025-12-23 14:15:11</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551215</td>
<td>305504-C-CityLink-West Gate Tunnel : 2025-12-23</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551216</td>
<td>305504-C-CityLink-West Gate Tunnel : 2025-12-23</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551217</td>
<td>305504-C-Video Matching Fee : 2025-12-24 07:22:17</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551218</td>
<td>305504-C-Video Matching Fee : 2025-12-24 14:33:46</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551219</td>
<td>305504-C-CityLink-West Gate Tunnel : 2025-12-24</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551220</td>
<td>305504-C-CityLink-West Gate Tunnel : 2025-12-24</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551221</td>
<td>305504-C-Video Matching Fee : 2025-12-30 13:10:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551222</td>
<td>305504-C-Video Matching Fee : 2025-12-30 13:30:37</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551223</td>
<td>305504-C-Video Matching Fee : 2025-12-30 20:39:15</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551224</td>
<td>305504-C-Video Matching Fee : 2025-12-30 20:52:52</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551225</td>
<td>305504-C-West Gate Tunnel : 2025-12-30 13:10:02</td>
<td>5.95</td>
<td>0.60</td>
<td>6.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551226</td>
<td>305504-C-West Gate Tunnel : 2025-12-30 20:52:52</td>
<td>5.95</td>
<td>0.60</td>
<td>6.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551227</td>
<td>305504-C-CityLink : 2025-12-30 13:30:37</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551228</td>
<td>305504-C-CityLink : 2025-12-30 20:39:15</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551229</td>
<td>305504-C-Video Matching Fee:2026-01-01 14:07:37</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551230</td>
<td>305504-C-Video Matching Fee:2026-01-01 14:24:37</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551231</td>
<td>305504-C-Video Matching Fee:2026-01-01 17:16:46</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551232</td>
<td>305504-C-West Gate Tunnel:2026-01-01 14:07:37</td>
<td>6.01</td>
<td>0.60</td>
<td>6.61</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551233</td>
<td>305504-C-CityLink-West Gate Tunnel:2026-01-01 17:16:46</td>
<td>10.80</td>
<td>1.08</td>
<td>11.88</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551234</td>
<td>305504-C-CityLink:2026-01-01 14:24:37</td>
<td>10.80</td>
<td>1.08</td>
<td>11.88</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551235</td>
<td>305504-C-Video Matching Fee:2026-01-02 10:18:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551236</td>
<td>305504-C-Video Matching Fee:2026-01-02 10:37:19</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551237</td>
<td>305504-C-Video Matching Fee:2026-01-02 18:37:46</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551238</td>
<td>305504-C-West Gate Tunnel:2026-01-02 10:18:34</td>
<td>6.01</td>
<td>0.60</td>
<td>6.61</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551239</td>
<td>305504-C-CityLink:2026-01-02 10:37:19</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551240</td>
<td>305504-C-CityLink:2026-01-02 18:37:46</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551241</td>
<td>305504-C-Video Matching Fee:2026-01-05 07:14:59</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551242</td>
<td>305504-C-Video Matching Fee:2026-01-05 15:54:54</td>
<td>0.50</td>
<td colspan="2">0.05 0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551243</td>
<td>305504-C-CityLink-West Gate Tunnel:2026-01-05 07:14:59</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 31 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551244</td>
<td>305504-C-CityLink-West Gate Tunnel:2026-01-05 15:54:54</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551245</td>
<td>305504-C-Video Matching Fee:2026-01-06 07:27:09</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551246</td>
<td>305504-C-Video Matching Fee:2026-01-06 14:47:25</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551247</td>
<td>305504-C-CityLink-West Gate Tunnel:2026-01-06 07:27:09</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551248</td>
<td>305504-C-CityLink-West Gate Tunnel:2026-01-06 14:47:25</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551249</td>
<td>305504-C-Video Matching Fee:2026-01-12 08:05:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551250</td>
<td>305504-C-Video Matching Fee:2026-01-12 11:44:09</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551251</td>
<td>305504-C-CityLink:2026-01-12 08:05:55</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BG</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Bishnu Khanal</td>
<td>4843551252</td>
<td>305504-C-CityLink-West Gate Tunnel:2026-01-12 11:44:09</td>
<td>10.80</td>
<td>1.08</td>
<td>11.88</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551001</td>
<td>305495-C-Video Matching Fee : 2025-12-11 15:40:42</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551002</td>
<td>305495-C-CityLink : 2025-12-11 15:40:42</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551003</td>
<td>305495-C-Video Matching Fee : 2025-12-12 07:13:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551004</td>
<td>305495-C-CityLink : 2025-12-12 07:13:55</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551005</td>
<td>305495-C-Video Matching Fee : 2025-12-15 06:50:26</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551006</td>
<td>305495-C-Video Matching Fee : 2025-12-15 16:17:15</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551007</td>
<td>305495-C-EastLink : 2025-12-15 06:50:26</td>
<td>3.39</td>
<td>0.34</td>
<td>3.73</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551008</td>
<td>305495-C-CityLink : 2025-12-15 16:17:15</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551009</td>
<td>305495-C-Video Matching Fee : 2025-12-16 16:20:13</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551010</td>
<td>305495-C-CityLink : 2025-12-16 16:20:13</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551011</td>
<td>305495-C-Video Matching Fee : 2025-12-17 15:14:44</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551012</td>
<td>305495-C-Video Matching Fee : 2025-12-17 06:27:13</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551013</td>
<td>305495-C-Video Matching Fee : 2025-12-17 13:21:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551014</td>
<td>305495-C-CityLink : 2025-12-17 13:21:34</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551015</td>
<td>305495-C-CityLink : 2025-12-17 06:27:13</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551016</td>
<td>305495-C-CityLink : 2025-12-17 15:14:44</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551017</td>
<td>305495-C-Video Matching Fee : 2025-12-19 15:14:13</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551018</td>
<td>305495-C-Video Matching Fee : 2025-12-19 06:41:37</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551019</td>
<td>305495-C-Video Matching Fee : 2025-12-19 14:50:19</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551020</td>
<td>305495-C-Video Matching Fee : 2025-12-19 08:14:23</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551021</td>
<td>305495-C-EastLink : 2025-12-19 06:41:37</td>
<td>6.02</td>
<td>0.60</td>
<td>6.62</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551022</td>
<td>305495-C-EastLink : 2025-12-19 15:14:13</td>
<td>8.67</td>
<td>0.87</td>
<td>9.54</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551023</td>
<td>305495-C-CityLink : 2025-12-19 14:50:19</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551024</td>
<td>305495-C-CityLink : 2025-12-19 08:14:23</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 32 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551025</td>
<td>305495-C-Video Matching Fee:2026-01-02 14:11:25</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551026</td>
<td>305495-C-Video Matching Fee:2026-01-02 14:33:16</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551027</td>
<td>305495-C-EastLink:2026-01-02 14:11:25</td>
<td>4.89</td>
<td>0.49</td>
<td>5.38</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551028</td>
<td>305495-C-EastLink:2026-01-02 14:33:16</td>
<td>4.89</td>
<td>0.49</td>
<td>5.38</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551029</td>
<td>305495-C-Video Matching Fee:2026-01-04 07:38:03</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551030</td>
<td>305495-C-Video Matching Fee:2026-01-04 11:40:58</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551031</td>
<td>305495-C-CityLink:2026-01-04 07:38:03</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551032</td>
<td>305495-C-CityLink:2026-01-04 11:40:58</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551033</td>
<td>305495-C-Video Matching Fee:2026-01-06 07:17:17</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551034</td>
<td>305495-C-Video Matching Fee:2026-01-06 08:38:43</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551035</td>
<td>305495-C-Video Matching Fee:2026-01-06 15:34:46</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551036</td>
<td>305495-C-EastLink:2026-01-06 07:17:17</td>
<td>4.89</td>
<td>0.49</td>
<td>5.38</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551037</td>
<td>305495-C-CityLink:2026-01-06 08:38:43</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551038</td>
<td>305495-C-CityLink:2026-01-06 15:34:46</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551039</td>
<td>305495-C-Video Matching Fee:2026-01-07 16:12:12</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551040</td>
<td>305495-C-Video Matching Fee:2026-01-07 06:49:52</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551041</td>
<td>305495-C-EastLink:2026-01-07 16:12:12</td>
<td>11.30</td>
<td>1.13</td>
<td>12.43</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551042</td>
<td>305495-C-CityLink:2026-01-07 06:49:52</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551043</td>
<td>305495-C-Video Matching Fee:2026-01-08 16:11:56</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551044</td>
<td>305495-C-Video Matching Fee:2026-01-08 15:49:43</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551045</td>
<td>305495-C-Video Matching Fee:2026-01-08 07:09:03</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551046</td>
<td>305495-C-EastLink:2026-01-08 16:11:56</td>
<td>8.67</td>
<td>0.87</td>
<td>9.54</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551047</td>
<td>305495-C-CityLink:2026-01-08 07:09:03</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551048</td>
<td>305495-C-CityLink:2026-01-08 15:49:43</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551049</td>
<td>305495-C-Video Matching Fee:2026-01-09 06:43:39</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551050</td>
<td>305495-C-Video Matching Fee:2026-01-09 15:23:11</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551051</td>
<td>305495-C-CityLink:2026-01-09 15:23:11</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZB5BJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Michael Armstrong</td>
<td>4843551052</td>
<td>305495-C-CityLink:2026-01-09 06:43:39</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548901</td>
<td>296349-C-Video Matching Fee : 2025-12-12 14:01:27</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548902</td>
<td>296349-C-CityLink : 2025-12-12 14:01:27</td>
<td>5.95</td>
<td>0.60</td>
<td>6.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548903</td>
<td>296349-C-Video Matching Fee : 2025-12-15 15:00:30</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548904</td>
<td>296349-C-CityLink : 2025-12-15 15:00:30</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548905</td>
<td>296349-C-Video Matching Fee : 2025-12-17 16:23:41</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 33 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548906</td>
<td>296349-C-Video Matching Fee : 2025-12-17 07:32:01</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548907</td>
<td>296349-C-West Gate Tunnel : 2025-12-17 07:32:01</td>
<td>5.95</td>
<td>0.60</td>
<td>6.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548908</td>
<td>296349-C-CityLink : 2025-12-17 16:23:41</td>
<td>5.95</td>
<td>0.60</td>
<td>6.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548909</td>
<td>296349-C-Video Matching Fee : 2025-12-19 14:49:14</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548910</td>
<td>296349-C-Video Matching Fee : 2025-12-19 22:22:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548911</td>
<td>296349-C-CityLink : 2025-12-19 14:49:14</td>
<td>5.95</td>
<td>0.60</td>
<td>6.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548912</td>
<td>296349-C-CityLink : 2025-12-19 22:22:36</td>
<td>5.95</td>
<td>0.60</td>
<td>6.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548913</td>
<td>296349-C-Video Matching Fee : 2025-12-22 12:12:27</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548914</td>
<td>296349-C-Video Matching Fee : 2025-12-22 07:33:41</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548915</td>
<td>296349-C-Video Matching Fee : 2025-12-22 15:07:33</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548916</td>
<td>296349-C-EastLink : 2025-12-22 12:12:27</td>
<td>1.13</td>
<td>0.11</td>
<td>1.24</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548917</td>
<td>296349-C-CityLink : 2025-12-22 07:33:41</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548918</td>
<td>296349-C-CityLink : 2025-12-22 15:07:33</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548919</td>
<td>296349-C-Video Matching Fee : 2025-12-23 07:13:43</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548920</td>
<td>296349-C-Video Matching Fee : 2025-12-23 15:23:26</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548921</td>
<td>296349-C-CityLink : 2025-12-23 07:13:43</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548922</td>
<td>296349-C-CityLink : 2025-12-23 15:23:26</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548923</td>
<td>296349-C-Video Matching Fee : 2025-12-24 14:27:14</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548924</td>
<td>296349-C-Video Matching Fee : 2025-12-24 07:13:25</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548925</td>
<td>296349-C-CityLink : 2025-12-24 07:13:25</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AQ7XR</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Matt Maroney</td>
<td>4843548926</td>
<td>296349-C-CityLink : 2025-12-24 14:27:14</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545601</td>
<td>256892-C-AirportlinkM7 : 2025-12-16 06:15:11</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545602</td>
<td>256892-C-AirportlinkM7 : 2025-12-16 16:09:16</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545603</td>
<td>256892-C-AirportlinkM7 : 2025-12-19 14:43:50</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545604</td>
<td>256892-C-Go Between Bridge : 2025-12-21 14:01:42</td>
<td>5.53</td>
<td>0.55</td>
<td>6.08</td>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545605</td>
<td>256892-C-Go Between Bridge : 2025-12-21 18:09:37</td>
<td>5.53</td>
<td>0.55</td>
<td>6.08</td>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545606</td>
<td>256892-C-AirportlinkM7 : 2025-12-21 13:53:45</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545607</td>
<td>256892-C-AirportlinkM7 : 2025-12-21 18:14:45</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545608</td>
<td>256892-C-AirportlinkM7 : 2025-12-22 07:16:48</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545609</td>
<td>256892-C-AirportlinkM7 : 2025-12-22 10:37:28</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545610</td>
<td>256892-C-AirportlinkM7 : 2025-12-23 07:16:30</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545611</td>
<td>256892-C-AirportlinkM7 : 2025-12-23 10:01:37</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545612</td>
<td>256892-C-AirportlinkM7 : 2025-12-24 08:38:20</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 34 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No. AU1166479</th>
<th>Invoice Date 31 January 2026</th>
<th>Invoice No. AIN00014651</th>
<th colspan="2"></th>
<th colspan="3">P</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545613</td>
<td>256892-C-AirportlinkM7:2026-01-02 11:37:39</td>
<td>9.76</td>
<td>0.98</td>
<td>10.74</td>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545614</td>
<td>256892-C-AirportlinkM7:2026-01-02 13:44:37</td>
<td>9.76</td>
<td>0.98</td>
<td>10.74</td>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545615</td>
<td>256892-C-Toowoomba Second Range Crossing:2026-01-05</td>
<td>6.49</td>
<td>0.65</td>
<td>7.14</td>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545616</td>
<td>256892-C-Legacy Way:2026-01-05 05:32:49</td>
<td>9.55</td>
<td>0.96</td>
<td>10.51</td>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545617</td>
<td>256892-C-AirportlinkM7:2026-01-05 05:23:12</td>
<td>9.76</td>
<td>0.98</td>
<td>10.74</td>
</tr>
<tr>
<td>QLD</td>
<td>709LN4</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Luke Murphy</td>
<td>4843548701</td>
<td>296346-C-Video Matching Fee:2026-01-08 16:52:44</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>709LN4</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Luke Murphy</td>
<td>4843548702</td>
<td>296346-C-Legacy Way:2026-01-08 16:52:44</td>
<td>9.55</td>
<td>0.96</td>
<td>10.51</td>
</tr>
<tr>
<td>QLD</td>
<td>709LN4</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Luke Murphy</td>
<td>4843548703</td>
<td>296346-C-Video Matching Fee:2026-01-09 08:25:29</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>709LN4</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Luke Murphy</td>
<td>4843548704</td>
<td>296346-C-Legacy Way:2026-01-09 08:25:29</td>
<td>9.55</td>
<td>0.96</td>
<td>10.51</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551101</td>
<td>305497-C-Video Matching Fee : 2025-12-10 14:40:52</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551102</td>
<td>305497-C-CityLink : 2025-12-10 14:40:52</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551103</td>
<td>305497-C-Video Matching Fee : 2025-12-11 15:32:27</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551104</td>
<td>305497-C-CityLink : 2025-12-11 15:32:27</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551105</td>
<td>305497-C-Video Matching Fee : 2025-12-12 08:02:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551106</td>
<td>305497-C-Video Matching Fee : 2025-12-12 17:58:39</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551107</td>
<td>305497-C-Video Matching Fee : 2025-12-12 22:49:22</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551108</td>
<td>305497-C-CityLink : 2025-12-12 08:02:02</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551109</td>
<td>305497-C-CityLink : 2025-12-12 22:49:22</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551110</td>
<td>305497-C-CityLink : 2025-12-12 17:58:39</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551111</td>
<td>305497-C-Video Matching Fee : 2025-12-15 07:42:59</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551112</td>
<td>305497-C-CityLink : 2025-12-15 07:42:59</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551113</td>
<td>305497-C-Video Matching Fee : 2025-12-16 16:03:05</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551114</td>
<td>305497-C-Video Matching Fee : 2025-12-16 11:59:29</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551115</td>
<td>305497-C-CityLink : 2025-12-16 11:59:29</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551116</td>
<td>305497-C-CityLink : 2025-12-16 16:03:05</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551117</td>
<td>305497-C-Video Matching Fee : 2025-12-18 07:42:42</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551118</td>
<td>305497-C-Video Matching Fee : 2025-12-18 16:54:15</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551119</td>
<td>305497-C-CityLink : 2025-12-18 07:42:42</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551120</td>
<td>305497-C-CityLink : 2025-12-18 16:54:15</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551121</td>
<td>305497-C-Video Matching Fee : 2025-12-19 08:20:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551122</td>
<td>305497-C-Video Matching Fee : 2025-12-19 14:39:35</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">QLD 843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551123</td>
<td>305497-C-CityLink : 2025-12-19 08:20:16</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td colspan="2">QLD 843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551124</td>
<td>305497-C-CityLink : 2025-12-19 14:39:35</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 35 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No. AU1166479</th>
<th>Invoice Date 31 January 2026</th>
<th colspan="3">Invoice No. AIN00014651</th>
<th></th>
<th colspan="2">P</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551125</td>
<td>305497-C-Video Matching Fee : 2025-12-23 07:54:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551126</td>
<td>305497-C-Video Matching Fee : 2025-12-23 15:19:43</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551127</td>
<td>305497-C-CityLink : 2025-12-23 15:19:43</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551128</td>
<td>305497-C-CityLink : 2025-12-23 07:54:32</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551129</td>
<td>305497-C-Video Matching Fee : 2025-12-24 07:21:30</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551130</td>
<td>305497-C-Video Matching Fee : 2025-12-24 14:43:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551131</td>
<td>305497-C-CityLink : 2025-12-24 14:43:31</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551132</td>
<td>305497-C-CityLink : 2025-12-24 07:21:30</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551133</td>
<td>305497-C-Video Matching Fee : 2025-12-29 08:07:05</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551134</td>
<td>305497-C-Video Matching Fee : 2025-12-29 14:54:13</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551135</td>
<td>305497-C-CityLink-West Gate Tunnel : 2025-12-29</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551136</td>
<td>305497-C-CityLink : 2025-12-29 08:07:05</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551137</td>
<td>305497-C-Video Matching Fee : 2025-12-30 14:17:21</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551138</td>
<td>305497-C-Video Matching Fee : 2025-12-30 07:45:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551139</td>
<td>305497-C-CityLink : 2025-12-30 14:17:21</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551140</td>
<td>305497-C-CityLink : 2025-12-30 07:45:31</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551141</td>
<td>305497-C-Video Matching Fee : 2025-12-31 07:55:12</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551142</td>
<td>305497-C-Video Matching Fee : 2025-12-31 13:24:33</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551143</td>
<td>305497-C-CityLink : 2025-12-31 07:55:12</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>QLD</td>
<td>843LS9</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843551144</td>
<td>305497-C-CityLink : 2025-12-31 13:24:33</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550401</td>
<td>305031-C-Video Matching Fee : 2025-12-11 17:59:50</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550402</td>
<td>305031-C-AirportlinkM7 : 2025-12-11 17:59:50</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550403</td>
<td>305031-C-Video Matching Fee : 2025-12-15 16:27:27</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550404</td>
<td>305031-C-AirportlinkM7 : 2025-12-15 16:27:27</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550405</td>
<td>305031-C-Video Matching Fee : 2025-12-16 07:39:36</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550406</td>
<td>305031-C-Video Matching Fee : 2025-12-16 15:22:07</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550407</td>
<td>305031-C-AirportlinkM7 : 2025-12-16 07:39:36</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550408</td>
<td>305031-C-AirportlinkM7 : 2025-12-16 15:22:07</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550409</td>
<td>305031-C-Video Matching Fee : 2025-12-17 07:37:35</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550410</td>
<td>305031-C-Video Matching Fee : 2025-12-17 16:36:45</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550411</td>
<td>305031-C-AirportlinkM7 : 2025-12-17 07:37:35</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550412</td>
<td>305031-C-AirportlinkM7 : 2025-12-17 16:36:45</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td colspan="2">QLD 909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550413</td>
<td>305031-C-Video Matching Fee : 2025-12-18 07:49:33</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 36 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net GST Total</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550414</td>
<td>305031-C-Video Matching Fee : 2025-12-18 12:47:07</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550415</td>
<td>305031-C-AirportlinkM7 : 2025-12-18 07:49:33</td>
<td>9.32 0.93 10.25</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550416</td>
<td>305031-C-AirportlinkM7 : 2025-12-18 12:47:07</td>
<td>9.32 0.93 10.25</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550417</td>
<td>305031-C-Video Matching Fee : 2025-12-28 11:49:37</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550418</td>
<td>305031-C-AirportlinkM7 : 2025-12-28 11:49:37</td>
<td>6.99 0.70 7.69</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550419</td>
<td>305031-C-Video Matching Fee:2026-01-06 11:20:02</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550420</td>
<td>305031-C-Video Matching Fee:2026-01-06 14:26:38</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550421</td>
<td>305031-C-AirportlinkM7:2026-01-06 11:20:02</td>
<td>9.76 0.98 10.74</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550422</td>
<td>305031-C-AirportlinkM7:2026-01-06 14:26:38</td>
<td>9.76 0.98 10.74</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550423</td>
<td>305031-C-Video Matching Fee:2026-01-09 14:08:13</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550424</td>
<td>305031-C-AirportlinkM7:2026-01-09 14:08:13</td>
<td>9.76 0.98 10.74</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550425</td>
<td>305031-C-Video Matching Fee:2026-01-12 14:19:59</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550426</td>
<td>305031-C-Video Matching Fee:2026-01-12 14:26:08</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550427</td>
<td>305031-C-Video Matching Fee:2026-01-12 05:42:50</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550428</td>
<td>305031-C-Video Matching Fee:2026-01-12 05:52:38</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550429</td>
<td>305031-C-Legacy Way:2026-01-12 05:52:38</td>
<td>9.55 0.96 10.51</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550430</td>
<td>305031-C-Legacy Way:2026-01-12 14:19:59</td>
<td>9.55 0.96 10.51</td>
</tr>
<tr>
<td colspan="2">QLD 909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550431</td>
<td>305031-C-AirportlinkM7:2026-01-12 05:42:50</td>
<td>9.76 0.98 10.74</td>
</tr>
<tr>
<td colspan="2">QLD 909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550432</td>
<td>305031-C-AirportlinkM7:2026-01-12 14:26:08</td>
<td>9.76 0.98 10.74</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550433</td>
<td>305031-C-Video Matching Fee:2026-01-13 08:07:26</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550434</td>
<td>305031-C-AirportlinkM7:2026-01-13 08:07:26</td>
<td>9.76 0.98 10.74</td>
</tr>
<tr>
<td colspan="2">QLD 909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550435</td>
<td>305031-C-Video Matching Fee:2026-01-14 09:53:08</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550436</td>
<td>305031-C-Video Matching Fee:2026-01-14 14:43:27</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550437</td>
<td>305031-C-Gateway Motorway:2026-01-14 09:53:08</td>
<td>7.89 0.79 8.68</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550438</td>
<td>305031-C-Gateway Motorway:2026-01-14 14:43:27</td>
<td>7.89 0.79 8.68</td>
</tr>
<tr>
<td>QLD</td>
<td>909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550439</td>
<td>305031-C-Video Matching Fee:2026-01-15 07:59:46</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td colspan="2">QLD 909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550440</td>
<td>305031-C-Video Matching Fee:2026-01-15 08:50:16</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td colspan="2">QLD 909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550441</td>
<td>305031-C-Video Matching Fee:2026-01-15 17:21:45</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td colspan="2">QLD 909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550442</td>
<td>305031-C-Legacy Way:2026-01-15 08:50:16</td>
<td>9.55 0.96 10.51</td>
</tr>
<tr>
<td colspan="2">QLD 909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550443</td>
<td>305031-C-Legacy Way:2026-01-15 17:21:45</td>
<td>9.55 0.96 10.51</td>
</tr>
<tr>
<td colspan="2">QLD 909LE6</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Aaron Hall</td>
<td>4843550444</td>
<td>305031-C-AirportlinkM7:2026-01-15 07:59:46</td>
<td>9.76 0.98 10.74</td>
</tr>
<tr>
<td colspan="2">QLD 966HT7</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Kevin Wilkie</td>
<td>4843548001</td>
<td>295651-C-Video Matching Fee : 2025-12-19 05:08:18</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td colspan="2">QLD 966HT7</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Kevin Wilkie</td>
<td>4843548002</td>
<td>295651-C-Gateway Motorway : 2025-12-19 05:08:18</td>
<td>7.89 0.79 8.68</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 37 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net GST Total</td>
</tr>
<tr>
<td>QLD</td>
<td>966HT7</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Kevin Wilkie</td>
<td>4843548003</td>
<td>295651-C-Video Matching Fee : 2025-12-20 13:52:09</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>966HT7</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Kevin Wilkie</td>
<td>4843548004</td>
<td>295651-C-Video Matching Fee : 2025-12-20 14:04:17</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>966HT7</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Kevin Wilkie</td>
<td>4843548005</td>
<td>295651-C-Logan Motorway : 2025-12-20 13:52:09</td>
<td>4.65 0.47 5.12</td>
</tr>
<tr>
<td>QLD</td>
<td>966HT7</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Kevin Wilkie</td>
<td>4843548006</td>
<td>295651-C-Gateway Motorway : 2025-12-20 14:04:17</td>
<td>7.89 0.79 8.68</td>
</tr>
<tr>
<td>QLD</td>
<td>966HT7</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Kevin Wilkie</td>
<td>4843548007</td>
<td>295651-C-Video Matching Fee:2026-01-06 13:22:35</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>966HT7</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Kevin Wilkie</td>
<td>4843548008</td>
<td>295651-C-AirportlinkM7:2026-01-06 13:22:35</td>
<td>9.76 0.98 10.74</td>
</tr>
<tr>
<td>QLD</td>
<td>966HT7</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Kevin Wilkie</td>
<td>4843548009</td>
<td>295651-C-Video Matching Fee:2026-01-09 11:14:00</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>966HT7</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Kevin Wilkie</td>
<td>4843548010</td>
<td>295651-C-Video Matching Fee:2026-01-09 06:36:02</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>966HT7</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Kevin Wilkie</td>
<td>4843548011</td>
<td>295651-C-Gateway Motorway:2026-01-09 06:36:02</td>
<td>7.89 0.79 8.68</td>
</tr>
<tr>
<td>QLD</td>
<td>966HT7</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Kevin Wilkie</td>
<td>4843548012</td>
<td>295651-C-AirportlinkM7:2026-01-09 11:14:00</td>
<td>9.76 0.98 10.74</td>
</tr>
<tr>
<td>QLD</td>
<td>974LE6</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Steven Crooks</td>
<td>4843551301</td>
<td>306150-C-Video Matching Fee:2026-01-11 07:54:53</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>974LE6</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Steven Crooks</td>
<td>4843551302</td>
<td>306150-C-Gateway Motorway:2026-01-11 07:54:53</td>
<td>7.89 0.79 8.68</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548201</td>
<td>295657-C-Video Matching Fee : 2025-12-16 12:27:59</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548202</td>
<td>295657-C-Video Matching Fee : 2025-12-16 12:34:41</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548203</td>
<td>295657-C-Video Matching Fee : 2025-12-16 10:45:43</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548204</td>
<td>295657-C-Video Matching Fee : 2025-12-16 13:22:46</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548205</td>
<td>295657-C-M5 South West Motorway : 2025-12-16</td>
<td>5.33 0.53 5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548206</td>
<td>295657-C-WestConnex : 2025-12-16 13:22:46</td>
<td>5.66 0.57 6.23</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548207</td>
<td>295657-C-WestConnex : 2025-12-16 10:45:43</td>
<td>5.90 0.59 6.49</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548208</td>
<td>295657-C-WestConnex : 2025-12-16 12:34:41</td>
<td>6.78 0.68 7.46</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548209</td>
<td>295657-C-Video Matching Fee : 2025-12-18 08:28:18</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548210</td>
<td>295657-C-Video Matching Fee : 2025-12-18 16:50:50</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548211</td>
<td>295657-C-Video Matching Fee : 2025-12-18 16:29:41</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548212</td>
<td>295657-C-M5 South West Motorway : 2025-12-18</td>
<td>5.33 0.53 5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548213</td>
<td>295657-C-WestConnex : 2025-12-18 08:28:18</td>
<td>5.90 0.59 6.49</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548214</td>
<td>295657-C-WestLink M7 : 2025-12-18 16:29:41</td>
<td>8.54 0.85 9.39</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548215</td>
<td>295657-C-Video Matching Fee : 2025-12-19 06:07:59</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548216</td>
<td>295657-C-Video Matching Fee : 2025-12-19 15:40:25</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548217</td>
<td>295657-C-WestLink M7 : 2025-12-19 15:29:05</td>
<td>0.63 0.06 0.69</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548218</td>
<td>295657-C-Video Matching Fee : 2025-12-19 15:29:05</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548219</td>
<td>295657-C-WestConnex : 2025-12-19 06:07:59</td>
<td>5.90 0.59 6.49</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548220</td>
<td>295657-C-WestConnex : 2025-12-19 15:40:25</td>
<td>5.90 0.59 6.49</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548221</td>
<td>295657-C-Video Matching Fee : 2025-12-22 07:42:49</td>
<td>0.50 0.05 0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 38 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No. AU1166479</th>
<th>Invoice Date 31 January 2026</th>
<th colspan="3">Invoice No. AIN00014651</th>
<th></th>
<th colspan="2">P</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548222</td>
<td>295657-C-Video Matching Fee : 2025-12-22 07:26:58</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548223</td>
<td>295657-C-Video Matching Fee : 2025-12-22 13:40:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548224</td>
<td>295657-C-Video Matching Fee : 2025-12-22 13:49:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548225</td>
<td>295657-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-22</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548226</td>
<td>295657-C-WestConnex : 2025-12-22 07:26:58</td>
<td>6.70</td>
<td>0.67</td>
<td>7.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548227</td>
<td>295657-C-Eastern Distributor : 2025-12-22 07:42:49</td>
<td>9.24</td>
<td>0.92</td>
<td>10.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548228</td>
<td>295657-C-WestConnex : 2025-12-22 13:49:32</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548229</td>
<td>295657-C-Video Matching Fee : 2025-12-23 06:59:54</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548230</td>
<td>295657-C-Video Matching Fee : 2025-12-23 14:16:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548231</td>
<td>295657-C-WestLink M7 : 2025-12-23 14:05:33</td>
<td>0.63</td>
<td>0.06</td>
<td>0.69</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548232</td>
<td>295657-C-Video Matching Fee : 2025-12-23 14:05:33</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548233</td>
<td>295657-C-WestConnex : 2025-12-23 06:59:54</td>
<td>5.90</td>
<td>0.59</td>
<td>6.49</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548234</td>
<td>295657-C-WestConnex : 2025-12-23 14:16:20</td>
<td>5.90</td>
<td>0.59</td>
<td>6.49</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548235</td>
<td>295657-C-Video Matching Fee : 2025-12-24 07:50:25</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548236</td>
<td>295657-C-WestConnex : 2025-12-24 07:50:25</td>
<td>5.90</td>
<td>0.59</td>
<td>6.49</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548237</td>
<td>295657-C-Video Matching Fee : 2025-12-30 13:16:13</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548238</td>
<td>295657-C-Video Matching Fee : 2025-12-30 11:37:41</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548239</td>
<td>295657-C-Video Matching Fee : 2025-12-30 13:16:01</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548240</td>
<td>295657-C-Video Matching Fee : 2025-12-30 14:58:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548241</td>
<td>295657-C-Video Matching Fee : 2025-12-30 15:17:12</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548242</td>
<td>295657-C-WestConnex : 2025-12-30 15:17:12</td>
<td>3.30</td>
<td>0.33</td>
<td>3.63</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548243</td>
<td>295657-C-Hills M2 : 2025-12-30 13:16:01</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548244</td>
<td>295657-C-WestConnex : 2025-12-30 11:37:41</td>
<td>4.81</td>
<td>0.48</td>
<td>5.29</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548245</td>
<td>295657-C-North Connex : 2025-12-30 14:58:32</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548246</td>
<td>295657-C-North Connex : 2025-12-30 13:16:13</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548247</td>
<td>295657-C-Video Matching Fee : 2025-12-31 11:56:24</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548248</td>
<td>295657-C-WestConnex : 2025-12-31 11:56:24</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548249</td>
<td>295657-C-Video Matching Fee:2026-01-05 11:27:53</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548250</td>
<td>295657-C-Video Matching Fee:2026-01-05 14:03:04</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548251</td>
<td>295657-C-WestConnex:2026-01-05 11:27:53</td>
<td>5.00</td>
<td>0.50</td>
<td>5.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548252</td>
<td>295657-C-WestConnex:2026-01-05 14:03:04</td>
<td>5.00</td>
<td>0.50</td>
<td>5.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548253</td>
<td>295657-C-Video Matching Fee:2026-01-07 08:23:10</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548254</td>
<td>295657-C-Video Matching Fee:2026-01-07 17:35:45</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 39 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th colspan="2" rowspan="2"></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548255</td>
<td>295657-C-Video Matching Fee:2026-01-07 17:17:13</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548256</td>
<td>295657-C-M5 South West Motorway:2026-01-07 17:35:45</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548257</td>
<td>295657-C-WestConnex:2026-01-07 08:23:10</td>
<td>6.14</td>
<td>0.61</td>
<td>6.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548258</td>
<td>295657-C-WestLink M7:2026-01-07 17:17:13</td>
<td>8.65</td>
<td>0.87</td>
<td>9.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548259</td>
<td>295657-C-Video Matching Fee:2026-01-08 11:41:30</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548260</td>
<td>295657-C-Video Matching Fee:2026-01-08 15:31:19</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548261</td>
<td>295657-C-WestConnex:2026-01-08 11:41:30</td>
<td>5.00</td>
<td>0.50</td>
<td>5.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548262</td>
<td>295657-C-WestConnex:2026-01-08 15:31:19</td>
<td>5.00</td>
<td>0.50</td>
<td>5.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548263</td>
<td>295657-C-Video Matching Fee:2026-01-09 06:11:27</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548264</td>
<td>295657-C-Video Matching Fee:2026-01-09 13:03:56</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548265</td>
<td>295657-C-Video Matching Fee:2026-01-09 14:19:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548266</td>
<td>295657-C-Video Matching Fee:2026-01-09 16:42:50</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548267</td>
<td>295657-C-WestConnex:2026-01-09 14:19:18</td>
<td>3.20</td>
<td>0.32</td>
<td>3.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548268</td>
<td>295657-C-WestConnex:2026-01-09 13:03:56</td>
<td>3.20</td>
<td>0.32</td>
<td>3.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548269</td>
<td>295657-C-WestConnex:2026-01-09 16:42:50</td>
<td>5.00</td>
<td>0.50</td>
<td>5.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548270</td>
<td>295657-C-WestConnex:2026-01-09 06:11:27</td>
<td>5.00</td>
<td>0.50</td>
<td>5.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548271</td>
<td>295657-C-Video Matching Fee:2026-01-12 10:27:40</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548272</td>
<td>295657-C-Video Matching Fee:2026-01-12 07:36:17</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548273</td>
<td>295657-C-WestConnex:2026-01-12 07:36:17</td>
<td>5.00</td>
<td>0.50</td>
<td>5.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548274</td>
<td>295657-C-WestConnex:2026-01-12 10:27:40</td>
<td>11.36</td>
<td>1.14</td>
<td>12.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548275</td>
<td>295657-C-Video Matching Fee:2026-01-13 15:42:42</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548276</td>
<td>295657-C-Video Matching Fee:2026-01-13 06:33:53</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548277</td>
<td>295657-C-WestConnex:2026-01-13 15:42:42</td>
<td>5.00</td>
<td>0.50</td>
<td>5.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548278</td>
<td>295657-C-WestConnex:2026-01-13 06:33:53</td>
<td>5.00</td>
<td>0.50</td>
<td>5.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548279</td>
<td>295657-C-Video Matching Fee:2026-01-14 06:21:01</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548280</td>
<td>295657-C-Video Matching Fee:2026-01-14 17:13:52</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548281</td>
<td>295657-C-WestConnex:2026-01-14 17:13:52</td>
<td>5.00</td>
<td>0.50</td>
<td>5.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548282</td>
<td>295657-C-WestConnex:2026-01-14 06:21:01</td>
<td>5.00</td>
<td>0.50</td>
<td>5.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548283</td>
<td>295657-C-Video Matching Fee:2026-01-15 06:19:43</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548284</td>
<td>295657-C-Video Matching Fee:2026-01-15 17:47:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548285</td>
<td>295657-C-WestConnex:2026-01-15 17:47:32</td>
<td>5.00</td>
<td>0.50</td>
<td>5.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DK39RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arif Ullah</td>
<td>4843548286</td>
<td>295657-C-WestConnex:2026-01-15 06:19:43</td>
<td>5.00</td>
<td>0.50</td>
<td>5.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547301</td>
<td>295193-C-WestLink M7 : 2025-12-03 07:14:40</td>
<td>-9.25</td>
<td>-0.93</td>
<td>-10.18</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 40 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547302</td>
<td>295193-C-Video Matching Fee : 2025-12-03 07:14:40</td>
<td>-0.68</td>
<td>-0.07</td>
<td>-0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547303</td>
<td>295193-C-Video Matching Fee : 2025-12-03 07:51:34</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547304</td>
<td>295193-C-WestLink M7 : 2025-12-03 07:51:34</td>
<td>0.99</td>
<td>0.10</td>
<td>1.09</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547305</td>
<td>295193-C-Video Matching Fee : 2025-12-04 07:52:35</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547306</td>
<td>295193-C-WestConnex : 2025-12-04 07:52:35</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547307</td>
<td>295193-C-Video Matching Fee : 2025-12-10 14:09:43</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547308</td>
<td>295193-C-Video Matching Fee : 2025-12-10 14:42:07</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547309</td>
<td>295193-C-WestLink M7 : 2025-12-10 14:09:43</td>
<td>1.05</td>
<td>0.11</td>
<td>1.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547310</td>
<td>295193-C-WestLink M7 : 2025-12-10 14:42:07</td>
<td>2.50</td>
<td>0.25</td>
<td>2.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547311</td>
<td>295193-C-Video Matching Fee : 2025-12-11 12:02:21</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547312</td>
<td>295193-C-Video Matching Fee : 2025-12-11 16:27:28</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547313</td>
<td>295193-C-M5 South West Motorway : 2025-12-11</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547314</td>
<td>295193-C-M5 South West Motorway : 2025-12-11</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547315</td>
<td>295193-C-Video Matching Fee : 2025-12-13 07:35:43</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547316</td>
<td>295193-C-Video Matching Fee : 2025-12-13 07:41:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547317</td>
<td>295193-C-Video Matching Fee : 2025-12-13 07:59:13</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547318</td>
<td>295193-C-Video Matching Fee : 2025-12-13 14:55:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547319</td>
<td>295193-C-Video Matching Fee : 2025-12-13 15:58:56</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547320</td>
<td>295193-C-Video Matching Fee : 2025-12-13 16:20:08</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547321</td>
<td>295193-C-WestConnex : 2025-12-13 14:55:32</td>
<td>4.15</td>
<td>0.42</td>
<td>4.57</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547322</td>
<td>295193-C-M5 South West Motorway : 2025-12-13</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547323</td>
<td>295193-C-M5 South West Motorway : 2025-12-13</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547324</td>
<td>295193-C-WestConnex : 2025-12-13 07:41:55</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547325</td>
<td>295193-C-Eastern Distributor : 2025-12-13 07:59:13</td>
<td>9.24</td>
<td>0.92</td>
<td>10.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547326</td>
<td>295193-C-WestConnex : 2025-12-13 15:58:56</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547327</td>
<td>295193-C-Video Matching Fee : 2025-12-15 10:29:49</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547328</td>
<td>295193-C-Video Matching Fee : 2025-12-15 17:09:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547329</td>
<td>295193-C-Video Matching Fee : 2025-12-15 09:55:40</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547330</td>
<td>295193-C-Video Matching Fee : 2025-12-15 17:22:16</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547331</td>
<td>295193-C-Hills M2 : 2025-12-15 10:29:49</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547332</td>
<td>295193-C-Hills M2 : 2025-12-15 17:09:34</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547333</td>
<td>295193-C-WestLink M7 : 2025-12-15 09:55:40</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547334</td>
<td>295193-C-WestLink M7 : 2025-12-15 17:22:16</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 41 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547335</td>
<td>295193-C-Video Matching Fee : 2025-12-16 16:51:56</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547336</td>
<td>295193-C-M5 South West Motorway : 2025-12-16</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547337</td>
<td>295193-C-M5 South West Motorway : 2025-12-16</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547338</td>
<td>295193-C-Video Matching Fee : 2025-12-17 08:07:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547339</td>
<td>295193-C-Video Matching Fee : 2025-12-17 12:33:40</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547340</td>
<td>295193-C-Video Matching Fee : 2025-12-17 15:55:20</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547341</td>
<td>295193-C-Video Matching Fee : 2025-12-17 12:49:03</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547342</td>
<td>295193-C-Video Matching Fee : 2025-12-17 07:25:04</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547343</td>
<td>295193-C-WestLink M7 : 2025-12-17 12:49:03</td>
<td>2.15</td>
<td>0.22</td>
<td>2.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547344</td>
<td>295193-C-WestConnex : 2025-12-17 12:33:40</td>
<td>4.16</td>
<td>0.42</td>
<td>4.58</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547345</td>
<td>295193-C-WestConnex : 2025-12-17 08:07:34</td>
<td>4.16</td>
<td>0.42</td>
<td>4.58</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547346</td>
<td>295193-C-WestLink M7 : 2025-12-17 07:25:04</td>
<td>9.15</td>
<td>0.92</td>
<td>10.07</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547347</td>
<td>295193-C-WestLink M7 : 2025-12-17 15:55:20</td>
<td>9.15</td>
<td>0.92</td>
<td>10.07</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547348</td>
<td>295193-C-Video Matching Fee : 2025-12-18 17:16:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547349</td>
<td>295193-C-Video Matching Fee : 2025-12-18 14:33:47</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547350</td>
<td>295193-C-Video Matching Fee : 2025-12-18 07:03:37</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547351</td>
<td>295193-C-Video Matching Fee : 2025-12-18 07:15:45</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547352</td>
<td>295193-C-M5 South West Motorway : 2025-12-18</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547353</td>
<td>295193-C-M5 South West Motorway : 2025-12-18</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547354</td>
<td>295193-C-WestConnex : 2025-12-18 14:33:47</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547355</td>
<td>295193-C-WestConnex : 2025-12-18 07:15:45</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547356</td>
<td>295193-C-Video Matching Fee : 2025-12-19 06:57:52</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547357</td>
<td>295193-C-Video Matching Fee : 2025-12-19 07:06:33</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547358</td>
<td>295193-C-Video Matching Fee : 2025-12-19 16:54:29</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547359</td>
<td>295193-C-Video Matching Fee : 2025-12-19 17:16:30</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547360</td>
<td>295193-C-Video Matching Fee : 2025-12-19 14:51:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547361</td>
<td>295193-C-Video Matching Fee : 2025-12-19 15:30:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547362</td>
<td>295193-C-M5 South West Motorway : 2025-12-19</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547363</td>
<td>295193-C-M5 South West Motorway : 2025-12-19</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547364</td>
<td>295193-C-WestConnex : 2025-12-19 07:06:33</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547365</td>
<td>295193-C-WestConnex : 2025-12-19 15:30:36</td>
<td>8.35</td>
<td>0.84</td>
<td>9.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547366</td>
<td>295193-C-WestConnex : 2025-12-19 14:51:31</td>
<td>10.93</td>
<td>1.09</td>
<td>12.02</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547367</td>
<td>295193-C-WestConnex : 2025-12-19 16:54:29</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 42 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547368</td>
<td>295193-C-Video Matching Fee : 2025-12-20 16:03:42</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547369</td>
<td>295193-C-Video Matching Fee : 2025-12-20 13:22:45</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547370</td>
<td>295193-C-Video Matching Fee : 2025-12-20 14:03:37</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547371</td>
<td>295193-C-M5 South West Motorway : 2025-12-20</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547372</td>
<td>295193-C-M5 South West Motorway : 2025-12-20</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547373</td>
<td>295193-C-WestConnex : 2025-12-20 14:03:37</td>
<td>6.78</td>
<td>0.68</td>
<td>7.46</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547374</td>
<td>295193-C-Video Matching Fee : 2025-12-21 16:42:12</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547375</td>
<td>295193-C-Video Matching Fee : 2025-12-21 16:54:54</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547376</td>
<td>295193-C-Video Matching Fee : 2025-12-21 13:22:25</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547377</td>
<td>295193-C-Video Matching Fee : 2025-12-21 13:28:59</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547378</td>
<td>295193-C-Video Matching Fee : 2025-12-21 13:46:44</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547379</td>
<td>295193-C-M5 South West Motorway : 2025-12-21</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547380</td>
<td>295193-C-M5 South West Motorway : 2025-12-21</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547381</td>
<td>295193-C-WestConnex : 2025-12-21 13:28:59</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547382</td>
<td>295193-C-WestConnex : 2025-12-21 16:42:12</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547383</td>
<td>295193-C-Eastern Distributor : 2025-12-21 13:46:44</td>
<td>9.24</td>
<td>0.92</td>
<td>10.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547384</td>
<td>295193-C-Video Matching Fee : 2025-12-22 16:39:30</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547385</td>
<td>295193-C-Video Matching Fee : 2025-12-22 14:02:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547386</td>
<td>295193-C-Video Matching Fee : 2025-12-22 08:31:01</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547387</td>
<td>295193-C-M5 South West Motorway : 2025-12-22</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547388</td>
<td>295193-C-M5 South West Motorway : 2025-12-22</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547389</td>
<td>295193-C-M5 South West Motorway : 2025-12-22</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547390</td>
<td>295193-C-Video Matching Fee : 2025-12-27 13:39:54</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547391</td>
<td>295193-C-M5 South West Motorway : 2025-12-27</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547392</td>
<td>295193-C-WestLink M7 : 2025-12-28 13:29:02</td>
<td>0.63</td>
<td>0.06</td>
<td>0.69</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547393</td>
<td>295193-C-Video Matching Fee : 2025-12-28 16:42:43</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547394</td>
<td>295193-C-Video Matching Fee : 2025-12-28 13:29:02</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547395</td>
<td>295193-C-WestLink M7 : 2025-12-28 16:42:43</td>
<td>1.45</td>
<td>0.15</td>
<td>1.60</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547396</td>
<td>295193-C-Video Matching Fee : 2025-12-29 16:22:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547397</td>
<td>295193-C-Video Matching Fee : 2025-12-29 16:29:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547398</td>
<td>295193-C-Video Matching Fee : 2025-12-29 20:48:07</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547399</td>
<td>295193-C-Video Matching Fee : 2025-12-29 21:02:38</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547400</td>
<td>295193-C-M5 South West Motorway : 2025-12-29</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 43 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td colspan="2">GST Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547401</td>
<td>295193-C-M5 South West Motorway : 2025-12-29</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547402</td>
<td>295193-C-WestConnex : 2025-12-29 16:29:16</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547403</td>
<td>295193-C-WestConnex : 2025-12-29 20:48:07</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547404</td>
<td>295193-C-WestLink M7 : 2025-12-30 14:21:50</td>
<td>0.63</td>
<td>0.06</td>
<td>0.69</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547405</td>
<td>295193-C-WestLink M7 : 2025-12-30 16:52:26</td>
<td>0.63</td>
<td>0.06</td>
<td>0.69</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547406</td>
<td>295193-C-Video Matching Fee : 2025-12-30 16:52:26</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547407</td>
<td>295193-C-Video Matching Fee : 2025-12-30 14:21:50</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547408</td>
<td>295193-C-Video Matching Fee : 2025-12-31 11:40:08</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547409</td>
<td>295193-C-Video Matching Fee : 2025-12-31 08:41:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547410</td>
<td>295193-C-M5 South West Motorway : 2025-12-31</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547411</td>
<td>295193-C-M5 South West Motorway : 2025-12-31</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547412</td>
<td>295193-C-Video Matching Fee:2026-01-05 14:38:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547413</td>
<td>295193-C-Video Matching Fee:2026-01-05 16:13:56</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547414</td>
<td>295193-C-Video Matching Fee:2026-01-05 16:27:40</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547415</td>
<td>295193-C-Video Matching Fee:2026-01-05 08:32:41</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547416</td>
<td>295193-C-Video Matching Fee:2026-01-05 14:20:50</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547417</td>
<td>295193-C-M5 South West Motorway:2026-01-05 08:32:41</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547418</td>
<td>295193-C-M5 South West Motorway:2026-01-05 16:27:40</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547419</td>
<td>295193-C-WestConnex:2026-01-05 14:20:50</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547420</td>
<td>295193-C-WestConnex:2026-01-05 16:13:56</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547421</td>
<td>295193-C-Eastern Distributor:2026-01-05 14:38:55</td>
<td>9.33</td>
<td>0.93</td>
<td>10.26</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547422</td>
<td>295193-C-Video Matching Fee:2026-01-06 09:27:52</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547423</td>
<td>295193-C-Video Matching Fee:2026-01-06 09:45:41</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547424</td>
<td>295193-C-Video Matching Fee:2026-01-06 13:13:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547425</td>
<td>295193-C-Video Matching Fee:2026-01-06 13:33:37</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547426</td>
<td>295193-C-Video Matching Fee:2026-01-06 16:42:25</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547427</td>
<td>295193-C-Video Matching Fee:2026-01-06 09:21:24</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547428</td>
<td>295193-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-06</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547429</td>
<td>295193-C-M5 South West Motorway:2026-01-06 16:42:25</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547430</td>
<td>295193-C-M5 South West Motorway:2026-01-06 09:21:24</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547431</td>
<td>295193-C-WestConnex:2026-01-06 13:33:37</td>
<td>8.14</td>
<td>0.81</td>
<td>8.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547432</td>
<td>295193-C-WestConnex:2026-01-06 09:27:52</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547433</td>
<td>295193-C-Eastern Distributor:2026-01-06 09:45:41</td>
<td>9.33</td>
<td>0.93</td>
<td>10.26</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 44 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547434</td>
<td>295193-C-Video Matching Fee:2026-01-07 09:13:15</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547435</td>
<td>295193-C-Video Matching Fee:2026-01-07 16:18:12</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547436</td>
<td>295193-C-Video Matching Fee:2026-01-07 16:49:14</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547437</td>
<td>295193-C-Video Matching Fee:2026-01-07 09:06:33</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547438</td>
<td>295193-C-M5 South West Motorway:2026-01-07 16:49:14</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547439</td>
<td>295193-C-M5 South West Motorway:2026-01-07 09:06:33</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547440</td>
<td>295193-C-Cross City Tunnel:2026-01-07 16:18:12</td>
<td>6.61</td>
<td>0.66</td>
<td>7.27</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547441</td>
<td>295193-C-WestConnex:2026-01-07 09:13:15</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547442</td>
<td>295193-C-Video Matching Fee:2026-01-08 08:13:54</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547443</td>
<td>295193-C-Video Matching Fee:2026-01-08 11:03:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547444</td>
<td>295193-C-Video Matching Fee:2026-01-08 11:22:21</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547445</td>
<td>295193-C-Video Matching Fee:2026-01-08 16:40:14</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547446</td>
<td>295193-C-M5 South West Motorway:2026-01-08 08:13:54</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547447</td>
<td>295193-C-M5 South West Motorway:2026-01-08 16:54:07</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547448</td>
<td>295193-C-WestConnex:2026-01-08 11:03:32</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547449</td>
<td>295193-C-WestConnex:2026-01-08 16:40:14</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547450</td>
<td>295193-C-Eastern Distributor:2026-01-08 11:22:21</td>
<td>9.33</td>
<td>0.93</td>
<td>10.26</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547451</td>
<td>295193-C-Video Matching Fee:2026-01-09 08:25:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547452</td>
<td>295193-C-Video Matching Fee:2026-01-09 16:58:06</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547453</td>
<td>295193-C-Video Matching Fee:2026-01-09 14:19:26</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547454</td>
<td>295193-C-Video Matching Fee:2026-01-09 16:28:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547455</td>
<td>295193-C-Video Matching Fee:2026-01-09 16:44:37</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547456</td>
<td>295193-C-M5 South West Motorway:2026-01-09 16:58:06</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547457</td>
<td>295193-C-M5 South West Motorway:2026-01-09 08:25:34</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547458</td>
<td>295193-C-Cross City Tunnel:2026-01-09 16:28:16</td>
<td>6.61</td>
<td>0.66</td>
<td>7.27</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547459</td>
<td>295193-C-WestConnex:2026-01-09 14:19:26</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547460</td>
<td>295193-C-WestConnex:2026-01-09 16:44:37</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547461</td>
<td>295193-C-Video Matching Fee:2026-01-12 07:18:23</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547462</td>
<td>295193-C-Video Matching Fee:2026-01-12 07:24:53</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547463</td>
<td>295193-C-Video Matching Fee:2026-01-12 13:56:21</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547464</td>
<td>295193-C-M5 South West Motorway:2026-01-12 16:15:09</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547465</td>
<td>295193-C-M5 South West Motorway:2026-01-12 07:18:23</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547466</td>
<td>295193-C-WestConnex:2026-01-12 13:56:21</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 45 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th colspan="2"></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547467</td>
<td>295193-C-WestConnex:2026-01-12 07:24:53</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547468</td>
<td>295193-C-Video Matching Fee:2026-01-13 09:10:22</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547469</td>
<td>295193-C-Video Matching Fee:2026-01-13 07:15:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547470</td>
<td>295193-C-M5 South West Motorway:2026-01-13 12:01:43</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547471</td>
<td>295193-C-M5 South West Motorway:2026-01-13 07:15:34</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547472</td>
<td>295193-C-WestConnex:2026-01-13 09:10:22</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547473</td>
<td>295193-C-Video Matching Fee:2026-01-14 07:19:06</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547474</td>
<td>295193-C-Video Matching Fee:2026-01-14 07:12:33</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547475</td>
<td>295193-C-Video Matching Fee:2026-01-14 16:24:03</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547476</td>
<td>295193-C-Video Matching Fee:2026-01-14 16:42:41</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547477</td>
<td>295193-C-M5 South West Motorway:2026-01-14 07:12:33</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547478</td>
<td>295193-C-M5 South West Motorway:2026-01-14 16:42:41</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547479</td>
<td>295193-C-WestConnex:2026-01-14 16:24:03</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547480</td>
<td>295193-C-WestConnex:2026-01-14 07:19:06</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547481</td>
<td>295193-C-Video Matching Fee:2026-01-15 07:10:08</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547482</td>
<td>295193-C-Video Matching Fee:2026-01-15 16:40:27</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547483</td>
<td>295193-C-Video Matching Fee:2026-01-15 16:12:59</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547484</td>
<td>295193-C-M5 South West Motorway:2026-01-15 16:40:27</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547485</td>
<td>295193-C-M5 South West Motorway:2026-01-15 07:10:08</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK40RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Oscar Vasquez</td>
<td>4843547486</td>
<td>295193-C-WestConnex:2026-01-15 16:12:59</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548501</td>
<td>296318-C-Video Matching Fee : 2025-12-16 14:53:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548502</td>
<td>296318-C-Video Matching Fee : 2025-12-16 06:40:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548503</td>
<td>296318-C-Video Matching Fee : 2025-12-16 13:41:18</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548504</td>
<td>296318-C-WestConnex : 2025-12-16 14:53:55</td>
<td>4.16</td>
<td>0.42</td>
<td>4.58</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548505</td>
<td>296318-C-WestConnex : 2025-12-16 06:40:16</td>
<td>4.16</td>
<td>0.42</td>
<td>4.58</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548506</td>
<td>296318-C-WestLink M7 : 2025-12-16 13:41:18</td>
<td>7.15</td>
<td>0.72</td>
<td>7.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548507</td>
<td>296318-C-Video Matching Fee : 2025-12-19 15:40:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548508</td>
<td>296318-C-Video Matching Fee : 2025-12-19 16:06:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548509</td>
<td>296318-C-Video Matching Fee : 2025-12-19 06:26:54</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548510</td>
<td>296318-C-WestLink M7 : 2025-12-19 15:29:11</td>
<td>0.63</td>
<td>0.06</td>
<td>0.69</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548511</td>
<td>296318-C-Video Matching Fee : 2025-12-19 15:29:11</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548512</td>
<td>296318-C-WestConnex : 2025-12-19 06:26:54</td>
<td>4.16</td>
<td>0.42</td>
<td>4.58</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548513</td>
<td>296318-C-WestConnex : 2025-12-19 16:06:16</td>
<td>6.85</td>
<td>0.69</td>
<td>7.54</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 46 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net GST Total</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548514</td>
<td>296318-C-WestConnex : 2025-12-19 15:40:34</td>
<td>9.44 0.94 10.38</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548515</td>
<td>296318-C-Video Matching Fee : 2025-12-20 17:10:41</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548516</td>
<td>296318-C-Hills M2 : 2025-12-20 17:10:41</td>
<td>4.66 0.47 5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548517</td>
<td>296318-C-Video Matching Fee : 2025-12-21 06:21:22</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548518</td>
<td>296318-C-Video Matching Fee : 2025-12-21 06:47:28</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548519</td>
<td>296318-C-Video Matching Fee : 2025-12-21 14:29:16</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548520</td>
<td>296318-C-Video Matching Fee : 2025-12-21 15:00:54</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548521</td>
<td>296318-C-WestConnex : 2025-12-21 06:21:22</td>
<td>6.85 0.69 7.54</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548522</td>
<td>296318-C-WestConnex : 2025-12-21 06:47:28</td>
<td>6.85 0.69 7.54</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548523</td>
<td>296318-C-WestConnex : 2025-12-21 14:29:16</td>
<td>6.85 0.69 7.54</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548524</td>
<td>296318-C-WestConnex : 2025-12-21 15:00:54</td>
<td>6.85 0.69 7.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548525</td>
<td>296318-C-Video Matching Fee : 2025-12-22 06:27:54</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548526</td>
<td>296318-C-Video Matching Fee : 2025-12-22 06:49:40</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548527</td>
<td>296318-C-Video Matching Fee : 2025-12-22 14:26:52</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548528</td>
<td>296318-C-Video Matching Fee : 2025-12-22 15:00:34</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548529</td>
<td>296318-C-WestConnex : 2025-12-22 06:27:54</td>
<td>6.85 0.69 7.54</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548530</td>
<td>296318-C-WestConnex : 2025-12-22 06:49:40</td>
<td>6.85 0.69 7.54</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548531</td>
<td>296318-C-WestConnex : 2025-12-22 14:26:52</td>
<td>6.85 0.69 7.54</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548532</td>
<td>296318-C-WestConnex : 2025-12-22 15:00:34</td>
<td>6.85 0.69 7.54</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548533</td>
<td>296318-C-Video Matching Fee : 2025-12-24 16:50:31</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548534</td>
<td>296318-C-WestConnex : 2025-12-24 16:50:31</td>
<td>4.68 0.47 5.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548535</td>
<td>296318-C-Video Matching Fee : 2025-12-25 14:52:20</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548536</td>
<td>296318-C-Video Matching Fee : 2025-12-25 12:00:53</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548537</td>
<td>296318-C-WestConnex : 2025-12-25 14:52:20</td>
<td>4.68 0.47 5.15</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548538</td>
<td>296318-C-WestConnex : 2025-12-25 12:00:53</td>
<td>6.85 0.69 7.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548539</td>
<td>296318-C-Video Matching Fee : 2025-12-26 06:27:43</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548540</td>
<td>296318-C-Video Matching Fee : 2025-12-26 06:45:38</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548541</td>
<td>296318-C-Video Matching Fee : 2025-12-26 14:24:37</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548542</td>
<td>296318-C-WestConnex : 2025-12-26 14:24:37</td>
<td>6.85 0.69 7.54</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548543</td>
<td>296318-C-WestConnex : 2025-12-26 06:27:43</td>
<td>6.85 0.69 7.54</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548544</td>
<td>296318-C-WestConnex : 2025-12-26 06:45:38</td>
<td>6.85 0.69 7.54</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548545</td>
<td>296318-C-Video Matching Fee : 2025-12-27 14:29:07</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548546</td>
<td>296318-C-Video Matching Fee : 2025-12-27 11:23:47</td>
<td>0.50 0.05 0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 47 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th colspan="2"></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548547</td>
<td>296318-C-WestConnex : 2025-12-27 11:23:47</td>
<td>3.30</td>
<td>0.33</td>
<td>3.63</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548548</td>
<td>296318-C-WestConnex : 2025-12-27 14:29:07</td>
<td>3.30</td>
<td>0.33</td>
<td>3.63</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548549</td>
<td>296318-C-Video Matching Fee : 2025-12-28 13:16:58</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548550</td>
<td>296318-C-Video Matching Fee : 2025-12-28 13:46:42</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548551</td>
<td>296318-C-WestConnex : 2025-12-28 13:16:58</td>
<td>2.28</td>
<td>0.23</td>
<td>2.51</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548552</td>
<td>296318-C-WestConnex : 2025-12-28 13:46:42</td>
<td>2.28</td>
<td>0.23</td>
<td>2.51</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548553</td>
<td>296318-C-Video Matching Fee : 2025-12-29 14:57:56</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548554</td>
<td>296318-C-Video Matching Fee : 2025-12-29 06:29:28</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548555</td>
<td>296318-C-Video Matching Fee : 2025-12-29 06:49:45</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548556</td>
<td>296318-C-Video Matching Fee : 2025-12-29 14:23:54</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548557</td>
<td>296318-C-WestConnex : 2025-12-29 14:23:54</td>
<td>6.85</td>
<td>0.69</td>
<td>7.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548558</td>
<td>296318-C-WestConnex : 2025-12-29 14:57:56</td>
<td>6.85</td>
<td>0.69</td>
<td>7.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548559</td>
<td>296318-C-WestConnex : 2025-12-29 06:29:28</td>
<td>6.85</td>
<td>0.69</td>
<td>7.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548560</td>
<td>296318-C-WestConnex : 2025-12-29 06:49:45</td>
<td>6.85</td>
<td>0.69</td>
<td>7.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548561</td>
<td>296318-C-Video Matching Fee : 2025-12-31 11:39:14</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548562</td>
<td>296318-C-Video Matching Fee : 2025-12-31 13:38:12</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548563</td>
<td>296318-C-WestConnex : 2025-12-31 13:38:12</td>
<td>4.68</td>
<td>0.47</td>
<td>5.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548564</td>
<td>296318-C-WestConnex : 2025-12-31 11:39:14</td>
<td>4.68</td>
<td>0.47</td>
<td>5.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548565</td>
<td>296318-C-Video Matching Fee:2026-01-01 22:43:03</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548566</td>
<td>296318-C-WestConnex:2026-01-01 22:43:03</td>
<td>7.12</td>
<td>0.71</td>
<td>7.83</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548567</td>
<td>296318-C-Video Matching Fee:2026-01-02 18:59:23</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548568</td>
<td>296318-C-Video Matching Fee:2026-01-02 12:41:57</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548569</td>
<td>296318-C-Video Matching Fee:2026-01-02 00:56:24</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548570</td>
<td>296318-C-WestConnex:2026-01-02 18:59:23</td>
<td>9.80</td>
<td>0.98</td>
<td>10.78</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548571</td>
<td>296318-C-WestConnex:2026-01-02 00:56:24</td>
<td>9.80</td>
<td>0.98</td>
<td>10.78</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548572</td>
<td>296318-C-WestConnex:2026-01-02 12:41:57</td>
<td>9.80</td>
<td>0.98</td>
<td>10.78</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548573</td>
<td>296318-C-Video Matching Fee:2026-01-03 12:48:23</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548574</td>
<td>296318-C-Video Matching Fee:2026-01-03 13:30:58</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548575</td>
<td>296318-C-WestConnex:2026-01-03 13:30:58</td>
<td>3.44</td>
<td>0.34</td>
<td>3.78</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548576</td>
<td>296318-C-WestConnex:2026-01-03 12:48:23</td>
<td>3.44</td>
<td>0.34</td>
<td>3.78</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548577</td>
<td>296318-C-Video Matching Fee:2026-01-04 06:21:33</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548578</td>
<td>296318-C-Video Matching Fee:2026-01-04 06:39:54</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548579</td>
<td>296318-C-Video Matching Fee:2026-01-04 14:28:51</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 48 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2" rowspan="2">Customer No. AU1166479</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td colspan="2">GST Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548580</td>
<td>296318-C-Video Matching Fee:2026-01-04 14:56:45</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548581</td>
<td>296318-C-WestConnex:2026-01-04 14:28:51</td>
<td>7.12</td>
<td>0.71</td>
<td>7.83</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548582</td>
<td>296318-C-WestConnex:2026-01-04 14:56:45</td>
<td>7.12</td>
<td>0.71</td>
<td>7.83</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548583</td>
<td>296318-C-WestConnex:2026-01-04 06:21:33</td>
<td>7.12</td>
<td>0.71</td>
<td>7.83</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548584</td>
<td>296318-C-WestConnex:2026-01-04 06:39:54</td>
<td>7.12</td>
<td>0.71</td>
<td>7.83</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548585</td>
<td>296318-C-Video Matching Fee:2026-01-05 14:02:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548586</td>
<td>296318-C-Video Matching Fee:2026-01-05 10:18:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548587</td>
<td>296318-C-Video Matching Fee:2026-01-05 14:40:01</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548588</td>
<td>296318-C-Video Matching Fee:2026-01-05 15:32:59</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548589</td>
<td>296318-C-Video Matching Fee:2026-01-05 14:00:32</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548590</td>
<td>296318-C-WestLink M7:2026-01-05 14:00:32</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548591</td>
<td>296318-C-Hills M2:2026-01-05 14:02:55</td>
<td>3.34</td>
<td>0.33</td>
<td>3.67</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548592</td>
<td>296318-C-WestConnex:2026-01-05 10:18:16</td>
<td>4.34</td>
<td>0.43</td>
<td>4.77</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548593</td>
<td>296318-C-WestConnex:2026-01-05 15:32:59</td>
<td>4.87</td>
<td>0.49</td>
<td>5.36</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548594</td>
<td>296318-C-WestConnex:2026-01-05 14:40:01</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548595</td>
<td>296318-C-Video Matching Fee:2026-01-06 12:13:42</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548596</td>
<td>296318-C-Video Matching Fee:2026-01-06 12:25:57</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548597</td>
<td>296318-C-Video Matching Fee:2026-01-06 12:28:38</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548598</td>
<td>296318-C-WestLink M7:2026-01-06 12:28:38</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548599</td>
<td>296318-C-WestConnex:2026-01-06 12:13:42</td>
<td>3.20</td>
<td>0.32</td>
<td>3.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548600</td>
<td>296318-C-Hills M2:2026-01-06 12:25:57</td>
<td>3.34</td>
<td>0.33</td>
<td>3.67</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548601</td>
<td>296318-C-Video Matching Fee:2026-01-07 00:04:10</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548602</td>
<td>296318-C-WestConnex:2026-01-07 00:04:10</td>
<td>4.34</td>
<td>0.43</td>
<td>4.77</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548603</td>
<td>296318-C-Video Matching Fee:2026-01-08 15:11:51</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548604</td>
<td>296318-C-Video Matching Fee:2026-01-08 07:28:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548605</td>
<td>296318-C-M5 South West Motorway:2026-01-08 07:28:02</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548606</td>
<td>296318-C-M5 South West Motorway:2026-01-08 15:11:51</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548607</td>
<td>296318-C-Video Matching Fee:2026-01-09 14:57:22</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548608</td>
<td>296318-C-Video Matching Fee:2026-01-09 14:25:23</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548609</td>
<td>296318-C-WestConnex:2026-01-09 14:25:23</td>
<td>7.12</td>
<td>0.71</td>
<td>7.83</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548610</td>
<td>296318-C-WestConnex:2026-01-09 14:57:22</td>
<td>7.12</td>
<td>0.71</td>
<td>7.83</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548611</td>
<td>296318-C-Video Matching Fee:2026-01-10 18:11:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548612</td>
<td>296318-C-North Connex:2026-01-10 18:11:31</td>
<td>9.45</td>
<td colspan="2">0.95 10.40</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 49 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548613</td>
<td>296318-C-Video Matching Fee:2026-01-11 00:42:29</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548614</td>
<td>296318-C-North Connex:2026-01-11 00:42:29</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548615</td>
<td>296318-C-Video Matching Fee:2026-01-12 06:26:56</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548616</td>
<td>296318-C-Video Matching Fee:2026-01-12 07:02:56</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548617</td>
<td>296318-C-WestConnex:2026-01-12 06:26:56</td>
<td>7.12</td>
<td>0.71</td>
<td>7.83</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548618</td>
<td>296318-C-WestConnex:2026-01-12 07:02:56</td>
<td>7.12</td>
<td>0.71</td>
<td>7.83</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548619</td>
<td>296318-C-Video Matching Fee:2026-01-14 17:22:44</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548620</td>
<td>296318-C-Video Matching Fee:2026-01-14 05:56:29</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548621</td>
<td>296318-C-WestConnex:2026-01-14 05:56:29</td>
<td>11.37</td>
<td>1.14</td>
<td>12.51</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548622</td>
<td>296318-C-WestConnex:2026-01-14 17:22:44</td>
<td>11.37</td>
<td>1.14</td>
<td>12.51</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548623</td>
<td>296318-C-Video Matching Fee:2026-01-15 16:14:06</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548624</td>
<td>296318-C-Video Matching Fee:2026-01-15 07:08:38</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548625</td>
<td>296318-C-WestLink M7:2026-01-15 16:02:09</td>
<td>0.64</td>
<td>0.06</td>
<td>0.70</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548626</td>
<td>296318-C-Video Matching Fee:2026-01-15 16:02:09</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548627</td>
<td>296318-C-WestConnex:2026-01-15 07:08:38</td>
<td>4.34</td>
<td>0.43</td>
<td>4.77</td>
</tr>
<tr>
<td>NSW</td>
<td>DK41RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Andrew Tang</td>
<td>4843548628</td>
<td>296318-C-WestConnex:2026-01-15 16:14:06</td>
<td>4.34</td>
<td>0.43</td>
<td>4.77</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548601</td>
<td>296321-C-Video Matching Fee : 2025-12-17 14:01:47</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548602</td>
<td>296321-C-WestConnex : 2025-12-17 14:01:47</td>
<td>2.66</td>
<td>0.27</td>
<td>2.93</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548603</td>
<td>296321-C-Video Matching Fee : 2025-12-18 13:50:15</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548604</td>
<td>296321-C-Video Matching Fee : 2025-12-18 13:47:33</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548605</td>
<td>296321-C-WestLink M7 : 2025-12-18 13:47:33</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548606</td>
<td>296321-C-Hills M2 : 2025-12-18 13:50:15</td>
<td>3.30</td>
<td>0.33</td>
<td>3.63</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548607</td>
<td>296321-C-Video Matching Fee:2026-01-06 08:26:03</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548608</td>
<td>296321-C-WestLink M7:2026-01-06 08:26:03</td>
<td>7.72</td>
<td>0.77</td>
<td>8.49</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548609</td>
<td>296321-C-Video Matching Fee:2026-01-09 14:29:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548610</td>
<td>296321-C-Video Matching Fee:2026-01-09 13:24:38</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548611</td>
<td>296321-C-Video Matching Fee:2026-01-09 14:17:49</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548612</td>
<td>296321-C-WestLink M7:2026-01-09 13:24:38</td>
<td>2.81</td>
<td>0.28</td>
<td>3.09</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548613</td>
<td>296321-C-Hills M2:2026-01-09 14:29:02</td>
<td>3.34</td>
<td>0.33</td>
<td>3.67</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548614</td>
<td>296321-C-WestLink M7:2026-01-09 14:17:49</td>
<td>6.59</td>
<td>0.66</td>
<td>7.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548615</td>
<td>296321-C-Video Matching Fee:2026-01-12 14:17:44</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548616</td>
<td>296321-C-WestConnex:2026-01-12 14:17:44</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548617</td>
<td>296321-C-Video Matching Fee:2026-01-13 06:16:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 50 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548618</td>
<td>296321-C-Video Matching Fee:2026-01-13 11:56:19</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548619</td>
<td>296321-C-Video Matching Fee:2026-01-13 12:32:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548620</td>
<td>296321-C-WestConnex:2026-01-13 11:56:19</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548621</td>
<td>296321-C-WestConnex:2026-01-13 12:32:55</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548622</td>
<td>296321-C-WestConnex:2026-01-13 06:16:32</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548623</td>
<td>296321-C-Video Matching Fee:2026-01-14 07:47:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548624</td>
<td>296321-C-Video Matching Fee:2026-01-14 08:40:59</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548625</td>
<td>296321-C-Video Matching Fee:2026-01-14 13:19:51</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548626</td>
<td>296321-C-Video Matching Fee:2026-01-14 14:41:40</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548627</td>
<td>296321-C-Video Matching Fee:2026-01-14 14:25:41</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548628</td>
<td>296321-C-WestConnex:2026-01-14 13:19:51</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548629</td>
<td>296321-C-WestConnex:2026-01-14 14:25:41</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548630</td>
<td>296321-C-WestConnex:2026-01-14 14:41:40</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548631</td>
<td>296321-C-Lane Cove Tunnel:2026-01-14 07:47:31</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548632</td>
<td>296321-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-14</td>
<td>4.01</td>
<td>0.40</td>
<td>4.41</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548633</td>
<td>296321-C-WestConnex:2026-01-14 08:40:59</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548634</td>
<td>296321-C-Video Matching Fee:2026-01-15 14:40:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK44RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Chris Liakis</td>
<td>4843548635</td>
<td>296321-C-WestConnex:2026-01-15 14:40:02</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK45RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843549601</td>
<td>302290-C-Video Matching Fee : 2025-12-15 09:11:13</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK45RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare</td>
<td>4843549602</td>
<td>302290-C-WestLink M7 : 2025-12-15 09:11:13</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549101</td>
<td>297288-C-Video Matching Fee : 2025-12-12 08:53:07</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549102</td>
<td>297288-C-Lane Cove Tunnel : 2025-12-12 08:53:07</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549103</td>
<td>297288-C-Video Matching Fee : 2025-12-17 10:42:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549104</td>
<td>297288-C-Video Matching Fee : 2025-12-17 13:13:48</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549105</td>
<td>297288-C-Video Matching Fee : 2025-12-17 13:23:10</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549106</td>
<td>297288-C-WestConnex : 2025-12-17 10:42:36</td>
<td>5.90</td>
<td>0.59</td>
<td>6.49</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549107</td>
<td>297288-C-WestLink M7 : 2025-12-17 13:23:10</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549108</td>
<td>297288-C-Hills M2 : 2025-12-17 13:13:48</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549109</td>
<td>297288-C-Video Matching Fee : 2025-12-18 09:42:56</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549110</td>
<td>297288-C-Video Matching Fee : 2025-12-18 12:00:57</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549111</td>
<td>297288-C-WestLink M7 : 2025-12-18 09:42:56</td>
<td>1.67</td>
<td>0.17</td>
<td>1.84</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549112</td>
<td>297288-C-WestLink M7 : 2025-12-18 12:00:57</td>
<td>1.67</td>
<td>0.17</td>
<td>1.84</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549113</td>
<td>297288-C-Video Matching Fee : 2025-12-19 13:43:03</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 51 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549114</td>
<td>297288-C-Video Matching Fee : 2025-12-19 12:24:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549115</td>
<td>297288-C-Video Matching Fee : 2025-12-19 12:40:17</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549116</td>
<td>297288-C-Video Matching Fee : 2025-12-19 09:11:28</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549117</td>
<td>297288-C-Video Matching Fee : 2025-12-19 09:17:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549118</td>
<td>297288-C-WestConnex : 2025-12-19 09:17:55</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549119</td>
<td>297288-C-M5 South West Motorway : 2025-12-19</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549120</td>
<td>297288-C-WestConnex : 2025-12-19 12:24:32</td>
<td>6.70</td>
<td>0.67</td>
<td>7.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549121</td>
<td>297288-C-Eastern Distributor : 2025-12-19 12:40:17</td>
<td>9.24</td>
<td>0.92</td>
<td>10.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549122</td>
<td>297288-C-WestConnex : 2025-12-19 13:43:03</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549123</td>
<td>297288-C-Video Matching Fee : 2025-12-20 23:20:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549124</td>
<td>297288-C-Video Matching Fee : 2025-12-20 23:25:39</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549125</td>
<td>297288-C-Video Matching Fee : 2025-12-20 18:11:11</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549126</td>
<td>297288-C-Video Matching Fee : 2025-12-20 18:28:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549127</td>
<td>297288-C-Cross City Tunnel : 2025-12-20 18:28:18</td>
<td>6.52</td>
<td>0.65</td>
<td>7.17</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549128</td>
<td>297288-C-Cross City Tunnel : 2025-12-20 23:20:31</td>
<td>6.52</td>
<td>0.65</td>
<td>7.17</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549129</td>
<td>297288-C-WestConnex : 2025-12-20 23:25:39</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549130</td>
<td>297288-C-WestConnex : 2025-12-20 18:11:11</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549131</td>
<td>297288-C-Video Matching Fee : 2025-12-23 16:53:54</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549132</td>
<td>297288-C-Video Matching Fee : 2025-12-23 13:56:33</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549133</td>
<td>297288-C-Video Matching Fee : 2025-12-23 17:03:16</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549134</td>
<td>297288-C-Video Matching Fee : 2025-12-23 13:31:21</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549135</td>
<td>297288-C-WestLink M7 : 2025-12-23 13:31:21</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549136</td>
<td>297288-C-WestLink M7 : 2025-12-23 17:03:16</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549137</td>
<td>297288-C-Hills M2 : 2025-12-23 16:53:54</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549138</td>
<td>297288-C-Hills M2 : 2025-12-23 13:56:33</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549139</td>
<td>297288-C-Video Matching Fee:2026-01-03 05:59:19</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549140</td>
<td>297288-C-Video Matching Fee:2026-01-03 12:53:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549141</td>
<td>297288-C-WestConnex:2026-01-03 05:59:19</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549142</td>
<td>297288-C-WestConnex:2026-01-03 12:53:16</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549143</td>
<td>297288-C-Video Matching Fee:2026-01-04 11:43:05</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549144</td>
<td>297288-C-Video Matching Fee:2026-01-04 07:41:00</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549145</td>
<td>297288-C-WestConnex:2026-01-04 11:43:05</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549146</td>
<td>297288-C-WestConnex:2026-01-04 07:41:00</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 52 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549147</td>
<td>297288-C-Video Matching Fee:2026-01-05 14:08:39</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549148</td>
<td>297288-C-Video Matching Fee:2026-01-05 13:25:14</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549149</td>
<td>297288-C-Video Matching Fee:2026-01-05 11:20:04</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549150</td>
<td>297288-C-WestLink M7:2026-01-05 14:08:39</td>
<td>1.69</td>
<td>0.17</td>
<td>1.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549151</td>
<td>297288-C-WestLink M7:2026-01-05 13:25:14</td>
<td>7.25</td>
<td>0.73</td>
<td>7.98</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549152</td>
<td>297288-C-WestLink M7:2026-01-05 11:20:04</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549153</td>
<td>297288-C-Video Matching Fee:2026-01-06 12:44:03</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549154</td>
<td>297288-C-Video Matching Fee:2026-01-06 12:47:19</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549155</td>
<td>297288-C-Video Matching Fee:2026-01-06 09:51:43</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549156</td>
<td>297288-C-Video Matching Fee:2026-01-06 09:55:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549157</td>
<td>297288-C-Video Matching Fee:2026-01-06 12:56:30</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549158</td>
<td>297288-C-Video Matching Fee:2026-01-06 09:26:58</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549159</td>
<td>297288-C-Lane Cove Tunnel:2026-01-06 09:55:02</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549160</td>
<td>297288-C-Lane Cove Tunnel:2026-01-06 12:44:03</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549161</td>
<td>297288-C-WestLink M7:2026-01-06 12:56:30</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549162</td>
<td>297288-C-WestLink M7:2026-01-06 09:26:58</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549163</td>
<td>297288-C-Hills M2:2026-01-06 09:51:43</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549164</td>
<td>297288-C-Hills M2:2026-01-06 12:47:19</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549165</td>
<td>297288-C-Video Matching Fee:2026-01-07 12:40:25</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549166</td>
<td>297288-C-Video Matching Fee:2026-01-07 09:33:40</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549167</td>
<td>297288-C-WestConnex:2026-01-07 09:33:40</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549168</td>
<td>297288-C-WestConnex:2026-01-07 12:40:25</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549169</td>
<td>297288-C-Video Matching Fee:2026-01-08 09:40:32</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549170</td>
<td>297288-C-Video Matching Fee:2026-01-08 14:29:44</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549171</td>
<td>297288-C-WestLink M7:2026-01-08 09:40:32</td>
<td>1.69</td>
<td>0.17</td>
<td>1.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549172</td>
<td>297288-C-WestLink M7:2026-01-08 14:29:44</td>
<td>1.69</td>
<td>0.17</td>
<td>1.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549173</td>
<td>297288-C-Video Matching Fee:2026-01-09 15:16:26</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549174</td>
<td>297288-C-Video Matching Fee:2026-01-09 16:18:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549175</td>
<td>297288-C-Video Matching Fee:2026-01-09 13:08:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549176</td>
<td>297288-C-Video Matching Fee:2026-01-09 09:26:56</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549177</td>
<td>297288-C-WestConnex:2026-01-09 13:08:18</td>
<td>9.80</td>
<td>0.98</td>
<td>10.78</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549178</td>
<td>297288-C-WestConnex:2026-01-09 15:16:26</td>
<td>9.80</td>
<td>0.98</td>
<td>10.78</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549179</td>
<td>297288-C-WestConnex:2026-01-09 16:18:34</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 53 of 121" -->
<!-- PageBreak -->

Customer No.

Invoice Date

Invoice No.

AU1166479

31 January 2026

AIN00014651


<figure>

P

</figure>


<table>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549180</td>
<td>297288-C-WestConnex:2026-01-09 09:26:56</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549181</td>
<td>297288-C-Video Matching Fee:2026-01-10 07:34:42</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549182</td>
<td>297288-C-Video Matching Fee:2026-01-10 10:00:13</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549183</td>
<td>297288-C-WestConnex:2026-01-10 07:34:42</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549184</td>
<td>297288-C-WestConnex:2026-01-10 10:00:13</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549185</td>
<td>297288-C-Video Matching Fee:2026-01-12 16:07:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549186</td>
<td>297288-C-Video Matching Fee:2026-01-12 10:58:05</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549187</td>
<td>297288-C-Video Matching Fee:2026-01-12 16:16:47</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549188</td>
<td>297288-C-Video Matching Fee:2026-01-12 10:31:42</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549189</td>
<td>297288-C-WestLink M7:2026-01-12 10:31:42</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549190</td>
<td>297288-C-WestLink M7:2026-01-12 16:16:47</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549191</td>
<td>297288-C-Hills M2:2026-01-12 10:58:05</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549192</td>
<td>297288-C-Hills M2:2026-01-12 16:07:20</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549193</td>
<td>297288-C-Video Matching Fee:2026-01-13 07:24:33</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549194</td>
<td>297288-C-Video Matching Fee:2026-01-13 09:03:07</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549195</td>
<td>297288-C-Video Matching Fee:2026-01-13 14:38:45</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549196</td>
<td>297288-C-Video Matching Fee:2026-01-13 12:08:03</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549197</td>
<td>297288-C-WestLink M7:2026-01-13 12:08:03</td>
<td>1.69</td>
<td>0.17</td>
<td>1.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549198</td>
<td>297288-C-WestLink M7:2026-01-13 14:38:45</td>
<td>2.33</td>
<td>0.23</td>
<td>2.56</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549199</td>
<td>297288-C-WestConnex:2026-01-13 07:24:33</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549200</td>
<td>297288-C-WestConnex:2026-01-13 09:03:07</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549201</td>
<td>297288-C-Video Matching Fee:2026-01-14 11:22:40</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549202</td>
<td>297288-C-Video Matching Fee:2026-01-14 08:23:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549203</td>
<td>297288-C-WestConnex:2026-01-14 11:22:40</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK81ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Fadey Sayegh</td>
<td>4843549204</td>
<td>297288-C-WestConnex:2026-01-14 08:23:16</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549701</td>
<td>302291-C-Video Matching Fee : 2025-12-16 14:54:21</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549702</td>
<td>302291-C-Video Matching Fee : 2025-12-16 13:41:13</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549703</td>
<td>302291-C-Video Matching Fee : 2025-12-16 10:54:36</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549704</td>
<td>302291-C-Video Matching Fee : 2025-12-16 11:56:00</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549705</td>
<td>302291-C-Video Matching Fee : 2025-12-16 12:11:48</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549706</td>
<td>302291-C-Video Matching Fee : 2025-12-16 06:54:36</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549707</td>
<td>302291-C-WestLink M7 : 2025-12-16 11:56:00</td>
<td>4.97</td>
<td>0.50</td>
<td>5.47</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549708</td>
<td>302291-C-WestLink M7 : 2025-12-16 06:54:36</td>
<td>6.86</td>
<td>0.69</td>
<td>7.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 54 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th></th>
<th></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549709</td>
<td>302291-C-WestLink M7 : 2025-12-16 10:54:36</td>
<td>6.86</td>
<td>0.69</td>
<td>7.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549710</td>
<td>302291-C-WestLink M7 : 2025-12-16 14:54:21</td>
<td>6.86</td>
<td>0.69</td>
<td>7.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549711</td>
<td>302291-C-WestLink M7 : 2025-12-16 13:41:13</td>
<td>7.15</td>
<td>0.72</td>
<td>7.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549712</td>
<td>302291-C-WestLink M7 : 2025-12-16 12:11:48</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549713</td>
<td>302291-C-Video Matching Fee : 2025-12-17 17:13:07</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549714</td>
<td>302291-C-Video Matching Fee : 2025-12-17 16:41:33</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549715</td>
<td>302291-C-Video Matching Fee : 2025-12-17 06:44:35</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549716</td>
<td>302291-C-Video Matching Fee : 2025-12-17 06:52:08</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549717</td>
<td>302291-C-M5 South West Motorway : 2025-12-17</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549718</td>
<td>302291-C-M5 South West Motorway : 2025-12-17</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549719</td>
<td>302291-C-WestConnex : 2025-12-17 06:52:08</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549720</td>
<td>302291-C-WestConnex : 2025-12-17 16:41:33</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549721</td>
<td>302291-C-Video Matching Fee : 2025-12-18 15:07:24</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549722</td>
<td>302291-C-Video Matching Fee : 2025-12-18 14:41:57</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549723</td>
<td>302291-C-Video Matching Fee : 2025-12-18 06:44:10</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549724</td>
<td>302291-C-Video Matching Fee : 2025-12-18 06:58:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549725</td>
<td>302291-C-M5 South West Motorway : 2025-12-18</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549726</td>
<td>302291-C-M5 South West Motorway : 2025-12-18</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549727</td>
<td>302291-C-WestConnex : 2025-12-18 14:41:57</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549728</td>
<td>302291-C-WestConnex : 2025-12-18 06:58:36</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549729</td>
<td>302291-C-Video Matching Fee : 2025-12-19 10:31:32</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549730</td>
<td>302291-C-Video Matching Fee : 2025-12-19 09:48:43</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549731</td>
<td>302291-C-WestLink M7 : 2025-12-19 09:48:43</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549732</td>
<td>302291-C-WestLink M7 : 2025-12-19 10:31:32</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549733</td>
<td>302291-C-Video Matching Fee:2026-01-05 13:31:32</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549734</td>
<td>302291-C-Video Matching Fee:2026-01-05 14:12:30</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549735</td>
<td>302291-C-Video Matching Fee:2026-01-05 07:38:41</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549736</td>
<td>302291-C-WestLink M7:2026-01-05 13:31:32</td>
<td>7.25</td>
<td>0.73</td>
<td>7.98</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549737</td>
<td>302291-C-WestLink M7:2026-01-05 14:12:30</td>
<td>8.65</td>
<td>0.87</td>
<td>9.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549738</td>
<td>302291-C-WestLink M7:2026-01-05 07:38:41</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549739</td>
<td>302291-C-Video Matching Fee:2026-01-06 13:17:53</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549740</td>
<td>302291-C-Video Matching Fee:2026-01-06 13:00:09</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549741</td>
<td>302291-C-Video Matching Fee:2026-01-06 09:24:37</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 55 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th></th>
<th></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549742</td>
<td>302291-C-Video Matching Fee:2026-01-06 09:01:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549743</td>
<td>302291-C-Video Matching Fee:2026-01-06 09:07:48</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549744</td>
<td>302291-C-M5 South West Motorway:2026-01-06 13:17:53</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549745</td>
<td>302291-C-M5 South West Motorway:2026-01-06 09:01:20</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549746</td>
<td>302291-C-WestConnex:2026-01-06 09:07:48</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549747</td>
<td>302291-C-Eastern Distributor:2026-01-06 09:24:37</td>
<td>9.33</td>
<td>0.93</td>
<td>10.26</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549748</td>
<td>302291-C-WestConnex:2026-01-06 13:00:09</td>
<td>11.40</td>
<td>1.14</td>
<td>12.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549749</td>
<td>302291-C-Video Matching Fee:2026-01-12 18:11:33</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549750</td>
<td>302291-C-Video Matching Fee:2026-01-12 16:43:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549751</td>
<td>302291-C-Video Matching Fee:2026-01-12 08:21:43</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549752</td>
<td>302291-C-Video Matching Fee:2026-01-12 10:24:35</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549753</td>
<td>302291-C-Video Matching Fee:2026-01-12 08:33:47</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549754</td>
<td>302291-C-Video Matching Fee:2026-01-12 08:54:05</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549755</td>
<td>302291-C-Video Matching Fee:2026-01-12 10:00:51</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549756</td>
<td>302291-C-WestLink M7:2026-01-12 08:54:05</td>
<td>2.54</td>
<td>0.25</td>
<td>2.79</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549757</td>
<td>302291-C-WestConnex:2026-01-12 08:21:43</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549758</td>
<td>302291-C-WestConnex:2026-01-12 10:24:35</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549759</td>
<td>302291-C-M5 South West Motorway:2026-01-12 18:11:33</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549760</td>
<td>302291-C-WestConnex:2026-01-12 16:43:34</td>
<td>6.44</td>
<td>0.64</td>
<td>7.08</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549761</td>
<td>302291-C-WestLink M7:2026-01-12 08:33:47</td>
<td>6.75</td>
<td>0.68</td>
<td>7.43</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549762</td>
<td>302291-C-WestLink M7:2026-01-12 10:00:51</td>
<td>9.28</td>
<td>0.93</td>
<td>10.21</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549763</td>
<td>302291-C-Video Matching Fee:2026-01-14 17:36:53</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549764</td>
<td>302291-C-Video Matching Fee:2026-01-14 17:22:39</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549765</td>
<td>302291-C-Video Matching Fee:2026-01-14 05:50:29</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549766</td>
<td>302291-C-Video Matching Fee:2026-01-14 05:57:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549767</td>
<td>302291-C-M5 South West Motorway:2026-01-14 05:50:29</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549768</td>
<td>302291-C-M5 South West Motorway:2026-01-14 17:36:53</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549769</td>
<td>302291-C-WestConnex:2026-01-14 17:22:39</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549770</td>
<td>302291-C-WestConnex:2026-01-14 05:57:18</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549771</td>
<td>302291-C-Video Matching Fee:2026-01-15 07:12:35</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549772</td>
<td>302291-C-Video Matching Fee:2026-01-15 16:04:06</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549773</td>
<td>302291-C-Video Matching Fee:2026-01-15 07:00:00</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549774</td>
<td>302291-C-WestLink M7:2026-01-15 07:00:00</td>
<td>2.54</td>
<td>0.25</td>
<td>2.79</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 56 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549775</td>
<td>302291-C-WestLink M7:2026-01-15 07:12:35</td>
<td>6.12</td>
<td>0.61</td>
<td>6.73</td>
</tr>
<tr>
<td>NSW</td>
<td>DK82ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>George Baramilis</td>
<td>4843549776</td>
<td>302291-C-WestLink M7:2026-01-15 16:04:06</td>
<td>8.65</td>
<td>0.87</td>
<td>9.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549901</td>
<td>302293-C-Lane Cove Tunnel : 2025-12-11 07:49:33</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549902</td>
<td>302293-C-Video Matching Fee : 2025-12-16 14:52:17</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549903</td>
<td>302293-C-Video Matching Fee : 2025-12-16 15:04:29</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549904</td>
<td>302293-C-Video Matching Fee : 2025-12-16 08:03:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549905</td>
<td>302293-C-Video Matching Fee : 2025-12-16 07:39:24</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549906</td>
<td>302293-C-Cross City Tunnel : 2025-12-16 14:52:17</td>
<td>3.07</td>
<td>0.31</td>
<td>3.38</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549907</td>
<td>302293-C-Lane Cove Tunnel : 2025-12-16 15:04:29</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549908</td>
<td>302293-C-Lane Cove Tunnel : 2025-12-16 07:52:57</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549909</td>
<td>302293-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-16</td>
<td>4.01</td>
<td>0.40</td>
<td>4.41</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549910</td>
<td>302293-C-North Connex : 2025-12-16 07:39:24</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549911</td>
<td>302293-C-North Connex : 2025-12-16 15:15:03</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549912</td>
<td>302293-C-Hills M2 : 2025-12-16 07:43:51</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549913</td>
<td>302293-C-Hills M2 : 2025-12-16 15:08:16</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549914</td>
<td>302293-C-Video Matching Fee : 2025-12-17 07:48:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549915</td>
<td>302293-C-Video Matching Fee : 2025-12-17 12:12:49</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549916</td>
<td>302293-C-North Connex : 2025-12-17 07:48:16</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549917</td>
<td>302293-C-North Connex : 2025-12-17 12:12:49</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549918</td>
<td>302293-C-WestLink M7 : 2025-12-18 15:00:29</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549919</td>
<td>302293-C-WestLink M7 : 2025-12-18 10:23:56</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549920</td>
<td>302293-C-Hills M2 : 2025-12-18 15:06:27</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549921</td>
<td>302293-C-Hills M2 : 2025-12-18 10:18:06</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549922</td>
<td>302293-C-North Connex : 2025-12-18 10:17:55</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549923</td>
<td>302293-C-Video Matching Fee : 2025-12-19 12:41:27</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549924</td>
<td>302293-C-Video Matching Fee : 2025-12-19 12:24:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549925</td>
<td>302293-C-Video Matching Fee : 2025-12-19 09:23:11</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549926</td>
<td>302293-C-Video Matching Fee : 2025-12-19 09:39:13</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549927</td>
<td>302293-C-Video Matching Fee : 2025-12-19 10:02:38</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549928</td>
<td>302293-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-19</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549929</td>
<td>302293-C-Lane Cove Tunnel : 2025-12-19 09:31:08</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549930</td>
<td>302293-C-Lane Cove Tunnel : 2025-12-19 13:51:23</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549931</td>
<td>302293-C-Cross City Tunnel : 2025-12-19 12:41:27</td>
<td>6.52</td>
<td>0.65</td>
<td>7.17</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 57 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net GST Total</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549932</td>
<td>302293-C-WestConnex : 2025-12-19 12:24:36</td>
<td>6.70 0.67 7.37</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549933</td>
<td>302293-C-WestConnex : 2025-12-19 10:02:38</td>
<td>6.70 0.67 7.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549934</td>
<td>302293-C-Eastern Distributor : 2025-12-19 12:40:31</td>
<td>9.24 0.92 10.16</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549935</td>
<td>302293-C-North Connex : 2025-12-19 09:23:11</td>
<td>9.32 0.93 10.25</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549936</td>
<td>302293-C-North Connex : 2025-12-19 14:00:59</td>
<td>9.32 0.93 10.25</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549937</td>
<td>302293-C-Hills M2 : 2025-12-19 09:27:44</td>
<td>9.32 0.93 10.25</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549938</td>
<td>302293-C-Hills M2 : 2025-12-19 13:54:43</td>
<td>9.32 0.93 10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549939</td>
<td>302293-C-Video Matching Fee : 2025-12-28 09:59:49</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549940</td>
<td>302293-C-Video Matching Fee : 2025-12-28 09:59:59</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549941</td>
<td>302293-C-Video Matching Fee : 2025-12-28 10:05:20</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549942</td>
<td>302293-C-Hills M2 : 2025-12-28 09:59:59</td>
<td>4.66 0.47 5.13</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549943</td>
<td>302293-C-WestLink M7 : 2025-12-28 10:05:20</td>
<td>9.25 0.93 10.18</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549944</td>
<td>302293-C-North Connex : 2025-12-28 09:59:49</td>
<td>9.32 0.93 10.25</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549945</td>
<td>302293-C-Video Matching Fee:2026-01-04 13:02:32</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549946</td>
<td>302293-C-Video Matching Fee:2026-01-04 13:02:42</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549947</td>
<td>302293-C-Video Matching Fee:2026-01-04 12:29:14</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549948</td>
<td>302293-C-Hills M2:2026-01-04 13:02:32</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549949</td>
<td>302293-C-WestLink M7:2026-01-04 12:29:14</td>
<td>9.36 0.94 10.30</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549950</td>
<td>302293-C-North Connex:2026-01-04 13:02:42</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549951</td>
<td>302293-C-Video Matching Fee:2026-01-06 07:38:04</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549952</td>
<td>302293-C-Video Matching Fee:2026-01-06 07:38:14</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549953</td>
<td>302293-C-Video Matching Fee:2026-01-06 16:11:52</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549954</td>
<td>302293-C-Video Matching Fee:2026-01-06 16:12:03</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549955</td>
<td>302293-C-Video Matching Fee:2026-01-06 07:43:47</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549956</td>
<td>302293-C-WestLink M7:2026-01-06 07:43:47</td>
<td>0.80 0.08 0.88</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549957</td>
<td>302293-C-Hills M2:2026-01-06 07:38:14</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549958</td>
<td>302293-C-Hills M2:2026-01-06 16:11:52</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549959</td>
<td>302293-C-North Connex:2026-01-06 07:38:04</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549960</td>
<td>302293-C-North Connex:2026-01-06 16:12:03</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549961</td>
<td>302293-C-Video Matching Fee:2026-01-07 07:31:19</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549962</td>
<td>302293-C-Video Matching Fee:2026-01-07 07:31:29</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549963</td>
<td>302293-C-Video Matching Fee:2026-01-07 16:15:21</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549964</td>
<td>302293-C-Video Matching Fee:2026-01-07 07:36:54</td>
<td>0.68 0.07 0.75</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 58 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No. AU1166479</th>
<th>Invoice Date 31 January 2026</th>
<th colspan="3">Invoice No. AIN00014651</th>
<th>P</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net GST Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549965</td>
<td>302293-C-WestLink M7:2026-01-07 07:36:54</td>
<td>0.80 0.08 0.88</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549966</td>
<td>302293-C-Hills M2:2026-01-07 07:31:29</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549967</td>
<td>302293-C-Hills M2:2026-01-07 16:15:21</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549968</td>
<td>302293-C-North Connex:2026-01-07 07:31:19</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549969</td>
<td>302293-C-North Connex:2026-01-07 16:15:31</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549970</td>
<td>302293-C-Video Matching Fee:2026-01-08 16:29:49</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549971</td>
<td>302293-C-Video Matching Fee:2026-01-08 16:29:59</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549972</td>
<td>302293-C-Video Matching Fee:2026-01-08 07:29:20</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549973</td>
<td>302293-C-Video Matching Fee:2026-01-08 07:34:39</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549974</td>
<td>302293-C-WestLink M7:2026-01-08 07:34:39</td>
<td>0.80 0.08 0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549975</td>
<td>302293-C-Hills M2:2026-01-08 07:29:20</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549976</td>
<td>302293-C-Hills M2:2026-01-08 16:29:49</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549977</td>
<td>302293-C-North Connex:2026-01-08 07:29:10</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549978</td>
<td>302293-C-North Connex:2026-01-08 16:29:59</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549979</td>
<td>302293-C-Video Matching Fee:2026-01-09 07:35:26</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549980</td>
<td>302293-C-Video Matching Fee:2026-01-09 07:35:36</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549981</td>
<td>302293-C-WestLink M7:2026-01-09 07:41:02</td>
<td>0.80 0.08 0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549982</td>
<td>302293-C-Hills M2:2026-01-09 14:42:00</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549983</td>
<td>302293-C-Hills M2:2026-01-09 07:35:36</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549984</td>
<td>302293-C-North Connex:2026-01-09 14:42:11</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549985</td>
<td>302293-C-North Connex:2026-01-09 07:35:26</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549986</td>
<td>302293-C-WestLink M7:2026-01-12 07:34:12</td>
<td>0.80 0.08 0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549987</td>
<td>302293-C-Hills M2:2026-01-12 16:25:19</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549988</td>
<td>302293-C-Hills M2:2026-01-12 07:28:52</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549989</td>
<td>302293-C-North Connex:2026-01-12 07:28:43</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549990</td>
<td>302293-C-North Connex:2026-01-12 16:25:30</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549991</td>
<td>302293-C-Video Matching Fee:2026-01-14 07:31:41</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549992</td>
<td>302293-C-Hills M2:2026-01-14 07:31:41</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549993</td>
<td>302293-C-Hills M2:2026-01-14 16:37:21</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549994</td>
<td>302293-C-North Connex:2026-01-14 07:31:32</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549995</td>
<td>302293-C-North Connex:2026-01-14 16:37:32</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549996</td>
<td>302293-C-Video Matching Fee:2026-01-15 13:01:58</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549997</td>
<td>302293-C-Hills M2:2026-01-15 13:01:47</td>
<td>4.72 0.47 5.19</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 59 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2" rowspan="2">Customer No. AU1166479</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th colspan="2" rowspan="2"></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th>31 January 2026</th>
<th>AIN00014651</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549998</td>
<td>302293-C-Hills M2:2026-01-15 07:26:50</td>
<td>4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843549999</td>
<td>302293-C-WestLink M7:2026-01-15 11:58:19</td>
<td>8.35</td>
<td>0.84</td>
<td>9.19</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843550000</td>
<td>302293-C-WestLink M7:2026-01-15 12:41:43</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843550001</td>
<td>302293-C-North Connex:2026-01-15 07:26:40</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td colspan="2">NSW DK83ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Ben Potter</td>
<td>4843550002</td>
<td>302293-C-North Connex:2026-01-15 13:01:58</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total for Cost Centre: Power</td>
<td>6,256.82</td>
<td>626.51</td>
<td>6,883.33</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">Cost Centre: Supervisor</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545501</td>
<td>256890-C-EastLink : 2025-12-11 15:35:32</td>
<td>4.14</td>
<td>0.41</td>
<td>4.55</td>
</tr>
<tr>
<td colspan="2">VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545502</td>
<td>256890-C-EastLink : 2025-12-12 13:27:16</td>
<td>4.14</td>
<td>0.41</td>
<td>4.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545503</td>
<td>256890-C-EastLink : 2025-12-12 22:18:56</td>
<td>4.14</td>
<td>0.41</td>
<td>4.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545504</td>
<td>256890-C-EastLink : 2025-12-12 06:31:49</td>
<td>6.69</td>
<td>0.67</td>
<td>7.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545505</td>
<td>256890-C-EastLink : 2025-12-14 10:30:05</td>
<td>1.50</td>
<td>0.15</td>
<td>1.65</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545506</td>
<td>256890-C-EastLink : 2025-12-15 14:22:45</td>
<td>3.01</td>
<td>0.30</td>
<td>3.31</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545507</td>
<td>256890-C-EastLink : 2025-12-15 06:41:44</td>
<td>6.69</td>
<td>0.67</td>
<td>7.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545508</td>
<td>256890-C-EastLink : 2025-12-16 13:16:45</td>
<td>3.39</td>
<td>0.34</td>
<td>3.73</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545509</td>
<td>256890-C-EastLink : 2025-12-16 06:41:24</td>
<td>6.69</td>
<td>0.67</td>
<td>7.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545510</td>
<td>256890-C-EastLink : 2025-12-16 14:42:54</td>
<td>7.53</td>
<td>0.75</td>
<td>8.28</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545511</td>
<td>256890-C-CityLink : 2025-12-16 12:56:48</td>
<td>12.48</td>
<td>1.25</td>
<td>13.73</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545512</td>
<td>256890-C-West Gate Tunnel : 2025-12-17 12:46:31</td>
<td>5.95</td>
<td>0.60</td>
<td>6.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545513</td>
<td>256890-C-CityLink : 2025-12-17 07:06:20</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545514</td>
<td>256890-C-CityLink : 2025-12-17 13:39:54</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545515</td>
<td>256890-C-EastLink : 2025-12-18 15:20:41</td>
<td>4.14</td>
<td>0.41</td>
<td>4.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545516</td>
<td>256890-C-West Gate Tunnel : 2025-12-18 11:06:21</td>
<td>5.95</td>
<td>0.60</td>
<td>6.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545517</td>
<td>256890-C-CityLink : 2025-12-18 07:23:59</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545518</td>
<td>256890-C-CityLink : 2025-12-18 12:18:23</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW3OI</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545519</td>
<td>256890-C-CityLink : 2025-12-18 14:29:43</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545520</td>
<td>256890-C-EastLink : 2025-12-19 14:55:55</td>
<td>4.14</td>
<td>0.41</td>
<td>4.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545521</td>
<td>256890-C-CityLink : 2025-12-19 14:32:40</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545522</td>
<td>256890-C-CityLink : 2025-12-19 07:08:54</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545523</td>
<td>256890-C-EastLink : 2025-12-22 14:38:22</td>
<td>0.75</td>
<td>0.08</td>
<td>0.83</td>
</tr>
<tr>
<td>VIC</td>
<td>1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545524</td>
<td>256890-C-EastLink : 2025-12-22 15:18:08</td>
<td>0.75</td>
<td>0.08</td>
<td>0.83</td>
</tr>
<tr>
<td colspan="2">VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545525</td>
<td>256890-C-EastLink : 2025-12-24 17:06:58</td>
<td>1.50</td>
<td>0.15</td>
<td>1.65</td>
</tr>
<tr>
<td colspan="2">VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545526</td>
<td>256890-C-EastLink : 2025-12-25 11:06:31</td>
<td>1.88</td>
<td>0.19</td>
<td>2.07</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 60 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th rowspan="2">Customer No. AU1166479</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th>31 January 2026</th>
</tr>
<tr>
<td>State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net GST Total</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545527</td>
<td>256890-C-EastLink : 2025-12-25 17:00:26</td>
<td>4.14 0.41 4.55</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545528</td>
<td>256890-C-EastLink : 2025-12-26 10:19:40</td>
<td>4.14 0.41 4.55</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545529</td>
<td>256890-C-EastLink : 2025-12-28 11:16:53</td>
<td>4.14 0.41 4.55</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545530</td>
<td>256890-C-EastLink:2026-01-03 15:56:56</td>
<td>1.50 0.15 1.65</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545531</td>
<td>256890-C-EastLink:2026-01-05 18:58:16</td>
<td>1.88 0.19 2.07</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545532</td>
<td>256890-C-EastLink:2026-01-06 15:32:51</td>
<td>4.14 0.41 4.55</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545533</td>
<td>256890-C-CityLink:2026-01-06 07:03:41</td>
<td>15.60 1.56 17.16</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545534</td>
<td>256890-C-CityLink:2026-01-06 15:14:19</td>
<td>15.60 1.56 17.16</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545535</td>
<td>256890-C-EastLink:2026-01-07 14:40:16</td>
<td>3.39 0.34 3.73</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545536</td>
<td>256890-C-EastLink:2026-01-07 06:45:56</td>
<td>6.69 0.67 7.36</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545537</td>
<td>256890-C-EastLink:2026-01-07 10:23:39</td>
<td>7.44 0.74 8.18</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545538</td>
<td>256890-C-EastLink:2026-01-07 15:32:09</td>
<td>7.53 0.75 8.28</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545539</td>
<td>256890-C-EastLink:2026-01-08 15:45:00</td>
<td>4.14 0.41 4.55</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545540</td>
<td>256890-C-CityLink:2026-01-08 15:10:02</td>
<td>15.60 1.56 17.16</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545541</td>
<td>256890-C-CityLink:2026-01-08 06:30:37</td>
<td>15.60 1.56 17.16</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545542</td>
<td>256890-C-EastLink:2026-01-09 16:26:54</td>
<td>4.14 0.41 4.55</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545543</td>
<td>256890-C-CityLink:2026-01-09 08:42:14</td>
<td>10.80 1.08 11.88</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545544</td>
<td>256890-C-CityLink:2026-01-09 10:17:21</td>
<td>10.80 1.08 11.88</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545545</td>
<td>256890-C-CityLink:2026-01-09 14:14:47</td>
<td>15.60 1.56 17.16</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545546</td>
<td>256890-C-CityLink:2026-01-09 16:09:01</td>
<td>15.60 1.56 17.16</td>
</tr>
<tr>
<td>VIC 1SW3O1</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545547</td>
<td>256890-C-CityLink:2026-01-09 12:27:16</td>
<td>15.60 1.56 17.16</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545548</td>
<td>256890-C-CityLink:2026-01-09 07:03:49</td>
<td>15.60 1.56 17.16</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545549</td>
<td>256890-C-CityLink:2026-01-14 11:54:29</td>
<td>12.60 1.26 13.86</td>
</tr>
<tr>
<td>VIC 1SW301</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Shane Gower</td>
<td>4843545550</td>
<td>256890-C-CityLink:2026-01-15 16:10:04</td>
<td>9.60 0.96 10.56</td>
</tr>
<tr>
<td>VIC 1SW3OJ</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Carlo La Civita</td>
<td>4843545401</td>
<td>256889-C-EastLink : 2025-12-11 18:42:03</td>
<td>5.19 0.52 5.71</td>
</tr>
<tr>
<td>VIC 1SW3OJ</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Carlo La Civita</td>
<td>4843545402</td>
<td>256889-C-EastLink : 2025-12-11 20:07:47</td>
<td>5.19 0.52 5.71</td>
</tr>
<tr>
<td>VIC 1SW3OJ</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Carlo La Civita</td>
<td>4843545403</td>
<td>256889-C-EastLink : 2025-12-18 19:41:13</td>
<td>5.19 0.52 5.71</td>
</tr>
<tr>
<td>VIC 1SW3OJ</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Carlo La Civita</td>
<td>4843545404</td>
<td>256889-C-EastLink : 2025-12-18 20:41:54</td>
<td>5.19 0.52 5.71</td>
</tr>
<tr>
<td>VIC 1SW3OJ</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Carlo La Civita</td>
<td>4843545405</td>
<td>256889-C-EastLink : 2025-12-21 12:11:46</td>
<td>11.30 1.13 12.43</td>
</tr>
<tr>
<td>VIC 1SW3OJ</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Carlo La Civita</td>
<td>4843545406</td>
<td>256889-C-EastLink : 2025-12-21 15:18:32</td>
<td>11.30 1.13 12.43</td>
</tr>
<tr>
<td>VIC 1SW3OJ</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Carlo La Civita</td>
<td>4843545407</td>
<td>256889-C-CityLink:2026-01-09 10:18:06</td>
<td>15.60 1.56 17.16</td>
</tr>
<tr>
<td>VIC 1SW3OJ</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Carlo La Civita</td>
<td>4843545408</td>
<td>256889-C-CityLink:2026-01-09 12:43:55</td>
<td>15.60 1.56 17.16</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546901</td>
<td>278913-C-CityLink : 2025-12-09 12:48:45</td>
<td>-15.45 -1.55 -17.00</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 61 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th>Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th>AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td>State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546902</td>
<td>278913-C-CityLink : 2025-12-09 12:48:45</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546903</td>
<td>278913-C-CityLink : 2025-12-11 10:32:58</td>
<td>-4.75</td>
<td>-0.48</td>
<td>-5.23</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546904</td>
<td>278913-C-EastLink : 2025-12-11 06:48:11</td>
<td>8.67</td>
<td>0.87</td>
<td>9.54</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546905</td>
<td>278913-C-EastLink : 2025-12-11 14:48:30</td>
<td>11.30</td>
<td>1.13</td>
<td>12.43</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546906</td>
<td>278913-C-CityLink : 2025-12-11 10:28:11</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546907</td>
<td>278913-C-EastLink : 2025-12-12 06:17:42</td>
<td>11.30</td>
<td>1.13</td>
<td>12.43</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546908</td>
<td>278913-C-EastLink : 2025-12-12 13:28:17</td>
<td>11.30</td>
<td>1.13</td>
<td>12.43</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546909</td>
<td>278913-C-EastLink : 2025-12-16 14:59:34</td>
<td>8.67</td>
<td>0.87</td>
<td>9.54</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546910</td>
<td>278913-C-EastLink : 2025-12-16 06:24:08</td>
<td>10.93</td>
<td>1.09</td>
<td>12.02</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546911</td>
<td>278913-C-EastLink : 2025-12-17 14:35:05</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546912</td>
<td>278913-C-EastLink : 2025-12-17 05:23:02</td>
<td>8.67</td>
<td>0.87</td>
<td>9.54</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546913</td>
<td>278913-C-CityLink : 2025-12-17 05:46:32</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546914</td>
<td>278913-C-EastLink : 2025-12-29 09:52:19</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546915</td>
<td>278913-C-CityLink : 2025-12-29 10:13:53</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546916</td>
<td>278913-C-Video Matching Fee : 2025-12-31 08:42:33</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546917</td>
<td>278913-C-EastLink : 2025-12-31 08:42:33</td>
<td>8.67</td>
<td>0.87</td>
<td>9.54</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546918</td>
<td>278913-C-CityLink-West Gate Tunnel : 2025-12-31</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546919</td>
<td>278913-C-Video Matching Fee:2026-01-03 20:38:00</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546920</td>
<td>278913-C-EastLink:2026-01-03 13:39:22</td>
<td>8.67</td>
<td>0.87</td>
<td>9.54</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546921</td>
<td>278913-C-EastLink:2026-01-03 20:38:00</td>
<td>8.67</td>
<td>0.87</td>
<td>9.54</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546922</td>
<td>278913-C-CityLink:2026-01-03 14:02:16</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546923</td>
<td>278913-C-CityLink:2026-01-03 20:11:10</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546924</td>
<td>278913-C-EastLink:2026-01-04 11:18:01</td>
<td>8.67</td>
<td>0.87</td>
<td>9.54</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546925</td>
<td>278913-C-CityLink:2026-01-04 11:42:35</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546926</td>
<td>278913-C-CityLink:2026-01-04 15:10:24</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546927</td>
<td>278913-C-EastLink:2026-01-05 12:22:01</td>
<td>4.51</td>
<td>0.45</td>
<td>4.96</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546928</td>
<td>278913-C-EastLink:2026-01-05 07:12:44</td>
<td>8.67</td>
<td>0.87</td>
<td>9.54</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546929</td>
<td>278913-C-EastLink:2026-01-05 13:06:15</td>
<td>11.30</td>
<td>1.13</td>
<td>12.43</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546930</td>
<td>278913-C-CityLink:2026-01-05 07:37:01</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546931</td>
<td>278913-C-CityLink:2026-01-05 12:04:12</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546932</td>
<td>278913-C-EastLink:2026-01-06 07:12:42</td>
<td>8.67</td>
<td>0.87</td>
<td>9.54</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546933</td>
<td>278913-C-EastLink:2026-01-06 10:22:16</td>
<td>8.67</td>
<td>0.87</td>
<td>9.54</td>
</tr>
<tr>
<td>VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546934</td>
<td>278913-C-CityLink:2026-01-06 07:37:48</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 62 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th colspan="2" rowspan="2"></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546935</td>
<td>278913-C-CityLink:2026-01-06 10:05:30</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td colspan="2">VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546936</td>
<td>278913-C-EastLink:2026-01-09 07:15:27</td>
<td>8.67</td>
<td>0.87</td>
<td>9.54</td>
</tr>
<tr>
<td>VIC</td>
<td>1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546937</td>
<td>278913-C-EastLink:2026-01-09 13:46:11</td>
<td>8.67</td>
<td>0.87</td>
<td>9.54</td>
</tr>
<tr>
<td colspan="2">VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546938</td>
<td>278913-C-CityLink:2026-01-09 07:40:01</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td colspan="2">VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546939</td>
<td>278913-C-CityLink:2026-01-10 14:16:46</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td colspan="2">VIC 1VQ6XK</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Corey Skelton</td>
<td>4843546940</td>
<td>278913-C-EastLink:2026-01-10 07:47:37</td>
<td>11.30</td>
<td>1.13</td>
<td>12.43</td>
</tr>
<tr>
<td colspan="2">VIC 1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547701</td>
<td>295354-C-Video Matching Fee : 2025-12-11 16:27:09</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547702</td>
<td>295354-C-CityLink : 2025-12-11 16:27:09</td>
<td>10.70</td>
<td>1.07</td>
<td>11.77</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547703</td>
<td>295354-C-Video Matching Fee : 2025-12-15 16:25:13</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547704</td>
<td>295354-C-Video Matching Fee : 2025-12-15 07:46:59</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547705</td>
<td>295354-C-CityLink : 2025-12-15 16:25:13</td>
<td>10.70</td>
<td>1.07</td>
<td>11.77</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547706</td>
<td>295354-C-CityLink : 2025-12-15 07:46:59</td>
<td>10.70</td>
<td>1.07</td>
<td>11.77</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547707</td>
<td>295354-C-Video Matching Fee : 2025-12-16 07:25:38</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547708</td>
<td>295354-C-Video Matching Fee : 2025-12-16 16:25:13</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547709</td>
<td>295354-C-CityLink : 2025-12-16 07:25:38</td>
<td>10.70</td>
<td>1.07</td>
<td>11.77</td>
</tr>
<tr>
<td colspan="2">VIC 1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547710</td>
<td>295354-C-CityLink : 2025-12-16 16:25:13</td>
<td>10.70</td>
<td>1.07</td>
<td>11.77</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547711</td>
<td>295354-C-Video Matching Fee : 2025-12-17 06:57:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547712</td>
<td>295354-C-Video Matching Fee : 2025-12-17 15:23:29</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">VIC 1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547713</td>
<td>295354-C-CityLink : 2025-12-17 15:23:29</td>
<td>10.70</td>
<td>1.07</td>
<td>11.77</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547714</td>
<td>295354-C-CityLink : 2025-12-17 06:57:55</td>
<td>10.70</td>
<td>1.07</td>
<td>11.77</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547715</td>
<td>295354-C-Video Matching Fee : 2025-12-24 12:36:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547716</td>
<td>295354-C-CityLink : 2025-12-24 12:36:18</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547717</td>
<td>295354-C-Video Matching Fee : 2025-12-29 12:43:47</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547718</td>
<td>295354-C-Video Matching Fee : 2025-12-29 11:05:38</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547719</td>
<td>295354-C-CityLink : 2025-12-29 11:05:38</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547720</td>
<td>295354-C-CityLink : 2025-12-29 12:43:47</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547721</td>
<td>295354-C-Video Matching Fee:2026-01-07 07:21:38</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547722</td>
<td>295354-C-Video Matching Fee:2026-01-07 16:15:54</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547723</td>
<td>295354-C-CityLink:2026-01-07 16:15:54</td>
<td>10.80</td>
<td>1.08</td>
<td>11.88</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547724</td>
<td>295354-C-CityLink:2026-01-07 07:21:38</td>
<td>10.80</td>
<td>1.08</td>
<td>11.88</td>
</tr>
<tr>
<td colspan="2">VIC 1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547725</td>
<td>295354-C-Video Matching Fee:2026-01-08 15:49:33</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">VIC 1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547726</td>
<td>295354-C-Video Matching Fee:2026-01-08 07:20:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">VIC 1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547727</td>
<td>295354-C-CityLink:2026-01-08 15:49:33</td>
<td>10.80</td>
<td>1.08</td>
<td>11.88</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 63 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th></th>
<th></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547728</td>
<td>295354-C-CityLink:2026-01-08 07:20:36</td>
<td>10.80</td>
<td>1.08</td>
<td>11.88</td>
</tr>
<tr>
<td colspan="2">VIC 1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547729</td>
<td>295354-C-Video Matching Fee:2026-01-09 07:08:13</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547730</td>
<td>295354-C-Video Matching Fee:2026-01-09 13:15:30</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547731</td>
<td>295354-C-CityLink:2026-01-09 07:08:13</td>
<td>10.80</td>
<td>1.08</td>
<td>11.88</td>
</tr>
<tr>
<td>VIC</td>
<td>1YJ9XL</td>
<td>ISUZU RG MY23 D-MAX LS-U</td>
<td>Matthew Quinn</td>
<td>4843547732</td>
<td>295354-C-CityLink:2026-01-09 13:15:30</td>
<td>10.80</td>
<td>1.08</td>
<td>11.88</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550801</td>
<td>305035-C-CityLink : 2025-12-15 11:10:15</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550802</td>
<td>305035-C-CityLink-West Gate Tunnel : 2025-12-16</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550803</td>
<td>305035-C-CityLink : 2025-12-16 15:29:14</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550804</td>
<td>305035-C-CityLink : 2025-12-19 11:46:47</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550805</td>
<td>305035-C-CityLink : 2025-12-19 14:24:54</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550806</td>
<td>305035-C-CityLink : 2025-12-22 11:54:28</td>
<td>12.48</td>
<td>1.25</td>
<td>13.73</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550807</td>
<td>305035-C-CityLink : 2025-12-22 08:06:12</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550808</td>
<td>305035-C-CityLink : 2025-12-23 14:19:46</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550809</td>
<td>305035-C-CityLink : 2025-12-29 19:41:43</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550810</td>
<td>305035-C-CityLink : 2025-12-29 21:21:30</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550811</td>
<td>305035-C-CityLink : 2025-12-30 07:25:27</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550812</td>
<td>305035-C-CityLink:2026-01-03 17:41:11</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550813</td>
<td>305035-C-CityLink:2026-01-03 23:13:08</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550814</td>
<td>305035-C-CityLink:2026-01-06 10:24:50</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550815</td>
<td>305035-C-CityLink:2026-01-06 14:53:49</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550816</td>
<td>305035-C-Video Matching Fee:2026-01-08 11:55:35</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550817</td>
<td>305035-C-Video Matching Fee:2026-01-08 13:43:06</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550818</td>
<td>305035-C-EastLink:2026-01-08 11:55:35</td>
<td>5.26</td>
<td>0.53</td>
<td>5.79</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550819</td>
<td>305035-C-EastLink:2026-01-08 13:43:06</td>
<td>8.65</td>
<td>0.87</td>
<td>9.52</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550820</td>
<td>305035-C-CityLink:2026-01-14 07:46:00</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550821</td>
<td>305035-C-CityLink:2026-01-14 15:18:52</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HO</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Everett</td>
<td>4843550822</td>
<td>305035-C-CityLink:2026-01-15 17:02:42</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550301</td>
<td>305030-C-Video Matching Fee : 2025-12-11 06:42:30</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550302</td>
<td>305030-C-Video Matching Fee : 2025-12-11 14:19:40</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550303</td>
<td>305030-C-Video Matching Fee : 2025-12-11 18:19:52</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550304</td>
<td>305030-C-Video Matching Fee : 2025-12-11 20:05:20</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550305</td>
<td>305030-C-Video Matching Fee : 2025-12-11 14:00:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">VIC 2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550306</td>
<td>305030-C-EastLink : 2025-12-11 14:19:40</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 64 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550307</td>
<td>305030-C-EastLink : 2025-12-11 06:42:30</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550308</td>
<td>305030-C-EastLink : 2025-12-11 18:19:52</td>
<td>11.30</td>
<td>1.13</td>
<td>12.43</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550309</td>
<td>305030-C-EastLink : 2025-12-11 20:05:20</td>
<td>11.30</td>
<td>1.13</td>
<td>12.43</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550310</td>
<td>305030-C-CityLink : 2025-12-11 14:00:02</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550311</td>
<td>305030-C-Video Matching Fee : 2025-12-12 06:19:02</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550312</td>
<td>305030-C-Video Matching Fee : 2025-12-12 13:29:58</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550313</td>
<td>305030-C-EastLink : 2025-12-12 06:19:02</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550314</td>
<td>305030-C-EastLink : 2025-12-12 13:29:58</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550315</td>
<td>305030-C-Video Matching Fee : 2025-12-15 06:55:50</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550316</td>
<td>305030-C-Video Matching Fee : 2025-12-15 17:31:11</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550317</td>
<td>305030-C-Video Matching Fee : 2025-12-15 07:41:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550318</td>
<td>305030-C-Video Matching Fee : 2025-12-15 16:53:12</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550319</td>
<td>305030-C-EastLink : 2025-12-15 06:55:50</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550320</td>
<td>305030-C-EastLink : 2025-12-15 17:31:11</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550321</td>
<td>305030-C-CityLink : 2025-12-15 07:41:32</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550322</td>
<td>305030-C-CityLink : 2025-12-15 16:53:12</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550323</td>
<td>305030-C-Video Matching Fee : 2025-12-16 13:09:45</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550324</td>
<td>305030-C-Video Matching Fee : 2025-12-16 07:04:17</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550325</td>
<td>305030-C-Video Matching Fee : 2025-12-16 12:51:09</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550326</td>
<td>305030-C-Video Matching Fee : 2025-12-16 08:16:57</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550327</td>
<td>305030-C-EastLink : 2025-12-16 07:04:17</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550328</td>
<td>305030-C-EastLink : 2025-12-16 13:09:45</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550329</td>
<td>305030-C-CityLink : 2025-12-16 12:51:09</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550330</td>
<td>305030-C-CityLink : 2025-12-16 08:16:57</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550331</td>
<td>305030-C-Video Matching Fee : 2025-12-17 15:04:47</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550332</td>
<td>305030-C-Video Matching Fee : 2025-12-17 07:08:55</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550333</td>
<td>305030-C-Video Matching Fee : 2025-12-17 07:54:30</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550334</td>
<td>305030-C-Video Matching Fee : 2025-12-17 14:17:51</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550335</td>
<td>305030-C-EastLink : 2025-12-17 07:08:55</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550336</td>
<td>305030-C-EastLink : 2025-12-17 15:04:47</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550337</td>
<td>305030-C-CityLink : 2025-12-17 07:54:30</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550338</td>
<td>305030-C-CityLink : 2025-12-17 14:17:51</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550339</td>
<td>305030-C-Video Matching Fee : 2025-12-18 19:16:24</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 65 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550340</td>
<td>305030-C-Video Matching Fee : 2025-12-18 20:39:40</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550341</td>
<td>305030-C-Video Matching Fee : 2025-12-18 07:46:08</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550342</td>
<td>305030-C-Video Matching Fee : 2025-12-18 15:20:59</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550343</td>
<td>305030-C-Video Matching Fee : 2025-12-18 08:32:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550344</td>
<td>305030-C-Video Matching Fee : 2025-12-18 14:29:40</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550345</td>
<td>305030-C-EastLink : 2025-12-18 07:46:08</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550346</td>
<td>305030-C-EastLink : 2025-12-18 15:20:59</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550347</td>
<td>305030-C-EastLink : 2025-12-18 19:16:24</td>
<td>11.30</td>
<td>1.13</td>
<td>12.43</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550348</td>
<td>305030-C-EastLink : 2025-12-18 20:39:40</td>
<td>11.30</td>
<td>1.13</td>
<td>12.43</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550349</td>
<td>305030-C-CityLink : 2025-12-18 14:29:40</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550350</td>
<td>305030-C-CityLink : 2025-12-18 08:32:20</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550351</td>
<td>305030-C-Video Matching Fee : 2025-12-23 12:10:23</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550352</td>
<td>305030-C-Video Matching Fee : 2025-12-23 07:44:02</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550353</td>
<td>305030-C-Video Matching Fee : 2025-12-23 08:07:24</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550354</td>
<td>305030-C-Video Matching Fee : 2025-12-23 11:37:47</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550355</td>
<td>305030-C-EastLink : 2025-12-23 12:10:23</td>
<td>1.13</td>
<td>0.11</td>
<td>1.24</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550356</td>
<td>305030-C-EastLink : 2025-12-23 07:44:02</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550357</td>
<td>305030-C-CityLink : 2025-12-23 08:07:24</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550358</td>
<td>305030-C-CityLink : 2025-12-23 11:37:47</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550359</td>
<td>305030-C-Video Matching Fee : 2025-12-30 14:02:45</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550360</td>
<td>305030-C-Video Matching Fee : 2025-12-30 15:01:37</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550361</td>
<td>305030-C-EastLink : 2025-12-30 14:02:45</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550362</td>
<td>305030-C-EastLink : 2025-12-30 15:01:37</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550363</td>
<td>305030-C-Video Matching Fee:2026-01-07 10:51:12</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550364</td>
<td>305030-C-Video Matching Fee:2026-01-07 12:51:25</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550365</td>
<td>305030-C-Video Matching Fee:2026-01-07 11:14:30</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550366</td>
<td>305030-C-Video Matching Fee:2026-01-07 11:43:21</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550367</td>
<td>305030-C-Video Matching Fee:2026-01-07 12:30:53</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550368</td>
<td>305030-C-CityLink:2026-01-07 11:43:21</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550369</td>
<td>305030-C-EastLink:2026-01-07 10:51:12</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550370</td>
<td>305030-C-EastLink:2026-01-07 12:51:25</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550371</td>
<td>305030-C-CityLink:2026-01-07 12:30:53</td>
<td>12.60</td>
<td>1.26</td>
<td>13.86</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550372</td>
<td>305030-C-CityLink:2026-01-07 11:14:30</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 66 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th></th>
<th></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550373</td>
<td>305030-C-Video Matching Fee:2026-01-09 08:17:12</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550374</td>
<td>305030-C-Video Matching Fee:2026-01-09 13:25:47</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550375</td>
<td>305030-C-Video Matching Fee:2026-01-09 08:41:51</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550376</td>
<td>305030-C-Video Matching Fee:2026-01-09 10:18:53</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550377</td>
<td>305030-C-Video Matching Fee:2026-01-09 12:52:38</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550378</td>
<td>305030-C-EastLink:2026-01-09 08:17:12</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550379</td>
<td>305030-C-EastLink:2026-01-09 13:25:47</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550380</td>
<td>305030-C-CityLink:2026-01-09 10:18:53</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550381</td>
<td>305030-C-CityLink:2026-01-09 12:52:38</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550382</td>
<td>305030-C-CityLink:2026-01-09 08:41:51</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550383</td>
<td>305030-C-Video Matching Fee:2026-01-12 14:16:24</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550384</td>
<td>305030-C-Video Matching Fee:2026-01-12 08:54:47</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550385</td>
<td>305030-C-CityLink:2026-01-12 08:54:47</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550386</td>
<td>305030-C-CityLink:2026-01-12 14:16:24</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550387</td>
<td>305030-C-Video Matching Fee:2026-01-14 08:45:45</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550388</td>
<td>305030-C-Video Matching Fee:2026-01-14 12:24:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550389</td>
<td>305030-C-CityLink:2026-01-14 08:45:45</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HP</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>William Hunter</td>
<td>4843550390</td>
<td>305030-C-CityLink:2026-01-14 12:24:36</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HQ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Tony Barratt</td>
<td>4843550001</td>
<td>305026-C-Video Matching Fee : 2025-12-11 14:18:32</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HQ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Tony Barratt</td>
<td>4843550002</td>
<td>305026-C-Video Matching Fee : 2025-12-11 06:38:00</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HQ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Tony Barratt</td>
<td>4843550003</td>
<td>305026-C-CityLink : 2025-12-11 11:58:31</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HQ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Tony Barratt</td>
<td>4843550004</td>
<td>305026-C-EastLink : 2025-12-11 06:38:00</td>
<td>5.19</td>
<td>0.52</td>
<td>5.71</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2HQ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Tony Barratt</td>
<td>4843550005</td>
<td>305026-C-EastLink : 2025-12-11 14:18:32</td>
<td>5.19</td>
<td>0.52</td>
<td>5.71</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550101</td>
<td>305028-C-Video Matching Fee : 2025-12-11 05:55:19</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550102</td>
<td>305028-C-Video Matching Fee : 2025-12-11 14:56:58</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550103</td>
<td>305028-C-EastLink : 2025-12-11 05:55:19</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550104</td>
<td>305028-C-CityLink : 2025-12-11 14:56:58</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550105</td>
<td>305028-C-Video Matching Fee : 2025-12-12 06:24:26</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550106</td>
<td>305028-C-Video Matching Fee : 2025-12-12 06:59:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550107</td>
<td>305028-C-EastLink : 2025-12-12 06:24:26</td>
<td>8.29</td>
<td>0.83</td>
<td>9.12</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550108</td>
<td>305028-C-CityLink : 2025-12-12 06:59:16</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550109</td>
<td>305028-C-Video Matching Fee : 2025-12-15 06:37:23</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550110</td>
<td>305028-C-Video Matching Fee : 2025-12-15 17:26:26</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 67 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th></th>
<th></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550111</td>
<td>305028-C-Video Matching Fee : 2025-12-15 07:20:35</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550112</td>
<td>305028-C-Video Matching Fee : 2025-12-15 09:29:13</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550113</td>
<td>305028-C-CityLink : 2025-12-15 07:20:35</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550114</td>
<td>305028-C-CityLink : 2025-12-15 09:29:13</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550115</td>
<td>305028-C-EastLink : 2025-12-15 17:26:26</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550116</td>
<td>305028-C-EastLink : 2025-12-15 06:37:23</td>
<td>8.29</td>
<td>0.83</td>
<td>9.12</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550117</td>
<td>305028-C-Video Matching Fee : 2025-12-16 07:05:51</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550118</td>
<td>305028-C-Video Matching Fee : 2025-12-16 08:00:00</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550119</td>
<td>305028-C-Video Matching Fee : 2025-12-16 14:33:12</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550120</td>
<td>305028-C-EastLink : 2025-12-16 07:05:51</td>
<td>7.16</td>
<td>0.72</td>
<td>7.88</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550121</td>
<td>305028-C-CityLink : 2025-12-16 08:00:00</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550122</td>
<td>305028-C-CityLink : 2025-12-16 14:33:12</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550123</td>
<td>305028-C-Video Matching Fee : 2025-12-17 06:48:34</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550124</td>
<td>305028-C-Video Matching Fee : 2025-12-17 07:27:00</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550125</td>
<td>305028-C-Video Matching Fee : 2025-12-17 11:11:58</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550126</td>
<td>305028-C-EastLink : 2025-12-17 06:48:34</td>
<td>8.29</td>
<td>0.83</td>
<td>9.12</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550127</td>
<td>305028-C-CityLink : 2025-12-17 11:11:58</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550128</td>
<td>305028-C-CityLink : 2025-12-17 07:27:00</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550129</td>
<td>305028-C-Video Matching Fee : 2025-12-18 06:33:18</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550130</td>
<td>305028-C-Video Matching Fee : 2025-12-18 07:11:22</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550131</td>
<td>305028-C-Video Matching Fee : 2025-12-18 14:47:47</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550132</td>
<td>305028-C-EastLink : 2025-12-18 06:33:18</td>
<td>8.29</td>
<td>0.83</td>
<td>9.12</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550133</td>
<td>305028-C-CityLink : 2025-12-18 07:11:22</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550134</td>
<td>305028-C-CityLink : 2025-12-18 14:47:47</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550135</td>
<td>305028-C-Video Matching Fee : 2025-12-19 06:36:08</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550136</td>
<td>305028-C-Video Matching Fee : 2025-12-19 15:35:05</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550137</td>
<td>305028-C-Video Matching Fee : 2025-12-19 07:01:01</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550138</td>
<td>305028-C-Video Matching Fee : 2025-12-19 09:16:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550139</td>
<td>305028-C-Video Matching Fee : 2025-12-19 12:20:44</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550140</td>
<td>305028-C-Video Matching Fee : 2025-12-19 13:50:53</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550141</td>
<td>305028-C-EastLink : 2025-12-19 06:36:08</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550142</td>
<td>305028-C-EastLink : 2025-12-19 15:35:05</td>
<td>6.39</td>
<td>0.64</td>
<td>7.03</td>
</tr>
<tr>
<td colspan="2">VIC 2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550143</td>
<td>305028-C-CityLink : 2025-12-19 09:16:18</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 68 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550144</td>
<td>305028-C-CityLink : 2025-12-19 12:20:44</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550145</td>
<td>305028-C-CityLink : 2025-12-19 13:50:53</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550146</td>
<td>305028-C-CityLink : 2025-12-19 07:01:01</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550147</td>
<td>305028-C-Video Matching Fee:2026-01-06 07:15:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550148</td>
<td>305028-C-Video Matching Fee:2026-01-06 07:47:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550149</td>
<td>305028-C-Video Matching Fee:2026-01-06 14:25:54</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550150</td>
<td>305028-C-CityLink:2026-01-06 07:47:20</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550151</td>
<td>305028-C-CityLink:2026-01-06 07:15:36</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550152</td>
<td>305028-C-CityLink:2026-01-06 14:25:54</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550153</td>
<td>305028-C-Video Matching Fee:2026-01-07 07:20:15</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550154</td>
<td>305028-C-Video Matching Fee:2026-01-07 15:17:50</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550155</td>
<td>305028-C-CityLink:2026-01-07 07:20:15</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550156</td>
<td>305028-C-CityLink:2026-01-07 15:17:50</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550157</td>
<td>305028-C-Video Matching Fee:2026-01-08 12:00:44</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550158</td>
<td>305028-C-EastLink:2026-01-08 12:00:44</td>
<td>6.03</td>
<td>0.60</td>
<td>6.63</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550159</td>
<td>305028-C-Video Matching Fee:2026-01-09 13:08:50</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550160</td>
<td>305028-C-Video Matching Fee:2026-01-09 13:15:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550161</td>
<td>305028-C-Video Matching Fee:2026-01-09 13:42:29</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550162</td>
<td>305028-C-Video Matching Fee:2026-01-09 07:34:40</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550163</td>
<td>305028-C-CityLink:2026-01-09 13:08:50</td>
<td>10.80</td>
<td>1.08</td>
<td>11.88</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550164</td>
<td>305028-C-CityLink:2026-01-09 13:15:34</td>
<td>10.80</td>
<td>1.08</td>
<td>11.88</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550165</td>
<td>305028-C-CityLink:2026-01-09 07:34:40</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550166</td>
<td>305028-C-CityLink:2026-01-09 13:42:29</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550167</td>
<td>305028-C-Video Matching Fee:2026-01-12 11:09:57</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550168</td>
<td>305028-C-CityLink-West Gate Tunnel:2026-01-12 11:09:57</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550169</td>
<td>305028-C-Video Matching Fee:2026-01-14 06:56:45</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550170</td>
<td>305028-C-CityLink-West Gate Tunnel:2026-01-14 06:56:45</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550171</td>
<td>305028-C-Video Matching Fee:2026-01-15 06:28:58</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AJ2LB</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Rodelio Nervoil</td>
<td>4843550172</td>
<td>305028-C-CityLink:2026-01-15 06:28:58</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546201</td>
<td>261717-C-Logan Motorway : 2025-12-17 13:50:39</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546202</td>
<td>261717-C-Logan Motorway : 2025-12-17 13:39:11</td>
<td>4.91</td>
<td>0.49</td>
<td>5.40</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546203</td>
<td>261717-C-Legacy Way : 2025-12-17 10:08:47</td>
<td>9.55</td>
<td>0.96</td>
<td>10.51</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546204</td>
<td>261717-C-Logan Motorway : 2025-12-19 12:32:48</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 69 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th rowspan="2">Invoice Date 31 January 2026</th>
<th>Invoice No.</th>
<th rowspan="2"></th>
<th rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>AIN00014651</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546205</td>
<td>261717-C-Logan Motorway : 2025-12-22 14:55:36</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546206</td>
<td>261717-C-Logan Motorway : 2025-12-22 15:04:35</td>
<td>4.91</td>
<td>0.49</td>
<td>5.40</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546207</td>
<td>261717-C-Logan Motorway : 2025-12-22 15:20:07</td>
<td>4.91</td>
<td>0.49</td>
<td>5.40</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546208</td>
<td>261717-C-Logan Motorway : 2025-12-26 17:46:22</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546209</td>
<td>261717-C-Logan Motorway:2026-01-02 13:01:36</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546210</td>
<td>261717-C-Logan Motorway:2026-01-02 13:12:04</td>
<td>4.91</td>
<td>0.49</td>
<td>5.40</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546211</td>
<td>261717-C-Logan Motorway:2026-01-05 07:19:17</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546212</td>
<td>261717-C-Logan Motorway:2026-01-05 10:54:14</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546213</td>
<td>261717-C-Logan Motorway:2026-01-05 07:29:50</td>
<td>4.91</td>
<td>0.49</td>
<td>5.40</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546214</td>
<td>261717-C-Logan Motorway:2026-01-05 10:43:30</td>
<td>4.91</td>
<td>0.49</td>
<td>5.40</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546215</td>
<td>261717-C-Gateway Motorway:2026-01-06 17:55:15</td>
<td>7.89</td>
<td>0.79</td>
<td>8.68</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546216</td>
<td>261717-C-AirportlinkM7:2026-01-06 13:22:34</td>
<td>9.76</td>
<td>0.98</td>
<td>10.74</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546217</td>
<td>261717-C-Logan Motorway:2026-01-12 05:30:48</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546218</td>
<td>261717-C-Logan Motorway:2026-01-12 14:38:42</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546219</td>
<td>261717-C-Logan Motorway:2026-01-12 05:41:27</td>
<td>4.91</td>
<td>0.49</td>
<td>5.40</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546220</td>
<td>261717-C-Logan Motorway:2026-01-12 14:27:53</td>
<td>4.91</td>
<td>0.49</td>
<td>5.40</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546221</td>
<td>261717-C-Logan Motorway:2026-01-13 05:28:41</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546222</td>
<td>261717-C-Logan Motorway:2026-01-13 12:59:39</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546223</td>
<td>261717-C-Logan Motorway:2026-01-13 05:39:11</td>
<td>4.91</td>
<td>0.49</td>
<td>5.40</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546224</td>
<td>261717-C-Logan Motorway:2026-01-13 12:48:55</td>
<td>4.91</td>
<td>0.49</td>
<td>5.40</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546225</td>
<td>261717-C-Logan Motorway:2026-01-14 05:33:15</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546226</td>
<td>261717-C-Logan Motorway:2026-01-14 14:35:59</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546227</td>
<td>261717-C-Logan Motorway:2026-01-14 05:44:39</td>
<td>4.91</td>
<td>0.49</td>
<td>5.40</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546228</td>
<td>261717-C-Logan Motorway:2026-01-14 14:24:02</td>
<td>4.91</td>
<td>0.49</td>
<td>5.40</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546229</td>
<td>261717-C-Logan Motorway:2026-01-15 05:30:54</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546230</td>
<td>261717-C-Logan Motorway:2026-01-15 14:19:09</td>
<td>2.99</td>
<td>0.30</td>
<td>3.29</td>
</tr>
<tr>
<td>QLD</td>
<td>487BP9</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Spare</td>
<td>4843546231</td>
<td>261717-C-Logan Motorway:2026-01-15 05:42:56</td>
<td>4.91</td>
<td>0.49</td>
<td>5.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546301</td>
<td>264256-C-Video Matching Fee : 2025-12-15 09:30:50</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546302</td>
<td>264256-C-Video Matching Fee : 2025-12-15 09:40:25</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546303</td>
<td>264256-C-Video Matching Fee : 2025-12-15 14:58:08</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546304</td>
<td>264256-C-Video Matching Fee : 2025-12-15 09:13:49</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546305</td>
<td>264256-C-Video Matching Fee : 2025-12-15 15:14:39</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546306</td>
<td>264256-C-WestLink M7 : 2025-12-15 09:13:49</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 70 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No. AU1166479</th>
<th>Invoice Date 31 January 2026</th>
<th>Invoice No. AIN00014651</th>
<th></th>
<th></th>
<th colspan="3">P</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546307</td>
<td>264256-C-WestLink M7 : 2025-12-15 15:14:39</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546308</td>
<td>264256-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-15</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546309</td>
<td>264256-C-Lane Cove Tunnel : 2025-12-15 09:30:50</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546310</td>
<td>264256-C-Lane Cove Tunnel : 2025-12-15 14:58:08</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546311</td>
<td>264256-C-Video Matching Fee:2026-01-12 16:05:10</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546312</td>
<td>264256-C-WestLink M7:2026-01-12 15:35:16</td>
<td>0.64</td>
<td>0.06</td>
<td>0.70</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546313</td>
<td>264256-C-Video Matching Fee:2026-01-12 07:38:06</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546314</td>
<td>264256-C-Video Matching Fee:2026-01-12 15:35:16</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546315</td>
<td>264256-C-WestLink M7:2026-01-12 07:38:06</td>
<td>8.35</td>
<td>0.84</td>
<td>9.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546316</td>
<td>264256-C-WestConnex:2026-01-12 16:05:10</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546317</td>
<td>264256-C-Video Matching Fee:2026-01-13 16:42:15</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546318</td>
<td>264256-C-Video Matching Fee:2026-01-13 06:43:25</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546319</td>
<td>264256-C-WestLink M7:2026-01-13 16:11:37</td>
<td>0.64</td>
<td>0.06</td>
<td>0.70</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546320</td>
<td>264256-C-Video Matching Fee:2026-01-13 16:11:37</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546321</td>
<td>264256-C-WestConnex:2026-01-13 16:42:15</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546322</td>
<td>264256-C-WestConnex:2026-01-13 06:43:25</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546323</td>
<td>264256-C-Video Matching Fee:2026-01-14 16:10:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546324</td>
<td>264256-C-Video Matching Fee:2026-01-14 07:15:39</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546325</td>
<td>264256-C-WestLink M7:2026-01-14 15:45:00</td>
<td>0.64</td>
<td>0.06</td>
<td>0.70</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546326</td>
<td>264256-C-Video Matching Fee:2026-01-14 15:45:00</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546327</td>
<td>264256-C-WestConnex:2026-01-14 16:10:31</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546328</td>
<td>264256-C-WestConnex:2026-01-14 07:15:39</td>
<td>11.36</td>
<td>1.14</td>
<td>12.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546329</td>
<td>264256-C-Video Matching Fee:2026-01-15 16:46:06</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546330</td>
<td>264256-C-Video Matching Fee:2026-01-15 06:54:53</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546331</td>
<td>264256-C-WestLink M7:2026-01-15 16:16:45</td>
<td>0.64</td>
<td>0.06</td>
<td>0.70</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546332</td>
<td>264256-C-Video Matching Fee:2026-01-15 16:16:45</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546333</td>
<td>264256-C-WestConnex:2026-01-15 06:54:53</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB58QW</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Robert Hardman</td>
<td>4843546334</td>
<td>264256-C-WestConnex:2026-01-15 16:46:06</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547101</td>
<td>283677-C-WestLink M7 : 2025-12-16 16:42:28</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547102</td>
<td>283677-C-Hills M2 : 2025-12-16 16:44:53</td>
<td>3.30</td>
<td>0.33</td>
<td>3.63</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547103</td>
<td>283677-C-WestConnex : 2025-12-16 07:53:34</td>
<td>8.35</td>
<td>0.84</td>
<td>9.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547104</td>
<td>283677-C-WestConnex : 2025-12-16 17:03:26</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547105</td>
<td>283677-C-WestConnex : 2025-12-17 08:03:33</td>
<td>8.35</td>
<td>0.84</td>
<td>9.19</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 71 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No. AU1166479</th>
<th>Invoice Date 31 January 2026</th>
<th>Invoice No. AIN00014651</th>
<th></th>
<th></th>
<th colspan="3">P</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547106</td>
<td>283677-C-WestConnex : 2025-12-17 18:36:28</td>
<td>9.44</td>
<td>0.94</td>
<td>10.38</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547107</td>
<td>283677-C-WestLink M7 : 2025-12-18 16:29:56</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547108</td>
<td>283677-C-Hills M2 : 2025-12-18 16:32:29</td>
<td>3.30</td>
<td>0.33</td>
<td>3.63</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547109</td>
<td>283677-C-WestConnex : 2025-12-18 07:09:42</td>
<td>8.35</td>
<td>0.84</td>
<td>9.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547110</td>
<td>283677-C-WestConnex : 2025-12-18 16:47:24</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547111</td>
<td>283677-C-WestConnex : 2025-12-19 16:25:58</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547112</td>
<td>283677-C-WestConnex : 2025-12-19 07:15:15</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547113</td>
<td>283677-C-M5 South West Motorway : 2025-12-19</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547114</td>
<td>283677-C-M5 South West Motorway : 2025-12-19</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547115</td>
<td>283677-C-WestLink M7 : 2025-12-19 07:30:42</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547116</td>
<td>283677-C-WestConnex : 2025-12-24 07:43:12</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547117</td>
<td>283677-C-WestConnex : 2025-12-24 08:34:37</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547118</td>
<td>283677-C-M5 South West Motorway : 2025-12-24</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547119</td>
<td>283677-C-M5 South West Motorway : 2025-12-24</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547120</td>
<td>283677-C-WestConnex : 2025-12-24 18:16:53</td>
<td>6.85</td>
<td>0.69</td>
<td>7.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547121</td>
<td>283677-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-27</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547122</td>
<td>283677-C-WestConnex : 2025-12-27 06:12:31</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547123</td>
<td>283677-C-WestConnex : 2025-12-27 06:50:59</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547124</td>
<td>283677-C-Lane Cove Tunnel : 2025-12-27 10:01:37</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547125</td>
<td>283677-C-WestConnex : 2025-12-27 19:46:47</td>
<td>4.15</td>
<td>0.42</td>
<td>4.57</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547126</td>
<td>283677-C-M5 South West Motorway : 2025-12-27</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547127</td>
<td>283677-C-M5 South West Motorway : 2025-12-27</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547128</td>
<td>283677-C-Hills M2 : 2025-12-27 10:05:11</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547129</td>
<td>283677-C-North Connex : 2025-12-27 10:10:41</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547130</td>
<td>283677-C-WestConnex : 2025-12-28 06:37:15</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547131</td>
<td>283677-C-WestConnex : 2025-12-28 07:12:15</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547132</td>
<td>283677-C-M5 South West Motorway : 2025-12-28</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547133</td>
<td>283677-C-M5 South West Motorway : 2025-12-28</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547134</td>
<td>283677-C-WestConnex : 2025-12-29 10:25:11</td>
<td>6.70</td>
<td>0.67</td>
<td>7.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547135</td>
<td>283677-C-WestConnex : 2025-12-29 15:10:06</td>
<td>6.70</td>
<td>0.67</td>
<td>7.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547136</td>
<td>283677-C-WestConnex : 2025-12-30 07:38:20</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547137</td>
<td>283677-C-WestConnex : 2025-12-30 08:50:58</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547138</td>
<td>283677-C-WestConnex : 2025-12-30 17:38:27</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 72 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th rowspan="2">Invoice Date 31 January 2026</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547139</td>
<td>283677-C-WestConnex : 2025-12-30 18:18:31</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547140</td>
<td>283677-C-M5 South West Motorway : 2025-12-30</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547141</td>
<td>283677-C-M5 South West Motorway : 2025-12-30</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547142</td>
<td>283677-C-M5 South West Motorway : 2025-12-30</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547143</td>
<td>283677-C-M5 South West Motorway : 2025-12-30</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547144</td>
<td>283677-C-WestConnex : 2025-12-31 06:42:49</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547145</td>
<td>283677-C-WestConnex : 2025-12-31 17:21:48</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547146</td>
<td>283677-C-M5 South West Motorway : 2025-12-31</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547147</td>
<td>283677-C-M5 South West Motorway : 2025-12-31</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547148</td>
<td>283677-C-WestConnex:2026-01-03 06:08:05</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547149</td>
<td>283677-C-WestConnex:2026-01-03 07:06:50</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547150</td>
<td>283677-C-M5 South West Motorway:2026-01-03 06:12:41</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547151</td>
<td>283677-C-M5 South West Motorway:2026-01-03 07:04:26</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547152</td>
<td>283677-C-WestConnex:2026-01-04 07:09:15</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547153</td>
<td>283677-C-WestConnex:2026-01-04 08:03:02</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547154</td>
<td>283677-C-WestConnex:2026-01-04 17:02:37</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547155</td>
<td>283677-C-M5 South West Motorway:2026-01-04 07:13:51</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547156</td>
<td>283677-C-M5 South West Motorway:2026-01-04 08:00:40</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547157</td>
<td>283677-C-M5 South West Motorway:2026-01-04 17:00:06</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547158</td>
<td>283677-C-WestConnex:2026-01-04 11:43:34</td>
<td>6.14</td>
<td>0.61</td>
<td>6.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547159</td>
<td>283677-C-WestLink M7:2026-01-05 16:36:08</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547160</td>
<td>283677-C-Hills M2:2026-01-05 16:38:48</td>
<td>3.34</td>
<td>0.33</td>
<td>3.67</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547161</td>
<td>283677-C-WestConnex:2026-01-05 08:01:15</td>
<td>5.68</td>
<td>0.57</td>
<td>6.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547162</td>
<td>283677-C-WestConnex:2026-01-05 16:49:58</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547163</td>
<td>283677-C-WestConnex:2026-01-05 08:17:27</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547164</td>
<td>283677-C-WestConnex:2026-01-06 18:10:17</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547165</td>
<td>283677-C-M5 South West Motorway:2026-01-06 18:03:33</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547166</td>
<td>283677-C-WestConnex:2026-01-06 07:30:56</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547167</td>
<td>283677-C-WestLink M7:2026-01-06 17:31:58</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547168</td>
<td>283677-C-WestConnex:2026-01-07 07:26:15</td>
<td>3.20</td>
<td>0.32</td>
<td>3.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547169</td>
<td>283677-C-WestConnex:2026-01-07 06:40:34</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547170</td>
<td>283677-C-WestConnex:2026-01-07 18:24:47</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547171</td>
<td>283677-C-M5 South West Motorway:2026-01-07 06:45:12</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 73 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th rowspan="2"></th>
<th></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547172</td>
<td>283677-C-M5 South West Motorway:2026-01-07 17:33:15</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547173</td>
<td>283677-C-M5 South West Motorway:2026-01-07 18:22:15</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547174</td>
<td>283677-C-WestLink M7:2026-01-07 17:02:03</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547175</td>
<td>283677-C-Hills M2:2026-01-08 18:02:33</td>
<td>3.34</td>
<td>0.33</td>
<td>3.67</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547176</td>
<td>283677-C-WestConnex:2026-01-08 07:32:26</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547177</td>
<td>283677-C-M5 South West Motorway:2026-01-08 07:41:58</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547178</td>
<td>283677-C-WestConnex:2026-01-08 18:14:34</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547179</td>
<td>283677-C-WestLink M7:2026-01-08 07:48:11</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547180</td>
<td>283677-C-WestConnex:2026-01-09 06:37:01</td>
<td>5.68</td>
<td>0.57</td>
<td>6.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547181</td>
<td>283677-C-WestConnex:2026-01-09 08:44:45</td>
<td>5.68</td>
<td>0.57</td>
<td>6.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547182</td>
<td>283677-C-WestConnex:2026-01-10 12:49:20</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547183</td>
<td>283677-C-WestConnex:2026-01-10 17:14:28</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547184</td>
<td>283677-C-M5 South West Motorway:2026-01-10 12:54:07</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547185</td>
<td>283677-C-M5 South West Motorway:2026-01-10 17:11:59</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547186</td>
<td>283677-C-WestConnex:2026-01-10 23:56:11</td>
<td>6.14</td>
<td>0.61</td>
<td>6.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547187</td>
<td>283677-C-WestConnex:2026-01-10 19:16:03</td>
<td>9.81</td>
<td>0.98</td>
<td>10.79</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547188</td>
<td>283677-C-WestConnex:2026-01-11 23:50:59</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547189</td>
<td>283677-C-Hills M2:2026-01-12 18:16:52</td>
<td>3.34</td>
<td>0.33</td>
<td>3.67</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547190</td>
<td>283677-C-WestConnex:2026-01-12 07:48:55</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547191</td>
<td>283677-C-M5 South West Motorway:2026-01-12 07:57:46</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547192</td>
<td>283677-C-WestConnex:2026-01-12 18:28:36</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547193</td>
<td>283677-C-WestLink M7:2026-01-12 08:03:55</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547194</td>
<td>283677-C-WestLink M7:2026-01-13 18:16:45</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547195</td>
<td>283677-C-Hills M2:2026-01-13 18:19:07</td>
<td>3.34</td>
<td>0.33</td>
<td>3.67</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547196</td>
<td>283677-C-WestConnex:2026-01-13 08:07:57</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547197</td>
<td>283677-C-M5 South West Motorway:2026-01-13 08:17:00</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547198</td>
<td>283677-C-WestConnex:2026-01-13 18:30:26</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547199</td>
<td>283677-C-WestLink M7:2026-01-13 08:23:14</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547200</td>
<td>283677-C-WestConnex:2026-01-14 07:29:15</td>
<td>3.20</td>
<td>0.32</td>
<td>3.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547201</td>
<td>283677-C-WestConnex:2026-01-14 06:40:28</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547202</td>
<td>283677-C-WestConnex:2026-01-14 18:10:48</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547203</td>
<td>283677-C-M5 South West Motorway:2026-01-14 06:44:59</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547204</td>
<td>283677-C-M5 South West Motorway:2026-01-14 17:19:31</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 74 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th></th>
<th></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547205</td>
<td>283677-C-M5 South West Motorway:2026-01-14 18:08:15</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547206</td>
<td>283677-C-WestLink M7:2026-01-14 16:45:47</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547207</td>
<td>283677-C-WestLink M7:2026-01-15 17:46:30</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547208</td>
<td>283677-C-Hills M2:2026-01-15 17:49:03</td>
<td>3.34</td>
<td>0.33</td>
<td>3.67</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547209</td>
<td>283677-C-WestConnex:2026-01-15 06:58:27</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547210</td>
<td>283677-C-M5 South West Motorway:2026-01-15 07:07:25</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547211</td>
<td>283677-C-WestConnex:2026-01-15 18:00:19</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DG89XA</td>
<td>NISSAN D23 MY23 NAVARA ST</td>
<td>Adalberto Da Costa</td>
<td>4843547212</td>
<td>283677-C-WestLink M7:2026-01-15 07:13:39</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total for Cost Centre: Supervisor</td>
<td>3,153.77</td>
<td>315.34</td>
<td>3,469.11</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">Cost Centre: Thermal</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545301</td>
<td>256887-C-EastLink : 2025-12-13 18:05:18</td>
<td>2.25</td>
<td>0.23</td>
<td>2.48</td>
</tr>
<tr>
<td colspan="2">QLD 090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545302</td>
<td>256887-C-EastLink : 2025-12-13 19:52:30</td>
<td>11.30</td>
<td>1.13</td>
<td>12.43</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545303</td>
<td>256887-C-EastLink : 2025-12-15 07:26:04</td>
<td>7.44</td>
<td>0.74</td>
<td>8.18</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545304</td>
<td>256887-C-CityLink : 2025-12-16 18:10:34</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545305</td>
<td>256887-C-CityLink : 2025-12-16 07:02:54</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545306</td>
<td>256887-C-CityLink : 2025-12-17 07:05:34</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545307</td>
<td>256887-C-CityLink : 2025-12-17 14:35:04</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545308</td>
<td>256887-C-EastLink : 2025-12-18 14:26:43</td>
<td>5.19</td>
<td>0.52</td>
<td>5.71</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545309</td>
<td>256887-C-CityLink : 2025-12-18 13:48:54</td>
<td>10.70</td>
<td>1.07</td>
<td>11.77</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545310</td>
<td>256887-C-CityLink : 2025-12-18 07:12:32</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545311</td>
<td>256887-C-CityLink : 2025-12-19 12:04:40</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545312</td>
<td>256887-C-CityLink : 2025-12-19 14:15:35</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545313</td>
<td>256887-C-EastLink : 2025-12-24 11:10:28</td>
<td>5.19</td>
<td>0.52</td>
<td>5.71</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545314</td>
<td>256887-C-CityLink : 2025-12-24 08:57:04</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545315</td>
<td>256887-C-CityLink:2026-01-12 07:52:11</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545316</td>
<td>256887-C-CityLink:2026-01-12 14:20:18</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545317</td>
<td>256887-C-CityLink:2026-01-13 07:10:39</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545318</td>
<td>256887-C-CityLink:2026-01-13 14:18:54</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545319</td>
<td>256887-C-CityLink:2026-01-14 07:26:56</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545320</td>
<td>256887-C-CityLink:2026-01-14 13:13:23</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>QLD</td>
<td>090AN3</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Hayden Steen</td>
<td>4843545321</td>
<td>256887-C-CityLink:2026-01-15 15:06:36</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548401</td>
<td>296317-C-Video Matching Fee : 2025-12-11 13:31:38</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548402</td>
<td>296317-C-Video Matching Fee : 2025-12-11 06:13:25</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 75 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548403</td>
<td>296317-C-Video Matching Fee : 2025-12-11 12:59:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548404</td>
<td>296317-C-EastLink : 2025-12-11 06:13:25</td>
<td>5.19</td>
<td>0.52</td>
<td>5.71</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548405</td>
<td>296317-C-EastLink : 2025-12-11 13:31:38</td>
<td>5.19</td>
<td>0.52</td>
<td>5.71</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548406</td>
<td>296317-C-CityLink : 2025-12-11 12:59:32</td>
<td>10.70</td>
<td>1.07</td>
<td>11.77</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548407</td>
<td>296317-C-Video Matching Fee : 2025-12-12 11:18:58</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548408</td>
<td>296317-C-Video Matching Fee : 2025-12-12 05:43:07</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548409</td>
<td>296317-C-EastLink : 2025-12-12 11:18:58</td>
<td>5.19</td>
<td>0.52</td>
<td>5.71</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548410</td>
<td>296317-C-EastLink : 2025-12-12 05:43:07</td>
<td>5.19</td>
<td>0.52</td>
<td>5.71</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548411</td>
<td>296317-C-Video Matching Fee : 2025-12-17 14:51:31</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548412</td>
<td>296317-C-Video Matching Fee : 2025-12-17 07:57:59</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548413</td>
<td>296317-C-Video Matching Fee : 2025-12-17 08:46:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548414</td>
<td>296317-C-EastLink : 2025-12-17 14:51:31</td>
<td>5.19</td>
<td>0.52</td>
<td>5.71</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548415</td>
<td>296317-C-EastLink : 2025-12-17 07:57:59</td>
<td>5.19</td>
<td>0.52</td>
<td>5.71</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548416</td>
<td>296317-C-CityLink : 2025-12-17 08:46:16</td>
<td>10.70</td>
<td>1.07</td>
<td>11.77</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548417</td>
<td>296317-C-Video Matching Fee : 2025-12-19 14:24:57</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548418</td>
<td>296317-C-Video Matching Fee : 2025-12-19 13:52:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548419</td>
<td>296317-C-Video Matching Fee : 2025-12-19 11:58:03</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548420</td>
<td>296317-C-EastLink : 2025-12-19 14:24:57</td>
<td>5.19</td>
<td>0.52</td>
<td>5.71</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548421</td>
<td>296317-C-CityLink : 2025-12-19 13:52:31</td>
<td>10.70</td>
<td>1.07</td>
<td>11.77</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZL7ZM</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Daniel Bebarfald</td>
<td>4843548422</td>
<td>296317-C-CityLink : 2025-12-19 11:58:03</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZM1TU</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Benjamin Coleman</td>
<td>4843549801</td>
<td>302292-C-Video Matching Fee:2026-01-02 12:50:05</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZM1TU</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Benjamin Coleman</td>
<td>4843549802</td>
<td>302292-C-CityLink-West Gate Tunnel:2026-01-02 12:50:05</td>
<td>10.81</td>
<td>1.08</td>
<td>11.89</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZM1TU</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Benjamin Coleman</td>
<td>4843549803</td>
<td>302292-C-Video Matching Fee:2026-01-03 09:51:07</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZM1TU</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Benjamin Coleman</td>
<td>4843549804</td>
<td>302292-C-CityLink:2026-01-03 09:51:07</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZM1TU</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Benjamin Coleman</td>
<td>4843549805</td>
<td>302292-C-Video Matching Fee:2026-01-04 14:29:05</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZM1TU</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Benjamin Coleman</td>
<td>4843549806</td>
<td>302292-C-Video Matching Fee:2026-01-04 20:31:25</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZM1TU</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Benjamin Coleman</td>
<td>4843549807</td>
<td>302292-C-CityLink:2026-01-04 14:29:05</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZM1TU</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Benjamin Coleman</td>
<td>4843549808</td>
<td>302292-C-CityLink:2026-01-04 20:31:25</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZM1TU</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Benjamin Coleman</td>
<td>4843549809</td>
<td>302292-C-Video Matching Fee:2026-01-06 17:39:50</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZM1TU</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Benjamin Coleman</td>
<td>4843549810</td>
<td>302292-C-CityLink:2026-01-06 17:39:50</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZM1TU</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Benjamin Coleman</td>
<td>4843549811</td>
<td>302292-C-Video Matching Fee:2026-01-07 07:40:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZM1TU</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Benjamin Coleman</td>
<td>4843549812</td>
<td>302292-C-CityLink-West Gate Tunnel:2026-01-07 07:40:31</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZM1TU</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Benjamin Coleman</td>
<td>4843549813</td>
<td>302292-C-Video Matching Fee:2026-01-08 18:26:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 76 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No. AU1166479</th>
<th>Invoice Date 31 January 2026</th>
<th>Invoice No. AIN00014651</th>
<th></th>
<th></th>
<th colspan="3">P</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZM1TU</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Benjamin Coleman</td>
<td>4843549814</td>
<td>302292-C-CityLink-West Gate Tunnel:2026-01-08 18:26:34</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZM1TU</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Benjamin Coleman</td>
<td>4843549815</td>
<td>302292-C-Video Matching Fee:2026-01-09 14:37:48</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>1ZM1TU</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Benjamin Coleman</td>
<td>4843549816</td>
<td>302292-C-CityLink-West Gate Tunnel:2026-01-09 14:37:48</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>QLD</td>
<td>265YOA</td>
<td>D23 S2 RX CAB CHASSIS DUA</td>
<td>Shaun Bishop</td>
<td>4843545101</td>
<td>235104-C-CityLink : 2025-12-17 05:42:24</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>QLD</td>
<td>265YOA</td>
<td>D23 S2 RX CAB CHASSIS DUA</td>
<td>Shaun Bishop</td>
<td>4843545102</td>
<td>235104-C-CityLink : 2025-12-18 14:32:10</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>QLD</td>
<td>265YOA</td>
<td>D23 S2 RX CAB CHASSIS DUA</td>
<td>Shaun Bishop</td>
<td>4843545103</td>
<td>235104-C-CityLink : 2025-12-19 06:58:03</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>QLD</td>
<td>265YOA</td>
<td>D23 S2 RX CAB CHASSIS DUA</td>
<td>Shaun Bishop</td>
<td>4843545104</td>
<td>235104-C-CityLink : 2025-12-19 14:00:07</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>QLD</td>
<td>265YOA</td>
<td>D23 S2 RX CAB CHASSIS DUA</td>
<td>Shaun Bishop</td>
<td>4843545105</td>
<td>235104-C-CityLink:2026-01-02 08:01:42</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>QLD</td>
<td>265YOA</td>
<td>D23 S2 RX CAB CHASSIS DUA</td>
<td>Shaun Bishop</td>
<td>4843545106</td>
<td>235104-C-CityLink:2026-01-02 12:17:45</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>QLD</td>
<td>265YOA</td>
<td>D23 S2 RX CAB CHASSIS DUA</td>
<td>Shaun Bishop</td>
<td>4843545107</td>
<td>235104-C-CityLink:2026-01-08 14:08:39</td>
<td>9.60</td>
<td>0.96</td>
<td>10.56</td>
</tr>
<tr>
<td>QLD</td>
<td>265YOA</td>
<td>D23 S2 RX CAB CHASSIS DUA</td>
<td>Shaun Bishop</td>
<td>4843545108</td>
<td>235104-C-CityLink:2026-01-08 07:13:36</td>
<td>9.60</td>
<td>0.96</td>
<td>10.56</td>
</tr>
<tr>
<td>QLD</td>
<td>265YOA</td>
<td>D23 S2 RX CAB CHASSIS DUA</td>
<td>Shaun Bishop</td>
<td>4843545109</td>
<td>235104-C-CityLink:2026-01-09 12:31:41</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>QLD</td>
<td>265YOA</td>
<td>D23 S2 RX CAB CHASSIS DUA</td>
<td>Shaun Bishop</td>
<td>4843545110</td>
<td>235104-C-CityLink:2026-01-09 10:18:48</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>QLD</td>
<td>265YOA</td>
<td>D23 S2 RX CAB CHASSIS DUA</td>
<td>Shaun Bishop</td>
<td>4843545111</td>
<td>235104-C-CityLink:2026-01-10 07:55:05</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>QLD</td>
<td>265YOA</td>
<td>D23 S2 RX CAB CHASSIS DUA</td>
<td>Shaun Bishop</td>
<td>4843545112</td>
<td>235104-C-CityLink:2026-01-10 14:14:43</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>QLD</td>
<td>265YOA</td>
<td>D23 S2 RX CAB CHASSIS DUA</td>
<td>Shaun Bishop</td>
<td>4843545113</td>
<td>235104-C-CityLink:2026-01-15 15:04:21</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551601</td>
<td>309351-C-CityLink : 2025-12-13 21:07:55</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551602</td>
<td>309351-C-CityLink : 2025-12-14 09:38:51</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551603</td>
<td>309351-C-CityLink : 2025-12-17 17:30:46</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551604</td>
<td>309351-C-CityLink : 2025-12-17 22:01:23</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551605</td>
<td>309351-C-CityLink : 2025-12-17 22:56:07</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551606</td>
<td>309351-C-West Gate Tunnel : 2025-12-17 12:40:43</td>
<td>5.95</td>
<td>0.60</td>
<td>6.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551607</td>
<td>309351-C-CityLink-West Gate Tunnel : 2025-12-18</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551608</td>
<td>309351-C-CityLink : 2025-12-18 10:36:53</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551609</td>
<td>309351-C-CityLink : 2025-12-19 11:06:45</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551610</td>
<td>309351-C-CityLink : 2025-12-21 19:41:10</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551611</td>
<td>309351-C-West Gate Tunnel : 2025-12-21 19:44:37</td>
<td>5.95</td>
<td>0.60</td>
<td>6.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551612</td>
<td>309351-C-CityLink : 2025-12-21 17:21:12</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551613</td>
<td>309351-C-CityLink : 2025-12-21 19:27:56</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551614</td>
<td>309351-C-CityLink : 2025-12-26 15:55:52</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551615</td>
<td>309351-C-CityLink : 2025-12-26 21:21:13</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551616</td>
<td>309351-C-CityLink : 2025-12-28 16:07:44</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551617</td>
<td>309351-C-Video Matching Fee : 2025-12-29 01:44:06</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 77 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th rowspan="2">Invoice Date 31 January 2026</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551618</td>
<td>309351-C-EastLink : 2025-12-29 01:44:06</td>
<td>8.67</td>
<td>0.87</td>
<td>9.54</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551619</td>
<td>309351-C-CityLink : 2025-12-29 02:08:20</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551620</td>
<td>309351-C-CityLink : 2025-12-30 13:06:57</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551621</td>
<td>309351-C-CityLink : 2025-12-30 16:40:21</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551622</td>
<td>309351-C-CityLink : 2025-12-31 10:35:10</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551623</td>
<td>309351-C-CityLink : 2025-12-31 11:22:53</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551624</td>
<td>309351-C-CityLink : 2025-12-31 19:53:05</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551625</td>
<td>309351-C-CityLink:2026-01-01 01:17:34</td>
<td>9.60</td>
<td>0.96</td>
<td>10.56</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551626</td>
<td>309351-C-Video Matching Fee:2026-01-02 22:46:46</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551627</td>
<td>309351-C-EastLink:2026-01-02 22:46:46</td>
<td>4.89</td>
<td>0.49</td>
<td>5.38</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551628</td>
<td>309351-C-CityLink:2026-01-02 12:39:13</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551629</td>
<td>309351-C-CityLink:2026-01-02 23:07:43</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551630</td>
<td>309351-C-CityLink:2026-01-04 14:51:12</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551631</td>
<td>309351-C-CityLink:2026-01-04 19:14:39</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551632</td>
<td>309351-C-CityLink:2026-01-04 16:10:43</td>
<td>9.60</td>
<td>0.96</td>
<td>10.56</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551633</td>
<td>309351-C-CityLink:2026-01-05 00:44:52</td>
<td>9.60</td>
<td>0.96</td>
<td>10.56</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551634</td>
<td>309351-C-Video Matching Fee:2026-01-07 16:39:34</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551635</td>
<td>309351-C-EastLink:2026-01-07 16:39:34</td>
<td>8.67</td>
<td>0.87</td>
<td>9.54</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551636</td>
<td>309351-C-CityLink:2026-01-07 16:11:15</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551637</td>
<td>309351-C-Video Matching Fee:2026-01-09 05:17:57</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551638</td>
<td>309351-C-EastLink:2026-01-09 05:17:57</td>
<td>8.67</td>
<td>0.87</td>
<td>9.54</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551639</td>
<td>309351-C-CityLink:2026-01-09 10:28:37</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551640</td>
<td>309351-C-CityLink:2026-01-09 12:51:52</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551641</td>
<td>309351-C-CityLink:2026-01-09 05:41:55</td>
<td>18.01</td>
<td>1.80</td>
<td>19.81</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551642</td>
<td>309351-C-CityLink:2026-01-10 17:35:26</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LT</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ray Jeffrey</td>
<td>4843551643</td>
<td>309351-C-CityLink:2026-01-10 19:34:43</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551701</td>
<td>309354-C-Video Matching Fee : 2025-12-15 15:17:04</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551702</td>
<td>309354-C-Video Matching Fee : 2025-12-15 07:58:50</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551703</td>
<td>309354-C-CityLink : 2025-12-15 15:17:04</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551704</td>
<td>309354-C-CityLink : 2025-12-15 07:58:50</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551705</td>
<td>309354-C-Video Matching Fee : 2025-12-16 15:10:08</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551706</td>
<td>309354-C-Video Matching Fee : 2025-12-16 07:52:25</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551707</td>
<td>309354-C-CityLink : 2025-12-16 15:10:08</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 78 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551708</td>
<td>309354-C-CityLink : 2025-12-16 07:52:25</td>
<td>4.75</td>
<td>0.48</td>
<td>5.23</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551709</td>
<td>309354-C-Video Matching Fee : 2025-12-17 07:49:50</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551710</td>
<td>309354-C-CityLink : 2025-12-17 07:49:50</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551711</td>
<td>309354-C-Video Matching Fee : 2025-12-18 11:01:04</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551712</td>
<td>309354-C-West Gate Tunnel : 2025-12-18 11:01:04</td>
<td>5.95</td>
<td>0.60</td>
<td>6.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551713</td>
<td>309354-C-Video Matching Fee:2026-01-05 07:54:11</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551714</td>
<td>309354-C-Video Matching Fee:2026-01-05 13:46:09</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551715</td>
<td>309354-C-CityLink:2026-01-05 07:54:11</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551716</td>
<td>309354-C-CityLink:2026-01-05 13:46:09</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551717</td>
<td>309354-C-Video Matching Fee:2026-01-06 07:52:47</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551718</td>
<td>309354-C-Video Matching Fee:2026-01-06 14:39:46</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551719</td>
<td>309354-C-CityLink:2026-01-06 14:39:46</td>
<td>9.60</td>
<td>0.96</td>
<td>10.56</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551720</td>
<td>309354-C-CityLink:2026-01-06 07:52:47</td>
<td>9.60</td>
<td>0.96</td>
<td>10.56</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551721</td>
<td>309354-C-Video Matching Fee:2026-01-07 07:54:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551722</td>
<td>309354-C-Video Matching Fee:2026-01-07 13:58:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551723</td>
<td>309354-C-CityLink:2026-01-07 13:58:16</td>
<td>10.80</td>
<td>1.08</td>
<td>11.88</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551724</td>
<td>309354-C-CityLink:2026-01-07 07:54:20</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551725</td>
<td>309354-C-Video Matching Fee:2026-01-09 10:02:48</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551726</td>
<td>309354-C-Video Matching Fee:2026-01-09 13:44:15</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551727</td>
<td>309354-C-CityLink:2026-01-09 10:02:48</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>2AY3LU</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Tejinder Thethi</td>
<td>4843551728</td>
<td>309354-C-CityLink:2026-01-09 13:44:15</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>QLD</td>
<td>418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551801</td>
<td>309361-C-Video Matching Fee : 2025-12-15 15:47:38</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551802</td>
<td>309361-C-Toowoomba Second Range Crossing :</td>
<td>6.49</td>
<td>0.65</td>
<td>7.14</td>
</tr>
<tr>
<td>QLD</td>
<td>418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551803</td>
<td>309361-C-Video Matching Fee : 2025-12-16 15:44:56</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551804</td>
<td>309361-C-Video Matching Fee : 2025-12-16 10:36:09</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551805</td>
<td>309361-C-Legacy Way : 2025-12-16 10:36:09</td>
<td>9.55</td>
<td>0.96</td>
<td>10.51</td>
</tr>
<tr>
<td>QLD</td>
<td>418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551806</td>
<td>309361-C-Legacy Way : 2025-12-16 15:44:56</td>
<td>9.55</td>
<td>0.96</td>
<td>10.51</td>
</tr>
<tr>
<td>QLD</td>
<td>418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551807</td>
<td>309361-C-Video Matching Fee : 2025-12-17 15:11:01</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551808</td>
<td>309361-C-Go Between Bridge : 2025-12-17 15:11:01</td>
<td>5.53</td>
<td>0.55</td>
<td>6.08</td>
</tr>
<tr>
<td>QLD</td>
<td>418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551809</td>
<td>309361-C-Video Matching Fee : 2025-12-18 10:38:55</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551810</td>
<td>309361-C-Video Matching Fee : 2025-12-18 10:45:55</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551811</td>
<td>309361-C-Video Matching Fee : 2025-12-18 12:07:11</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
<tr>
<td>QLD</td>
<td>418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551812</td>
<td>309361-C-Video Matching Fee : 2025-12-18 12:42:13</td>
<td>0.56</td>
<td>0.06</td>
<td>0.62</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 79 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th rowspan="2">Customer No. AU1166479</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2">P</th>
</tr>
<tr>
<th>31 January 2026</th>
</tr>
<tr>
<td>State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net GST Total</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551813</td>
<td>309361-C-Go Between Bridge : 2025-12-18 12:07:11</td>
<td>5.53 0.55 6.08</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551814</td>
<td>309361-C-Go Between Bridge : 2025-12-18 12:42:13</td>
<td>5.53 0.55 6.08</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551815</td>
<td>309361-C-Clem7 : 2025-12-18 10:45:55</td>
<td>8.86 0.89 9.75</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551816</td>
<td>309361-C-Legacy Way : 2025-12-18 10:38:55</td>
<td>9.55 0.96 10.51</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551817</td>
<td>309361-C-Video Matching Fee : 2025-12-19 14:53:10</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551818</td>
<td>309361-C-Video Matching Fee : 2025-12-19 10:01:06</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551819</td>
<td>309361-C-Legacy Way : 2025-12-19 10:01:06</td>
<td>9.55 0.96 10.51</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551820</td>
<td>309361-C-Legacy Way : 2025-12-19 14:53:10</td>
<td>9.55 0.96 10.51</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551821</td>
<td>309361-C-Video Matching Fee : 2025-12-23 14:30:58</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551822</td>
<td>309361-C-Video Matching Fee : 2025-12-23 15:26:15</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551823</td>
<td>309361-C-Legacy Way : 2025-12-23 14:30:58</td>
<td>9.55 0.96 10.51</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551824</td>
<td>309361-C-Legacy Way : 2025-12-23 15:26:15</td>
<td>9.55 0.96 10.51</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551825</td>
<td>309361-C-Video Matching Fee : 2025-12-31 20:12:34</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551826</td>
<td>309361-C-Go Between Bridge : 2025-12-31 20:12:34</td>
<td>5.53 0.55 6.08</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551827</td>
<td>309361-C-Video Matching Fee:2026-01-06 13:50:59</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551828</td>
<td>309361-C-Video Matching Fee:2026-01-06 11:30:30</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551829</td>
<td>309361-C-Legacy Way:2026-01-06 11:30:30</td>
<td>9.55 0.96 10.51</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551830</td>
<td>309361-C-Legacy Way:2026-01-06 13:50:59</td>
<td>9.55 0.96 10.51</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551831</td>
<td>309361-C-Video Matching Fee:2026-01-13 06:53:41</td>
<td>0.56 0.06 0.62</td>
</tr>
<tr>
<td>QLD 418MQ5</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Paul Foley</td>
<td>4843551832</td>
<td>309361-C-Legacy Way:2026-01-13 06:53:41</td>
<td>9.55 0.96 10.51</td>
</tr>
<tr>
<td>NSW CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545001</td>
<td>230347-C-Video Matching Fee:2026-01-12 15:39:28</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545002</td>
<td>230347-C-Video Matching Fee:2026-01-12 11:28:19</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545003</td>
<td>230347-C-Video Matching Fee:2026-01-12 12:01:18</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545004</td>
<td>230347-C-WestLink M7:2026-01-12 12:01:18</td>
<td>7.25 0.73 7.98</td>
</tr>
<tr>
<td>NSW CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545005</td>
<td>230347-C-WestLink M7:2026-01-12 11:28:19</td>
<td>8.35 0.84 9.19</td>
</tr>
<tr>
<td>NSW CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545006</td>
<td>230347-C-Hills M2:2026-01-12 15:39:28</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545007</td>
<td>230347-C-Video Matching Fee:2026-01-13 07:47:12</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545008</td>
<td>230347-C-Video Matching Fee:2026-01-13 15:17:33</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545009</td>
<td>230347-C-Video Matching Fee:2026-01-13 07:55:57</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545010</td>
<td>230347-C-Video Matching Fee:2026-01-13 15:08:35</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545011</td>
<td>230347-C-WestLink M7:2026-01-13 07:55:57</td>
<td>0.80 0.08 0.88</td>
</tr>
<tr>
<td>NSW CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545012</td>
<td>230347-C-WestLink M7:2026-01-13 15:08:35</td>
<td>0.80 0.08 0.88</td>
</tr>
<tr>
<td>NSW CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545013</td>
<td>230347-C-Hills M2:2026-01-13 07:47:12</td>
<td>9.45 0.95 10.40</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 80 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td colspan="2">GST Total</td>
</tr>
<tr>
<td>NSW</td>
<td>CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545014</td>
<td>230347-C-Hills M2:2026-01-13 15:17:33</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545015</td>
<td>230347-C-Video Matching Fee:2026-01-14 07:35:52</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545016</td>
<td>230347-C-Video Matching Fee:2026-01-14 16:02:56</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545017</td>
<td>230347-C-Video Matching Fee:2026-01-14 09:32:55</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545018</td>
<td>230347-C-WestLink M7:2026-01-14 09:32:55</td>
<td>1.00</td>
<td>0.10</td>
<td>1.10</td>
</tr>
<tr>
<td>NSW</td>
<td>CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545019</td>
<td>230347-C-Hills M2:2026-01-14 07:35:52</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545020</td>
<td>230347-C-Hills M2:2026-01-14 16:02:56</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545021</td>
<td>230347-C-Video Matching Fee:2026-01-15 07:02:52</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545022</td>
<td>230347-C-Video Matching Fee:2026-01-15 15:51:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545023</td>
<td>230347-C-Hills M2:2026-01-15 07:02:52</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>CQ62LI</td>
<td>NISSAN D23 S3 NAVARA RX U</td>
<td>Ben Hamlat</td>
<td>4843545024</td>
<td>230347-C-Hills M2:2026-01-15 15:51:36</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546001</td>
<td>260132-C-WestConnex : 2025-12-16 15:44:21</td>
<td>2.66</td>
<td>0.27</td>
<td>2.93</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546002</td>
<td>260132-C-M5 South West Motorway : 2025-12-17</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546003</td>
<td>260132-C-WestLink M7 : 2025-12-17 15:26:10</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546004</td>
<td>260132-C-Hills M2 : 2025-12-17 15:11:44</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546005</td>
<td>260132-C-WestConnex : 2025-12-17 07:04:24</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546006</td>
<td>260132-C-WestConnex : 2025-12-18 11:20:25</td>
<td>2.59</td>
<td>0.26</td>
<td>2.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546007</td>
<td>260132-C-WestConnex : 2025-12-18 07:55:30</td>
<td>4.88</td>
<td>0.49</td>
<td>5.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546008</td>
<td>260132-C-WestConnex : 2025-12-18 11:25:20</td>
<td>5.90</td>
<td>0.59</td>
<td>6.49</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546009</td>
<td>260132-C-WestLink M7 : 2025-12-18 11:40:52</td>
<td>7.62</td>
<td>0.76</td>
<td>8.38</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546010</td>
<td>260132-C-WestLink M7 : 2025-12-18 14:23:28</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546011</td>
<td>260132-C-WestLink M7 : 2025-12-19 14:36:30</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546012</td>
<td>260132-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-22</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546013</td>
<td>260132-C-Lane Cove Tunnel : 2025-12-22 10:51:53</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546014</td>
<td>260132-C-M5 South West Motorway : 2025-12-22</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546015</td>
<td>260132-C-Hills M2 : 2025-12-22 10:48:32</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546016</td>
<td>260132-C-WestConnex : 2025-12-22 15:16:59</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546017</td>
<td>260132-C-WestLink M7 : 2025-12-23 06:26:47</td>
<td>1.45</td>
<td>0.15</td>
<td>1.60</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546018</td>
<td>260132-C-WestLink M7 : 2025-12-23 16:34:25</td>
<td>1.45</td>
<td>0.15</td>
<td>1.60</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546019</td>
<td>260132-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-23</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546020</td>
<td>260132-C-M5 South West Motorway : 2025-12-23</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546021</td>
<td>260132-C-M5 South West Motorway : 2025-12-23</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546022</td>
<td>260132-C-WestConnex : 2025-12-23 06:39:35</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 81 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546023</td>
<td>260132-C-WestConnex : 2025-12-23 16:14:01</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546024</td>
<td>260132-C-Lane Cove Tunnel : 2025-12-24 07:25:52</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546025</td>
<td>260132-C-Lane Cove Tunnel : 2025-12-24 12:26:34</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546026</td>
<td>260132-C-WestLink M7 : 2025-12-24 12:39:49</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546027</td>
<td>260132-C-WestLink M7 : 2025-12-24 06:51:28</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546028</td>
<td>260132-C-Hills M2 : 2025-12-24 07:22:33</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546029</td>
<td>260132-C-Hills M2 : 2025-12-24 12:30:05</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546030</td>
<td>260132-C-Lane Cove Tunnel : 2025-12-25 12:54:50</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546031</td>
<td>260132-C-Lane Cove Tunnel : 2025-12-25 11:48:47</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546032</td>
<td>260132-C-WestLink M7 : 2025-12-25 11:10:31</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546033</td>
<td>260132-C-WestLink M7 : 2025-12-25 13:07:45</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546034</td>
<td>260132-C-Hills M2 : 2025-12-25 11:45:23</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546035</td>
<td>260132-C-Hills M2 : 2025-12-25 12:58:16</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546036</td>
<td>260132-C-Lane Cove Tunnel : 2025-12-26 23:34:21</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546037</td>
<td>260132-C-WestLink M7 : 2025-12-26 22:57:01</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546038</td>
<td>260132-C-Hills M2 : 2025-12-26 23:30:53</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546039</td>
<td>260132-C-Lane Cove Tunnel : 2025-12-27 00:38:53</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546040</td>
<td>260132-C-WestLink M7 : 2025-12-27 00:52:00</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546041</td>
<td>260132-C-Hills M2 : 2025-12-27 00:42:16</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546042</td>
<td>260132-C-Lane Cove Tunnel : 2025-12-29 06:52:27</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546043</td>
<td>260132-C-Lane Cove Tunnel : 2025-12-29 14:26:50</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546044</td>
<td>260132-C-WestConnex : 2025-12-29 23:43:42</td>
<td>4.88</td>
<td>0.49</td>
<td>5.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546045</td>
<td>260132-C-WestLink M7 : 2025-12-29 06:18:49</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546046</td>
<td>260132-C-WestLink M7 : 2025-12-29 14:39:42</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546047</td>
<td>260132-C-Hills M2 : 2025-12-29 06:49:15</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546048</td>
<td>260132-C-Hills M2 : 2025-12-29 14:30:15</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546049</td>
<td>260132-C-WestLink M7 : 2025-12-30 07:12:00</td>
<td>1.45</td>
<td>0.15</td>
<td>1.60</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546050</td>
<td>260132-C-WestConnex : 2025-12-30 01:00:02</td>
<td>4.88</td>
<td>0.49</td>
<td>5.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546051</td>
<td>260132-C-M5 South West Motorway : 2025-12-30</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546052</td>
<td>260132-C-WestConnex : 2025-12-30 07:24:30</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546053</td>
<td>260132-C-WestConnex : 2025-12-30 13:54:19</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546054</td>
<td>260132-C-WestLink M7 : 2025-12-31 15:09:33</td>
<td>1.45</td>
<td>0.15</td>
<td>1.60</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546055</td>
<td>260132-C-WestLink M7 : 2025-12-31 07:09:28</td>
<td>1.45</td>
<td>0.15</td>
<td>1.60</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 82 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546056</td>
<td>260132-C-M5 South West Motorway : 2025-12-31</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546057</td>
<td>260132-C-M5 South West Motorway : 2025-12-31</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546058</td>
<td>260132-C-WestConnex : 2025-12-31 07:22:08</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546059</td>
<td>260132-C-WestConnex : 2025-12-31 14:45:58</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546060</td>
<td>260132-C-WestConnex:2026-01-02 09:25:26</td>
<td>3.94</td>
<td>0.39</td>
<td>4.33</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546061</td>
<td>260132-C-WestConnex:2026-01-02 15:18:44</td>
<td>5.07</td>
<td>0.51</td>
<td>5.58</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546062</td>
<td>260132-C-WestLink M7:2026-01-05 07:21:06</td>
<td>6.12</td>
<td>0.61</td>
<td>6.73</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546063</td>
<td>260132-C-WestLink M7:2026-01-05 08:27:15</td>
<td>8.35</td>
<td>0.84</td>
<td>9.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546064</td>
<td>260132-C-WestLink M7:2026-01-05 11:21:20</td>
<td>8.35</td>
<td>0.84</td>
<td>9.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546065</td>
<td>260132-C-WestConnex:2026-01-06 15:29:25</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546066</td>
<td>260132-C-WestConnex:2026-01-07 10:39:57</td>
<td>4.34</td>
<td>0.43</td>
<td>4.77</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546067</td>
<td>260132-C-WestConnex:2026-01-07 13:34:20</td>
<td>4.34</td>
<td>0.43</td>
<td>4.77</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546068</td>
<td>260132-C-WestConnex:2026-01-08 15:44:18</td>
<td>5.07</td>
<td>0.51</td>
<td>5.58</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546069</td>
<td>260132-C-WestLink M7:2026-01-09 15:21:17</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546070</td>
<td>260132-C-WestLink M7:2026-01-09 07:18:20</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546071</td>
<td>260132-C-Hills M2:2026-01-09 07:50:30</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546072</td>
<td>260132-C-Hills M2:2026-01-09 15:11:08</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546073</td>
<td>260132-C-Lane Cove Tunnel:2026-01-10 06:49:44</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546074</td>
<td>260132-C-Lane Cove Tunnel:2026-01-10 08:56:55</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546075</td>
<td>260132-C-WestLink M7:2026-01-10 06:10:51</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546076</td>
<td>260132-C-WestLink M7:2026-01-10 09:09:41</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546077</td>
<td>260132-C-Hills M2:2026-01-10 06:46:21</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546078</td>
<td>260132-C-Hills M2:2026-01-10 09:00:13</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546079</td>
<td>260132-C-WestLink M7:2026-01-11 13:45:56</td>
<td>1.47</td>
<td>0.15</td>
<td>1.62</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546080</td>
<td>260132-C-M5 South West Motorway:2026-01-11 13:51:53</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546081</td>
<td>260132-C-M5 South West Motorway:2026-01-11 14:27:02</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546082</td>
<td>260132-C-WestConnex:2026-01-11 13:58:20</td>
<td>7.05</td>
<td>0.71</td>
<td>7.76</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546083</td>
<td>260132-C-WestConnex:2026-01-11 14:14:39</td>
<td>7.05</td>
<td>0.71</td>
<td>7.76</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546084</td>
<td>260132-C-WestLink M7:2026-01-12 07:27:55</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546085</td>
<td>260132-C-WestLink M7:2026-01-12 15:23:24</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546086</td>
<td>260132-C-Hills M2:2026-01-12 08:01:11</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546087</td>
<td>260132-C-Hills M2:2026-01-12 15:12:49</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546088</td>
<td>260132-C-WestLink M7:2026-01-13 15:26:36</td>
<td>1.47</td>
<td>0.15</td>
<td>1.62</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 83 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2" rowspan="2">Customer No. AU1166479</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546089</td>
<td>260132-C-WestLink M7:2026-01-13 10:58:11</td>
<td>7.25</td>
<td>0.73</td>
<td>7.98</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546090</td>
<td>260132-C-WestLink M7:2026-01-13 11:45:42</td>
<td>8.65</td>
<td>0.87</td>
<td>9.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546091</td>
<td>260132-C-WestLink M7:2026-01-13 08:22:03</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546092</td>
<td>260132-C-WestLink M7:2026-01-14 07:18:41</td>
<td>1.47</td>
<td>0.15</td>
<td>1.62</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546093</td>
<td>260132-C-Lane Cove Tunnel:2026-01-14 09:54:52</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546094</td>
<td>260132-C-M5 South West Motorway:2026-01-14 07:24:53</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546095</td>
<td>260132-C-WestLink M7:2026-01-14 15:42:46</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546096</td>
<td>260132-C-Hills M2:2026-01-14 09:58:47</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546097</td>
<td>260132-C-Hills M2:2026-01-14 12:06:24</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546098</td>
<td>260132-C-Hills M2:2026-01-14 15:32:08</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546099</td>
<td>260132-C-WestConnex:2026-01-14 07:31:34</td>
<td>11.40</td>
<td>1.14</td>
<td>12.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546100</td>
<td>260132-C-WestLink M7:2026-01-15 16:24:17</td>
<td>1.47</td>
<td>0.15</td>
<td>1.62</td>
</tr>
<tr>
<td>NSW</td>
<td>DB78KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sanjay Kumar</td>
<td>4843546101</td>
<td>260132-C-WestLink M7:2026-01-15 07:17:06</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546101</td>
<td>260133-C-WestLink M7 : 2025-12-16 14:49:46</td>
<td>0.63</td>
<td>0.06</td>
<td>0.69</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546102</td>
<td>260133-C-WestConnex : 2025-12-16 15:01:04</td>
<td>9.44</td>
<td>0.94</td>
<td>10.38</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546103</td>
<td>260133-C-WestConnex : 2025-12-16 06:26:09</td>
<td>9.44</td>
<td>0.94</td>
<td>10.38</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546104</td>
<td>260133-C-WestLink M7 : 2025-12-17 13:39:16</td>
<td>0.63</td>
<td>0.06</td>
<td>0.69</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546105</td>
<td>260133-C-WestLink M7 : 2025-12-17 10:21:20</td>
<td>8.24</td>
<td>0.82</td>
<td>9.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546106</td>
<td>260133-C-WestLink M7 : 2025-12-17 12:48:10</td>
<td>8.24</td>
<td>0.82</td>
<td>9.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546107</td>
<td>260133-C-WestConnex : 2025-12-17 13:50:21</td>
<td>9.44</td>
<td>0.94</td>
<td>10.38</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546108</td>
<td>260133-C-WestConnex : 2025-12-17 06:12:00</td>
<td>9.44</td>
<td>0.94</td>
<td>10.38</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546109</td>
<td>260133-C-WestLink M7 : 2025-12-18 13:59:35</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546110</td>
<td>260133-C-Hills M2 : 2025-12-18 14:01:52</td>
<td>3.30</td>
<td>0.33</td>
<td>3.63</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546111</td>
<td>260133-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-18</td>
<td>4.01</td>
<td>0.40</td>
<td>4.41</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546112</td>
<td>260133-C-WestLink M7 : 2025-12-18 09:35:37</td>
<td>8.24</td>
<td>0.82</td>
<td>9.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546113</td>
<td>260133-C-WestConnex : 2025-12-18 14:14:35</td>
<td>8.35</td>
<td>0.84</td>
<td>9.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546114</td>
<td>260133-C-WestConnex : 2025-12-18 05:54:06</td>
<td>9.44</td>
<td>0.94</td>
<td>10.38</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546115</td>
<td>260133-C-WestLink M7 : 2025-12-19 14:05:26</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546116</td>
<td>260133-C-Hills M2 : 2025-12-19 14:28:11</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546117</td>
<td>260133-C-WestConnex : 2025-12-19 05:57:17</td>
<td>9.44</td>
<td>0.94</td>
<td>10.38</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546118</td>
<td>260133-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-20</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546119</td>
<td>260133-C-Cross City Tunnel : 2025-12-21 11:47:59</td>
<td>6.52</td>
<td>0.65</td>
<td>7.17</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546120</td>
<td>260133-C-Cross City Tunnel : 2025-12-21 12:03:31</td>
<td>6.52</td>
<td>0.65</td>
<td>7.17</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 84 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546121</td>
<td>260133-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-25</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546122</td>
<td>260133-C-Cross City Tunnel:2026-01-01 15:04:24</td>
<td>6.61</td>
<td>0.66</td>
<td>7.27</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546123</td>
<td>260133-C-Eastern Distributor:2026-01-01 13:22:06</td>
<td>9.33</td>
<td>0.93</td>
<td>10.26</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546124</td>
<td>260133-C-WestLink M7:2026-01-05 15:36:03</td>
<td>0.64</td>
<td>0.06</td>
<td>0.70</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546125</td>
<td>260133-C-WestLink M7:2026-01-05 11:22:48</td>
<td>8.35</td>
<td>0.84</td>
<td>9.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546126</td>
<td>260133-C-WestConnex:2026-01-05 08:02:43</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546127</td>
<td>260133-C-WestConnex:2026-01-05 15:47:49</td>
<td>9.81</td>
<td>0.98</td>
<td>10.79</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546128</td>
<td>260133-C-WestLink M7:2026-01-06 15:54:12</td>
<td>0.64</td>
<td>0.06</td>
<td>0.70</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546129</td>
<td>260133-C-WestConnex:2026-01-06 16:19:35</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546130</td>
<td>260133-C-WestConnex:2026-01-06 06:47:34</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546131</td>
<td>260133-C-WestLink M7:2026-01-07 16:31:38</td>
<td>0.64</td>
<td>0.06</td>
<td>0.70</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546132</td>
<td>260133-C-WestLink M7:2026-01-07 16:21:49</td>
<td>1.69</td>
<td>0.17</td>
<td>1.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546133</td>
<td>260133-C-WestConnex:2026-01-07 07:19:32</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546134</td>
<td>260133-C-WestConnex:2026-01-07 16:54:27</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546135</td>
<td>260133-C-WestLink M7:2026-01-08 14:44:31</td>
<td>0.64</td>
<td>0.06</td>
<td>0.70</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546136</td>
<td>260133-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-08</td>
<td>4.01</td>
<td>0.40</td>
<td>4.41</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546137</td>
<td>260133-C-WestLink M7:2026-01-08 08:15:33</td>
<td>8.35</td>
<td>0.84</td>
<td>9.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546138</td>
<td>260133-C-WestConnex:2026-01-08 07:17:21</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546139</td>
<td>260133-C-Hills M2:2026-01-08 15:23:24</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546140</td>
<td>260133-C-Cross City Tunnel:2026-01-09 14:50:49</td>
<td>6.61</td>
<td>0.66</td>
<td>7.27</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546141</td>
<td>260133-C-Cross City Tunnel:2026-01-09 17:50:43</td>
<td>6.61</td>
<td>0.66</td>
<td>7.27</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546142</td>
<td>260133-C-WestConnex:2026-01-09 07:29:56</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546143</td>
<td>260133-C-WestConnex:2026-01-09 14:34:20</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546144</td>
<td>260133-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-10</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546145</td>
<td>260133-C-Cross City Tunnel:2026-01-10 15:01:30</td>
<td>6.61</td>
<td>0.66</td>
<td>7.27</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546146</td>
<td>260133-C-Cross City Tunnel:2026-01-11 13:34:55</td>
<td>6.61</td>
<td>0.66</td>
<td>7.27</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546147</td>
<td>260133-C-Cross City Tunnel:2026-01-11 13:54:34</td>
<td>6.61</td>
<td>0.66</td>
<td>7.27</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546148</td>
<td>260133-C-WestLink M7:2026-01-12 08:43:14</td>
<td>8.35</td>
<td>0.84</td>
<td>9.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546149</td>
<td>260133-C-WestConnex:2026-01-12 07:21:10</td>
<td>8.68</td>
<td>0.87</td>
<td>9.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546150</td>
<td>260133-C-North Connex:2026-01-12 16:23:13</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td colspan="2">NSW DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546151</td>
<td>260133-C-WestLink M7:2026-01-13 15:11:35</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td colspan="2">NSW DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546152</td>
<td>260133-C-WestLink M7:2026-01-13 07:57:05</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546153</td>
<td>260133-C-Hills M2:2026-01-13 15:17:43</td>
<td>4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 85 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th colspan="5" rowspan="2">P Invoice No. AIN00014651</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546154</td>
<td>260133-C-Hills M2:2026-01-13 07:51:27 4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546155</td>
<td>260133-C-North Connex:2026-01-13 07:51:16 9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546156</td>
<td>260133-C-North Connex:2026-01-13 15:17:54 9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546157</td>
<td>260133-C-WestLink M7:2026-01-14 07:51:54 0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546158</td>
<td>260133-C-WestLink M7:2026-01-14 15:56:13 0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546159</td>
<td>260133-C-Hills M2:2026-01-14 16:01:52 4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546160</td>
<td>260133-C-Hills M2:2026-01-14 07:46:30 4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546161</td>
<td>260133-C-North Connex:2026-01-14 07:46:19 9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546162</td>
<td>260133-C-North Connex:2026-01-14 16:02:02 9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546163</td>
<td>260133-C-WestLink M7:2026-01-15 07:22:05 0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546164</td>
<td>260133-C-WestLink M7:2026-01-15 15:51:06 0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546165</td>
<td>260133-C-Hills M2:2026-01-15 07:16:48 4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546166</td>
<td>260133-C-Hills M2:2026-01-15 15:56:36 4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546167</td>
<td>260133-C-NorthConnex:2026-01-15 07:16:38 9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB79KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Earl Walker</td>
<td>4843546168</td>
<td>260133-C-North Connex:2026-01-15 15:56:48 9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545901</td>
<td>260131-C-WestLink M7 : 2025-12-06 08:55:46 0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545902</td>
<td>260131-C-WestLink M7 : 2025-12-18 14:41:20 0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545903</td>
<td>260131-C-Hills M2 : 2025-12-18 14:47:05 4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545904</td>
<td>260131-C-North Connex : 2025-12-18 14:47:16 9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545905</td>
<td>260131-C-WestLink M7 : 2025-12-19 10:02:34 6.63</td>
<td>0.66</td>
<td>7.29</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545906</td>
<td>260131-C-WestLink M7 : 2025-12-19 15:48:53 7.25</td>
<td>0.73</td>
<td>7.98</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545907</td>
<td>260131-C-WestLink M7 : 2025-12-25 13:47:39 6.63</td>
<td>0.66</td>
<td>7.29</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545908</td>
<td>260131-C-WestLink M7 : 2025-12-25 15:53:39 6.63</td>
<td>0.66</td>
<td>7.29</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545909</td>
<td>260131-C-WestLink M7 : 2025-12-26 12:19:43 9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545910</td>
<td>260131-C-WestLink M7 : 2025-12-26 17:24:33 9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545911</td>
<td>260131-C-WestLink M7:2026-01-06 14:25:32 6.72</td>
<td>0.67</td>
<td>7.39</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545912</td>
<td>260131-C-WestLink M7:2026-01-06 08:26:00 7.72</td>
<td>0.77</td>
<td>8.49</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545913</td>
<td>260131-C-WestLink M7:2026-01-08 16:00:51 6.25</td>
<td>0.63</td>
<td>6.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545914</td>
<td>260131-C-WestLink M7:2026-01-08 13:54:31 6.72</td>
<td>0.67</td>
<td>7.39</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545915</td>
<td>260131-C-WestLink M7:2026-01-09 08:11:01 1.91</td>
<td>0.19</td>
<td>2.10</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545916</td>
<td>260131-C-WestLink M7:2026-01-09 11:26:16 6.25</td>
<td>0.63</td>
<td>6.88</td>
</tr>
<tr>
<td colspan="2">NSW DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545917</td>
<td>260131-C-WestLink M7:2026-01-10 18:36:40 6.25</td>
<td>0.63</td>
<td>6.88</td>
</tr>
<tr>
<td colspan="2">NSW DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545918</td>
<td>260131-C-WestLink M7:2026-01-10 16:51:52 6.72</td>
<td>0.67</td>
<td>7.39</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 86 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545919</td>
<td>260131-C-WestLink M7:2026-01-12 13:54:57</td>
<td>6.25</td>
<td>0.63</td>
<td>6.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545920</td>
<td>260131-C-WestLink M7:2026-01-13 15:14:34</td>
<td>7.35</td>
<td>0.74</td>
<td>8.09</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545921</td>
<td>260131-C-WestLink M7:2026-01-14 12:26:18</td>
<td>7.35</td>
<td>0.74</td>
<td>8.09</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545922</td>
<td>260131-C-M5 South West Motorway:2026-01-15 17:46:58</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545923</td>
<td>260131-C-M5 South West Motorway:2026-01-15 19:17:30</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545924</td>
<td>260131-C-WestLink M7:2026-01-15 15:34:52</td>
<td>6.25</td>
<td>0.63</td>
<td>6.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545925</td>
<td>260131-C-WestLink M7:2026-01-15 07:19:52</td>
<td>6.72</td>
<td>0.67</td>
<td>7.39</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545926</td>
<td>260131-C-WestLink M7:2026-01-15 17:14:29</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB80KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Ersin Husnu</td>
<td>4843545927</td>
<td>260131-C-WestLink M7:2026-01-15 19:23:49</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545801</td>
<td>260130-C-Eastern Distributor : 2025-12-16 11:47:35</td>
<td>9.24</td>
<td>0.92</td>
<td>10.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545802</td>
<td>260130-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-17</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545803</td>
<td>260130-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-17</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545804</td>
<td>260130-C-WestConnex : 2025-12-17 11:14:15</td>
<td>4.15</td>
<td>0.42</td>
<td>4.57</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545805</td>
<td>260130-C-WestConnex : 2025-12-17 12:00:53</td>
<td>4.15</td>
<td>0.42</td>
<td>4.57</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545806</td>
<td>260130-C-Eastern Distributor : 2025-12-17 07:27:40</td>
<td>9.24</td>
<td>0.92</td>
<td>10.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545807</td>
<td>260130-C-WestLink M7 : 2025-12-18 14:50:34</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545808</td>
<td>260130-C-WestLink M7 : 2025-12-18 09:45:33</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545809</td>
<td>260130-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-18</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545810</td>
<td>260130-C-Lane Cove Tunnel : 2025-12-18 15:04:17</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545811</td>
<td>260130-C-Eastern Distributor : 2025-12-18 07:13:23</td>
<td>9.24</td>
<td>0.92</td>
<td>10.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545812</td>
<td>260130-C-Hills M2 : 2025-12-18 15:00:49</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545813</td>
<td>260130-C-Hills M2 : 2025-12-18 09:35:36</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545814</td>
<td>260130-C-Cross City Tunnel : 2025-12-19 15:06:59</td>
<td>6.52</td>
<td>0.65</td>
<td>7.17</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545815</td>
<td>260130-C-Eastern Distributor : 2025-12-19 07:25:01</td>
<td>9.24</td>
<td>0.92</td>
<td>10.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545816</td>
<td>260130-C-M5 South West Motorway : 2025-12-28</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545817</td>
<td>260130-C-WestConnex : 2025-12-28 08:17:41</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545818</td>
<td>260130-C-M5 South West Motorway : 2025-12-30</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545819</td>
<td>260130-C-WestConnex : 2025-12-30 16:13:03</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545820</td>
<td>260130-C-WestConnex:2026-01-03 15:02:31</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545821</td>
<td>260130-C-WestConnex:2026-01-03 17:27:44</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545822</td>
<td>260130-C-WestLink M7:2026-01-05 11:40:56</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545823</td>
<td>260130-C-WestLink M7:2026-01-05 08:03:43</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545824</td>
<td>260130-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-05</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 87 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545825</td>
<td>260130-C-Lane Cove Tunnel:2026-01-05 07:49:33</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545826</td>
<td>260130-C-Lane Cove Tunnel:2026-01-05 11:56:21</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545827</td>
<td>260130-C-Cross City Tunnel:2026-01-05 15:48:58</td>
<td>6.61</td>
<td>0.66</td>
<td>7.27</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545828</td>
<td>260130-C-Eastern Distributor:2026-01-05 07:37:30</td>
<td>9.33</td>
<td>0.93</td>
<td>10.26</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545829</td>
<td>260130-C-Hills M2:2026-01-05 07:53:21</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545830</td>
<td>260130-C-Hills M2:2026-01-05 11:52:33</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545831</td>
<td>260130-C-Eastern Distributor:2026-01-07 10:28:41</td>
<td>9.33</td>
<td>0.93</td>
<td>10.26</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545832</td>
<td>260130-C-Cross City Tunnel:2026-01-08 07:40:41</td>
<td>6.61</td>
<td>0.66</td>
<td>7.27</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545833</td>
<td>260130-C-Cross City Tunnel:2026-01-08 16:08:01</td>
<td>6.61</td>
<td>0.66</td>
<td>7.27</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545834</td>
<td>260130-C-Eastern Distributor:2026-01-08 07:39:45</td>
<td>9.33</td>
<td>0.93</td>
<td>10.26</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545835</td>
<td>260130-C-Eastern Distributor:2026-01-09 11:09:18</td>
<td>9.33</td>
<td>0.93</td>
<td>10.26</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545836</td>
<td>260130-C-Eastern Distributor:2026-01-12 08:11:04</td>
<td>9.33</td>
<td>0.93</td>
<td>10.26</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545837</td>
<td>260130-C-Cross City Tunnel:2026-01-13 15:24:21</td>
<td>6.61</td>
<td>0.66</td>
<td>7.27</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545838</td>
<td>260130-C-WestLink M7:2026-01-15 07:49:42</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545839</td>
<td>260130-C-WestLink M7:2026-01-15 09:36:14</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545840</td>
<td>260130-C-Lane Cove Tunnel:2026-01-15 07:35:52</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545841</td>
<td>260130-C-Lane Cove Tunnel:2026-01-15 09:51:04</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545842</td>
<td>260130-C-Eastern Distributor:2026-01-15 07:23:56</td>
<td>9.33</td>
<td>0.93</td>
<td>10.26</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545843</td>
<td>260130-C-Hills M2:2026-01-15 07:39:38</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DB81KG</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Sean Baldwin</td>
<td>4843545844</td>
<td>260130-C-Hills M2:2026-01-15 09:47:04</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549001</td>
<td>296350-C-Video Matching Fee : 2025-12-15 16:59:11</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549002</td>
<td>296350-C-North Connex : 2025-12-15 16:59:11</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549003</td>
<td>296350-C-Video Matching Fee : 2025-12-16 07:08:35</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549004</td>
<td>296350-C-Video Matching Fee : 2025-12-16 07:22:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549005</td>
<td>296350-C-Video Matching Fee : 2025-12-16 14:44:14</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549006</td>
<td>296350-C-Video Matching Fee : 2025-12-16 15:01:43</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549007</td>
<td>296350-C-Video Matching Fee : 2025-12-16 15:27:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549008</td>
<td>296350-C-M5 South West Motorway : 2025-12-16</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549009</td>
<td>296350-C-M5 South West Motorway : 2025-12-16</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549010</td>
<td>296350-C-Cross City Tunnel : 2025-12-16 14:44:14</td>
<td>6.52</td>
<td>0.65</td>
<td>7.17</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549011</td>
<td>296350-C-WestConnex : 2025-12-16 15:01:43</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549012</td>
<td>296350-C-WestConnex : 2025-12-16 07:22:32</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549013</td>
<td>296350-C-Video Matching Fee : 2025-12-18 08:46:12</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 88 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th colspan="2"></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549014</td>
<td>296350-C-Video Matching Fee : 2025-12-18 16:25:15</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549015</td>
<td>296350-C-WestLink M7 : 2025-12-18 08:46:12</td>
<td>8.54</td>
<td>0.85</td>
<td>9.39</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549016</td>
<td>296350-C-WestLink M7 : 2025-12-18 16:25:15</td>
<td>8.54</td>
<td>0.85</td>
<td>9.39</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549017</td>
<td>296350-C-Video Matching Fee : 2025-12-19 06:51:16</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549018</td>
<td>296350-C-Video Matching Fee : 2025-12-19 12:11:14</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549019</td>
<td>296350-C-WestLink M7 : 2025-12-19 12:11:14</td>
<td>6.04</td>
<td>0.60</td>
<td>6.64</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549020</td>
<td>296350-C-WestLink M7 : 2025-12-19 06:51:16</td>
<td>8.54</td>
<td>0.85</td>
<td>9.39</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549021</td>
<td>296350-C-Video Matching Fee : 2025-12-22 14:07:30</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549022</td>
<td>296350-C-Video Matching Fee : 2025-12-22 07:23:21</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549023</td>
<td>296350-C-Video Matching Fee : 2025-12-22 07:30:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549024</td>
<td>296350-C-Video Matching Fee : 2025-12-22 13:39:06</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549025</td>
<td>296350-C-Video Matching Fee : 2025-12-22 13:55:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549026</td>
<td>296350-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-22</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549027</td>
<td>296350-C-M5 South West Motorway : 2025-12-22</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549028</td>
<td>296350-C-M5 South West Motorway : 2025-12-22</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549029</td>
<td>296350-C-WestConnex : 2025-12-22 13:55:20</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549030</td>
<td>296350-C-WestConnex : 2025-12-22 07:30:20</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549031</td>
<td>296350-C-Video Matching Fee : 2025-12-23 07:20:37</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549032</td>
<td>296350-C-Video Matching Fee : 2025-12-23 14:03:52</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549033</td>
<td>296350-C-WestLink M7 : 2025-12-23 07:20:37</td>
<td>8.54</td>
<td>0.85</td>
<td>9.39</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549034</td>
<td>296350-C-WestLink M7 : 2025-12-23 14:03:52</td>
<td>8.54</td>
<td>0.85</td>
<td>9.39</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549035</td>
<td>296350-C-Video Matching Fee : 2025-12-24 08:03:52</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549036</td>
<td>296350-C-WestLink M7 : 2025-12-24 08:03:52</td>
<td>9.15</td>
<td>0.92</td>
<td>10.07</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549037</td>
<td>296350-C-Video Matching Fee : 2025-12-25 13:18:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549038</td>
<td>296350-C-Video Matching Fee : 2025-12-25 10:29:28</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549039</td>
<td>296350-C-M5 South West Motorway : 2025-12-25</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549040</td>
<td>296350-C-M5 South West Motorway : 2025-12-25</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549041</td>
<td>296350-C-Video Matching Fee : 2025-12-30 13:16:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549042</td>
<td>296350-C-Video Matching Fee : 2025-12-30 13:16:14</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549043</td>
<td>296350-C-Video Matching Fee : 2025-12-30 14:58:53</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549044</td>
<td>296350-C-Video Matching Fee : 2025-12-30 14:59:04</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549045</td>
<td>296350-C-Video Matching Fee : 2025-12-30 11:36:09</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549046</td>
<td>296350-C-Video Matching Fee : 2025-12-30 15:04:39</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 89 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th colspan="2"></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549047</td>
<td>296350-C-Video Matching Fee : 2025-12-30 20:56:05</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549048</td>
<td>296350-C-Hills M2 : 2025-12-30 13:16:02</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549049</td>
<td>296350-C-Hills M2 : 2025-12-30 14:59:04</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549050</td>
<td>296350-C-WestLink M7 : 2025-12-30 15:04:39</td>
<td>6.51</td>
<td>0.65</td>
<td>7.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549051</td>
<td>296350-C-WestLink M7 : 2025-12-30 20:56:05</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549052</td>
<td>296350-C-WestLink M7 : 2025-12-30 11:36:09</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549053</td>
<td>296350-C-North Connex : 2025-12-30 13:16:14</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549054</td>
<td>296350-C-North Connex : 2025-12-30 14:58:53</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549055</td>
<td>296350-C-Video Matching Fee:2026-01-05 14:33:14</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549056</td>
<td>296350-C-Video Matching Fee:2026-01-05 11:02:18</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549057</td>
<td>296350-C-Video Matching Fee:2026-01-05 13:59:47</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549058</td>
<td>296350-C-WestLink M7:2026-01-05 13:59:47</td>
<td>5.10</td>
<td>0.51</td>
<td>5.61</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549059</td>
<td>296350-C-WestLink M7:2026-01-05 14:33:14</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549060</td>
<td>296350-C-WestLink M7:2026-01-05 11:02:18</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549061</td>
<td>296350-C-Video Matching Fee:2026-01-07 09:08:42</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549062</td>
<td>296350-C-Video Matching Fee:2026-01-07 17:19:52</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549063</td>
<td>296350-C-WestLink M7:2026-01-07 09:08:42</td>
<td>8.65</td>
<td>0.87</td>
<td>9.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549064</td>
<td>296350-C-WestLink M7:2026-01-07 17:19:52</td>
<td>8.65</td>
<td>0.87</td>
<td>9.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549065</td>
<td>296350-C-Video Matching Fee:2026-01-08 16:22:43</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549066</td>
<td>296350-C-Video Matching Fee:2026-01-08 15:22:11</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549067</td>
<td>296350-C-Video Matching Fee:2026-01-08 10:17:21</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549068</td>
<td>296350-C-WestConnex:2026-01-08 15:22:11</td>
<td>3.20</td>
<td>0.32</td>
<td>3.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549069</td>
<td>296350-C-M5 South West Motorway:2026-01-08 16:22:43</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549070</td>
<td>296350-C-WestLink M7:2026-01-08 10:17:21</td>
<td>9.28</td>
<td>0.93</td>
<td>10.21</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549071</td>
<td>296350-C-Video Matching Fee:2026-01-09 06:20:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549072</td>
<td>296350-C-Video Matching Fee:2026-01-09 17:25:26</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549073</td>
<td>296350-C-WestConnex:2026-01-09 06:20:31</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549074</td>
<td>296350-C-WestLink M7:2026-01-09 17:25:26</td>
<td>9.28</td>
<td>0.93</td>
<td>10.21</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549075</td>
<td>296350-C-Video Matching Fee:2026-01-15 17:48:51</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549076</td>
<td>296350-C-Video Matching Fee:2026-01-15 18:01:03</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549077</td>
<td>296350-C-WestConnex:2026-01-15 17:48:51</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK43RJ</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Arvind Maharaj</td>
<td>4843549078</td>
<td>296350-C-WestLink M7:2026-01-15 18:01:03</td>
<td>7.81</td>
<td>0.78</td>
<td>8.59</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548101</td>
<td>295656-C-Video Matching Fee : 2025-12-15 16:06:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 90 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548102</td>
<td>295656-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-15</td>
<td>4.01</td>
<td>0.40</td>
<td>4.41</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548103</td>
<td>295656-C-Video Matching Fee : 2025-12-16 06:57:30</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548104</td>
<td>295656-C-Video Matching Fee : 2025-12-16 06:51:53</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548105</td>
<td>295656-C-Video Matching Fee : 2025-12-16 15:20:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548106</td>
<td>295656-C-Video Matching Fee : 2025-12-16 15:52:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548107</td>
<td>295656-C-Video Matching Fee : 2025-12-16 15:30:05</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548108</td>
<td>295656-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-16</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548109</td>
<td>295656-C-M5 South West Motorway : 2025-12-16</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548110</td>
<td>295656-C-M5 South West Motorway : 2025-12-16</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548111</td>
<td>295656-C-WestConnex : 2025-12-16 15:30:05</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548112</td>
<td>295656-C-WestConnex : 2025-12-16 06:57:30</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548113</td>
<td>295656-C-Video Matching Fee : 2025-12-17 07:17:35</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548114</td>
<td>295656-C-Video Matching Fee : 2025-12-17 11:50:23</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548115</td>
<td>295656-C-Video Matching Fee : 2025-12-17 11:53:23</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548116</td>
<td>295656-C-Video Matching Fee : 2025-12-17 07:35:12</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548117</td>
<td>295656-C-Video Matching Fee : 2025-12-17 11:41:02</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548118</td>
<td>295656-C-WestLink M7 : 2025-12-17 11:41:02</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548119</td>
<td>295656-C-Lane Cove Tunnel : 2025-12-17 11:53:23</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548120</td>
<td>295656-C-M5 South West Motorway : 2025-12-17</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548121</td>
<td>295656-C-WestLink M7 : 2025-12-17 07:35:12</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548122</td>
<td>295656-C-Hills M2 : 2025-12-17 11:50:23</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548123</td>
<td>295656-C-Video Matching Fee : 2025-12-18 09:40:28</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548124</td>
<td>295656-C-Video Matching Fee : 2025-12-18 09:37:12</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548125</td>
<td>295656-C-Video Matching Fee : 2025-12-18 15:35:05</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548126</td>
<td>295656-C-Video Matching Fee : 2025-12-18 14:49:56</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548127</td>
<td>295656-C-Video Matching Fee : 2025-12-18 09:49:17</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548128</td>
<td>295656-C-WestLink M7 : 2025-12-18 09:49:17</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548129</td>
<td>295656-C-Lane Cove Tunnel : 2025-12-18 09:37:12</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548130</td>
<td>295656-C-M5 South West Motorway : 2025-12-18</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548131</td>
<td>295656-C-WestLink M7 : 2025-12-18 14:49:56</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548132</td>
<td>295656-C-Hills M2 : 2025-12-18 09:40:28</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548133</td>
<td>295656-C-Video Matching Fee : 2025-12-19 06:51:24</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548134</td>
<td>295656-C-Video Matching Fee : 2025-12-19 06:56:13</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 91 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548135</td>
<td>295656-C-Video Matching Fee : 2025-12-19 07:28:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548136</td>
<td>295656-C-Video Matching Fee : 2025-12-19 12:02:19</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548137</td>
<td>295656-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-19</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548138</td>
<td>295656-C-WestConnex : 2025-12-19 06:56:13</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548139</td>
<td>295656-C-M5 South West Motorway : 2025-12-19</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548140</td>
<td>295656-C-WestConnex : 2025-12-19 07:28:18</td>
<td>8.35</td>
<td>0.84</td>
<td>9.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548141</td>
<td>295656-C-Video Matching Fee : 2025-12-20 10:44:46</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548142</td>
<td>295656-C-Video Matching Fee : 2025-12-20 10:53:19</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548143</td>
<td>295656-C-Video Matching Fee : 2025-12-20 11:06:14</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548144</td>
<td>295656-C-Video Matching Fee : 2025-12-20 20:28:36</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548145</td>
<td>295656-C-Video Matching Fee : 2025-12-20 20:31:58</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548146</td>
<td>295656-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-20</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548147</td>
<td>295656-C-M5 South West Motorway : 2025-12-20</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548148</td>
<td>295656-C-M5 South West Motorway : 2025-12-20</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548149</td>
<td>295656-C-WestConnex : 2025-12-20 20:31:58</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548150</td>
<td>295656-C-WestConnex : 2025-12-20 10:53:19</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548151</td>
<td>295656-C-Video Matching Fee : 2025-12-22 07:05:38</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548152</td>
<td>295656-C-Video Matching Fee : 2025-12-22 07:08:54</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548153</td>
<td>295656-C-M5 South West Motorway : 2025-12-22</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548154</td>
<td>295656-C-WestConnex : 2025-12-22 07:08:54</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548155</td>
<td>295656-C-Video Matching Fee : 2025-12-23 14:18:26</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548156</td>
<td>295656-C-Video Matching Fee : 2025-12-23 15:09:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548157</td>
<td>295656-C-Video Matching Fee : 2025-12-23 15:18:05</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548158</td>
<td>295656-C-Video Matching Fee : 2025-12-23 15:19:48</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548159</td>
<td>295656-C-Video Matching Fee : 2025-12-23 09:02:53</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548160</td>
<td>295656-C-Video Matching Fee : 2025-12-23 09:43:17</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548161</td>
<td>295656-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-23</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548162</td>
<td>295656-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-23</td>
<td>4.01</td>
<td>0.40</td>
<td>4.41</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548163</td>
<td>295656-C-M5 South West Motorway : 2025-12-23</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548164</td>
<td>295656-C-M5 South West Motorway : 2025-12-23</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548165</td>
<td>295656-C-WestConnex : 2025-12-23 15:09:18</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548166</td>
<td>295656-C-Eastern Distributor : 2025-12-23 09:43:17</td>
<td>9.24</td>
<td>0.92</td>
<td>10.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548167</td>
<td>295656-C-Video Matching Fee : 2025-12-24 07:01:57</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 92 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td colspan="2">GST Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548168</td>
<td>295656-C-Video Matching Fee : 2025-12-24 07:05:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548169</td>
<td>295656-C-Video Matching Fee : 2025-12-24 12:23:54</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548170</td>
<td>295656-C-Video Matching Fee : 2025-12-24 12:38:35</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548171</td>
<td>295656-C-Video Matching Fee : 2025-12-24 12:46:40</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548172</td>
<td>295656-C-Video Matching Fee : 2025-12-24 15:35:49</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548173</td>
<td>295656-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-24</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548174</td>
<td>295656-C-M5 South West Motorway : 2025-12-24</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548175</td>
<td>295656-C-M5 South West Motorway : 2025-12-24</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548176</td>
<td>295656-C-M5 South West Motorway : 2025-12-24</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548177</td>
<td>295656-C-WestConnex : 2025-12-24 12:38:35</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548178</td>
<td>295656-C-WestConnex : 2025-12-24 07:05:18</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548179</td>
<td>295656-C-Video Matching Fee : 2025-12-26 09:41:46</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548180</td>
<td>295656-C-Video Matching Fee : 2025-12-26 09:45:08</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548181</td>
<td>295656-C-M5 South West Motorway : 2025-12-26</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548182</td>
<td>295656-C-WestConnex : 2025-12-26 09:45:08</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548183</td>
<td>295656-C-Video Matching Fee : 2025-12-27 18:16:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548184</td>
<td>295656-C-Video Matching Fee : 2025-12-27 18:20:05</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548185</td>
<td>295656-C-Video Matching Fee : 2025-12-27 18:55:22</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548186</td>
<td>295656-C-WestConnex : 2025-12-27 18:20:05</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548187</td>
<td>295656-C-M5 South West Motorway : 2025-12-27</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548188</td>
<td>295656-C-Eastern Distributor : 2025-12-27 18:55:22</td>
<td>9.24</td>
<td>0.92</td>
<td>10.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548189</td>
<td>295656-C-Video Matching Fee : 2025-12-29 14:33:48</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548190</td>
<td>295656-C-Video Matching Fee : 2025-12-29 14:24:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548191</td>
<td>295656-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-29</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548192</td>
<td>295656-C-WestConnex : 2025-12-29 14:33:48</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548193</td>
<td>295656-C-Video Matching Fee:2026-01-03 10:09:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548194</td>
<td>295656-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-03</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548195</td>
<td>295656-C-Video Matching Fee:2026-01-04 15:16:52</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548196</td>
<td>295656-C-Video Matching Fee:2026-01-04 15:20:07</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548197</td>
<td>295656-C-Video Matching Fee:2026-01-04 15:55:03</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548198</td>
<td>295656-C-Video Matching Fee:2026-01-04 16:00:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548199</td>
<td>295656-C-Video Matching Fee:2026-01-04 12:50:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548200</td>
<td>295656-C-Video Matching Fee:2026-01-04 13:40:47</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 93 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td colspan="2">GST Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548201</td>
<td>295656-C-Video Matching Fee:2026-01-04 13:46:11</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548202</td>
<td>295656-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-04</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548203</td>
<td>295656-C-WestConnex:2026-01-04 13:40:47</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548204</td>
<td>295656-C-WestConnex:2026-01-04 15:20:07</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548205</td>
<td>295656-C-WestConnex:2026-01-04 15:55:03</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548206</td>
<td>295656-C-M5 South West Motorway:2026-01-04 13:46:11</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548207</td>
<td>295656-C-M5 South West Motorway:2026-01-04 15:16:52</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548208</td>
<td>295656-C-M5 South West Motorway:2026-01-04 16:00:31</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548209</td>
<td>295656-C-Video Matching Fee:2026-01-07 18:41:47</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548210</td>
<td>295656-C-Video Matching Fee:2026-01-07 20:39:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548211</td>
<td>295656-C-Video Matching Fee:2026-01-07 20:49:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548212</td>
<td>295656-C-M5 South West Motorway:2026-01-07 18:41:47</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548213</td>
<td>295656-C-M5 South West Motorway:2026-01-07 20:49:16</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548214</td>
<td>295656-C-WestConnex:2026-01-07 20:39:02</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548215</td>
<td>295656-C-Video Matching Fee:2026-01-08 13:41:27</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548216</td>
<td>295656-C-Video Matching Fee:2026-01-08 07:13:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548217</td>
<td>295656-C-Video Matching Fee:2026-01-08 07:17:14</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548218</td>
<td>295656-C-Lane Cove Tunnel:2026-01-08 13:41:27</td>
<td>1.92</td>
<td>0.19</td>
<td>2.11</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548219</td>
<td>295656-C-M5 South West Motorway:2026-01-08 07:13:55</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548220</td>
<td>295656-C-WestConnex:2026-01-08 07:17:14</td>
<td>11.40</td>
<td>1.14</td>
<td>12.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548221</td>
<td>295656-C-Video Matching Fee:2026-01-10 11:44:57</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548222</td>
<td>295656-C-Video Matching Fee:2026-01-10 11:53:59</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548223</td>
<td>295656-C-Video Matching Fee:2026-01-10 12:19:29</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548224</td>
<td>295656-C-Video Matching Fee:2026-01-10 13:58:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548225</td>
<td>295656-C-Video Matching Fee:2026-01-10 14:11:46</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548226</td>
<td>295656-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-10</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548227</td>
<td>295656-C-WestConnex:2026-01-10 11:53:59</td>
<td>4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548228</td>
<td>295656-C-WestConnex:2026-01-10 12:19:29</td>
<td>4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548229</td>
<td>295656-C-M5 South West Motorway:2026-01-10 14:11:46</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548230</td>
<td>295656-C-WestConnex:2026-01-10 13:58:02</td>
<td>11.40</td>
<td>1.14</td>
<td>12.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548231</td>
<td>295656-C-Video Matching Fee:2026-01-12 06:42:33</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548232</td>
<td>295656-C-Video Matching Fee:2026-01-12 06:45:58</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548233</td>
<td>295656-C-Video Matching Fee:2026-01-12 17:31:51</td>
<td>0.50</td>
<td colspan="2">0.05 0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 94 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548234</td>
<td>295656-C-Video Matching Fee:2026-01-12 17:42:01</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548235</td>
<td>295656-C-Video Matching Fee:2026-01-12 17:56:07</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548236</td>
<td>295656-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-12</td>
<td>4.01</td>
<td>0.40</td>
<td>4.41</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548237</td>
<td>295656-C-M5 South West Motorway:2026-01-12 17:56:07</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548238</td>
<td>295656-C-M5 South West Motorway:2026-01-12 06:42:33</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548239</td>
<td>295656-C-WestConnex:2026-01-12 17:42:01</td>
<td>11.40</td>
<td>1.14</td>
<td>12.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548240</td>
<td>295656-C-WestConnex:2026-01-12 06:45:58</td>
<td>11.40</td>
<td>1.14</td>
<td>12.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548241</td>
<td>295656-C-Video Matching Fee:2026-01-13 14:45:22</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548242</td>
<td>295656-C-Video Matching Fee:2026-01-13 14:53:45</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548243</td>
<td>295656-C-Video Matching Fee:2026-01-13 15:08:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548244</td>
<td>295656-C-Video Matching Fee:2026-01-13 07:15:59</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548245</td>
<td>295656-C-Video Matching Fee:2026-01-13 07:19:08</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548246</td>
<td>295656-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-13</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548247</td>
<td>295656-C-M5 South West Motorway:2026-01-13 15:08:02</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548248</td>
<td>295656-C-M5 South West Motorway:2026-01-13 07:15:59</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548249</td>
<td>295656-C-WestConnex:2026-01-13 14:53:45</td>
<td>11.40</td>
<td>1.14</td>
<td>12.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548250</td>
<td>295656-C-WestConnex:2026-01-13 07:19:08</td>
<td>11.40</td>
<td>1.14</td>
<td>12.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548251</td>
<td>295656-C-Video Matching Fee:2026-01-14 07:09:40</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548252</td>
<td>295656-C-Video Matching Fee:2026-01-14 07:12:50</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548253</td>
<td>295656-C-M5 South West Motorway:2026-01-14 07:09:40</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548254</td>
<td>295656-C-WestConnex:2026-01-14 07:12:50</td>
<td>11.40</td>
<td>1.14</td>
<td>12.54</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548255</td>
<td>295656-C-Video Matching Fee:2026-01-15 15:24:54</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548256</td>
<td>295656-C-Video Matching Fee:2026-01-15 21:14:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548257</td>
<td>295656-C-Video Matching Fee:2026-01-15 18:54:54</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548258</td>
<td>295656-C-Video Matching Fee:2026-01-15 15:34:24</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548259</td>
<td>295656-C-Video Matching Fee:2026-01-15 17:53:21</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548260</td>
<td>295656-C-WestLink M7:2026-01-15 17:53:21</td>
<td>3.57</td>
<td>0.36</td>
<td>3.93</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548261</td>
<td>295656-C-M5 South West Motorway:2026-01-15 18:54:54</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548262</td>
<td>295656-C-M5 South West Motorway:2026-01-15 21:14:32</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548263</td>
<td>295656-C-WestLink M7:2026-01-15 15:34:24</td>
<td>8.75</td>
<td>0.88</td>
<td>9.63</td>
</tr>
<tr>
<td>NSW</td>
<td>DK76ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Jamie Lee</td>
<td>4843548264</td>
<td>295656-C-Hills M2:2026-01-15 15:24:54</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547901</td>
<td>295649-C-Video Matching Fee : 2025-12-08 12:25:00</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547902</td>
<td>295649-C-WestLink M7 : 2025-12-08 12:25:00</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 95 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No. AU1166479</th>
<th>Invoice Date 31 January 2026</th>
<th colspan="3">Invoice No. AIN00014651</th>
<th></th>
<th colspan="2">P</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547903</td>
<td>295649-C-Video Matching Fee : 2025-12-11 14:34:51</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547904</td>
<td>295649-C-Video Matching Fee : 2025-12-11 07:26:13</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547905</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-11 07:26:13</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547906</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-11 14:34:51</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547907</td>
<td>295649-C-Video Matching Fee : 2025-12-12 13:30:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547908</td>
<td>295649-C-Video Matching Fee : 2025-12-12 07:40:44</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547909</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-12 07:40:44</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547910</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-12 13:30:16</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547911</td>
<td>295649-C-Video Matching Fee : 2025-12-15 16:39:41</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547912</td>
<td>295649-C-Video Matching Fee : 2025-12-15 07:44:00</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547913</td>
<td>295649-C-Video Matching Fee : 2025-12-15 07:56:08</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547914</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-15 16:39:41</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547915</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-15 07:44:00</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547916</td>
<td>295649-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-15</td>
<td>4.01</td>
<td>0.40</td>
<td>4.41</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547917</td>
<td>295649-C-Video Matching Fee : 2025-12-16 07:51:23</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547918</td>
<td>295649-C-Video Matching Fee : 2025-12-16 08:00:08</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547919</td>
<td>295649-C-Video Matching Fee : 2025-12-16 08:10:54</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547920</td>
<td>295649-C-Video Matching Fee : 2025-12-16 18:00:23</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547921</td>
<td>295649-C-Video Matching Fee : 2025-12-16 18:03:42</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547922</td>
<td>295649-C-Video Matching Fee : 2025-12-16 18:17:56</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547923</td>
<td>295649-C-WestLink M7 : 2025-12-16 18:17:56</td>
<td>2.46</td>
<td>0.25</td>
<td>2.71</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547924</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-16 18:00:23</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547925</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-16 08:00:08</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547926</td>
<td>295649-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-16</td>
<td>4.01</td>
<td>0.40</td>
<td>4.41</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547927</td>
<td>295649-C-Hills M2 : 2025-12-16 07:51:23</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547928</td>
<td>295649-C-Hills M2 : 2025-12-16 18:03:42</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547929</td>
<td>295649-C-Video Matching Fee : 2025-12-17 07:57:01</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547930</td>
<td>295649-C-Video Matching Fee : 2025-12-17 15:40:49</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547931</td>
<td>295649-C-Video Matching Fee : 2025-12-17 15:44:35</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547932</td>
<td>295649-C-Video Matching Fee : 2025-12-17 16:03:49</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547933</td>
<td>295649-C-WestLink M7 : 2025-12-17 16:03:49</td>
<td>2.46</td>
<td>0.25</td>
<td>2.71</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547934</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-17 15:40:49</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547935</td>
<td>295649-C-Hills M2 : 2025-12-17 15:44:35</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 96 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2" rowspan="2">Customer No. AU1166479</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547936</td>
<td>295649-C-WestConnex : 2025-12-17 07:57:01</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547937</td>
<td>295649-C-Video Matching Fee : 2025-12-18 09:36:40</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547938</td>
<td>295649-C-Video Matching Fee : 2025-12-18 07:31:12</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547939</td>
<td>295649-C-Video Matching Fee : 2025-12-18 07:38:09</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547940</td>
<td>295649-C-Video Matching Fee : 2025-12-18 09:40:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547941</td>
<td>295649-C-Video Matching Fee : 2025-12-18 14:41:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547942</td>
<td>295649-C-Video Matching Fee : 2025-12-18 14:28:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547943</td>
<td>295649-C-Video Matching Fee : 2025-12-18 14:32:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547944</td>
<td>295649-C-Video Matching Fee : 2025-12-18 16:12:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547945</td>
<td>295649-C-Video Matching Fee : 2025-12-18 16:16:44</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547946</td>
<td>295649-C-Video Matching Fee : 2025-12-18 14:19:13</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547947</td>
<td>295649-C-Video Matching Fee : 2025-12-18 16:44:13</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547948</td>
<td>295649-C-Video Matching Fee : 2025-12-18 17:30:35</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547949</td>
<td>295649-C-WestLink M7 : 2025-12-18 14:19:13</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547950</td>
<td>295649-C-WestLink M7 : 2025-12-18 16:44:13</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547951</td>
<td>295649-C-WestLink M7 : 2025-12-18 17:30:35</td>
<td>0.99</td>
<td>0.10</td>
<td>1.09</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547952</td>
<td>295649-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-18</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547953</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-18 07:38:09</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547954</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-18 09:36:40</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547955</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-18 14:32:31</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547956</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-18 16:12:55</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547957</td>
<td>295649-C-Hills M2 : 2025-12-18 07:31:12</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547958</td>
<td>295649-C-Hills M2 : 2025-12-18 09:40:02</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547959</td>
<td>295649-C-Hills M2 : 2025-12-18 14:28:55</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547960</td>
<td>295649-C-Hills M2 : 2025-12-18 16:16:44</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547961</td>
<td>295649-C-Video Matching Fee : 2025-12-19 08:42:28</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547962</td>
<td>295649-C-Video Matching Fee : 2025-12-19 14:01:14</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547963</td>
<td>295649-C-WestConnex : 2025-12-19 08:42:28</td>
<td>9.44</td>
<td>0.94</td>
<td>10.38</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547964</td>
<td>295649-C-WestConnex : 2025-12-19 14:01:14</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547965</td>
<td>295649-C-Video Matching Fee : 2025-12-20 22:37:14</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547966</td>
<td>295649-C-WestLink M7 : 2025-12-20 22:37:14</td>
<td>1.88</td>
<td>0.19</td>
<td>2.07</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547967</td>
<td>295649-C-Video Matching Fee : 2025-12-22 10:22:51</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547968</td>
<td>295649-C-Video Matching Fee : 2025-12-22 15:17:30</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 97 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No. AU1166479</th>
<th>Invoice Date 31 January 2026</th>
<th colspan="3">Invoice No. AIN00014651</th>
<th colspan="3">P</th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547969</td>
<td>295649-C-WestConnex : 2025-12-22 15:17:30</td>
<td>7.69</td>
<td>0.77</td>
<td>8.46</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547970</td>
<td>295649-C-WestConnex : 2025-12-22 10:22:51</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547971</td>
<td>295649-C-Video Matching Fee : 2025-12-23 06:31:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547972</td>
<td>295649-C-Video Matching Fee : 2025-12-23 11:12:58</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547973</td>
<td>295649-C-Video Matching Fee : 2025-12-23 15:45:59</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547974</td>
<td>295649-C-Video Matching Fee : 2025-12-23 15:49:27</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547975</td>
<td>295649-C-Video Matching Fee : 2025-12-23 15:58:55</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547976</td>
<td>295649-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-23</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547977</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-23 15:45:59</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547978</td>
<td>295649-C-WestLink M7 : 2025-12-23 15:58:55</td>
<td>5.53</td>
<td>0.55</td>
<td>6.08</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547979</td>
<td>295649-C-Hills M2 : 2025-12-23 15:49:27</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547980</td>
<td>295649-C-WestConnex : 2025-12-23 06:31:32</td>
<td>9.44</td>
<td>0.94</td>
<td>10.38</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547981</td>
<td>295649-C-Video Matching Fee : 2025-12-24 12:23:57</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547982</td>
<td>295649-C-Video Matching Fee : 2025-12-24 12:27:27</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547983</td>
<td>295649-C-Video Matching Fee : 2025-12-24 06:30:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547984</td>
<td>295649-C-Video Matching Fee : 2025-12-24 06:33:43</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547985</td>
<td>295649-C-Video Matching Fee : 2025-12-24 12:37:19</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547986</td>
<td>295649-C-Video Matching Fee : 2025-12-24 06:17:23</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547987</td>
<td>295649-C-WestLink M7 : 2025-12-24 06:17:23</td>
<td>2.46</td>
<td>0.25</td>
<td>2.71</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547988</td>
<td>295649-C-WestLink M7 : 2025-12-24 12:37:19</td>
<td>2.46</td>
<td>0.25</td>
<td>2.71</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547989</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-24 06:33:43</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547990</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-24 12:23:57</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547991</td>
<td>295649-C-Hills M2 : 2025-12-24 06:30:16</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547992</td>
<td>295649-C-Hills M2 : 2025-12-24 12:27:27</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547993</td>
<td>295649-C-Video Matching Fee : 2025-12-26 19:26:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547994</td>
<td>295649-C-Video Matching Fee : 2025-12-26 23:03:58</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547995</td>
<td>295649-C-Video Matching Fee : 2025-12-26 19:13:44</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547996</td>
<td>295649-C-Video Matching Fee : 2025-12-26 23:13:35</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547997</td>
<td>295649-C-WestLink M7 : 2025-12-26 19:13:44</td>
<td>2.46</td>
<td>0.25</td>
<td>2.71</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547998</td>
<td>295649-C-WestLink M7 : 2025-12-26 23:13:35</td>
<td>2.46</td>
<td>0.25</td>
<td>2.71</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843547999</td>
<td>295649-C-Hills M2 : 2025-12-26 19:26:18</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548000</td>
<td>295649-C-Hills M2 : 2025-12-26 23:03:58</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548001</td>
<td>295649-C-Video Matching Fee : 2025-12-29 14:23:53</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 98 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No. AU1166479</th>
<th>Invoice Date 31 January 2026</th>
<th colspan="3">Invoice No. AIN00014651</th>
<th></th>
<th colspan="2">P</th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548002</td>
<td>295649-C-Video Matching Fee : 2025-12-29 07:39:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548003</td>
<td>295649-C-Video Matching Fee : 2025-12-29 07:43:35</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548004</td>
<td>295649-C-Video Matching Fee : 2025-12-29 14:27:21</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548005</td>
<td>295649-C-Video Matching Fee : 2025-12-29 07:28:01</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548006</td>
<td>295649-C-Video Matching Fee : 2025-12-29 14:37:14</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548007</td>
<td>295649-C-WestLink M7 : 2025-12-29 14:37:14</td>
<td>2.46</td>
<td>0.25</td>
<td>2.71</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548008</td>
<td>295649-C-WestLink M7 : 2025-12-29 07:28:01</td>
<td>2.46</td>
<td>0.25</td>
<td>2.71</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548009</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-29 07:43:35</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548010</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-29 14:23:53</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548011</td>
<td>295649-C-Hills M2 : 2025-12-29 07:39:55</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548012</td>
<td>295649-C-Hills M2 : 2025-12-29 14:27:21</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548013</td>
<td>295649-C-Video Matching Fee : 2025-12-30 07:29:15</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548014</td>
<td>295649-C-Video Matching Fee : 2025-12-30 14:04:15</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548015</td>
<td>295649-C-Video Matching Fee : 2025-12-30 14:07:40</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548016</td>
<td>295649-C-Video Matching Fee : 2025-12-30 14:17:46</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548017</td>
<td>295649-C-WestLink M7 : 2025-12-30 14:17:46</td>
<td>2.46</td>
<td>0.25</td>
<td>2.71</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548018</td>
<td>295649-C-Lane Cove Tunnel : 2025-12-30 14:04:15</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548019</td>
<td>295649-C-Hills M2 : 2025-12-30 14:07:40</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548020</td>
<td>295649-C-WestConnex : 2025-12-30 07:29:15</td>
<td>9.44</td>
<td>0.94</td>
<td>10.38</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548021</td>
<td>295649-C-Video Matching Fee : 2025-12-31 07:53:40</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548022</td>
<td>295649-C-Video Matching Fee : 2025-12-31 14:45:10</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548023</td>
<td>295649-C-WestConnex : 2025-12-31 07:53:40</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548024</td>
<td>295649-C-WestConnex : 2025-12-31 14:45:10</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548025</td>
<td>295649-C-Video Matching Fee:2026-01-02 13:22:50</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548026</td>
<td>295649-C-WestLink M7:2026-01-02 13:22:50</td>
<td>4.11</td>
<td>0.41</td>
<td>4.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548027</td>
<td>295649-C-Video Matching Fee:2026-01-05 11:32:25</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548028</td>
<td>295649-C-Video Matching Fee:2026-01-05 11:35:59</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548029</td>
<td>295649-C-Video Matching Fee:2026-01-05 11:44:45</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548030</td>
<td>295649-C-Video Matching Fee:2026-01-05 15:38:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548031</td>
<td>295649-C-Video Matching Fee:2026-01-05 15:28:23</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548032</td>
<td>295649-C-Video Matching Fee:2026-01-05 11:22:01</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548033</td>
<td>295649-C-Video Matching Fee:2026-01-05 15:48:18</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548034</td>
<td>295649-C-WestLink M7:2026-01-05 11:22:01</td>
<td>0.80</td>
<td>0.08</td>
<td>0.88</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 99 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548035</td>
<td>295649-C-WestLink M7:2026-01-05 15:48:18</td>
<td>2.50</td>
<td>0.25</td>
<td>2.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548036</td>
<td>295649-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-05</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548037</td>
<td>295649-C-Lane Cove Tunnel:2026-01-05 11:35:59</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548038</td>
<td>295649-C-Lane Cove Tunnel:2026-01-05 15:28:23</td>
<td>5.75</td>
<td>0.58</td>
<td>6.33</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548039</td>
<td>295649-C-Hills M2:2026-01-05 11:32:25</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548040</td>
<td>295649-C-Hills M2:2026-01-05 15:38:55</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548041</td>
<td>295649-C-Video Matching Fee:2026-01-06 07:26:42</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548042</td>
<td>295649-C-Video Matching Fee:2026-01-06 14:37:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548043</td>
<td>295649-C-WestLink M7:2026-01-06 15:00:05</td>
<td>0.64</td>
<td>0.06</td>
<td>0.70</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548044</td>
<td>295649-C-Video Matching Fee:2026-01-06 15:00:05</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548045</td>
<td>295649-C-WestConnex:2026-01-06 07:26:42</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548046</td>
<td>295649-C-WestConnex:2026-01-06 14:37:31</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548047</td>
<td>295649-C-Video Matching Fee:2026-01-07 13:32:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548048</td>
<td>295649-C-Video Matching Fee:2026-01-07 13:36:07</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548049</td>
<td>295649-C-Video Matching Fee:2026-01-07 07:55:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548050</td>
<td>295649-C-Video Matching Fee:2026-01-07 08:18:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548051</td>
<td>295649-C-Video Matching Fee:2026-01-07 13:45:57</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548052</td>
<td>295649-C-WestLink M7:2026-01-07 13:45:57</td>
<td>2.50</td>
<td>0.25</td>
<td>2.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548053</td>
<td>295649-C-WestConnex:2026-01-07 07:55:31</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548054</td>
<td>295649-C-Lane Cove Tunnel:2026-01-07 13:32:18</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548055</td>
<td>295649-C-Hills M2:2026-01-07 13:36:07</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548056</td>
<td>295649-C-WestConnex:2026-01-07 08:18:18</td>
<td>11.36</td>
<td>1.14</td>
<td>12.50</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548057</td>
<td>295649-C-Video Matching Fee:2026-01-08 07:18:30</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548058</td>
<td>295649-C-Video Matching Fee:2026-01-08 15:00:50</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548059</td>
<td>295649-C-Video Matching Fee:2026-01-08 15:04:11</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548060</td>
<td>295649-C-Video Matching Fee:2026-01-08 15:13:51</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548061</td>
<td>295649-C-WestLink M7:2026-01-08 15:13:51</td>
<td>2.50</td>
<td>0.25</td>
<td>2.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548062</td>
<td>295649-C-Lane Cove Tunnel:2026-01-08 15:00:50</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548063</td>
<td>295649-C-Hills M2:2026-01-08 15:04:11</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548064</td>
<td>295649-C-WestConnex:2026-01-08 07:18:30</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548065</td>
<td>295649-C-Video Matching Fee:2026-01-09 12:12:56</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548066</td>
<td>295649-C-Video Matching Fee:2026-01-09 09:51:56</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548067</td>
<td>295649-C-Video Matching Fee:2026-01-09 10:06:49</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 100 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No. AU1166479</th>
<th>Invoice Date 31 January 2026</th>
<th>Invoice No. AIN00014651</th>
<th colspan="2"></th>
<th></th>
<th colspan="2">P</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548068</td>
<td>295649-C-Video Matching Fee:2026-01-09 13:50:00</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548069</td>
<td>295649-C-Video Matching Fee:2026-01-09 13:53:27</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548070</td>
<td>295649-C-Video Matching Fee:2026-01-09 09:18:51</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548071</td>
<td>295649-C-Video Matching Fee:2026-01-09 07:30:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548072</td>
<td>295649-C-Video Matching Fee:2026-01-09 14:02:44</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548073</td>
<td>295649-C-Video Matching Fee:2026-01-09 21:23:55</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548074</td>
<td>295649-C-WestLink M7:2026-01-09 21:23:55</td>
<td>1.00</td>
<td>0.10</td>
<td>1.10</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548075</td>
<td>295649-C-WestLink M7:2026-01-09 14:02:44</td>
<td>2.50</td>
<td>0.25</td>
<td>2.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548076</td>
<td>295649-C-Lane Cove Tunnel:2026-01-09 13:50:00</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548077</td>
<td>295649-C-Cross City Tunnel:2026-01-09 10:06:49</td>
<td>6.61</td>
<td>0.66</td>
<td>7.27</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548078</td>
<td>295649-C-Eastern Distributor:2026-01-09 12:12:56</td>
<td>9.33</td>
<td>0.93</td>
<td>10.26</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548079</td>
<td>295649-C-Hills M2:2026-01-09 13:53:27</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548080</td>
<td>295649-C-WestConnex:2026-01-09 09:18:51</td>
<td>9.80</td>
<td>0.98</td>
<td>10.78</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548081</td>
<td>295649-C-WestConnex:2026-01-09 09:51:56</td>
<td>9.80</td>
<td>0.98</td>
<td>10.78</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548082</td>
<td>295649-C-WestConnex:2026-01-09 07:30:02</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548083</td>
<td>295649-C-Video Matching Fee:2026-01-11 07:29:22</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK77ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Spare Act</td>
<td>4843548084</td>
<td>295649-C-WestConnex:2026-01-11 07:29:22</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547601</td>
<td>295196-C-WestLink M7 : 2025-12-17 13:02:35</td>
<td>2.30</td>
<td>0.23</td>
<td>2.53</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547602</td>
<td>295196-C-WestLink M7 : 2025-12-17 15:02:22</td>
<td>4.18</td>
<td>0.42</td>
<td>4.60</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547603</td>
<td>295196-C-Video Matching Fee : 2025-12-19 11:10:11</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547604</td>
<td>295196-C-WestLink M7 : 2025-12-19 11:10:11</td>
<td>4.18</td>
<td>0.42</td>
<td>4.60</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547605</td>
<td>295196-C-WestLink M7 : 2025-12-21 16:03:03</td>
<td>2.50</td>
<td>0.25</td>
<td>2.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547606</td>
<td>295196-C-WestLink M7 : 2025-12-21 12:58:15</td>
<td>4.97</td>
<td>0.50</td>
<td>5.47</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547607</td>
<td>295196-C-M5 South West Motorway : 2025-12-21</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547608</td>
<td>295196-C-M5 South West Motorway : 2025-12-21</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547609</td>
<td>295196-C-WestLink M7 : 2025-12-22 13:55:22</td>
<td>2.50</td>
<td>0.25</td>
<td>2.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547610</td>
<td>295196-C-WestLink M7 : 2025-12-22 07:57:12</td>
<td>4.97</td>
<td>0.50</td>
<td>5.47</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547611</td>
<td>295196-C-Video Matching Fee : 2025-12-26 11:44:43</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547612</td>
<td>295196-C-Video Matching Fee : 2025-12-26 14:33:11</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547613</td>
<td>295196-C-Video Matching Fee : 2025-12-26 17:18:51</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547614</td>
<td>295196-C-WestLink M7 : 2025-12-26 11:44:43</td>
<td>2.30</td>
<td>0.23</td>
<td>2.53</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547615</td>
<td>295196-C-WestLink M7 : 2025-12-26 17:18:51</td>
<td>3.52</td>
<td>0.35</td>
<td>3.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547616</td>
<td>295196-C-WestLink M7 : 2025-12-26 17:32:51</td>
<td>3.52</td>
<td>0.35</td>
<td>3.87</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 101 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net GST Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547617</td>
<td>295196-C-WestLink M7 : 2025-12-26 14:33:11</td>
<td>4.18 0.42 4.60</td>
</tr>
<tr>
<td colspan="2">NSW DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547618</td>
<td>295196-C-WestLink M7 : 2025-12-29 17:12:20</td>
<td>2.50 0.25 2.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547619</td>
<td>295196-C-WestLink M7 : 2025-12-29 12:26:54</td>
<td>4.97 0.50 5.47</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547620</td>
<td>295196-C-M5 South West Motorway : 2025-12-29</td>
<td>5.33 0.53 5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547621</td>
<td>295196-C-M5 South West Motorway : 2025-12-29</td>
<td>5.33 0.53 5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547622</td>
<td>295196-C-WestLink M7 : 2025-12-29 18:15:47</td>
<td>5.86 0.59 6.45</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547623</td>
<td>295196-C-WestLink M7 : 2025-12-31 12:00:45</td>
<td>7.75 0.78 8.53</td>
</tr>
<tr>
<td colspan="2">NSW DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547624</td>
<td>295196-C-Video Matching Fee:2026-01-05 06:39:08</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547625</td>
<td>295196-C-Video Matching Fee:2026-01-05 16:37:51</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547626</td>
<td>295196-C-Video Matching Fee:2026-01-05 21:45:44</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547627</td>
<td>295196-C-Video Matching Fee:2026-01-05 11:33:07</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547628</td>
<td>295196-C-Video Matching Fee:2026-01-05 16:21:26</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547629</td>
<td>295196-C-WestLink M7:2026-01-05 06:25:56</td>
<td>2.33 0.23 2.56</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547630</td>
<td>295196-C-WestLink M7:2026-01-05 16:21:26</td>
<td>2.33 0.23 2.56</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547631</td>
<td>295196-C-WestConnex:2026-01-05 06:39:08</td>
<td>2.77 0.28 3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547632</td>
<td>295196-C-WestConnex:2026-01-05 07:16:12</td>
<td>2.77 0.28 3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547633</td>
<td>295196-C-WestLink M7:2026-01-05 21:59:51</td>
<td>4.24 0.42 4.66</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547634</td>
<td>295196-C-WestConnex:2026-01-05 16:37:51</td>
<td>5.07 0.51 5.58</td>
</tr>
<tr>
<td colspan="2">NSW DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547635</td>
<td>295196-C-WestConnex:2026-01-05 21:45:44</td>
<td>5.07 0.51 5.58</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547636</td>
<td>295196-C-WestLink M7:2026-01-05 11:33:07</td>
<td>9.36 0.94 10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547637</td>
<td>295196-C-Video Matching Fee:2026-01-06 06:29:45</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547638</td>
<td>295196-C-Video Matching Fee:2026-01-06 15:15:04</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547639</td>
<td>295196-C-WestLink M7:2026-01-06 06:29:45</td>
<td>2.33 0.23 2.56</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547640</td>
<td>295196-C-WestConnex:2026-01-06 15:03:43</td>
<td>2.77 0.28 3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547641</td>
<td>295196-C-WestConnex:2026-01-06 06:43:22</td>
<td>2.77 0.28 3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547642</td>
<td>295196-C-WestLink M7:2026-01-06 15:15:04</td>
<td>4.24 0.42 4.66</td>
</tr>
<tr>
<td colspan="2">NSW DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547643</td>
<td>295196-C-WestLink M7:2026-01-07 06:51:15</td>
<td>2.33 0.23 2.56</td>
</tr>
<tr>
<td colspan="2">NSW DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547644</td>
<td>295196-C-WestConnex:2026-01-07 14:57:02</td>
<td>2.77 0.28 3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547645</td>
<td>295196-C-WestConnex:2026-01-07 07:04:32</td>
<td>2.77 0.28 3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547646</td>
<td>295196-C-Video Matching Fee:2026-01-08 06:46:43</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547647</td>
<td>295196-C-WestLink M7:2026-01-08 06:46:43</td>
<td>2.33 0.23 2.56</td>
</tr>
<tr>
<td colspan="2">NSW DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547648</td>
<td>295196-C-WestConnex:2026-01-08 07:01:49</td>
<td>2.77 0.28 3.05</td>
</tr>
<tr>
<td colspan="2">NSW DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547649</td>
<td>295196-C-WestLink M7:2026-01-08 15:44:24</td>
<td>9.36 0.94 10.30</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 102 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th></th>
<th></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td colspan="2">GST Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547650</td>
<td>295196-C-WestLink M7:2026-01-08 17:18:33</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547651</td>
<td>295196-C-WestLink M7:2026-01-08 19:08:56</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547652</td>
<td>295196-C-WestLink M7:2026-01-09 07:23:30</td>
<td>2.33</td>
<td>0.23</td>
<td>2.56</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547653</td>
<td>295196-C-WestLink M7:2026-01-09 18:50:27</td>
<td>2.54</td>
<td>0.25</td>
<td>2.79</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547654</td>
<td>295196-C-WestConnex:2026-01-09 07:36:53</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547655</td>
<td>295196-C-M5 South West Motorway:2026-01-09 18:44:30</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547656</td>
<td>295196-C-WestConnex:2026-01-09 18:30:46</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547657</td>
<td>295196-C-WestConnex:2026-01-09 15:52:14</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547658</td>
<td>295196-C-WestLink M7:2026-01-10 16:14:41</td>
<td>2.33</td>
<td>0.23</td>
<td>2.56</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547659</td>
<td>295196-C-WestLink M7:2026-01-10 19:01:12</td>
<td>4.24</td>
<td>0.42</td>
<td>4.66</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547660</td>
<td>295196-C-WestConnex:2026-01-10 18:48:50</td>
<td>4.34</td>
<td>0.43</td>
<td>4.77</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547661</td>
<td>295196-C-WestConnex:2026-01-10 16:27:22</td>
<td>4.34</td>
<td>0.43</td>
<td>4.77</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547662</td>
<td>295196-C-WestLink M7:2026-01-12 15:01:31</td>
<td>0.64</td>
<td>0.06</td>
<td>0.70</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547663</td>
<td>295196-C-Video Matching Fee:2026-01-12 06:57:30</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547664</td>
<td>295196-C-WestLink M7:2026-01-12 06:57:30</td>
<td>2.33</td>
<td>0.23</td>
<td>2.56</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547665</td>
<td>295196-C-WestConnex:2026-01-12 14:48:38</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547666</td>
<td>295196-C-WestConnex:2026-01-12 07:17:03</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547667</td>
<td>295196-C-WestConnex:2026-01-13 06:59:00</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547668</td>
<td>295196-C-WestConnex:2026-01-13 15:14:03</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547669</td>
<td>295196-C-WestLink M7:2026-01-13 06:36:44</td>
<td>3.65</td>
<td>0.37</td>
<td>4.02</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547670</td>
<td>295196-C-WestConnex:2026-01-14 15:09:24</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547671</td>
<td>295196-C-WestConnex:2026-01-14 06:55:40</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547672</td>
<td>295196-C-WestLink M7:2026-01-14 06:33:56</td>
<td>3.65</td>
<td>0.37</td>
<td>4.02</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547673</td>
<td>295196-C-WestLink M7:2026-01-14 15:26:11</td>
<td>4.24</td>
<td>0.42</td>
<td>4.66</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547674</td>
<td>295196-C-Video Matching Fee:2026-01-15 06:27:35</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547675</td>
<td>295196-C-Video Matching Fee:2026-01-15 17:55:44</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547676</td>
<td>295196-C-WestConnex:2026-01-15 17:44:32</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547677</td>
<td>295196-C-WestConnex:2026-01-15 06:50:30</td>
<td>2.77</td>
<td>0.28</td>
<td>3.05</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547678</td>
<td>295196-C-WestLink M7:2026-01-15 06:27:35</td>
<td>3.65</td>
<td>0.37</td>
<td>4.02</td>
</tr>
<tr>
<td>NSW</td>
<td>DK78ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Eddie Tannous</td>
<td>4843547679</td>
<td>295196-C-WestLink M7:2026-01-15 17:55:44</td>
<td>4.24</td>
<td>0.42</td>
<td>4.66</td>
</tr>
<tr>
<td>NSW</td>
<td>DK79ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Borthwick</td>
<td>4843547501</td>
<td>295195-C-Video Matching Fee : 2025-12-16 07:47:19</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK79ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Paul Borthwick</td>
<td>4843547502</td>
<td>295195-C-Eastern Distributor : 2025-12-16 07:47:19</td>
<td>9.24</td>
<td colspan="2">0.92 10.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547401</td>
<td>295194-C-Video Matching Fee : 2025-12-16 06:09:55</td>
<td>0.50</td>
<td colspan="2">0.05 0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 103 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td colspan="2">Net GST Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547402</td>
<td>295194-C-Video Matching Fee : 2025-12-16 17:31:45</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547403</td>
<td>295194-C-Video Matching Fee : 2025-12-16 06:16:22</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547404</td>
<td>295194-C-Video Matching Fee : 2025-12-16 15:02:27</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547405</td>
<td>295194-C-WestLink M7 : 2025-12-16 06:16:22</td>
<td colspan="2">2.50 0.25 2.75</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547406</td>
<td>295194-C-M5 South West Motorway : 2025-12-16</td>
<td colspan="2">5.33 0.53 5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547407</td>
<td>295194-C-M5 South West Motorway : 2025-12-16</td>
<td colspan="2">5.33 0.53 5.86</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547408</td>
<td>295194-C-WestLink M7 : 2025-12-16 15:02:27</td>
<td colspan="2">6.86 0.69 7.55</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547409</td>
<td>295194-C-Video Matching Fee : 2025-12-17 10:18:43</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547410</td>
<td>295194-C-M5 South West Motorway : 2025-12-17</td>
<td colspan="2">5.33 0.53 5.86</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547411</td>
<td>295194-C-Video Matching Fee : 2025-12-18 14:55:45</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547412</td>
<td>295194-C-Video Matching Fee : 2025-12-18 09:10:27</td>
<td>0.50 0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547413</td>
<td>295194-C-Video Matching Fee : 2025-12-18 14:14:37</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547414</td>
<td>295194-C-WestConnex : 2025-12-18 09:10:27</td>
<td colspan="2">3.07 0.31 3.38</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547415</td>
<td>295194-C-M5 South West Motorway : 2025-12-18</td>
<td colspan="2">5.33 0.53 5.86</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547416</td>
<td>295194-C-WestLink M7 : 2025-12-18 14:14:37</td>
<td colspan="2">9.25 0.93 10.18</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547417</td>
<td>295194-C-Video Matching Fee : 2025-12-21 14:13:06</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547418</td>
<td>295194-C-Video Matching Fee : 2025-12-21 08:59:06</td>
<td>0.50 0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547419</td>
<td>295194-C-M5 South West Motorway : 2025-12-21</td>
<td colspan="2">5.33 0.53 5.86</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547420</td>
<td>295194-C-M5 South West Motorway : 2025-12-21</td>
<td colspan="2">5.33 0.53 5.86</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547421</td>
<td>295194-C-Video Matching Fee : 2025-12-22 12:27:23</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547422</td>
<td>295194-C-WestConnex : 2025-12-22 12:27:23</td>
<td colspan="2">3.50 0.35 3.85</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547423</td>
<td>295194-C-Video Matching Fee : 2025-12-23 05:27:11</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547424</td>
<td>295194-C-Video Matching Fee : 2025-12-23 11:27:35</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547425</td>
<td>295194-C-Video Matching Fee : 2025-12-23 05:33:13</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547426</td>
<td>295194-C-M5 South West Motorway : 2025-12-23</td>
<td colspan="2">5.33 0.53 5.86</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547427</td>
<td>295194-C-WestLink M7 : 2025-12-23 11:27:35</td>
<td colspan="2">6.04 0.60 6.64</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547428</td>
<td>295194-C-WestLink M7 : 2025-12-23 05:33:13</td>
<td colspan="2">8.54 0.85 9.39</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547429</td>
<td>295194-C-Video Matching Fee : 2025-12-24 06:18:19</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547430</td>
<td>295194-C-Video Matching Fee : 2025-12-24 12:28:08</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547431</td>
<td>295194-C-Video Matching Fee : 2025-12-24 06:24:38</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547432</td>
<td>295194-C-Video Matching Fee : 2025-12-24 11:45:09</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547433</td>
<td>295194-C-Video Matching Fee : 2025-12-24 12:21:58</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td colspan="2">NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547434</td>
<td>295194-C-WestLink M7 : 2025-12-24 12:21:58</td>
<td colspan="2">1.45 0.15 1.60</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 104 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th rowspan="2">Customer No. AU1166479</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th>31 January 2026</th>
</tr>
<tr>
<td>State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td colspan="2">Net GST Total</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547435</td>
<td>295194-C-M5 South West Motorway : 2025-12-24</td>
<td colspan="2">5.33 0.53 5.86</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547436</td>
<td>295194-C-M5 South West Motorway : 2025-12-24</td>
<td colspan="2">5.33 0.53 5.86</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547437</td>
<td>295194-C-WestLink M7 : 2025-12-24 11:45:09</td>
<td colspan="2">7.08 0.71 7.79</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547438</td>
<td>295194-C-WestLink M7 : 2025-12-24 06:24:38</td>
<td colspan="2">8.54 0.85 9.39</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547439</td>
<td>295194-C-Video Matching Fee : 2025-12-25 14:06:18</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547440</td>
<td>295194-C-Video Matching Fee : 2025-12-25 07:27:47</td>
<td>0.50 0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547441</td>
<td>295194-C-Video Matching Fee : 2025-12-25 07:33:16</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547442</td>
<td>295194-C-Video Matching Fee : 2025-12-25 09:22:29</td>
<td>0.50 0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547443</td>
<td>295194-C-Video Matching Fee : 2025-12-25 09:33:34</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547444</td>
<td>295194-C-Video Matching Fee : 2025-12-25 09:52:08</td>
<td>0.50 0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547445</td>
<td>295194-C-M5 South West Motorway : 2025-12-25</td>
<td>5.33 0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547446</td>
<td>295194-C-M5 South West Motorway : 2025-12-25</td>
<td colspan="2">5.33 0.53 5.86</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547447</td>
<td>295194-C-M5 South West Motorway : 2025-12-25</td>
<td colspan="2">5.33 0.53 5.86</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547448</td>
<td>295194-C-M5 South West Motorway : 2025-12-25</td>
<td colspan="2">5.33 0.53 5.86</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547449</td>
<td>295194-C-WestConnex : 2025-12-25 07:33:16</td>
<td colspan="2">6.78 0.68 7.46</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547450</td>
<td>295194-C-WestConnex : 2025-12-25 09:22:29</td>
<td colspan="2">6.78 0.68 7.46</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547451</td>
<td>295194-C-Video Matching Fee : 2025-12-26 09:56:01</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547452</td>
<td>295194-C-Video Matching Fee : 2025-12-26 11:06:19</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547453</td>
<td>295194-C-M5 South West Motorway : 2025-12-26</td>
<td>5.33 0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547454</td>
<td>295194-C-M5 South West Motorway : 2025-12-26</td>
<td colspan="2">5.33 0.53 5.86</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547455</td>
<td>295194-C-Video Matching Fee : 2025-12-30 14:03:32</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547456</td>
<td>295194-C-Video Matching Fee : 2025-12-30 09:14:09</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547457</td>
<td>295194-C-M5 South West Motorway : 2025-12-30</td>
<td colspan="2">5.33 0.53 5.86</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547458</td>
<td>295194-C-M5 South West Motorway : 2025-12-30</td>
<td colspan="2">5.33 0.53 5.86</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547459</td>
<td>295194-C-Video Matching Fee : 2025-12-31 12:02:36</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547460</td>
<td>295194-C-Video Matching Fee : 2025-12-31 10:40:54</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547461</td>
<td>295194-C-M5 South West Motorway : 2025-12-31</td>
<td colspan="2">5.33 0.53 5.86</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547462</td>
<td>295194-C-M5 South West Motorway : 2025-12-31</td>
<td colspan="2">5.33 0.53 5.86</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547463</td>
<td>295194-C-Video Matching Fee:2026-01-01 18:16:16</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547464</td>
<td>295194-C-Video Matching Fee:2026-01-01 18:31:06</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547465</td>
<td>295194-C-Video Matching Fee:2026-01-01 18:42:11</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547466</td>
<td>295194-C-Video Matching Fee:2026-01-01 13:04:03</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547467</td>
<td>295194-C-Video Matching Fee:2026-01-01 13:09:32</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 105 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547468</td>
<td>295194-C-Video Matching Fee:2026-01-01 13:25:44</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547469</td>
<td>295194-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-01</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547470</td>
<td>295194-C-M5 South West Motorway:2026-01-01 18:42:11</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547471</td>
<td>295194-C-M5 South West Motorway:2026-01-01 13:04:03</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547472</td>
<td>295194-C-WestConnex:2026-01-01 13:09:32</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547473</td>
<td>295194-C-WestConnex:2026-01-01 18:31:06</td>
<td>8.32</td>
<td>0.83</td>
<td>9.15</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547474</td>
<td>295194-C-Eastern Distributor:2026-01-01 13:25:44</td>
<td>9.33</td>
<td>0.93</td>
<td>10.26</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547475</td>
<td>295194-C-Video Matching Fee:2026-01-02 09:03:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547476</td>
<td>295194-C-Video Matching Fee:2026-01-02 12:59:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547477</td>
<td>295194-C-M5 South West Motorway:2026-01-02 09:03:20</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547478</td>
<td>295194-C-M5 South West Motorway:2026-01-02 12:59:02</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547479</td>
<td>295194-C-Video Matching Fee:2026-01-03 14:36:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547480</td>
<td>295194-C-Video Matching Fee:2026-01-03 15:56:15</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547481</td>
<td>295194-C-Video Matching Fee:2026-01-03 14:42:25</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547482</td>
<td>295194-C-Video Matching Fee:2026-01-03 15:37:17</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547483</td>
<td>295194-C-M5 South West Motorway:2026-01-03 14:36:20</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547484</td>
<td>295194-C-M5 South West Motorway:2026-01-03 15:56:15</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547485</td>
<td>295194-C-WestLink M7:2026-01-03 14:42:25</td>
<td>9.28</td>
<td>0.93</td>
<td>10.21</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547486</td>
<td>295194-C-WestLink M7:2026-01-03 15:37:17</td>
<td>9.28</td>
<td>0.93</td>
<td>10.21</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547487</td>
<td>295194-C-Video Matching Fee:2026-01-05 16:42:51</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547488</td>
<td>295194-C-Video Matching Fee:2026-01-05 06:40:23</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547489</td>
<td>295194-C-Video Matching Fee:2026-01-05 15:35:12</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547490</td>
<td>295194-C-Video Matching Fee:2026-01-05 06:46:38</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547491</td>
<td>295194-C-Video Matching Fee:2026-01-05 08:10:14</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547492</td>
<td>295194-C-WestLink M7:2026-01-05 06:46:38</td>
<td>2.54</td>
<td>0.25</td>
<td>2.79</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547493</td>
<td>295194-C-WestLink M7:2026-01-05 15:35:12</td>
<td>4.42</td>
<td>0.44</td>
<td>4.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547494</td>
<td>295194-C-M5 South West Motorway:2026-01-05 06:40:23</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547495</td>
<td>295194-C-M5 South West Motorway:2026-01-05 16:42:51</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547496</td>
<td>295194-C-WestLink M7:2026-01-05 08:10:14</td>
<td>7.25</td>
<td>0.73</td>
<td>7.98</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547497</td>
<td>295194-C-Video Matching Fee:2026-01-06 11:14:18</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547498</td>
<td>295194-C-Video Matching Fee:2026-01-06 14:36:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547499</td>
<td>295194-C-Video Matching Fee:2026-01-06 11:20:36</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547500</td>
<td>295194-C-Video Matching Fee:2026-01-06 14:17:24</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 106 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547501</td>
<td>295194-C-M5 South West Motorway:2026-01-06 11:14:18</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547502</td>
<td>295194-C-M5 South West Motorway:2026-01-06 14:36:16</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547503</td>
<td>295194-C-WestLink M7:2026-01-06 11:20:36</td>
<td>6.95</td>
<td>0.70</td>
<td>7.65</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547504</td>
<td>295194-C-WestLink M7:2026-01-06 14:17:24</td>
<td>8.65</td>
<td>0.87</td>
<td>9.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547505</td>
<td>295194-C-Video Matching Fee:2026-01-07 06:26:40</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547506</td>
<td>295194-C-Video Matching Fee:2026-01-07 14:57:59</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547507</td>
<td>295194-C-Video Matching Fee:2026-01-07 14:41:22</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547508</td>
<td>295194-C-Video Matching Fee:2026-01-07 06:32:46</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547509</td>
<td>295194-C-M5 South West Motorway:2026-01-07 06:26:40</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547510</td>
<td>295194-C-M5 South West Motorway:2026-01-07 14:57:59</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547511</td>
<td>295194-C-WestLink M7:2026-01-07 14:41:22</td>
<td>6.95</td>
<td>0.70</td>
<td>7.65</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547512</td>
<td>295194-C-WestLink M7:2026-01-07 06:32:46</td>
<td>6.95</td>
<td>0.70</td>
<td>7.65</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547513</td>
<td>295194-C-Video Matching Fee:2026-01-08 06:18:27</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547514</td>
<td>295194-C-Video Matching Fee:2026-01-08 18:29:45</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547515</td>
<td>295194-C-Video Matching Fee:2026-01-08 14:47:05</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547516</td>
<td>295194-C-Video Matching Fee:2026-01-08 06:24:42</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547517</td>
<td>295194-C-M5 South West Motorway:2026-01-08 06:18:27</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547518</td>
<td>295194-C-M5 South West Motorway:2026-01-08 18:29:45</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547519</td>
<td>295194-C-WestLink M7:2026-01-08 06:24:42</td>
<td>6.95</td>
<td>0.70</td>
<td>7.65</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547520</td>
<td>295194-C-WestLink M7:2026-01-08 14:47:05</td>
<td>8.65</td>
<td>0.87</td>
<td>9.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547521</td>
<td>295194-C-Video Matching Fee:2026-01-12 11:17:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547522</td>
<td>295194-C-Video Matching Fee:2026-01-12 15:47:02</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547523</td>
<td>295194-C-Video Matching Fee:2026-01-12 15:26:10</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547524</td>
<td>295194-C-Video Matching Fee:2026-01-12 11:23:45</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547525</td>
<td>295194-C-M5 South West Motorway:2026-01-12 11:17:34</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547526</td>
<td>295194-C-M5 South West Motorway:2026-01-12 15:47:02</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547527</td>
<td>295194-C-WestLink M7:2026-01-12 11:23:45</td>
<td>8.65</td>
<td>0.87</td>
<td>9.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547528</td>
<td>295194-C-WestLink M7:2026-01-12 15:26:10</td>
<td>8.65</td>
<td>0.87</td>
<td>9.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547529</td>
<td>295194-C-Video Matching Fee:2026-01-13 14:38:23</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547530</td>
<td>295194-C-Video Matching Fee:2026-01-13 06:23:26</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547531</td>
<td>295194-C-Video Matching Fee:2026-01-13 14:22:33</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547532</td>
<td>295194-C-Video Matching Fee:2026-01-13 06:29:51</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547533</td>
<td>295194-C-M5 South West Motorway:2026-01-13 06:23:26</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 107 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th colspan="3" rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547534</td>
<td>295194-C-M5 South West Motorway:2026-01-13 14:38:23</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547535</td>
<td>295194-C-WestLink M7:2026-01-13 14:22:33</td>
<td>6.95</td>
<td>0.70</td>
<td>7.65</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547536</td>
<td>295194-C-WestLink M7:2026-01-13 06:29:51</td>
<td>6.95</td>
<td>0.70</td>
<td>7.65</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547537</td>
<td>295194-C-Video Matching Fee:2026-01-15 06:41:14</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547538</td>
<td>295194-C-Video Matching Fee:2026-01-15 15:15:10</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547539</td>
<td>295194-C-Video Matching Fee:2026-01-15 06:47:45</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547540</td>
<td>295194-C-Video Matching Fee:2026-01-15 14:40:46</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547541</td>
<td>295194-C-Video Matching Fee:2026-01-15 15:06:28</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547542</td>
<td>295194-C-WestLink M7:2026-01-15 15:06:28</td>
<td>2.54</td>
<td>0.25</td>
<td>2.79</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547543</td>
<td>295194-C-M5 South West Motorway:2026-01-15 06:41:14</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547544</td>
<td>295194-C-M5 South West Motorway:2026-01-15 15:15:10</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547545</td>
<td>295194-C-WestLink M7:2026-01-15 14:40:46</td>
<td>6.12</td>
<td>0.61</td>
<td>6.73</td>
</tr>
<tr>
<td>NSW</td>
<td>DK80ZT</td>
<td>ISUZU RG MY23 D-MAX SX CR</td>
<td>Mario Hans</td>
<td>4843547546</td>
<td>295194-C-WestLink M7:2026-01-15 06:47:45</td>
<td>8.65</td>
<td>0.87</td>
<td>9.52</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551401</td>
<td>306158-C-Video Matching Fee : 2025-12-16 06:53:15</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551402</td>
<td>306158-C-Eastern Distributor : 2025-12-16 06:53:15</td>
<td>9.24</td>
<td>0.92</td>
<td>10.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551403</td>
<td>306158-C-Video Matching Fee : 2025-12-17 08:33:29</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551404</td>
<td>306158-C-Video Matching Fee : 2025-12-17 09:55:33</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551405</td>
<td>306158-C-WestConnex : 2025-12-17 09:55:33</td>
<td>5.90</td>
<td>0.59</td>
<td>6.49</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551406</td>
<td>306158-C-WestConnex : 2025-12-17 08:33:29</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551407</td>
<td>306158-C-Video Matching Fee : 2025-12-18 08:49:22</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551408</td>
<td>306158-C-Video Matching Fee : 2025-12-18 15:17:24</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551409</td>
<td>306158-C-Video Matching Fee : 2025-12-18 09:13:01</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551410</td>
<td>306158-C-WestLink M7 : 2025-12-18 09:13:01</td>
<td>7.62</td>
<td>0.76</td>
<td>8.38</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551411</td>
<td>306158-C-WestConnex : 2025-12-18 08:49:22</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551412</td>
<td>306158-C-WestConnex : 2025-12-18 15:17:24</td>
<td>11.14</td>
<td>1.11</td>
<td>12.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551413</td>
<td>306158-C-Video Matching Fee : 2025-12-19 11:34:19</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551414</td>
<td>306158-C-Video Matching Fee : 2025-12-19 11:37:32</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551415</td>
<td>306158-C-Video Matching Fee : 2025-12-19 11:44:57</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551416</td>
<td>306158-C-Video Matching Fee : 2025-12-19 07:35:57</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551417</td>
<td>306158-C-Video Matching Fee : 2025-12-19 07:56:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551418</td>
<td>306158-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-19</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551419</td>
<td>306158-C-Lane Cove Tunnel : 2025-12-19 07:56:16</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
<tr>
<td colspan="2">NSW DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551420</td>
<td>306158-C-Lane Cove Tunnel : 2025-12-19 11:37:32</td>
<td>3.78</td>
<td>0.38</td>
<td>4.16</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 108 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551421</td>
<td>306158-C-WestConnex : 2025-12-19 07:35:57</td>
<td>4.54</td>
<td>0.45</td>
<td>4.99</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551422</td>
<td>306158-C-Hills M2 : 2025-12-19 11:34:19</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551423</td>
<td>306158-C-Video Matching Fee : 2025-12-23 09:43:48</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551424</td>
<td>306158-C-Video Matching Fee : 2025-12-23 09:52:26</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551425</td>
<td>306158-C-Video Matching Fee : 2025-12-23 10:24:26</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551426</td>
<td>306158-C-Video Matching Fee : 2025-12-23 10:30:40</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551427</td>
<td>306158-C-WestConnex : 2025-12-23 09:43:48</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551428</td>
<td>306158-C-M5 South West Motorway : 2025-12-23</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551429</td>
<td>306158-C-M5 South West Motorway : 2025-12-23</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551430</td>
<td>306158-C-WestConnex : 2025-12-23 10:30:40</td>
<td>8.00</td>
<td>0.80</td>
<td>8.80</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551431</td>
<td>306158-C-Video Matching Fee : 2025-12-27 14:18:26</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551432</td>
<td>306158-C-Eastern Distributor : 2025-12-27 14:18:26</td>
<td>9.24</td>
<td>0.92</td>
<td>10.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551433</td>
<td>306158-C-Video Matching Fee : 2025-12-30 17:46:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551434</td>
<td>306158-C-WestConnex : 2025-12-30 17:46:20</td>
<td>3.50</td>
<td>0.35</td>
<td>3.85</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551435</td>
<td>306158-C-Video Matching Fee:2026-01-06 13:00:01</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551436</td>
<td>306158-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-06</td>
<td>4.01</td>
<td>0.40</td>
<td>4.41</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551437</td>
<td>306158-C-Eastern Distributor:2026-01-06 13:00:01</td>
<td>9.33</td>
<td>0.93</td>
<td>10.26</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551438</td>
<td>306158-C-Video Matching Fee:2026-01-11 14:35:11</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551439</td>
<td>306158-C-M5 South West Motorway:2026-01-11 14:35:11</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551440</td>
<td>306158-C-Video Matching Fee:2026-01-12 12:38:11</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551441</td>
<td>306158-C-Video Matching Fee:2026-01-12 14:36:14</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551442</td>
<td>306158-C-Video Matching Fee:2026-01-12 15:38:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551443</td>
<td>306158-C-Video Matching Fee:2026-01-12 15:44:42</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551444</td>
<td>306158-C-WestConnex:2026-01-12 15:44:42</td>
<td>3.64</td>
<td>0.36</td>
<td>4.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551445</td>
<td>306158-C-WestConnex:2026-01-12 12:38:11</td>
<td>4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551446</td>
<td>306158-C-M5 South West Motorway:2026-01-12 14:36:14</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551447</td>
<td>306158-C-M5 South West Motorway:2026-01-12 15:38:34</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551448</td>
<td>306158-C-Video Matching Fee:2026-01-15 09:40:21</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO39FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Ben Hamlat</td>
<td>4843551449</td>
<td>306158-C-WestConnex:2026-01-15 09:40:21</td>
<td>11.58</td>
<td>1.16</td>
<td>12.74</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551501</td>
<td>309350-C-Video Matching Fee : 2025-12-08 17:10:13</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551502</td>
<td>309350-C-WestLink M7 : 2025-12-08 17:10:13</td>
<td>0.79</td>
<td>0.08</td>
<td>0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551503</td>
<td>309350-C-Video Matching Fee : 2025-12-16 05:33:21</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551504</td>
<td>309350-C-Video Matching Fee : 2025-12-16 05:33:30</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 109 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2" rowspan="2">Customer No. AU1166479</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th colspan="2" rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th>31 January 2026</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td colspan="2">Net GST Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551505</td>
<td>309350-C-Video Matching Fee : 2025-12-16 16:07:42</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551506</td>
<td>309350-C-Video Matching Fee : 2025-12-16 16:07:53</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551507</td>
<td>309350-C-Video Matching Fee : 2025-12-16 05:38:41</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551508</td>
<td>309350-C-Video Matching Fee : 2025-12-16 15:45:00</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551509</td>
<td>309350-C-Hills M2 : 2025-12-16 05:33:30</td>
<td colspan="2">4.66 0.47 5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551510</td>
<td>309350-C-Hills M2 : 2025-12-16 16:07:42</td>
<td colspan="2">4.66 0.47 5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551511</td>
<td>309350-C-WestLink M7 : 2025-12-16 05:38:41</td>
<td colspan="2">9.25 0.93 10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551512</td>
<td>309350-C-WestLink M7 : 2025-12-16 15:45:00</td>
<td colspan="2">9.25 0.93 10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551513</td>
<td>309350-C-North Connex : 2025-12-16 05:33:21</td>
<td colspan="2">9.32 0.93 10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551514</td>
<td>309350-C-North Connex : 2025-12-16 16:07:53</td>
<td colspan="2">9.32 0.93 10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551515</td>
<td>309350-C-Video Matching Fee : 2025-12-17 04:59:48</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551516</td>
<td>309350-C-Video Matching Fee : 2025-12-17 04:59:57</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551517</td>
<td>309350-C-Video Matching Fee : 2025-12-17 16:30:21</td>
<td>0.50 0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551518</td>
<td>309350-C-Video Matching Fee : 2025-12-17 16:30:34</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551519</td>
<td>309350-C-Video Matching Fee : 2025-12-17 05:05:07</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551520</td>
<td>309350-C-Video Matching Fee : 2025-12-17 16:24:04</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551521</td>
<td>309350-C-WestLink M7 : 2025-12-17 16:24:04</td>
<td colspan="2">0.79 0.08 0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551522</td>
<td>309350-C-Hills M2 : 2025-12-17 04:59:57</td>
<td colspan="2">4.66 0.47 5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551523</td>
<td>309350-C-Hills M2 : 2025-12-17 16:30:21</td>
<td colspan="2">4.66 0.47 5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551524</td>
<td>309350-C-WestLink M7 : 2025-12-17 05:05:07</td>
<td colspan="2">9.25 0.93 10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551525</td>
<td>309350-C-North Connex : 2025-12-17 04:59:48</td>
<td colspan="2">9.32 0.93 10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551526</td>
<td>309350-C-NorthConnex : 2025-12-17 16:30:34</td>
<td colspan="2">9.32 0.93 10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551527</td>
<td>309350-C-Video Matching Fee : 2025-12-18 06:56:11</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551528</td>
<td>309350-C-Video Matching Fee : 2025-12-18 06:56:20</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551529</td>
<td>309350-C-Video Matching Fee : 2025-12-18 14:24:51</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551530</td>
<td>309350-C-Video Matching Fee : 2025-12-18 14:25:01</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551531</td>
<td>309350-C-Video Matching Fee : 2025-12-18 07:01:21</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551532</td>
<td>309350-C-Video Matching Fee : 2025-12-18 09:55:01</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551533</td>
<td>309350-C-Video Matching Fee : 2025-12-18 14:19:04</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551534</td>
<td>309350-C-WestLink M7 : 2025-12-18 14:19:04</td>
<td colspan="2">0.79 0.08 0.87</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551535</td>
<td>309350-C-Hills M2 : 2025-12-18 06:56:20</td>
<td colspan="2">4.66 0.47 5.13</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551536</td>
<td>309350-C-Hills M2 : 2025-12-18 14:24:51</td>
<td colspan="2">4.66 0.47 5.13</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551537</td>
<td>309350-C-WestLink M7 : 2025-12-18 09:55:01</td>
<td colspan="2">7.15 0.72 7.87</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 110 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th colspan="2" rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td colspan="2">Net GST Total</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551538</td>
<td>309350-C-WestLink M7 : 2025-12-18 07:01:21</td>
<td colspan="2">9.25 0.93 10.18</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551539</td>
<td>309350-C-North Connex : 2025-12-18 06:56:11</td>
<td colspan="2">9.32 0.93 10.25</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551540</td>
<td>309350-C-North Connex : 2025-12-18 14:25:01</td>
<td colspan="2">9.32 0.93 10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551541</td>
<td>309350-C-Video Matching Fee : 2025-12-19 05:13:47</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551542</td>
<td>309350-C-Video Matching Fee : 2025-12-19 05:13:56</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551543</td>
<td>309350-C-Video Matching Fee : 2025-12-19 14:24:29</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551544</td>
<td>309350-C-Video Matching Fee : 2025-12-19 14:24:39</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551545</td>
<td>309350-C-Video Matching Fee : 2025-12-19 05:19:14</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551546</td>
<td>309350-C-Video Matching Fee : 2025-12-19 14:05:20</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551547</td>
<td>309350-C-Hills M2 : 2025-12-19 05:13:56</td>
<td colspan="2">4.66 0.47 5.13</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551548</td>
<td>309350-C-Hills M2 : 2025-12-19 14:24:29</td>
<td colspan="2">4.66 0.47 5.13</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551549</td>
<td>309350-C-WestLink M7 : 2025-12-19 05:19:14</td>
<td colspan="2">9.25 0.93 10.18</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551550</td>
<td>309350-C-WestLink M7 : 2025-12-19 14:05:20</td>
<td colspan="2">9.25 0.93 10.18</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551551</td>
<td>309350-C-North Connex : 2025-12-19 05:13:47</td>
<td colspan="2">9.32 0.93 10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551552</td>
<td>309350-C-North Connex : 2025-12-19 14:24:39</td>
<td colspan="2">9.32 0.93 10.25</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551553</td>
<td>309350-C-Video Matching Fee : 2025-12-20 05:10:27</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551554</td>
<td>309350-C-Video Matching Fee : 2025-12-20 05:10:36</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551555</td>
<td>309350-C-Video Matching Fee : 2025-12-20 12:07:59</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551556</td>
<td>309350-C-Video Matching Fee : 2025-12-20 05:15:48</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551557</td>
<td>309350-C-Video Matching Fee : 2025-12-20 11:48:25</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551558</td>
<td>309350-C-Hills M2 : 2025-12-20 05:10:36</td>
<td colspan="2">4.66 0.47 5.13</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551559</td>
<td>309350-C-Hills M2 : 2025-12-20 12:07:59</td>
<td colspan="2">4.66 0.47 5.13</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551560</td>
<td>309350-C-WestLink M7 : 2025-12-20 05:15:48</td>
<td colspan="2">9.25 0.93 10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551561</td>
<td>309350-C-WestLink M7 : 2025-12-20 11:48:25</td>
<td colspan="2">9.25 0.93 10.18</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551562</td>
<td>309350-C-NorthConnex : 2025-12-20 05:10:27</td>
<td colspan="2">9.32 0.93 10.25</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551563</td>
<td>309350-C-Video Matching Fee : 2025-12-21 10:12:59</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551564</td>
<td>309350-C-Video Matching Fee : 2025-12-21 10:13:09</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551565</td>
<td>309350-C-Video Matching Fee : 2025-12-21 17:56:24</td>
<td colspan="2">0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551566</td>
<td>309350-C-Video Matching Fee : 2025-12-21 17:56:33</td>
<td>0.50 0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551567</td>
<td>309350-C-Video Matching Fee : 2025-12-21 10:18:13</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551568</td>
<td>309350-C-Video Matching Fee : 2025-12-21 11:07:32</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551569</td>
<td>309350-C-Video Matching Fee : 2025-12-21 17:38:35</td>
<td colspan="2">0.68 0.07 0.75</td>
</tr>
<tr>
<td colspan="2">NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551570</td>
<td>309350-C-WestLink M7 : 2025-12-21 11:07:32</td>
<td colspan="2">2.30 0.23 2.53</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 111 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th colspan="2"></th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551571</td>
<td>309350-C-Hills M2 : 2025-12-21 10:13:09</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551572</td>
<td>309350-C-Hills M2 : 2025-12-21 17:56:24</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551573</td>
<td>309350-C-WestLink M7 : 2025-12-21 17:38:35</td>
<td>9.09</td>
<td>0.91</td>
<td>10.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551574</td>
<td>309350-C-WestLink M7 : 2025-12-21 10:18:13</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551575</td>
<td>309350-C-North Connex : 2025-12-21 10:12:59</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551576</td>
<td>309350-C-North Connex : 2025-12-21 17:56:33</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551577</td>
<td>309350-C-Video Matching Fee : 2025-12-22 05:53:10</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551578</td>
<td>309350-C-Video Matching Fee : 2025-12-22 05:53:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551579</td>
<td>309350-C-Video Matching Fee : 2025-12-22 14:51:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551580</td>
<td>309350-C-Video Matching Fee : 2025-12-22 14:51:27</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551581</td>
<td>309350-C-Video Matching Fee : 2025-12-22 05:58:30</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551582</td>
<td>309350-C-Video Matching Fee : 2025-12-22 11:23:38</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551583</td>
<td>309350-C-Video Matching Fee : 2025-12-22 12:11:31</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551584</td>
<td>309350-C-Video Matching Fee : 2025-12-22 14:31:55</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551585</td>
<td>309350-C-WestLink M7 : 2025-12-22 11:23:38</td>
<td>4.19</td>
<td>0.42</td>
<td>4.61</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551586</td>
<td>309350-C-WestLink M7 : 2025-12-22 12:11:31</td>
<td>4.19</td>
<td>0.42</td>
<td>4.61</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551587</td>
<td>309350-C-Hills M2 : 2025-12-22 05:53:20</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551588</td>
<td>309350-C-Hills M2 : 2025-12-22 14:51:16</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551589</td>
<td>309350-C-WestLink M7 : 2025-12-22 05:58:30</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551590</td>
<td>309350-C-WestLink M7 : 2025-12-22 14:31:55</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551591</td>
<td>309350-C-North Connex : 2025-12-22 05:53:10</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551592</td>
<td>309350-C-North Connex : 2025-12-22 14:51:27</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551593</td>
<td>309350-C-Video Matching Fee : 2025-12-23 05:23:06</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551594</td>
<td>309350-C-Video Matching Fee : 2025-12-23 05:23:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551595</td>
<td>309350-C-Video Matching Fee : 2025-12-23 15:54:34</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551596</td>
<td>309350-C-Video Matching Fee : 2025-12-23 15:54:44</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551597</td>
<td>309350-C-Video Matching Fee : 2025-12-23 05:28:23</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551598</td>
<td>309350-C-Video Matching Fee : 2025-12-23 15:35:04</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551599</td>
<td>309350-C-Hills M2 : 2025-12-23 05:23:16</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551600</td>
<td>309350-C-Hills M2 : 2025-12-23 15:54:34</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551601</td>
<td>309350-C-WestLink M7 : 2025-12-23 05:28:23</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551602</td>
<td>309350-C-WestLink M7 : 2025-12-23 15:35:04</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551603</td>
<td>309350-C-North Connex : 2025-12-23 05:23:06</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 112 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th>Customer No.</th>
<th>Invoice Date</th>
<th rowspan="2">Invoice No. AIN00014651</th>
<th rowspan="2"></th>
<th rowspan="2"></th>
<th rowspan="2">P</th>
</tr>
<tr>
<th>AU1166479</th>
<th>31 January 2026</th>
</tr>
<tr>
<td>State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net GST Total</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551604</td>
<td>309350-C-North Connex : 2025-12-23 15:54:44</td>
<td>9.32 0.93 10.25</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551605</td>
<td>309350-C-Video Matching Fee : 2025-12-24 06:03:52</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551606</td>
<td>309350-C-Video Matching Fee : 2025-12-24 06:04:02</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551607</td>
<td>309350-C-Video Matching Fee : 2025-12-24 12:07:23</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551608</td>
<td>309350-C-Video Matching Fee : 2025-12-24 12:07:33</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551609</td>
<td>309350-C-Video Matching Fee : 2025-12-24 06:09:10</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551610</td>
<td>309350-C-Video Matching Fee : 2025-12-24 11:45:00</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551611</td>
<td>309350-C-Hills M2 : 2025-12-24 06:04:02</td>
<td>4.66 0.47 5.13</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551612</td>
<td>309350-C-Hills M2 : 2025-12-24 12:07:23</td>
<td>4.66 0.47 5.13</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551613</td>
<td>309350-C-WestLink M7 : 2025-12-24 06:09:10</td>
<td>9.25 0.93 10.18</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551614</td>
<td>309350-C-WestLink M7 : 2025-12-24 11:45:00</td>
<td>9.25 0.93 10.18</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551615</td>
<td>309350-C-North Connex : 2025-12-24 06:03:52</td>
<td>9.32 0.93 10.25</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551616</td>
<td>309350-C-North Connex : 2025-12-24 12:07:33</td>
<td>9.32 0.93 10.25</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551617</td>
<td>309350-C-Video Matching Fee : 2025-12-25 12:08:43</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551618</td>
<td>309350-C-Video Matching Fee : 2025-12-25 12:08:55</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551619</td>
<td>309350-C-Video Matching Fee : 2025-12-25 11:44:23</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551620</td>
<td>309350-C-Hills M2 : 2025-12-25 12:08:43</td>
<td>4.66 0.47 5.13</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551621</td>
<td>309350-C-WestLink M7 : 2025-12-25 11:44:23</td>
<td>9.09 0.91 10.00</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551622</td>
<td>309350-C-North Connex : 2025-12-25 12:08:55</td>
<td>9.32 0.93 10.25</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551623</td>
<td>309350-C-Video Matching Fee : 2025-12-28 11:17:33</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551624</td>
<td>309350-C-Video Matching Fee : 2025-12-28 11:17:43</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551625</td>
<td>309350-C-Video Matching Fee : 2025-12-28 16:14:02</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551626</td>
<td>309350-C-Video Matching Fee : 2025-12-28 16:14:12</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551627</td>
<td>309350-C-Video Matching Fee : 2025-12-28 11:23:01</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551628</td>
<td>309350-C-Video Matching Fee : 2025-12-28 15:56:06</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551629</td>
<td>309350-C-Hills M2 : 2025-12-28 11:17:43</td>
<td>4.66 0.47 5.13</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551630</td>
<td>309350-C-Hills M2 : 2025-12-28 16:14:02</td>
<td>4.66 0.47 5.13</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551631</td>
<td>309350-C-WestLink M7 : 2025-12-28 11:23:01</td>
<td>9.09 0.91 10.00</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551632</td>
<td>309350-C-WestLink M7 : 2025-12-28 15:56:06</td>
<td>9.09 0.91 10.00</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551633</td>
<td>309350-C-North Connex : 2025-12-28 11:17:33</td>
<td>9.32 0.93 10.25</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551634</td>
<td>309350-C-North Connex : 2025-12-28 16:14:12</td>
<td>9.32 0.93 10.25</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551635</td>
<td>309350-C-Video Matching Fee : 2025-12-29 05:07:32</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551636</td>
<td>309350-C-Video Matching Fee : 2025-12-29 05:07:41</td>
<td>0.50 0.05 0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 113 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th></th>
<th></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551637</td>
<td>309350-C-Video Matching Fee : 2025-12-29 16:46:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551638</td>
<td>309350-C-Video Matching Fee : 2025-12-29 16:46:31</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551639</td>
<td>309350-C-Video Matching Fee : 2025-12-29 05:12:51</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551640</td>
<td>309350-C-Video Matching Fee : 2025-12-29 16:26:41</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551641</td>
<td>309350-C-Hills M2 : 2025-12-29 05:07:41</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551642</td>
<td>309350-C-Hills M2 : 2025-12-29 16:46:20</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551643</td>
<td>309350-C-WestLink M7 : 2025-12-29 05:12:51</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551644</td>
<td>309350-C-WestLink M7 : 2025-12-29 16:26:41</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551645</td>
<td>309350-C-North Connex : 2025-12-29 05:07:32</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551646</td>
<td>309350-C-North Connex : 2025-12-29 16:46:31</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551647</td>
<td>309350-C-Video Matching Fee : 2025-12-30 05:33:11</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551648</td>
<td>309350-C-Video Matching Fee : 2025-12-30 05:33:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551649</td>
<td>309350-C-Video Matching Fee : 2025-12-30 14:57:41</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551650</td>
<td>309350-C-Video Matching Fee : 2025-12-30 14:57:52</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551651</td>
<td>309350-C-WestLink M7 : 2025-12-30 13:59:13</td>
<td>0.63</td>
<td>0.06</td>
<td>0.69</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551652</td>
<td>309350-C-Video Matching Fee : 2025-12-30 05:38:23</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551653</td>
<td>309350-C-Video Matching Fee : 2025-12-30 06:07:38</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551654</td>
<td>309350-C-Video Matching Fee : 2025-12-30 06:11:59</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551655</td>
<td>309350-C-Video Matching Fee : 2025-12-30 13:59:13</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551656</td>
<td>309350-C-Video Matching Fee : 2025-12-30 14:40:02</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551657</td>
<td>309350-C-WestLink M7 : 2025-12-30 06:11:59</td>
<td>1.69</td>
<td>0.17</td>
<td>1.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551658</td>
<td>309350-C-WestLink M7 : 2025-12-30 06:07:38</td>
<td>2.15</td>
<td>0.22</td>
<td>2.37</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551659</td>
<td>309350-C-Hills M2 : 2025-12-30 05:33:20</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551660</td>
<td>309350-C-Hills M2 : 2025-12-30 14:57:41</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551661</td>
<td>309350-C-WestLink M7 : 2025-12-30 14:40:02</td>
<td>9.09</td>
<td>0.91</td>
<td>10.00</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551662</td>
<td>309350-C-WestLink M7 : 2025-12-30 05:38:23</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551663</td>
<td>309350-C-North Connex : 2025-12-30 05:33:11</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551664</td>
<td>309350-C-North Connex : 2025-12-30 14:57:52</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551665</td>
<td>309350-C-Video Matching Fee : 2025-12-31 05:38:11</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551666</td>
<td>309350-C-Video Matching Fee : 2025-12-31 05:38:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551667</td>
<td>309350-C-Video Matching Fee : 2025-12-31 12:01:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551668</td>
<td>309350-C-Video Matching Fee : 2025-12-31 12:02:05</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551669</td>
<td>309350-C-Video Matching Fee : 2025-12-31 05:43:27</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 114 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th></th>
<th></th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551670</td>
<td>309350-C-Video Matching Fee : 2025-12-31 11:42:30</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551671</td>
<td>309350-C-Hills M2 : 2025-12-31 05:38:20</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551672</td>
<td>309350-C-Hills M2 : 2025-12-31 12:01:55</td>
<td>4.66</td>
<td>0.47</td>
<td>5.13</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551673</td>
<td>309350-C-WestLink M7 : 2025-12-31 05:43:27</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551674</td>
<td>309350-C-WestLink M7 : 2025-12-31 11:42:30</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551675</td>
<td>309350-C-North Connex : 2025-12-31 05:38:11</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551676</td>
<td>309350-C-North Connex : 2025-12-31 12:02:05</td>
<td>9.32</td>
<td>0.93</td>
<td>10.25</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551677</td>
<td>309350-C-Video Matching Fee:2026-01-05 05:31:10</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551678</td>
<td>309350-C-Video Matching Fee:2026-01-05 05:31:20</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551679</td>
<td>309350-C-Video Matching Fee:2026-01-05 19:12:40</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551680</td>
<td>309350-C-Video Matching Fee:2026-01-05 05:36:26</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551681</td>
<td>309350-C-Video Matching Fee:2026-01-05 08:34:55</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551682</td>
<td>309350-C-Video Matching Fee:2026-01-05 11:33:05</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551683</td>
<td>309350-C-Video Matching Fee:2026-01-05 17:21:42</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551684</td>
<td>309350-C-Video Matching Fee:2026-01-05 17:26:59</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551685</td>
<td>309350-C-WestLink M7:2026-01-05 17:26:59</td>
<td>2.17</td>
<td>0.22</td>
<td>2.39</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551686</td>
<td>309350-C-WestLink M7:2026-01-05 17:21:42</td>
<td>2.81</td>
<td>0.28</td>
<td>3.09</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551687</td>
<td>309350-C-Hills M2:2026-01-05 05:31:20</td>
<td>4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551688</td>
<td>309350-C-WestLink M7:2026-01-05 08:34:55</td>
<td>8.35</td>
<td>0.84</td>
<td>9.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551689</td>
<td>309350-C-WestLink M7:2026-01-05 11:33:05</td>
<td>8.35</td>
<td>0.84</td>
<td>9.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551690</td>
<td>309350-C-WestLink M7:2026-01-05 05:36:26</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551691</td>
<td>309350-C-North Connex:2026-01-05 05:31:10</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551692</td>
<td>309350-C-North Connex:2026-01-05 19:12:40</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551693</td>
<td>309350-C-Video Matching Fee:2026-01-06 05:43:46</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551694</td>
<td>309350-C-Video Matching Fee:2026-01-06 05:43:55</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551695</td>
<td>309350-C-Video Matching Fee:2026-01-06 16:30:37</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551696</td>
<td>309350-C-Video Matching Fee:2026-01-06 16:30:49</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551697</td>
<td>309350-C-Video Matching Fee:2026-01-06 05:49:03</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551698</td>
<td>309350-C-Video Matching Fee:2026-01-06 16:10:35</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551699</td>
<td>309350-C-Hills M2:2026-01-06 05:43:55</td>
<td>4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551700</td>
<td>309350-C-Hills M2:2026-01-06 16:30:37</td>
<td>4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551701</td>
<td>309350-C-WestLink M7:2026-01-06 05:49:03</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551702</td>
<td>309350-C-WestLink M7:2026-01-06 16:10:35</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 115 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th rowspan="2"></th>
<th rowspan="2"></th>
<th rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net GST Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551703</td>
<td>309350-C-North Connex:2026-01-06 05:43:46</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551704</td>
<td>309350-C-NorthConnex:2026-01-06 16:30:49</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551705</td>
<td>309350-C-Video Matching Fee:2026-01-07 05:37:33</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551706</td>
<td>309350-C-Video Matching Fee:2026-01-07 05:37:42</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551707</td>
<td>309350-C-Video Matching Fee:2026-01-07 16:44:00</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551708</td>
<td>309350-C-Video Matching Fee:2026-01-07 16:44:11</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551709</td>
<td>309350-C-Video Matching Fee:2026-01-07 05:42:58</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551710</td>
<td>309350-C-Video Matching Fee:2026-01-07 16:23:33</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551711</td>
<td>309350-C-Hills M2:2026-01-07 05:37:42</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551712</td>
<td>309350-C-Hills M2:2026-01-07 16:44:00</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551713</td>
<td>309350-C-WestLink M7:2026-01-07 05:42:58</td>
<td>9.36 0.94 10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551714</td>
<td>309350-C-WestLink M7:2026-01-07 16:23:33</td>
<td>9.36 0.94 10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551715</td>
<td>309350-C-North Connex:2026-01-07 05:37:33</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551716</td>
<td>309350-C-North Connex:2026-01-07 16:44:11</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551717</td>
<td>309350-C-Video Matching Fee:2026-01-08 05:59:09</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551718</td>
<td>309350-C-Video Matching Fee:2026-01-08 05:59:18</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551719</td>
<td>309350-C-Video Matching Fee:2026-01-08 14:29:09</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551720</td>
<td>309350-C-Video Matching Fee:2026-01-08 06:04:20</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551721</td>
<td>309350-C-Video Matching Fee:2026-01-08 14:09:07</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551722</td>
<td>309350-C-Hills M2:2026-01-08 05:59:18</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551723</td>
<td>309350-C-Hills M2:2026-01-08 14:29:09</td>
<td>4.72 0.47 5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551724</td>
<td>309350-C-WestLink M7:2026-01-08 06:04:20</td>
<td>9.36 0.94 10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551725</td>
<td>309350-C-WestLink M7:2026-01-08 14:09:07</td>
<td>9.36 0.94 10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551726</td>
<td>309350-C-North Connex:2026-01-08 05:59:09</td>
<td>9.45 0.95 10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551727</td>
<td>309350-C-Video Matching Fee:2026-01-09 05:42:57</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551728</td>
<td>309350-C-Video Matching Fee:2026-01-09 05:43:07</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551729</td>
<td>309350-C-Video Matching Fee:2026-01-09 14:20:02</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551730</td>
<td>309350-C-Video Matching Fee:2026-01-09 16:55:39</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551731</td>
<td>309350-C-Video Matching Fee:2026-01-09 16:55:48</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551732</td>
<td>309350-C-Video Matching Fee:2026-01-09 18:11:35</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551733</td>
<td>309350-C-Video Matching Fee:2026-01-09 18:11:46</td>
<td>0.50 0.05 0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551734</td>
<td>309350-C-Video Matching Fee:2026-01-09 05:48:07</td>
<td>0.68 0.07 0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551735</td>
<td>309350-C-Video Matching Fee:2026-01-09 14:00:57</td>
<td>0.68 0.07 0.75</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 116 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2" rowspan="2">Customer No. AU1166479</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th colspan="2" rowspan="2"></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th>31 January 2026</th>
<th>AIN00014651</th>
</tr>
<tr>
<td>State</td>
<td>Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551736</td>
<td>309350-C-Video Matching Fee:2026-01-09 17:00:58</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551737</td>
<td>309350-C-Video Matching Fee:2026-01-09 17:49:33</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551738</td>
<td>309350-C-Hills M2:2026-01-09 05:43:07</td>
<td>4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551739</td>
<td>309350-C-Hills M2:2026-01-09 14:20:02</td>
<td>4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551740</td>
<td>309350-C-Hills M2:2026-01-09 16:55:48</td>
<td>4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551741</td>
<td>309350-C-Hills M2:2026-01-09 18:11:35</td>
<td>4.72</td>
<td>0.47</td>
<td>5.19</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551742</td>
<td>309350-C-WestLink M7:2026-01-09 05:48:07</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551743</td>
<td>309350-C-WestLink M7:2026-01-09 14:00:57</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551744</td>
<td>309350-C-WestLink M7:2026-01-09 17:00:58</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551745</td>
<td>309350-C-WestLink M7:2026-01-09 17:49:33</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551746</td>
<td>309350-C-North Connex:2026-01-09 05:42:57</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551747</td>
<td>309350-C-North Connex:2026-01-09 16:55:39</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551748</td>
<td>309350-C-North Connex:2026-01-09 18:11:46</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551749</td>
<td>309350-C-Video Matching Fee:2026-01-11 08:05:00</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551750</td>
<td>309350-C-Video Matching Fee:2026-01-11 08:09:12</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551751</td>
<td>309350-C-Video Matching Fee:2026-01-11 08:12:43</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551752</td>
<td>309350-C-Video Matching Fee:2026-01-11 08:20:14</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551753</td>
<td>309350-C-Sydney Harbour Bridge &amp; Tunnel:2026-01-11</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551754</td>
<td>309350-C-Lane Cove Tunnel:2026-01-11 08:12:43</td>
<td>3.84</td>
<td>0.38</td>
<td>4.22</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551755</td>
<td>309350-C-Hills M2:2026-01-11 08:09:12</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td>NSW</td>
<td>DO40FD</td>
<td>ISUZU RG MY24 D-MAX SX CR</td>
<td>Christian Evans</td>
<td>4843551756</td>
<td>309350-C-North Connex:2026-01-11 08:05:00</td>
<td>9.45</td>
<td>0.95</td>
<td>10.40</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total for Cost Centre: Thermal</td>
<td>6,416.10</td>
<td>642.54</td>
<td>7,058.64</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">Cost Centre: Vertiv Services NSW</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>NSW</td>
<td>DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546801</td>
<td>265147-C-Video Matching Fee : 2025-12-17 08:33:53</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546802</td>
<td>265147-C-WestLink M7 : 2025-12-17 15:19:19</td>
<td>2.87</td>
<td>0.29</td>
<td>3.16</td>
</tr>
<tr>
<td>NSW</td>
<td>DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546803</td>
<td>265147-C-WestLink M7 : 2025-12-17 08:33:53</td>
<td>6.65</td>
<td>0.67</td>
<td>7.32</td>
</tr>
<tr>
<td>NSW</td>
<td>DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546804</td>
<td>265147-C-Video Matching Fee : 2025-12-19 08:46:39</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td>NSW</td>
<td>DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546805</td>
<td>265147-C-WestLink M7 : 2025-12-19 08:46:39</td>
<td>6.65</td>
<td>0.67</td>
<td>7.32</td>
</tr>
<tr>
<td>NSW</td>
<td>DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546806</td>
<td>265147-C-Video Matching Fee : 2025-12-23 16:54:19</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td>NSW</td>
<td>DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546807</td>
<td>265147-C-WestConnex : 2025-12-23 16:54:19</td>
<td>4.15</td>
<td>0.42</td>
<td>4.57</td>
</tr>
<tr>
<td>NSW</td>
<td>DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546808</td>
<td>265147-C-M5 South West Motorway : 2025-12-24</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>NSW</td>
<td>DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546809</td>
<td>265147-C-WestConnex : 2025-12-24 18:45:41</td>
<td>6.78</td>
<td>0.68</td>
<td>7.46</td>
</tr>
<tr>
<td>NSW</td>
<td>DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546810</td>
<td>265147-C-Video Matching Fee : 2025-12-25 14:20:10</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 117 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2" rowspan="2">Customer No. AU1166479</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2">P</th>
</tr>
<tr>
<th>31 January 2026</th>
<th>AIN00014651</th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546811</td>
<td>265147-C-Video Matching Fee : 2025-12-25 14:28:04</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546812</td>
<td>265147-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-25</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546813</td>
<td>265147-C-M5 South West Motorway : 2025-12-25</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546814</td>
<td>265147-C-M5 South West Motorway : 2025-12-25</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546815</td>
<td>265147-C-WestConnex : 2025-12-25 10:09:34</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546816</td>
<td>265147-C-WestConnex : 2025-12-25 14:28:04</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546817</td>
<td>265147-C-Video Matching Fee : 2025-12-28 18:53:14</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546818</td>
<td>265147-C-WestLink M7 : 2025-12-28 17:14:08</td>
<td>8.80</td>
<td>0.88</td>
<td>9.68</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546819</td>
<td>265147-C-WestLink M7 : 2025-12-28 18:53:14</td>
<td>8.80</td>
<td>0.88</td>
<td>9.68</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546820</td>
<td>265147-C-M5 South West Motorway:2026-01-01 11:39:40</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546821</td>
<td>265147-C-M5 South West Motorway:2026-01-01 15:29:32</td>
<td>5.41</td>
<td>0.54</td>
<td>5.95</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546822</td>
<td>265147-C-WestLink M7:2026-01-01 20:42:48</td>
<td>6.12</td>
<td>0.61</td>
<td>6.73</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546823</td>
<td>265147-C-WestLink M7:2026-01-01 23:11:47</td>
<td>6.12</td>
<td>0.61</td>
<td>6.73</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546824</td>
<td>265147-C-WestLink M7:2026-01-02 17:51:42</td>
<td>6.12</td>
<td>0.61</td>
<td>6.73</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546825</td>
<td>265147-C-WestLink M7:2026-01-02 18:32:09</td>
<td>6.12</td>
<td>0.61</td>
<td>6.73</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546826</td>
<td>265147-C-Video Matching Fee:2026-01-05 08:02:12</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546827</td>
<td>265147-C-WestLink M7:2026-01-05 08:02:12</td>
<td>6.72</td>
<td>0.67</td>
<td>7.39</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546828</td>
<td>265147-C-WestLink M7:2026-01-05 16:31:53</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546829</td>
<td>265147-C-Video Matching Fee:2026-01-06 18:21:25</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546830</td>
<td>265147-C-Video Matching Fee:2026-01-06 21:09:16</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546831</td>
<td>265147-C-Video Matching Fee:2026-01-06 09:23:55</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546832</td>
<td>265147-C-Video Matching Fee:2026-01-06 21:41:16</td>
<td>0.68</td>
<td>0.07</td>
<td>0.75</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546833</td>
<td>265147-C-WestConnex:2026-01-06 18:21:25</td>
<td>3.94</td>
<td>0.39</td>
<td>4.33</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546834</td>
<td>265147-C-WestConnex:2026-01-06 21:09:16</td>
<td>6.14</td>
<td>0.61</td>
<td>6.75</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546835</td>
<td>265147-C-WestLink M7:2026-01-06 09:23:55</td>
<td>6.72</td>
<td>0.67</td>
<td>7.39</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546836</td>
<td>265147-C-WestLink M7:2026-01-06 21:41:16</td>
<td>6.75</td>
<td>0.68</td>
<td>7.43</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546837</td>
<td>265147-C-WestLink M7:2026-01-12 14:41:27</td>
<td>6.75</td>
<td>0.68</td>
<td>7.43</td>
</tr>
<tr>
<td colspan="2">NSW DC72PT</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Andrew Garas</td>
<td>4843546838</td>
<td>265147-C-WestLink M7:2026-01-14 15:16:09</td>
<td>6.75</td>
<td>0.68</td>
<td>7.43</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total for Cost Centre: Vertiv Services NSW</td>
<td>180.62</td>
<td>18.09</td>
<td>198.71</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">Cost Centre: Vertiv Services Victoria</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">VIC 1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546501</td>
<td>264313-C-CityLink : 2025-12-15 11:24:13</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td colspan="2">VIC 1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546502</td>
<td>264313-C-CityLink : 2025-12-15 08:33:50</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td colspan="2">VIC 1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546503</td>
<td>264313-C-CityLink : 2025-12-16 09:36:15</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 118 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th></th>
<th></th>
<th colspan="3" rowspan="2">P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th colspan="2"></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td>VIC</td>
<td>1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546504</td>
<td>264313-C-CityLink : 2025-12-16 14:09:39</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546505</td>
<td>264313-C-CityLink : 2025-12-17 10:45:57</td>
<td>10.70</td>
<td>1.07</td>
<td>11.77</td>
</tr>
<tr>
<td>VIC</td>
<td>1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546506</td>
<td>264313-C-CityLink : 2025-12-17 09:04:31</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td>VIC</td>
<td>1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546507</td>
<td>264313-C-CityLink : 2025-12-18 14:09:35</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546508</td>
<td>264313-C-CityLink : 2025-12-18 11:49:39</td>
<td>9.51</td>
<td>0.95</td>
<td>10.46</td>
</tr>
<tr>
<td>VIC</td>
<td>1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546509</td>
<td>264313-C-CityLink : 2025-12-22 07:57:12</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546510</td>
<td>264313-C-CityLink : 2025-12-22 15:06:44</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546511</td>
<td>264313-C-CityLink : 2025-12-23 08:29:11</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546512</td>
<td>264313-C-CityLink : 2025-12-23 12:59:47</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546513</td>
<td>264313-C-CityLink : 2025-12-24 11:19:10</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546514</td>
<td>264313-C-CityLink : 2025-12-24 08:22:01</td>
<td>17.82</td>
<td>1.78</td>
<td>19.60</td>
</tr>
<tr>
<td>VIC</td>
<td>1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546515</td>
<td>264313-C-CityLink:2026-01-04 21:45:40</td>
<td>9.60</td>
<td>0.96</td>
<td>10.56</td>
</tr>
<tr>
<td>VIC</td>
<td>1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546516</td>
<td>264313-C-CityLink:2026-01-04 20:36:26</td>
<td>15.60</td>
<td>1.56</td>
<td>17.16</td>
</tr>
<tr>
<td>VIC</td>
<td>1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546517</td>
<td>264313-C-CityLink:2026-01-06 14:01:32</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>VIC</td>
<td>1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546518</td>
<td>264313-C-CityLink:2026-01-06 16:40:46</td>
<td>9.60</td>
<td>0.96</td>
<td>10.56</td>
</tr>
<tr>
<td>VIC</td>
<td>1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546519</td>
<td>264313-C-CityLink:2026-01-08 17:23:59</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td>VIC</td>
<td>1UF1DP</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Assam Karim</td>
<td>4843546520</td>
<td>264313-C-CityLink:2026-01-08 14:38:41</td>
<td>4.80</td>
<td>0.48</td>
<td>5.28</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total for Cost Centre: Vertiv Services Victoria</td>
<td>251.21</td>
<td>25.12</td>
<td>276.33</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">Cost Centre: Vertiv Services WA</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>WA</td>
<td>1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546601</td>
<td>264808-C-WestLink M7 : 2025-12-16 06:47:36</td>
<td>9.15</td>
<td>0.92</td>
<td>10.07</td>
</tr>
<tr>
<td>WA</td>
<td>1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546602</td>
<td>264808-C-WestConnex : 2025-12-17 13:07:00</td>
<td>3.07</td>
<td>0.31</td>
<td>3.38</td>
</tr>
<tr>
<td>WA</td>
<td>1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546603</td>
<td>264808-C-M5 South West Motorway : 2025-12-17</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td>WA</td>
<td>1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546604</td>
<td>264808-C-WestLink M7 : 2025-12-17 06:44:03</td>
<td>9.15</td>
<td>0.92</td>
<td>10.07</td>
</tr>
<tr>
<td>WA</td>
<td>1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546605</td>
<td>264808-C-WestLink M7 : 2025-12-18 06:12:39</td>
<td>9.15</td>
<td>0.92</td>
<td>10.07</td>
</tr>
<tr>
<td>WA</td>
<td>1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546606</td>
<td>264808-C-WestLink M7 : 2025-12-18 14:17:36</td>
<td>9.25</td>
<td>0.93</td>
<td>10.18</td>
</tr>
<tr>
<td>WA</td>
<td>1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546607</td>
<td>264808-C-WestLink M7 : 2025-12-19 06:16:22</td>
<td>8.54</td>
<td>0.85</td>
<td>9.39</td>
</tr>
<tr>
<td>WA</td>
<td>1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546608</td>
<td>264808-C-WestLink M7 : 2025-12-19 14:02:57</td>
<td>8.54</td>
<td>0.85</td>
<td>9.39</td>
</tr>
<tr>
<td>WA</td>
<td>1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546609</td>
<td>264808-C-WestLink M7 : 2025-12-20 14:39:03</td>
<td>8.54</td>
<td>0.85</td>
<td>9.39</td>
</tr>
<tr>
<td>WA</td>
<td>1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546610</td>
<td>264808-C-WestLink M7 : 2025-12-20 20:49:49</td>
<td>8.54</td>
<td>0.85</td>
<td>9.39</td>
</tr>
<tr>
<td>WA</td>
<td>1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546611</td>
<td>264808-C-WestLink M7 : 2025-12-22 08:39:10</td>
<td>8.54</td>
<td>0.85</td>
<td>9.39</td>
</tr>
<tr>
<td>WA</td>
<td>1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546612</td>
<td>264808-C-WestLink M7 : 2025-12-22 14:28:06</td>
<td>8.54</td>
<td>0.85</td>
<td>9.39</td>
</tr>
<tr>
<td colspan="2">WA 1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546613</td>
<td>264808-C-Sydney Harbour Bridge &amp; Tunnel : 2025-12-23</td>
<td>3.00</td>
<td>0.30</td>
<td>3.30</td>
</tr>
<tr>
<td colspan="2">WA 1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546614</td>
<td>264808-C-M5 South West Motorway : 2025-12-23</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 119 of 121" -->
<!-- PageBreak -->


<figure>
</figure>


<table>
<tr>
<th colspan="2">Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
<th rowspan="2"></th>
<th></th>
<th colspan="2" rowspan="2"></th>
<th>P</th>
</tr>
<tr>
<th colspan="2">AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
<th></th>
<th></th>
</tr>
<tr>
<td colspan="2">State Reg No.</td>
<td>Vehicle Description</td>
<td>Driver</td>
<td>Line Ref.</td>
<td>Contract - Description</td>
<td>Net</td>
<td>GST</td>
<td>Total</td>
</tr>
<tr>
<td colspan="2">WA 1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546615</td>
<td>264808-C-M5 South West Motorway : 2025-12-23</td>
<td>5.33</td>
<td>0.53</td>
<td>5.86</td>
</tr>
<tr>
<td colspan="2">WA 1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546616</td>
<td>264808-C-WestConnex : 2025-12-23 07:23:37</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td colspan="2">WA 1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546617</td>
<td>264808-C-WestConnex : 2025-12-23 14:28:16</td>
<td>10.96</td>
<td>1.10</td>
<td>12.06</td>
</tr>
<tr>
<td colspan="2">WA 1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546618</td>
<td>264808-C-WestLink M7 : 2025-12-24 06:46:38</td>
<td>8.54</td>
<td>0.85</td>
<td>9.39</td>
</tr>
<tr>
<td colspan="2">WA 1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546619</td>
<td>264808-C-WestLink M7 : 2025-12-24 11:45:12</td>
<td>8.54</td>
<td>0.85</td>
<td>9.39</td>
</tr>
<tr>
<td colspan="2">WA 1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546620</td>
<td>264808-C-WestLink M7 : 2025-12-29 14:12:36</td>
<td>7.08</td>
<td>0.71</td>
<td>7.79</td>
</tr>
<tr>
<td colspan="2">WA 1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546621</td>
<td>264808-C-WestLink M7 : 2025-12-29 07:17:01</td>
<td>8.54</td>
<td>0.85</td>
<td>9.39</td>
</tr>
<tr>
<td colspan="2">WA 1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546622</td>
<td>264808-C-WestLink M7 : 2025-12-30 10:26:55</td>
<td>4.19</td>
<td>0.42</td>
<td>4.61</td>
</tr>
<tr>
<td colspan="2">WA 1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546623</td>
<td>264808-C-WestLink M7 : 2025-12-30 12:22:00</td>
<td>4.19</td>
<td>0.42</td>
<td>4.61</td>
</tr>
<tr>
<td colspan="2">WA 1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546624</td>
<td>264808-C-WestLink M7 : 2025-12-30 07:42:53</td>
<td>8.54</td>
<td>0.85</td>
<td>9.39</td>
</tr>
<tr>
<td colspan="2">WA 1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546625</td>
<td>264808-C-WestLink M7 : 2025-12-30 13:56:57</td>
<td>8.54</td>
<td>0.85</td>
<td>9.39</td>
</tr>
<tr>
<td colspan="2">WA 1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546626</td>
<td>264808-C-WestLink M7 : 2025-12-31 07:51:20</td>
<td>8.54</td>
<td>0.85</td>
<td>9.39</td>
</tr>
<tr>
<td colspan="2">WA 1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546627</td>
<td>264808-C-WestLink M7 : 2025-12-31 11:37:34</td>
<td>8.54</td>
<td>0.85</td>
<td>9.39</td>
</tr>
<tr>
<td colspan="2">WA 1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546628</td>
<td>264808-C-WestLink M7:2026-01-05 12:56:17</td>
<td>2.54</td>
<td>0.25</td>
<td>2.79</td>
</tr>
<tr>
<td colspan="2">WA 1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546629</td>
<td>264808-C-WestLink M7:2026-01-05 11:25:32</td>
<td>7.25</td>
<td>0.73</td>
<td>7.98</td>
</tr>
<tr>
<td colspan="2">WA 1HIN526</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Jordan Strickland</td>
<td>4843546630</td>
<td>264808-C-WestLink M7:2026-01-05 07:46:39</td>
<td>9.36</td>
<td>0.94</td>
<td>10.30</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total for Cost Centre: Vertiv Services WA</td>
<td>226.31</td>
<td>22.61</td>
<td>248.92</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">Cost Centre: Vertiv Victoria</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">VIC 1UK9MO</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Zeph Klimis</td>
<td>4843546701</td>
<td>264809-C-Video Matching Fee : 2025-12-24 16:32:44</td>
<td>0.33</td>
<td>0.03</td>
<td>0.36</td>
</tr>
<tr>
<td colspan="2">VIC 1UK9MO</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Zeph Klimis</td>
<td>4843546702</td>
<td>264809-C-Video Matching Fee : 2025-12-24 14:31:45</td>
<td>0.50</td>
<td>0.05</td>
<td>0.55</td>
</tr>
<tr>
<td colspan="2">VIC 1UK9MO</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Zeph Klimis</td>
<td>4843546703</td>
<td>264809-C-EastLink : 2025-12-24 16:32:44</td>
<td>8.28</td>
<td>0.83</td>
<td>9.11</td>
</tr>
<tr>
<td colspan="2">VIC 1UK9MO</td>
<td>NISSAN D23 MY21 NAVARA SL</td>
<td>Zeph Klimis</td>
<td>4843546704</td>
<td>264809-C-CityLink : 2025-12-24 14:31:45</td>
<td>15.45</td>
<td>1.55</td>
<td>17.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total for Cost Centre: Vertiv Victoria</td>
<td>24.56</td>
<td>2.46</td>
<td>27.02</td>
</tr>
<tr>
<td colspan="3">Total for Toll Management</td>
<td></td>
<td></td>
<td></td>
<td>$19,285.77</td>
<td>$1,930.76</td>
<td>$21,216.53</td>
</tr>
<tr>
<td colspan="3">Tyre Costs</td>
<td></td>
<td colspan="5"></td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">Cost Centre: Power</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">QLD 321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545619</td>
<td>256892-C-Hankook RF12 Dynapro AT2 Xtreme-255/60R18</td>
<td>386.60</td>
<td>38.66</td>
<td>425.26</td>
</tr>
<tr>
<td colspan="2">QLD 321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545620</td>
<td>256892-C-Hankook RF12 Dynapro AT2 Xtreme-255/60R18</td>
<td>386.60</td>
<td>38.66</td>
<td>425.26</td>
</tr>
<tr>
<td colspan="2">QLD 321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545621</td>
<td>256892-C-Hankook RF12 Dynapro AT2 Xtreme-255/60R18</td>
<td>386.60</td>
<td>38.66</td>
<td>425.26</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 120 of 121" -->
<!-- PageBreak -->


<figure>

P

</figure>


<table>
<tr>
<th>Customer No.</th>
<th>Invoice Date</th>
<th>Invoice No.</th>
</tr>
<tr>
<th>AU1166479</th>
<th>31 January 2026</th>
<th>AIN00014651</th>
</tr>
</table>


<table>
<tr>
<th>State</th>
<th>Reg No.</th>
<th>Vehicle Description</th>
<th>Driver</th>
<th>Line Ref.</th>
<th>Contract - Description</th>
<th>Net</th>
<th>GST</th>
<th>Total</th>
</tr>
<tr>
<td>QLD</td>
<td>321AW8</td>
<td>NISSAN D23 S4 MY19 NAVARA</td>
<td>Mark Javernig</td>
<td>4843545622</td>
<td>256892-C-Hankook RF12 Dynapro AT2 Xtreme-255/60R18</td>
<td>386.60</td>
<td>38.66</td>
<td>425.26</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Total for Cost Centre: Power</td>
<td>1,546.40</td>
<td>154.64</td>
<td>1,701.04</td>
</tr>
<tr>
<td colspan="2">Total for Tyre Costs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>$1,546.40</td>
<td>$154.64</td>
<td>$1,701.04</td>
</tr>
</table>


<!-- PageFooter="Tax Invoice: Incidental costs" -->
<!-- PageNumber="Page 121 of 121" -->
