# OREILLY AUTOMOTIVE.pdf

<figure>

Reilly
®

AUTO
PARTS

</figure>


DEDICATED TO THE PROFESSIONAL
Store 1648, 1417 SOUTH HASTINGS WAY,
EAU CLAIRE, WI 54701
(715) 836-6606

Bill To:

WEISE BRANCH 091
1435 WOODSON RD

.

SAINT LOUIS, MO 63132


<table>
<tr>
<th>Invoice</th>
<th>1648-158639</th>
</tr>
<tr>
<td>Sale Type</td>
<td>CHARGE SALE</td>
</tr>
<tr>
<td>Date</td>
<td>01/27/2026 9:28 AM</td>
</tr>
<tr>
<td>Ship Via</td>
<td></td>
</tr>
<tr>
<td>PO Number</td>
<td>101312</td>
</tr>
</table>


<table>
<tr>
<th>Counter #</th>
<th>Customer #</th>
<th>Ordered By</th>
<th>Special Instructions</th>
</tr>
<tr>
<td>600232</td>
<td>2697256</td>
<td>Ryan</td>
<td>12459</td>
</tr>
</table>


<table>
<tr>
<th>Qty</th>
<th>Line</th>
<th>Item Number</th>
<th>Description</th>
<th>Warr</th>
<th>Unit</th>
<th>Tax</th>
<th>List</th>
<th>Net</th>
<th>Extended</th>
</tr>
<tr>
<td>1 1</td>
<td>Item KAT</td>
<td>24150</td>
<td>4X5 HTR PAD **</td>
<td>1Y Historical</td>
<td>Reprint ** EA</td>
<td>Y</td>
<td>93.20</td>
<td>52.48</td>
<td>52.48</td>
</tr>
</table>


<table>
<tr>
<td>Sub-Total</td>
<td>52.48</td>
</tr>
<tr>
<td>Sales Tax</td>
<td>2.89</td>
</tr>
<tr>
<td>Total</td>
<td>55.37</td>
</tr>
</table>


X

Customer Signature

WWW.OREILLYPRO.COM
Warranty/Garantia: www.oreillypro. com/warranty

WE APPRECIATE YOUR BUSINESS!
1648WS182 Remit To: PO BOX 9464, SPRINGFIELD, MO 65801-9464
