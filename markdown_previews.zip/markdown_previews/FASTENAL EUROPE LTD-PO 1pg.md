# FASTENAL EUROPE LTD-PO 1pg.pdf

<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


# Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UK0040224</td>
<td>Reference #:</td>
<td>UK00416887</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>296245</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>29/01/2026</td>
</tr>
<tr>
<td>Job #:</td>
<td>PRICE CHECKED - FE60205 POD</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 28/04/2026</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Skelmersdale MRO

PO Box 401

Finance Shared Services Centre

CAMERON HOUSE, PRIORSWOOD

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Skelmersdale MRO

Cameron House

Priorswood Place

East Pimbo

SKELMERSDALE, WA8 9QB GBR

ATTN: Darren Thompson

The store serving you is:

Fastenal Europe Ltd.

Unit 3 Ravenhead Business Park

Ravenhead Rd

SAINT HELENS, WA10 3DB GBR

Phone: +441744 417480

Email: UK004@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>1</td>
<td>DP999101</td>
<td>shukk0001</td>
<td>ABSORTMENT PADS LIGH</td>
<td>20</td>
<td>6,048.0000</td>
<td>1,209.60 N</td>
</tr>
</table>


Location:

Sub Location:

Received By:
Comments:

Contact: Darren Thompson


<table>
<tr>
<td>Subtotal:</td>
<td>1,209.60</td>
</tr>
<tr>
<td>Shipping &amp; Handling:</td>
<td>0.00</td>
</tr>
<tr>
<td>VAT 20%:</td>
<td>241.92</td>
</tr>
<tr>
<td>VAT ID:</td>
<td>GB 836666490-000</td>
</tr>
<tr>
<td>TOTAL (GBP):</td>
<td>1,451.52</td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
</table>


Tax Exemption:
No Exemption
Reasonable collection and attorney's fees will be assessed to all accounts placed for collection.
If you re-package or re-sell this product, you are required to maintain integrity of Country of Origin to the consumer of this product.
X indicates part is a hazardous material
\* indicates part was sold at a promotional or special discount price

No materials accepted for return without our permission.
All discrepancies must be reported within 10 days.


<table>
<tr>
<td>Bank Details:</td>
<td>Wells Fargo, N.A London Branch 33 Kind William Street, London, United Kingdom EC4R9AT</td>
</tr>
<tr>
<td>IBAN (GBP):</td>
<td>GB42PNBP16567108228036</td>
</tr>
<tr>
<td>IBAN (EUR):</td>
<td>GB24PNBP16567108228166</td>
</tr>
<tr>
<td>SWIFT Code:</td>
<td>PNBPGB2L</td>
</tr>
<tr>
<td>Account Number</td>
<td>08228036</td>
</tr>
<tr>
<td>(GBP):</td>
<td></td>
</tr>
<tr>
<td>Account Number</td>
<td>08228166</td>
</tr>
<tr>
<td>(EUR):</td>
<td></td>
</tr>
<tr>
<td>Sort Code:</td>
<td>(CHAPS: 165671) (BACS: 405133)</td>
</tr>
</table>


Registered Entity Address:
Fastenal Europe Ltd.
Units B&C Glasgow Trade Park
Springhill Parkway
Glasgow
G69 6GE
United Kingdom
VAT ID: GB984 554376
Company Number: SC370971

<!-- PageFooter="Thank you!" -->
<!-- PageNumber="Page 1 of 1" -->
