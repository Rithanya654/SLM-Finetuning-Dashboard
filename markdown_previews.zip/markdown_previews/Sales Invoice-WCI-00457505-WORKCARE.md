# Sales Invoice-WCI-00457505-WORKCARE.pdf

# INVOICE

Date: 07/06/2025

Invoice #: WCI-00457505

BILL TO

Nexpera - U328TX56 - RS-TX BORDERLAND

131 Continental Drive

Newark, DE 19713


<figure>

WorkCare®
WORK MATTERS. HEALTH COUNTS.

</figure>


1100 W. Town and Country Rd, Suite 1300, Orange, CA 92868
tel: (714) 978-7488 fax: (714) 456-2154
email: billing2@workcare.com
Tax ID Number: 33-0779311


<table>
<tr>
<th>CUSTOMER NO</th>
<th>PAYMENT TERMS</th>
<th>DUE DATE</th>
<th>PO NUMBER</th>
<th>REFERENCE</th>
</tr>
<tr>
<td>C-04181</td>
<td>Net 60</td>
<td>09/04/2025</td>
<td>4500016533</td>
<td>June 2025 Billing</td>
</tr>
</table>


<table>
<tr>
<th>DESCRIPTION</th>
<th>QTY</th>
<th>UNIT PRICE</th>
<th>LINE TOTAL</th>
</tr>
<tr>
<td>06/16/2025: Medical Surveillance Exam - Periodic [U328TX56 - RS-TX BORDERLAND] Juan Zavala</td>
<td>1</td>
<td>443.00</td>
<td>$443.00</td>
</tr>
<tr>
<td>06/16/2025: Tetanus Diphtheria [U328TX56 - RS-TX BORDERLAND] Juan Zavala</td>
<td>1</td>
<td>105.00</td>
<td>$105.00</td>
</tr>
<tr>
<td>06/16/2025: Breath Alcohol - Non DOT - Preplacement [U328TX56 - RS-TX BORDERLAND] Juan Zavala</td>
<td>1</td>
<td>49.00</td>
<td>$49.00</td>
</tr>
<tr>
<td>06/16/2025: Respirator Fit Test (Quantitative) [U328TX56 - RSTX BORDERLAND] Juan Zavala</td>
<td>1</td>
<td>64.00</td>
<td>$64.00</td>
</tr>
<tr>
<td>06/16/2025: Injection Administration Fee [U328TX56 - RS-TX BORDERLAND] Juan Zavala</td>
<td>1</td>
<td>35.00</td>
<td>$35.00</td>
</tr>
<tr>
<td>06/16/2025: 10 Panel Pre Placement Drug Screen [U328TX56 - RS-TX BORDERLAND] Juan Zavala</td>
<td>1</td>
<td>73.00</td>
<td>$73.00</td>
</tr>
<tr>
<td>06/16/2025: Expanded Non-DOT Drug Screen - Preplacement [U328TX56 - RS-TX BORDERLAND] Juan Zavala</td>
<td>1</td>
<td>65.00</td>
<td>$65.00</td>
</tr>
<tr>
<td colspan="2"></td>
<td>TOTAL</td>
<td>$834.00</td>
</tr>
</table>


Thank you for your business!

Remittance Advice

<!-- PageFooter="Wells Fargo Bank, N.A. Routing Number: 121000248" -->

Account Number: 4758570352

Email: ar@workcare.com
