# UPS CANADA-BDSZ.pdf

<figure>

Ups
TM

</figure>


Plan 1299YH


<table>
<tr>
<td colspan="2">Delivery Service Invoice</td>
</tr>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
<tr>
<td>Control ID</td>
<td>J038</td>
</tr>
<tr>
<td>Page 1 of 103</td>
<td></td>
</tr>
</table>


Sign up for electronic billing today!
Visit ups.com/billing

For questions about your invoice, call:
1-888-592-6188
Monday - Friday
8:00 a.m. - 7:00 p.m. E.T.

or email:

csbillingsupport@ups.com

BRS CANADA C/O NAFFI
MIKE HALLSTEIN
375 PENDANT DRIVE
MISSISSAUGA ON L5T 2W9

Incentive Savings

Total incentive savings this period

$ 17,947.31
Your amount due this period includes these savings.
See incentive summary section for details.
Account Status Summary
Weekly Payment Plan


<table>
<tr>
<td>Charges this period</td>
<td>$ 12,425.63</td>
</tr>
<tr>
<td>Amount outstanding (prior invoices)</td>
<td>$ 46,512.11</td>
</tr>
<tr>
<td>Total amount outstanding</td>
<td>$ 58,937.74</td>
</tr>
</table>


Ship to a UPS Access Point®
The UPS Access Point network offers safe and convenient
delivery locations that give your customers the option to pick up
their packages on their schedule. Flexible evening and weekend
hours available (varies by location). Visit
ups.com/accesspoint to learn more.

Thank you for using UPS.
Summary of Charges


<table>
<tr>
<th>Page</th>
<th></th>
<th>Charge</th>
</tr>
<tr>
<td></td>
<td>Outbound</td>
<td></td>
</tr>
<tr>
<td>4</td>
<td>Shipping API Inbound</td>
<td>$ 8,804.88</td>
</tr>
<tr>
<td>45</td>
<td>Collect</td>
<td>$ 50.80</td>
</tr>
<tr>
<td>45</td>
<td>Adjustments &amp; Other Charges</td>
<td>$ 2,638.83</td>
</tr>
<tr>
<td>103</td>
<td>Tax</td>
<td>$ 931.12</td>
</tr>
<tr>
<td colspan="2">Charges this period</td>
<td>CAD 12,425.63</td>
</tr>
</table>


Dear Customer: Do not pay. The above charges were submitted to
your consolidated paying location for processing.

Note: This invoice may contain a fuel surcharge as described at
ups.com. For more information, please visit ups.com.


<figure>

ups
TM

Remittance Instructions

</figure>


BRS CANADA C/O NAFFI
MIKE HALLSTEIN
375 PENDANT DRIVE
MISSISSAUGA ON L5T 2W9

Pay online today, visit:
https://ups.com/guestpay/ca

Please visit https://ups.com/ca and go to Support -
Understand and Pay Bills for more information.


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<table>
<tr>
<td>Amount due this period</td>
<td>CAD 0.00</td>
</tr>
<tr>
<td>Invoice Due Date</td>
<td>March 2, 2026</td>
</tr>
</table>


ACH Remittance instructions:


<table>
<tr>
<td>Bank Name:</td>
<td>JPMorgan Chase, Toronto</td>
</tr>
<tr>
<td>Bank Account Name:</td>
<td>UPS Canada Ltd.</td>
</tr>
<tr>
<td>Bank Account Number:</td>
<td>4679225102</td>
</tr>
<tr>
<td>Bank Number:</td>
<td>0270</td>
</tr>
<tr>
<td>Transit Number:</td>
<td>00012</td>
</tr>
<tr>
<td>Currency:</td>
<td>CAD Only</td>
</tr>
</table>


Please transmit using CTX 820 ACH format,
or send remittance details to: paymentremit@ups.com

Visit https://ups.com/payment-guide-ca for more information.

<!-- PageBreak -->


<figure>

ups

TM

</figure>


# Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 2 of 103" -->

Incentives
Outbound


<table>
<tr>
<th rowspan="2">Service Incentive Level</th>
<th rowspan="2">Date Count</th>
<th colspan="2">Incentive Plan</th>
</tr>
<tr>
<th>Published Charges</th>
<th>Incentive Credit</th>
</tr>
<tr>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>01/31/2026</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>-3,409.54</td>
</tr>
<tr>
<td>Delivery Area Surcharge</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>01/24/2026</td>
<td></td>
<td>FJPDFGO</td>
</tr>
<tr>
<td>Basic</td>
<td>3</td>
<td>16.20</td>
<td>-8.10</td>
</tr>
<tr>
<td colspan="2">Standard Shipment Pricing</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>01/24/2026</td>
<td></td>
<td>FSWTWHJ</td>
</tr>
<tr>
<td>Electronic Processed Tier</td>
<td>32</td>
<td>600.05</td>
<td>-312.04</td>
</tr>
<tr>
<td colspan="4">Tier incentive based on an average weekly revenue of $114,047.04 for W/E: 01/25/2025 - W/E: 01/17/2026.</td>
</tr>
<tr>
<td colspan="2">Standard Shipment Pricing</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>01/31/2026</td>
<td></td>
<td>FSWTWHJ</td>
</tr>
<tr>
<td>Electronic Processed Tier</td>
<td>103</td>
<td>2,034.62</td>
<td>-1,058.01</td>
</tr>
<tr>
<td colspan="4">Tier incentive based on an average weekly revenue of $113,832.76 for W/E: 02/01/2025 - W/E: 01/24/2026.</td>
</tr>
<tr>
<td colspan="2">Standard Shipment Pricing</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>01/24/2026</td>
<td></td>
<td>FSWTWJR</td>
</tr>
<tr>
<td>Electronic Processed Tier</td>
<td>231</td>
<td>12,007.74</td>
<td>-8,285.35</td>
</tr>
<tr>
<td colspan="3">Tier incentive based on an average weekly revenue of for W/E: 01/25/2025 - W/E: 01/17/2026.</td>
<td>$114,047.04</td>
</tr>
<tr>
<td colspan="2">Standard Shipment Pricing</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>01/31/2026</td>
<td></td>
<td>FSWTWJR</td>
</tr>
<tr>
<td>Electronic Processed Tier</td>
<td>124</td>
<td>6,844.56</td>
<td>-4,722.75</td>
</tr>
<tr>
<td colspan="3" rowspan="2">Tier incentive based on an average weekly revenue of for W/E: 02/01/2025 - W/E: 01/24/2026.</td>
<td>$113,832.76</td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td>Total Outbound</td>
<td></td>
<td></td>
<td>-17,795.79</td>
</tr>
</table>


<table>
<tr>
<th>Incentives</th>
<th colspan="2"></th>
<th></th>
<th></th>
</tr>
<tr>
<td>Inbound</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<th rowspan="2">Service Incentive Level</th>
<th>Date</th>
<th></th>
<th></th>
<th>Incentive Plan</th>
</tr>
<tr>
<th></th>
<th>Count</th>
<th>Published Charges</th>
<th>Incentive Credit</th>
</tr>
<tr>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">01/31/2026</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>-21.88</td>
</tr>
<tr>
<td colspan="3">Freight Collect/Third Party</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>01/31/2026</td>
<td></td>
<td>BBCVPTT</td>
</tr>
<tr>
<td>Basic</td>
<td></td>
<td>2</td>
<td>13.00</td>
<td>-13.00</td>
</tr>
<tr>
<td colspan="4">Bill Receiver/Third Party Standard Shipment Pricing</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">01/31/2026</td>
<td></td>
<td>FSWTWJR</td>
</tr>
<tr>
<td>Electronic Processed Tier</td>
<td></td>
<td>4</td>
<td>132.15</td>
<td>-91.18</td>
</tr>
<tr>
<td colspan="5">Tier incentive based on an average weekly revenue of $113,832.76 for W/E: 02/01/2025 - W/E: 01/24/2026.</td>
</tr>
<tr>
<td>Total Inbound</td>
<td></td>
<td></td>
<td></td>
<td>-126.06</td>
</tr>
</table>


<table>
<tr>
<th>Incentives</th>
<th></th>
<th colspan="2"></th>
</tr>
<tr>
<th colspan="2">Adjustments &amp; Other Charges</th>
<th></th>
<th></th>
</tr>
<tr>
<th rowspan="2">Service Incentive Level</th>
<th rowspan="2">Date Count</th>
<th></th>
<th>Incentive Plan</th>
</tr>
<tr>
<th>Published Charges</th>
<th>Incentive Credit</th>
</tr>
<tr>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>12/27/2025</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>-5.33</td>
</tr>
<tr>
<td colspan="2">Standard Shipment Pricing</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>12/27/2025</td>
<td></td>
<td>FSWTWHJ</td>
</tr>
<tr>
<td>Electronic Processed Tier</td>
<td>1</td>
<td>37.95</td>
<td>-19.73</td>
</tr>
<tr>
<td colspan="4">Tier incentive based on an average weekly revenue of $115,800.35 for W/E: 12/28/2024 - W/E: 12/20/2025.</td>
</tr>
<tr>
<td>Surge Fee - Com</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>12/27/2025</td>
<td></td>
<td>KLYCJHX</td>
</tr>
<tr>
<td>Basic</td>
<td>1</td>
<td>1.00</td>
<td>-0.40</td>
</tr>
<tr>
<td colspan="2">Total Adjustments &amp; Other Charges</td>
<td></td>
<td>-25.46</td>
</tr>
<tr>
<td>Total Incentives</td>
<td></td>
<td></td>
<td>-17,947.31</td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 3 of 103" -->

Account Status
Weekly Payment Plan
Payments Applied


<table>
<tr>
<th>Invoice Number</th>
<th>Invoice Date</th>
<th>Amount Paid</th>
</tr>
<tr>
<td>0000G7093D026</td>
<td>01/10/2026</td>
<td>$ 51,928.56</td>
</tr>
</table>


Account Status
Weekly Payment Plan

Amount Outstanding (prior invoices):

Please include the Return Portion of each outstanding invoice with
your payment.


<table>
<tr>
<th>Invoice Number</th>
<th>Invoice Date</th>
<th>Balance Due</th>
</tr>
<tr>
<td>0000G7093D036</td>
<td>01/17/2026</td>
<td>$ 30,297.56</td>
</tr>
<tr>
<td>0000G7093D046</td>
<td>01/24/2026</td>
<td>$ 16,214.55</td>
</tr>
</table>


Total

$ 46,512.11

Outstanding balances reflect any payments received as of
01/30/2026. Please ignore this message if a recent payment has
been made for any outstanding invoices.

<!-- PageBreak -->


<figure>

Ups

TM

</figure>


Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 4 of 103" -->

Outbound
Shipping API


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th rowspan="2">Tracking Number Shaded</th>
<th>Service</th>
<th colspan="3" rowspan="2">4 package Postal Code Zone</th>
<th rowspan="2">shipment Weight</th>
<th>Published Charge</th>
<th rowspan="2">Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<th>area denotes</th>
<th></th>
<th></th>
</tr>
<tr>
<td>01/19</td>
<td>1ZG7093D2002536111</td>
<td>Standard</td>
<td colspan="2">V7Y1G5</td>
<td>207</td>
<td>82 lbs</td>
<td>186.00</td>
<td>-128.34</td>
<td>57.66</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td colspan="2"></td>
<td></td>
<td>79 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>43.71</td>
<td>30.17</td>
<td>13.54</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>229.71</td>
<td>158.51</td>
<td>71.20</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848014</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2">Receiver: LULULEMON CANADA</td>
<td>129</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>LULULEMON CANADA</td>
<td>129</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="2"></td>
<td></td>
<td>701</td>
<td>WEST GEORGIA</td>
<td>ST</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>VANCOUVER BC</td>
<td>V7Y1G5</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2"></td>
<td>1ZG7093D2002536111</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td rowspan="2">52848014</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd</td>
<td>ref:</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2004211128 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848014</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2006179143</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd</td>
<td>ref:</td>
<td>52848014</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2010892131 1st ref: 68951</td>
<td></td>
<td colspan="2">2nd</td>
<td>ref:</td>
<td>52848014</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="6">Shaded area denotes 7 package shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2005409860</td>
<td>Standard</td>
<td colspan="2">V6Z2E7</td>
<td>207</td>
<td>212 lbs</td>
<td>449.44</td>
<td>-310.11</td>
<td>139.33</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td colspan="2"></td>
<td></td>
<td>179.3 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>105.63</td>
<td>72.88</td>
<td>32.75</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>555.07</td>
<td>382.99</td>
<td>172.08</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td colspan="2">ref: 52848020</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON CANADA</td>
<td>120</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>LULULEMON CANADA</td>
<td>120</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="2"></td>
<td></td>
<td>970</td>
<td>ROBSON ST</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>VANCOUVER BC</td>
<td>V6Z2E7</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2"></td>
<td>1ZG7093D2001094912</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td colspan="2">ref: 52848020</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2005409860 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848020</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011334876 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848020</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011802897</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848020</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2012265887</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848020</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2"></td>
<td>1ZG7093D2013545902</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848020</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2018049921 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848020</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


# Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 5 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td></td>
<td>Shaded</td>
<td colspan="5">area denotes 20 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/19</td>
<td>1ZG7093D2013530463</td>
<td>Standard</td>
<td>V7T0A5</td>
<td>207</td>
<td>442 lbs</td>
<td>937.04</td>
<td>646.56</td>
<td>290.48</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>426 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>220.25</td>
<td>151.94</td>
<td>68.31</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>1,157.29</td>
<td>798.50</td>
<td>358.79</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td colspan="3">Receiver: LULULEMON CANADA</td>
<td>170</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">BUNZL CO PENDANT</td>
<td></td>
<td></td>
<td colspan="2">LULULEMON CANADA</td>
<td>170</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td colspan="2">787 MAIN ST</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td>WEST</td>
<td>VANCOUVER</td>
<td>BC V7T0A5</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2000330524</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2001106480</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2001435615</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2001466609</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002810627</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2003650567 1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2004178648</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2005003495</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2007106504</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009191632 1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009578546</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011015514</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011346587 1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011371657</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011815472 1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 6 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/19</td>
<td>1ZG7093D2013530463</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2013995579</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2016711557</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2018651538</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2019303591</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td rowspan="2">52848025</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


Shaded area denotes 5 package shipment


<table>
<tr>
<td>1ZG7093D2016204695</td>
<td>Standard</td>
<td>V8W1T2</td>
<td>209</td>
<td>105 lbs</td>
<td>228.70</td>
<td>-157.80</td>
<td>70.90</td>
</tr>
<tr>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>100.7 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>53.74</td>
<td>37.07</td>
<td>16.67</td>
</tr>
<tr>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>282.44</td>
<td>194.87</td>
<td>87.57</td>
</tr>
</table>


1st ref: 68951

2nd ref: 52848021

UserID: NAFF1234

Sender : BUNZL
BUNZL CO PENDANT
375 PENDANT DRIVE
MISSISSAUGA ON L5T2W9

Receiver: LULULEMON CANADA 131
LULULEMON CANADA 131
801 WHARF ST
VICTORIA BC V8W1T2

Message Codes: ad

1ZG7093D2004732735

1st ref: 68951

2nd ref: 52848021

UserID: NAFF 1234

1ZG7093D2009691726

1st ref: 68951

2nd ref: 52848021

UserID: NAFF1234

1ZG7093D2015656717

1st ref: 68951

2nd ref: 52848021

UserID: NAFF 1234

1ZG7093D2016204695

1st ref: 68951

2nd ref: 52848021

UserID: NAFF1234

1ZG7093D2019027701

1st ref: 68951

2nd ref: 52848021

UserID: NAFF1234

1ZG7093D2016552952


<table>
<tr>
<td>Standard Customer Weight</td>
<td>T6H4M6</td>
<td>206</td>
<td>29 lbs 21.3 lbs</td>
<td>104.50</td>
<td>-72.11</td>
<td>32.39</td>
</tr>
<tr>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>24.56</td>
<td>-16.95</td>
<td>7.61</td>
</tr>
<tr>
<td colspan="4">Customer Entered Dimensions = 20 x 15 x 13 in</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>129.06</td>
<td>-89.06</td>
<td>40.00</td>
</tr>
</table>


1st ref: 68951
UserID: NAFF1234

2nd ref: 52848050

Sender : BUNZL
BUNZL CO PENDANT
375 PENDANT DRIVE
MISSISSAUGA ON L5T2W9

Message Codes: ad r

Receiver: LULULEMON CANADA 358
LULULEMON CANADA 358 C
5015 111 STREET
EDMONTON AB T6H4M6

<!-- PageBreak -->


<figure>

Ups

TM

</figure>


## Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 7 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td></td>
<td>Shaded</td>
<td>area denotes</td>
<td>2</td>
<td colspan="2">package shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/19</td>
<td>1ZG7093D2017576676</td>
<td>Standard</td>
<td>V6K1N7</td>
<td>207</td>
<td>20 lbs</td>
<td>92.60</td>
<td>63.89</td>
<td>28.71</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>21.76</td>
<td>15.02</td>
<td>6.74</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>114.36</td>
<td>78.91</td>
<td>35.45</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848019</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td>Receiver:</td>
<td colspan="2">LULULEMON CANADA 110</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">BUNZL CO PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 110</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td>2101</td>
<td>WEST 4TH</td>
<td>AVE</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>VANCOUVER BC</td>
<td>V6K1N7</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2003587681</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848019</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2017576676</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848019</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="6">Shaded area denotes 3 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2022029837</td>
<td>Standard</td>
<td>T8V3Y2</td>
<td>211</td>
<td>64 lbs</td>
<td>184.80</td>
<td>-127.51</td>
<td>57,29</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Delivery Area Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>5.40</td>
<td>-2.70</td>
<td>2.70</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>44.69</td>
<td>30.60</td>
<td>14.09</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>234.89</td>
<td>160.81</td>
<td>74.08</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848045</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 359</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 359</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td>11801</td>
<td>100 ST</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td>GRANDE</td>
<td>PRAIRIE</td>
<td>AB T8V3Y2</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2022029837</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848045</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2022684058</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848045</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039929244</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td>52848045</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="5">Shaded area denotes 2 package shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2024266194</td>
<td>Standard</td>
<td>V9T4T7</td>
<td>210</td>
<td>28 lbs</td>
<td>122.10</td>
<td>84.25</td>
<td>37.85</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>27.9 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>28.69</td>
<td>-19.80</td>
<td>8.89</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>150.79</td>
<td>104.05</td>
<td>46.74</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848061</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 115</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">BUNZL CO PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 115 LL115</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td>6631</td>
<td>ISLAND</td>
<td>HIGHWAY N</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td>NANAIMO</td>
<td colspan="2">BC V9T4T7</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020704002</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848061</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2024266194 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848061</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


## Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 8 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td></td>
<td>Shaded</td>
<td>area denotes</td>
<td colspan="3">7 package shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/19</td>
<td>1ZG7093D2026318286</td>
<td>Standard</td>
<td>S4P0J5</td>
<td>205</td>
<td>168 lbs</td>
<td>342.72</td>
<td>236.48</td>
<td>106.24</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>161 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>80.57</td>
<td>55.57</td>
<td>25.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>423.29</td>
<td>292.05</td>
<td>131.24</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848006</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON CANADA</td>
<td>432</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">BUNZL CO PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON CANADA</td>
<td>432</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td>2114</td>
<td>11TH AVE</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td colspan="2">REGINA SK S4P0J5</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020094332</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848006</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020484321</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848006</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023123741</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848006</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023810696</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848006</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2026318286</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848006</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2036578503</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848006</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2038897718 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848006</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="6">Shaded area denotes 3 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2029770264</td>
<td>Standard</td>
<td>V2T0C5</td>
<td>209</td>
<td>49 lbs</td>
<td>149.00</td>
<td>-102.81</td>
<td>46.19</td>
</tr>
<tr>
<td rowspan="2"></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>40.6 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>35.01</td>
<td>-24.16</td>
<td>10.85</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>184.01</td>
<td>126.97</td>
<td>57.04</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848056</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON CANADA</td>
<td>113</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">BUNZL CO PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON CANADA</td>
<td>113</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td>3122</td>
<td>MOUNT LEHMAN</td>
<td>RD</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>ABBOTSFORD BC</td>
<td>V2T0C5</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2024103878</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848056</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025640885 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848056</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2029770264</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848056</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

UPS

TM

</figure>


Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 9 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<th></th>
<th>Shaded</th>
<th>area denotes</th>
<th colspan="2">9 package shipment</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td>01/19</td>
<td>1ZG7093D2032339591</td>
<td>Standard</td>
<td>A1B1W3 211</td>
<td>218 lbs</td>
<td>490.50</td>
<td>-338.45</td>
<td>152.05</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td>210 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td>115.27</td>
<td>79.55</td>
<td>35.72</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td>605.77</td>
<td>418.00</td>
<td>187.77</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref:</td>
<td>52848012</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td colspan="2">Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 720</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td></td>
<td colspan="2">LULULEMON CANADA</td>
<td>720</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td colspan="2">48 KENMOUNT RD</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td>ST.</td>
<td>JOHN'S NL</td>
<td>A1B1W3</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020733454</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref: 52848012</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023655668</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref:</td>
<td>52848012</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2027598615</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td>2nd ref:</td>
<td>52848012</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2028931225</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref:</td>
<td>52848012</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2031173404</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref:</td>
<td>52848012</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2032339591</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref:</td>
<td>52848012</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035527239</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref:</td>
<td>52848012</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035665278</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref:</td>
<td>52848012</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2038382649</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref:</td>
<td>52848012</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


Shaded area denotes 2 package shipment


<table>
<tr>
<td>1ZG7093D2036658837</td>
<td>Standard</td>
<td>V3B5R5</td>
<td>207</td>
<td>20 lbs</td>
<td>92.60</td>
<td>63.89</td>
<td>28.71</td>
</tr>
<tr>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>21.76</td>
<td>-15.02</td>
<td>6.74</td>
</tr>
<tr>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td>114.36</td>
<td>78.91</td>
<td>35.45</td>
</tr>
</table>


1st ref: 68951

2nd ref: 52848044

UserID: NAFF1234

Sender : BUNZL

BUNZL CO PENDANT
375 PENDANT DRIVE
MISSISSAUGA ON L5T2W9

Receiver: LULULEMON CANADA 161
LULULEMON CANADA 161
2929 BARNET HIGHWAY
COQUITLAM BC V3B5R5

Message Codes: ad

1ZG7093D2034818248

1st ref: 68951

2nd ref: 52848044

UserID: NAFF 1234

1ZG7093D2036658837

1st ref: 68951

2nd ref: 52848044

UserID: NAFF 1234

<!-- PageBreak -->


<figure>

UPS

TM

</figure>


# Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 10 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td></td>
<td>Shaded</td>
<td colspan="5">area denotes 11 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/20</td>
<td>1ZG7093D2001706199</td>
<td>Standard</td>
<td>V5H4J2</td>
<td>207</td>
<td>261 lbs</td>
<td>553.32</td>
<td>-381.79</td>
<td>171.53</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>200.7 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>130.04</td>
<td>89.71</td>
<td>40.33</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>683.36</td>
<td>471.50</td>
<td>211.86</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848023</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td colspan="4">Receiver: LULULEMON CANADA</td>
<td>160</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td></td>
<td></td>
<td colspan="2" rowspan="2">LULULEMON CANADA 4800 KINGSWAY</td>
<td>160</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td colspan="2">BURNABY BC</td>
<td>V5H4J2</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2001706199</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848023</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002958219</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848023</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2003134259</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848023</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2003693262</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848023</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2005429204</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848023</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2012206299</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848023</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2013834233 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848023</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2014381248</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref: 52848023</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2014629285</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848023</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2017893225 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848023</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2019658271</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td rowspan="2"></td>
<td rowspan="2">2nd ref:</td>
<td rowspan="2">52848023</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="6">Shaded area denotes 10 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002180648</td>
<td>Standard</td>
<td>V8Z6E3</td>
<td>209</td>
<td>232 lbs</td>
<td>501.12</td>
<td>-345.77</td>
<td>155.35</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>188.7 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>117.77</td>
<td>81.27</td>
<td>36.50</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>618.89</td>
<td>427.04</td>
<td>191.85</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref: 52848052</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZŁ</td>
<td></td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 178</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON CANADA</td>
<td>178</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td>3147</td>
<td>DOUGLAS ST</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>VICTORIA BC</td>
<td>V8Z6E3</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 11 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/20</td>
<td>1ZG7093D2001628701</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848052</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002180648</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848052</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2004988684</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52848052</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009133730</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td rowspan="2">52848052</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2010573655</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848052</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2013492728</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848052</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2014772665</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848052</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2018205690</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52848052</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2018377675</td>
<td></td>
<td></td>
<td rowspan="3">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>52848052</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2018857718</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848052</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


Shaded area denotes 9 package shipment


<table>
<tr>
<th>1ZG7093D2008331965</th>
<th>Standard</th>
<th>V8E1H1</th>
<th>210</th>
<th>261 lbs</th>
<th>566.37</th>
<th>-390.80</th>
<th>175.57</th>
</tr>
<tr>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>199 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">Delivery Area Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>5.40</td>
<td>-2.70</td>
<td>2.70</td>
</tr>
<tr>
<td colspan="2">Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>134.38</td>
<td>92.50</td>
<td>41.88</td>
</tr>
<tr>
<td colspan="2">Total</td>
<td></td>
<td></td>
<td></td>
<td>706.15</td>
<td>486.00</td>
<td>220.15</td>
</tr>
</table>


1st ref: 68951

2nd ref: 52848022

UserID: NAFF 1234

Sender : BUNZL

BUNZL CO PENDANT
375 PENDANT DRIVE
MISSISSAUGA ON L5T2W9

Receiver: LULULEMON CANADA 141
LULULEMON CANADA 141
4154 VILLAGE GREEN
WHISTLER BC V8E 1H1

Message Codes: ad

1ZG7093D2000532020

1st ref: 68951

2nd ref: 52848022

UserID: NAFF1234

1ZG7093D2002504995

1st ref: 68951

2nd ref: 52848022

UserID: NAFF 1234

1ZG7093D2005508002

1st ref: 68951

2nd ref: 52848022

UserID: NAFF 1234

1ZG7093D2007516973

1st ref: 68951

2nd ref: 52848022

UserID: NAFF 1234

1ZG7093D2008331965

1st ref: 68951

2nd ref: 52848022

UserID: NAFF 1234

<!-- PageBreak -->


<figure>

UPS

TM

</figure>


## Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 12 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/20</td>
<td>1ZG7093D2010317011</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848022</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011580047</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848022</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2017707980</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848022</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2019753033</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848022</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="6">Shaded area denotes 7 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009380740</td>
<td>Standard</td>
<td>V2N2S9</td>
<td>209</td>
<td>153 lbs</td>
<td>330.48</td>
<td>-228.03</td>
<td>102.45</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>117.3 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Delivery Area Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>5.40</td>
<td>-2.70</td>
<td>2.70</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>78.94</td>
<td>54.24</td>
<td>24.70</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>414.82</td>
<td>284.97</td>
<td>129.85</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848058</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td colspan="2">Receiver:</td>
<td>LULULEMON CANADA</td>
<td>112</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">BUNZL CO PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON CANADA</td>
<td>112 CAD</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td colspan="2">3055</td>
<td>MASSEY DR</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td colspan="2">PRINCE</td>
<td>GEORGE</td>
<td>BC V2N2S9</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2005705790</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref: 52848058</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2008428781</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848058</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009188806</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848058</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009380740</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848058</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2013757773</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848058</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2017833754</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848058</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2018092768</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848058</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Shaded area denotes 4</td>
<td colspan="4">package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025614627</td>
<td>Standard</td>
<td>T4A0G3</td>
<td>207</td>
<td>112 lbs</td>
<td>238.50</td>
<td>-164.57</td>
<td>73.93</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>56.05</td>
<td>-38.68</td>
<td>17.37</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>294.55</td>
<td>-203.25</td>
<td>91.30</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52856018</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td>Receiver: HUGO</td>
<td>OUTLET</td>
<td>1358</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">BUNZL CO PENDANT</td>
<td></td>
<td></td>
<td>HUGO</td>
<td>OUTLET</td>
<td>1358</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">375 PENDANT DRIVE</td>
<td></td>
<td colspan="2">261055</td>
<td>CROSSIRON</td>
<td>BLVD</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">MISSISSAUGA ON L5T2W9</td>
<td></td>
<td colspan="2">ROCKY</td>
<td colspan="2">VIEW COUNTY AB T4A0G3</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


## Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 13 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th></th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/20</td>
<td>1ZG7093D2025614627</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52856018</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2030898044</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52856018</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2033124856</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52856018</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2038006635 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52856018</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="7">Shaded area denotes 20 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035363068</td>
<td>Standard</td>
<td colspan="2">STK1J5</td>
<td>205</td>
<td>580 lbs</td>
<td>1,183.20</td>
<td>-816.41</td>
<td>366.79</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td></td>
<td>460 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>278.00</td>
<td>-191.76</td>
<td>86.24</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="3"></td>
<td></td>
<td>1,461.20</td>
<td>-1,008.17</td>
<td>453.03</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 430</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 430</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>201</td>
<td>1ST AVE S</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>SASKATOON SK</td>
<td>S7K1J5</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020677195</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2021199147</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2021400838</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2024711774 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025574788</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2026106095</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2027559952</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2031949906</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2033377682</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2033892160</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2034455005 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

UPS

TM

</figure>


## Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 14 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/20</td>
<td>1ZG7093D2034580825</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2034785113</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035363068</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2037135051</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2037184212</td>
<td></td>
<td></td>
<td rowspan="3">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2037733735</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2037927722</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039040248</td>
<td></td>
<td></td>
<td rowspan="3">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039728676</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951 UserID: NAFF 1234</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52849403</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


Shaded area denotes 7 package shipment


<table>
<tr>
<th>1ZG7093D2037803543</th>
<th>Standard</th>
<th>V6Y2B6 207 136 lbs</th>
<th>289.00</th>
<th>-199.41</th>
<th>89.59</th>
</tr>
<tr>
<td></td>
<td>Customer Weight</td>
<td>101.6 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td>67.91</td>
<td>46.85</td>
<td>21.06</td>
</tr>
<tr>
<td></td>
<td>Total</td>
<td></td>
<td>356.91</td>
<td>246.26</td>
<td>110.65</td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52848053</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Sender : BUNZL</td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON CANADA</td>
<td>121</td>
<td></td>
</tr>
<tr>
<td colspan="2">BUNZL CO PENDANT</td>
<td></td>
<td colspan="2">LULULEMON CANADA 121</td>
<td></td>
</tr>
<tr>
<td colspan="2">375 PENDANT DRIVE</td>
<td colspan="2">6551 NO. 3 RD</td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">MISSISSAUGA ON L5T2W9</td>
<td colspan="3">RICHMOND BC V6Y2B6</td>
<td></td>
</tr>
<tr>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2028044176</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52848053</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2033763184</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52848053</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2034361599</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52848053</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2035408564</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52848053</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2035875407</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52848053</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2036700352</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52848053</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

UPS

TM

</figure>


Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 15 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/20</td>
<td>1ZG7093D2037803543</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td rowspan="2"></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td>52848053</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="5">Shaded area denotes 9 package shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039161260</td>
<td>Standard</td>
<td>T5T4J2</td>
<td>206</td>
<td>258 lbs</td>
<td>541.80</td>
<td>-373.84</td>
<td>167.96</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>175 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>127.32</td>
<td>87.88</td>
<td>39.44</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>669.12</td>
<td>461.72</td>
<td>207.40</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 350</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 350</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td>8882-170</td>
<td>ST NW</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>EDMONTON AB</td>
<td>T5T4J2</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020421344</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020788299</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2024323318</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025007935</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2030100109</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2031573928</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2032034875</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039161260</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039711880</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td>52848040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/21</td>
<td>1ZG7093D2007306593</td>
<td>Standard</td>
<td>V6Z2H3</td>
<td>207</td>
<td>2 lbs</td>
<td>51.75</td>
<td>-35.71</td>
<td>16.04</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>1.3 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>12.16</td>
<td>-8.39</td>
<td>3.77</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="4">Customer Entered Dimensions = 11 x 9 x 1 in</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>63.91</td>
<td>-44.10</td>
<td>19.81</td>
</tr>
</table>


1st ref: 68951
UserID: NAFF1234
Sender : BUNZL
BUNZL CO PENDANT
375 PENDANT DRIVE
MISSISSAUGA ON L5T2W9
Message Codes: ad

2nd ref: 52856679

Receiver: LULULEMON BILLING CA

LULULEMON BILLING CAD CA

1380 BURRARD ST

VANCOUVER BC V6Z2H3

<!-- PageBreak -->


<figure>

UPS

TM

</figure>


## Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 16 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th colspan="2">Postal Code</th>
<th>Zone</th>
<th colspan="2" rowspan="2">Weight shipment</th>
<th>Published Charge</th>
<th rowspan="2">Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<th>Shaded</th>
<th>area denotes</th>
<th colspan="3">4 package</th>
<th></th>
<th></th>
</tr>
<tr>
<td>01/23</td>
<td>1ZG7093D2001181649</td>
<td>Standard</td>
<td colspan="2">T6H4M6</td>
<td>206</td>
<td colspan="2">58 lbs</td>
<td>147.05</td>
<td>101.46</td>
<td>45.59</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td colspan="2"></td>
<td></td>
<td colspan="2">44 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>34.56</td>
<td>23.84</td>
<td>10.72</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>181.61</td>
<td>125.30</td>
<td>56.31</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52881043</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2">Receiver:</td>
<td>LULULEMON CANADA</td>
<td>358</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">BUNZL CO PENDANT</td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>LULULEMON CANADA</td>
<td>358 C</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="2"></td>
<td></td>
<td colspan="2">5015</td>
<td>111 STREET</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>EDMONTON AB</td>
<td>T6H4M6</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2001181649</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52881043</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2010174658</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52881043</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2014973662</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52881043</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2019178674 1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2" rowspan="2">52881043</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="8">Shaded area denotes 15 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002506993</td>
<td>Standard</td>
<td colspan="2">N6G3Y9</td>
<td>202</td>
<td colspan="2">419 lbs</td>
<td>745.82</td>
<td>514.62</td>
<td>231.20</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">335 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>175.26</td>
<td>120.92</td>
<td>54.34</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>921.08</td>
<td>635.54</td>
<td>285.54</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52881038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2">Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 273</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON CANADA</td>
<td>273</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="2"></td>
<td></td>
<td colspan="2">1680</td>
<td>RICHMOND</td>
<td>ST N</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">LONDON</td>
<td>ON N6G3Y9</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002070105</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52881038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002506993 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52881038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2004134024</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52881038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2004139118</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52881038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2004555034 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52881038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2006710004</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52881038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2006815053 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52881038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 17 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/23</td>
<td>1ZG7093D2007614125</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2007750086</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2008299073</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52881038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2012719011</td>
<td></td>
<td></td>
<td rowspan="3">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52881038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2015854066</td>
<td></td>
<td></td>
<td rowspan="3">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52881038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2016095134</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52881038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2017582043</td>
<td></td>
<td></td>
<td rowspan="3">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52881038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2017807096</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td rowspan="2">52881038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


Shaded area denotes 17 package shipment


<table>
<tr>
<th>1ZG7093D2006389685</th>
<th>Standard</th>
<th>STK1J5</th>
<th>205 479 lbs</th>
<th>977.16</th>
<th>-674.24</th>
<th>302.92</th>
</tr>
<tr>
<td></td>
<td>Customer Weight</td>
<td></td>
<td>365.8 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td>229.58</td>
<td>158.38</td>
<td>71.20</td>
</tr>
<tr>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td>1,206.74</td>
<td>832.62</td>
<td>374.12</td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52881040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON CANADA</td>
<td>430</td>
<td></td>
</tr>
<tr>
<td colspan="2">BUNZL CO PENDANT</td>
<td></td>
<td></td>
<td>LULULEMON CANADA</td>
<td>430</td>
<td></td>
</tr>
<tr>
<td colspan="2">375 PENDANT DRIVE</td>
<td></td>
<td>201</td>
<td>1ST AVE S</td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td>SASKATOON SK</td>
<td>S7K1J5</td>
<td></td>
</tr>
<tr>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2000206696</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52881040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2000558771</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52881040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2002058718</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52881040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2003274830</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52881040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2003434756</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52881040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2004229708</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52881040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2004293764</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951 UserID: NAFF 1234</td>
<td></td>
<td></td>
<td>2nd ref: 52881040</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 18 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/23</td>
<td>1ZG7093D2006389685</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2008181841</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011678817</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2013534736</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2013706792</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2014381748</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2015829781</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2017293721</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52881040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2017789802</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2018973824</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881040</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


Shaded area denotes 2 package shipment


<table>
<tr>
<td>1ZG7093D2011269607</td>
<td>Standard</td>
<td>R3P1J9</td>
<td>204</td>
<td>10 lbs</td>
<td>63.35</td>
<td>43.71</td>
<td>19.64</td>
</tr>
<tr>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>9.8 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>14.88</td>
<td>-10.26</td>
<td>4.62</td>
</tr>
<tr>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>78.23</td>
<td>53.97</td>
<td>24.26</td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52881034</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


UserID: NAFF 1234

Sender : BUNZL

BUNZL CO PENDANT
375 PENDANT DRIVE
MISSISSAUGA ON L5T2W9

Receiver: LULULEMON CANADA 600
LULULEMON CANADA 600
555 STERLING LYON PKWY
WINNIPEG MB R3P1J9

Message Codes: ad

1ZG7093D2011269607

1st ref: 68951

2nd ref: 52881034

UserID: NAFF 1234

1ZG7093D2013038611

1st ref: 68951

UserID: NAFF1234

2nd ref: 52881034

<!-- PageBreak -->


<figure>

UPS

TM

</figure>


### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 19 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td></td>
<td>Shaded</td>
<td colspan="4">area denotes 6 package shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/23</td>
<td>1ZG7093D2013182143</td>
<td>Standard</td>
<td>S4P0J5</td>
<td>205</td>
<td>155 lbs</td>
<td>316.20</td>
<td>218.18</td>
<td>98.02</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>125 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>74.29</td>
<td>51.25</td>
<td>23.04</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td>390.49</td>
<td>269.43</td>
<td>121.06</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881031</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td colspan="3">Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 432</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">BUNZL CO PENDANT</td>
<td colspan="2"></td>
<td colspan="2">LULULEMON</td>
<td>CANADA 432</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="2"></td>
<td>2114</td>
<td>11TH AVE</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td colspan="2"></td>
<td colspan="2">REGINA SK S4P0J5</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002475151</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="3">2nd ref: 52881031</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2007574160</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881031</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2012079178</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881031</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2013182143</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881031</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2013707193</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881031</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2019590183</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881031</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="6">Shaded area denotes 2 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2016213621</td>
<td>Standard</td>
<td>M5T1G1</td>
<td>200</td>
<td>12 lbs</td>
<td>27.80</td>
<td>14.46</td>
<td>13.34</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td colspan="2"></td>
<td>11.2 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>6.53</td>
<td>3.40</td>
<td>3.13</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td>34.33</td>
<td>-17.86</td>
<td>16.47</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881035</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td colspan="2">Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 220</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">BUNZL CO PENDANT</td>
<td colspan="2"></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 220</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="2"></td>
<td>2</td>
<td>BLOOR STREET</td>
<td>WEST</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td colspan="2"></td>
<td colspan="2">TORONTO ON</td>
<td>M5T1G1</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2004394637</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881035</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2016213621</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881035</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


## Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 20 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<th></th>
<th>Shaded</th>
<th>area denotes</th>
<th colspan="4">14 package shipment</th>
<th></th>
<th></th>
</tr>
<tr>
<td>01/23</td>
<td>1ZG7093D2017294855</td>
<td>Standard</td>
<td>T5T4J2</td>
<td>206</td>
<td>438 lbs</td>
<td>919.80</td>
<td>634.66</td>
<td>285.14</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>294.7 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>216.16</td>
<td>149.17</td>
<td>66.99</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>1,135.96</td>
<td>783.83</td>
<td>352.13</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881039</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 350</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 350</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="2"></td>
<td>8882-170</td>
<td>ST NW</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>EDMONTON AB</td>
<td>T5T4J2</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2001253928</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881039</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2001898910</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881039</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002538879</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881039</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002581947 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881039</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2004733967 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881039</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2005118979</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881039</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2005869882 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881039</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2007806892 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881039</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011754958</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881039</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011949908 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881039</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2013614935</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881039</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2014213867</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881039</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2016509982 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881039</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2"></td>
<td>1ZG7093D2017294855</td>
<td></td>
<td></td>
<td></td>
<td rowspan="3">52881039</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

UPS

TM

</figure>


Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 21 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/23</td>
<td>1ZG7093D2018030208</td>
<td>Standard</td>
<td>L4K5W4</td>
<td>200</td>
<td>12 lbs</td>
<td>27.80</td>
<td>-14.46</td>
<td>13.34</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>11.6 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>6.53</td>
<td>-3.40</td>
<td>3.13</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="4">Customer Entered Dimensions = 12 x 10 x 10 in</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>34.33</td>
<td>-17.86</td>
<td>16.47</td>
</tr>
</table>


1st ref: 68951

UserID: NAFF1234

Sender : BUNZL
BUNZL CO PENDANT
375 PENDANT DRIVE
MISSISSAUGA ON L5T2W9

2nd ref: 52881095

Receiver: LULULEMON CANADA 271
LULULEMON CANADA 271
1 BASS PRO MILLS DR
CONCORD ON L4K5W4

Message Codes: ad

Shaded area denotes 11 package shipment


<table>
<tr>
<th>1ZG7093D2021390537</th>
<th>Standard</th>
<th>L3Y4Z1 200 300 lbs</th>
<th>198.00</th>
<th>-102.96</th>
<th>95.04</th>
</tr>
<tr>
<td></td>
<td>Customer Weight</td>
<td>239.7 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td>46.55</td>
<td>24.19</td>
<td>22.36</td>
</tr>
<tr>
<td></td>
<td>Total</td>
<td></td>
<td>244.55</td>
<td>-127.15</td>
<td>117.40</td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52881044</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Sender : BUNZL</td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON CANADA</td>
<td>275</td>
<td></td>
</tr>
<tr>
<td colspan="2">BUNZL CO PENDANT</td>
<td></td>
<td>LULULEMON CANADA</td>
<td>275</td>
<td></td>
</tr>
<tr>
<td colspan="2">375 PENDANT DRIVE</td>
<td>17600</td>
<td>YONGE ST</td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">MISSISSAUGA ON L5T2W9</td>
<td></td>
<td>NEWMARKET ON</td>
<td>L3Y4Z1</td>
<td></td>
</tr>
<tr>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2020685999</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52881044</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2021390537</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52881044</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2024045628</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52881044</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2028764960</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52881044</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2031017010</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52881044</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2031535808</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52881044</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2032080753</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52881044</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2032577637</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52881044</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2032816575</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52881044</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2036991584</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52881044</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2039047947</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951 UserID: NAFF 1234</td>
<td></td>
<td>2nd ref: 52881044</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

UPS

TM

</figure>


# Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 22 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th colspan="3">Postal Code Zone Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<th></th>
<th>Shaded</th>
<th>area denotes</th>
<th colspan="4">10 package shipment</th>
<th></th>
<th></th>
</tr>
<tr>
<td>01/23</td>
<td>1ZG7093D2022143436</td>
<td>Standard</td>
<td colspan="2">M9C1B8 200</td>
<td>290 lbs</td>
<td>191.40</td>
<td>99.53</td>
<td>91.87</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td colspan="2"></td>
<td>220 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>45.00</td>
<td>23.39</td>
<td>21.61</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td>236.40</td>
<td>122.92</td>
<td>113.48</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td colspan="2"></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 262</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">BUNZL CO PENDANT</td>
<td colspan="2"></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 262</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">375 PENDANT DRIVE</td>
<td colspan="2"></td>
<td>25 THE</td>
<td>WEST MALL</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td colspan="2"></td>
<td></td>
<td>ETOBICOKE ON</td>
<td>M9C1B8</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020426849</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="3">2nd ref: 52881037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2021113470</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td colspan="2">ref: 52881037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2021274485</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2022143436</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2022697919</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52881037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2028315865</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td colspan="2">ref: 52881037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2028525656</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td colspan="3">2nd ref: 52881037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2033794892</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="3">2nd ref: 52881037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035910707</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="3">2nd ref: 52881037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2036672526 1st ref: 68951</td>
<td></td>
<td colspan="3" rowspan="2">2nd ref: 52881037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="6">Shaded area denotes 6 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023750377</td>
<td>Standard</td>
<td colspan="2">M5B2H6 200</td>
<td>155 lbs</td>
<td>102.30</td>
<td>53.20</td>
<td>49.10</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>121 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>24.05</td>
<td>12.50</td>
<td>11.55</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td>126.35</td>
<td>65.70</td>
<td>60.65</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="3">2nd ref: 52881036</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td colspan="3">Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 261</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">BUNZL CO PENDANT</td>
<td colspan="3"></td>
<td>LULULEMON</td>
<td>CANADA 261</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="3">218</td>
<td>YONGE STEEET</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td colspan="3">TORONTO</td>
<td>ON</td>
<td>M5B2H6</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2021639420 1st ref: 68951 UserID: NAFF1234</td>
<td></td>
<td colspan="3">2nd ref: 52881036</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


## Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 23 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th></th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/23</td>
<td>1ZG7093D2023750377</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881036</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2024443797</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881036</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025425608</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881036</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2031118812</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881036</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039497381 1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td rowspan="2">52881036</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="7">Shaded area denotes 16 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023954068</td>
<td>Standard</td>
<td colspan="3">L7S2J8 01</td>
<td>402 lbs</td>
<td>546.72</td>
<td>-377.24</td>
<td>169.48</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td></td>
<td>341.6 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>128.51</td>
<td>88.71</td>
<td>39.80</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="3"></td>
<td></td>
<td>675.23</td>
<td>465.95</td>
<td>209.28</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Receiver: LULULEMON</td>
<td>CANADA 290</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">BUNZL CO PENDANT</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON CANADA</td>
<td>290</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td colspan="2"></td>
<td>900</td>
<td>MAPLE AVE</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>BURLINGTON ON</td>
<td>L7S2J8</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2021117092</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2021875219</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2022206001 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52881032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2022648687</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023242774</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023954068</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2024610954 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52881032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2028300906</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52881032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2029883160</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2031088195 1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52881032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


## Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 24 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/23</td>
<td>1ZG7093D2031704732</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52881032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2032076115</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52881032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2034245787</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52881032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2034859678</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52881032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2038910149</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52881032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039758723</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52881032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2026606769</td>
<td>Standard</td>
<td>J3V5J5</td>
<td>203</td>
<td>24 lbs</td>
<td>73.20</td>
<td>-50.51</td>
<td>22.69</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>23.5 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>17.20</td>
<td>-11.87</td>
<td>5.33</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="4">Customer Entered Dimensions = 12 x 10 x 10 in</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>90.40</td>
<td>-62.38</td>
<td>28.02</td>
</tr>
</table>


1st ref: 68951

2nd ref: 52881045

UserID: NAFF1234

Sender : BUNZL

BUNZL CO PENDANT

375 PENDANT DRIVE

MISSISSAUGA ON L5T2W9

Receiver: LULULEMON CANADA 766

LULULEMON CANADA 766 LL766

1 BOUL DES PROMENADES

SAINT-BRUNO QC J3V5J5

Message Codes: ad

Shaded area denotes 3 package shipment


<table>
<tr>
<td>1ZG7093D2027637662</td>
<td>Standard</td>
<td>V3R7C1 207</td>
<td>53 lbs</td>
<td>143.35</td>
<td>98.91</td>
<td>44.44</td>
</tr>
<tr>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td>33.69</td>
<td>23.25</td>
<td>10.44</td>
</tr>
<tr>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td>177.04</td>
<td>122.16</td>
<td>54.88</td>
</tr>
</table>


1st ref: 68951

2nd ref: 52881041

UserID: NAFF 1234

Sender : BUNZL
BUNZL CO PENDANT
375 PENDANT DRIVE
MISSISSAUGA ON L5T2W9

Receiver: LULULEMON CANADA 162

LULULEMON CANADA 162

10355 152 ST

SURREY BC V3R7C1

Message Codes: ad

1ZG7093D2024727276

1st ref: 68951

2nd ref: 52881041

UserID: NAFF 1234

1ZG7093D2027637662

1st ref: 68951

2nd ref: 52881041

UserID: NAFF 1234

1ZG7093D2035660282

1st ref: 68951

2nd ref: 52881041

UserID: NAFF1234

<!-- PageBreak -->


<figure>

Ups

TM

</figure>


## Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 25 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th colspan="2">Postal Code</th>
<th>Zone</th>
<th colspan="2">Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<th>Shaded</th>
<th>area denotes</th>
<th colspan="5">2 package shipment</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td>01/23</td>
<td>1ZG7093D2033209041</td>
<td>Standard</td>
<td colspan="2">M5V0V2</td>
<td>200</td>
<td>58 lbs</td>
<td></td>
<td>52.75</td>
<td>27.43</td>
<td>25.32</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td colspan="2"></td>
<td></td>
<td>46 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>12.40</td>
<td>6.45</td>
<td>5.95</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>65.15</td>
<td>-33.88</td>
<td>31.27</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52881046</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>Receiver:</td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 768</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 768 LL768</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>486</td>
<td>FRONT STREET</td>
<td>W</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>TORONTO ON</td>
<td>M5V0V2</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2033209041</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52881046</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2038775859</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2" rowspan="2">2nd</td>
<td rowspan="2">ref:</td>
<td colspan="2" rowspan="2">52881046</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="7">Shaded area denotes 3 package shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035469230</td>
<td>Standard</td>
<td colspan="2">T3A0E2</td>
<td>206</td>
<td>60 lbs</td>
<td></td>
<td>149.95</td>
<td>-103.47</td>
<td>46.48</td>
</tr>
<tr>
<td rowspan="2"></td>
<td></td>
<td>Customer Weight</td>
<td colspan="2"></td>
<td></td>
<td>59.7 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>35.24</td>
<td>-24.31</td>
<td>10.93</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>185.19</td>
<td>127.78</td>
<td>57.41</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52881042</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>Receiver:</td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 321</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">LULULEMON</td>
<td>CANADA 321</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>3625</td>
<td>SHAGANAPPI</td>
<td>TRAIL NW</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>CALGARY AB</td>
<td>T3A0E2</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025804645</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52881042</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2026835459</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52881042</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035469230</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd</td>
<td>ref:</td>
<td>52881042</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="8">Shaded area denotes 7 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2036632695</td>
<td>Standard</td>
<td>H7T1C8</td>
<td></td>
<td>203</td>
<td>160 lbs</td>
<td></td>
<td>289.60</td>
<td>-199.82</td>
<td>89.78</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>68.05</td>
<td>46.96</td>
<td>21.09</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>357.65</td>
<td>246.78</td>
<td>110.87</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52881033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>Receiver:</td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 517</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2">LULULEMON</td>
<td>CANADA 517</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>3003</td>
<td>BLVD LE</td>
<td>CARREFOUR</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>LAVAL</td>
<td>QC H7T1C8</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020279713</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52881033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2021345747</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52881033</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2022946328 1st ref: 68951 UserID: NAFF1234</td>
<td></td>
<td colspan="2">2nd</td>
<td>ref:</td>
<td colspan="2">52881033</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 26 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/23</td>
<td>1ZG7093D2024080509</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2032110550</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2036632695</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2038836337</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951 UserID: NAFF1234</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52881033</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


Shaded area denotes 22 package shipment


<table>
<tr>
<th>01/26</th>
<th>1ZG7093D2005070387</th>
<th>Standard</th>
<th colspan="2">M6A2T9 200 638 lbs</th>
<th>421,08</th>
<th>-218.96</th>
<th>202.12</th>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td colspan="2">486 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td colspan="2"></td>
<td>100.98</td>
<td>52.54</td>
<td>48.44</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td>522.06</td>
<td>271.50</td>
<td>250.56</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref: 52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td colspan="2">Receiver:</td>
<td>LULULEMON CANADA</td>
<td>260</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">BUNZL CO PENDANT</td>
<td colspan="2"></td>
<td>LULULEMON CANADA</td>
<td>260</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="3">3401 DUFFERIN</td>
<td>ST</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td>NORTH</td>
<td colspan="2">YORK ON M6A2T9</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2000454561</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref: 52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2001582546</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref: 52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2001654423</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref: 52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2001999418</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref: 52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2003307590</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref: 52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2003582444</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref: 52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2005007491</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref: 52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2005070387</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref: 52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2006334466</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref: 52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2007019475</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref: 52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2007307396</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref: 52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 27 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th colspan="2">Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/26</td>
<td>1ZG7093D2007534524</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2008255539</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009510500</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011115559</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011750407</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2012950583</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2013055450</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2013199573</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2014315435</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2015819514</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2018710483 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887498</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2006390806</td>
<td>Standard</td>
<td colspan="2">T1L1A5</td>
<td>209</td>
<td>29 lbs</td>
<td>117.20</td>
<td>-80.87</td>
<td>36.33</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td></td>
<td>21 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>28.13</td>
<td>-19.41</td>
<td>8.72</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="5">Customer Entered Dimensions = 20 x 15 x 13 in</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>145.33</td>
<td>-100.28</td>
<td>45.05</td>
</tr>
</table>


2nd ref: 52887503

1st ref: 68951

UserID: NAFF1234
Sender : BUNZL
BUNZL CO PENDANT
375 PENDANT DRIVE
MISSISSAUGA ON L5T2W9

Receiver: LULULEMON CANADA 351
LULULEMON CANADA 351
125 BANFF AVE
BANFF AB T1L1A5

Message Codes: ad r
Shaded area denotes 14 package shipment


<table>
<tr>
<td>1ZG7093D2007870607</td>
<td>Standard</td>
<td>M5T1G1</td>
<td>200</td>
<td>377 lbs</td>
<td>248.82</td>
<td>-129.39</td>
<td>119.43</td>
</tr>
<tr>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>296.4 lbs</td>
<td></td>
<td rowspan="2">31.05</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>59.68</td>
<td>28.63</td>
</tr>
<tr>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>308.50</td>
<td>160.44</td>
<td>148.06</td>
</tr>
</table>


1st ref: 68951

UserID: NAFF 1234
Sender : BUNZL
BUNZL CO PENDANT
375 PENDANT DRIVE
MISSISSAUGA ON L5T2W9

2nd ref: 52887496

Receiver: LULULEMON CANADA 220
LULULEMON CANADA 220
2 BLOOR STREET WEST
TORONTO ON M5T1G1

Message Codes: ad

<!-- PageBreak -->


<figure>

UPS

TM

</figure>


### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 28 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/26</td>
<td>1ZG7093D2000182640</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887496</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2001094725</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887496</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002207691</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887496</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002795636</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887496</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2005259719</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887496</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2006830705</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887496</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2007790686</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887496</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2007870607</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887496</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009775654</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887496</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2010239614</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887496</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2014014626</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887496</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2015174667</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887496</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2017935733</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887496</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2019979675 1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887496</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="5">Shaded area denotes 3 package shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011694228</td>
<td>Standard</td>
<td>K1N9J7</td>
<td>202</td>
<td>29 lbs</td>
<td>75.90</td>
<td>52.37</td>
<td>23.53</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>27.1 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>18.21</td>
<td>12.56</td>
<td>5.65</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>94.11</td>
<td>64.93</td>
<td>29.18</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951 UserID: NAFF 1234</td>
<td></td>
<td colspan="3">2nd ref: 52887499</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 264</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 264</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td>50</td>
<td>RIDEAU STREET</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td>OTTAWA</td>
<td>ON K1N9J7</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2008235239</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951 UserID: NAFF1234</td>
<td></td>
<td colspan="3">2nd ref: 52887499</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 29 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/26</td>
<td>1ZG7093D2009382248</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887499</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011694228</td>
<td></td>
<td></td>
<td></td>
<td rowspan="3">52887499</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td rowspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Shaded area denotes</td>
<td colspan="4">13 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2013675834</td>
<td>Standard</td>
<td>K2T0K5</td>
<td>202</td>
<td>362 lbs</td>
<td>644.36</td>
<td>-444.61</td>
<td>199.75</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>297 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>154.66</td>
<td>106.72</td>
<td>47,94</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>799.02</td>
<td>551.33</td>
<td>247.69</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 188</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">BUNZL CO PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 188</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td>8555</td>
<td>CAMPEAU</td>
<td>DR</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td>KANATA</td>
<td>ON K2T0K5</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2001807893</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2006414861 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2006550900</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2008895857</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009355956</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2010015936 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2013675834</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2015339873</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2017054926</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2017099914 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2019182847 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2019270886</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2019582941</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 30 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td></td>
<td>Shaded</td>
<td>area denotes</td>
<td colspan="3">11 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/26</td>
<td>1ZG7093D2016459278</td>
<td>Standard</td>
<td>E1A4X5</td>
<td>209 298 lbs</td>
<td>643.68</td>
<td>444.14</td>
<td>199.54</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td>239.5 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td>154.46</td>
<td>106.55</td>
<td>47.91</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td>798.14</td>
<td>550.69</td>
<td>247.45</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52887488</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td colspan="2">Receiver: LULULEMON</td>
<td>CANADA 721</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 721</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td>477</td>
<td>RUE PAUL</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td colspan="2">DIEPPE NB E1A4X5</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2000975338</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52887488</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2001439371</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52887488</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2006182344</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52887488</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2008779312</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52887488</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2010207292</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52887488</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2012030282</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52887488</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2012814364</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52887488</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2014590307</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52887488</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2015595355</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52887488</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2016374323</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52887488</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2016459278</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52887488</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2018735251</td>
<td>Standard</td>
<td>L5B2C9</td>
<td>200 10 lbs</td>
<td>25.75</td>
<td>-13.39</td>
<td>12.36</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td>6.18</td>
<td>-3.21</td>
<td>2.97</td>
</tr>
</table>


<table>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="3">Customer Entered Dimensions = 20 x 6 x 5 in</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Total</td>
<td></td>
<td>31.93</td>
<td>-16.60</td>
<td>15.33</td>
</tr>
</table>


1st ref: 68951
UserID: NAFF1234
Sender : BUNZL
BUNZL CO PENDANT
375 PENDANT DRIVE
MISSISSAUGA ON L5T2W9
Message Codes: ad

2nd ref: 52887500

Receiver: LULULEMON CANADA 267
LULULEMON CANADA 267
100 CITY CENTRE DR
MISSISSAUGA ON L5B2C9

<!-- PageBreak -->


<figure>

Ups
TM

</figure>


Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 31 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<th></th>
<th>Shaded</th>
<th colspan="4">area denotes 6 package shipment</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td>01/26</td>
<td>1ZG7093D2019382747</td>
<td>Standard</td>
<td>H7T1C8</td>
<td>203</td>
<td>174 lbs</td>
<td>314.94</td>
<td>217.31</td>
<td>97.63</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>138 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td colspan="2"></td>
<td></td>
<td>75.60</td>
<td>52.14</td>
<td>23.46</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>390.54</td>
<td>269.45</td>
<td>121.09</td>
</tr>
</table>


1st ref: 68951

2nd ref: 52887484

UserID: NAFF 1234

Sender : BUNZL
BUNZL CO PENDANT
375 PENDANT DRIVE
MISSISSAUGA ON L5T2W9

Receiver: LULULEMON CANADA 517
LULULEMON CANADA 517
3003 BLVD LE CARREFOUR
LAVAL QC H7T 1C8

Message Codes: ad

1ZG7093D2001707796

1st ref: 68951

2nd ref: 52887484

UserID: NAFF 1234

1ZG7093D2003230789

1st ref: 68951

2nd ref: 52887484

UserID: NAFF 1234

1ZG7093D2007359778

1 st ref: 68951

2nd ref: 52887484

UserID: NAFF1234

1ZG7093D2009035757

1st ref: 68951

2nd ref: 52887484

UserID: NAFF1234

1ZG7093D2010494768

1st ref: 68951

2nd ref: 52887484

UserID: NAFF 1234

1ZG7093D2019382747

1st ref: 68951

2nd ref: 52887484

UserID: NAFF 1234

1ZG7093D2019894266


<table>
<tr>
<td>Standard</td>
<td>V2T0C5</td>
<td>209</td>
<td rowspan="2">9 lbs 5.4 lbs</td>
<td rowspan="2">70.70</td>
<td rowspan="2">-48.78</td>
<td rowspan="2">21.92</td>
</tr>
<tr>
<td>Customer Weight</td>
<td></td>
<td></td>
</tr>
<tr>
<td>Fuel Surcharge</td>
<td colspan="2"></td>
<td></td>
<td>16.97</td>
<td>-11.71</td>
<td>5.26</td>
</tr>
<tr>
<td colspan="4">Customer Entered Dimensions = 12 x 10 x 10 in</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td>87.67</td>
<td>-60.49</td>
<td>27.18</td>
</tr>
</table>


1st ref: 68951

2nd ref: 52887511

UserID: NAFF1234

Sender : BUNZL
BUNZL CO PENDANT
375 PENDANT DRIVE
MISSISSAUGA ON L5T2W9

Receiver: LULULEMON CANADA 113
LULULEMON CANADA 113
3122 MOUNT LEHMAN RD
ABBOTSFORD BC V2T0C5

Message Codes: ad r

Shaded area denotes 10 package shipment


<table>
<tr>
<td>1ZG7093D2024043693</td>
<td>Standard</td>
<td>B3L2H8</td>
<td>209</td>
<td>290 lbs</td>
<td>626.40</td>
<td>-432,22</td>
<td>194.18</td>
</tr>
<tr>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>230 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>150.30</td>
<td>103.68</td>
<td>46.62</td>
</tr>
<tr>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>776.70</td>
<td>535.90</td>
<td>240.80</td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td colspan="2">ref: 52887512</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


UserID: NAFF 1234

Sender : BUNZL
BUNZL CO PENDANT
375 PENDANT DRIVE
MISSISSAUGA ON L5T2W9

Receiver: LULULEMON CANADA 722
LULULEMON CANADA 722
7001 MUMFORD RD
HALIFAX NS B3L2H8

Message Codes: ad
1ZG7093D2021970713

1st ref: 68951

UserID: NAFF 1234

2nd ref: 52887512

<!-- PageBreak -->


<figure>

UPS

TM

</figure>


### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 32 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/26</td>
<td>1ZG7093D2022681373</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887512</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2024043693</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887512</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2024568386</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52887512</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025177323</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>52887512</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2026997767</td>
<td></td>
<td></td>
<td rowspan="3">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52887512</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2028831502</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52887512</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2029207337</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52887512</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2031456742</td>
<td></td>
<td></td>
<td rowspan="3">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>52887512</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2037561555</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951 UserID: NAFF 1234</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887512</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


Shaded area denotes 13 package shipment


<table>
<tr>
<td>1ZG7093D2025703521</td>
<td>Standard</td>
<td>T3A0E2 206 377 lbs</td>
<td>791.70</td>
<td>546.27</td>
<td>245.43</td>
</tr>
<tr>
<td></td>
<td>Customer Weight</td>
<td>289 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td>190.06</td>
<td>131.14</td>
<td>58.92</td>
</tr>
<tr>
<td></td>
<td>Total</td>
<td></td>
<td>981.76</td>
<td>677.41</td>
<td>304.35</td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52887507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Sender : BUNZL</td>
<td></td>
<td>Receiver:</td>
<td colspan="2">LULULEMON CANADA 321</td>
<td></td>
</tr>
<tr>
<td colspan="2">BUNZL CO PENDANT</td>
<td colspan="3">LULULEMON CANADA 321</td>
<td></td>
</tr>
<tr>
<td colspan="2">375 PENDANT DRIVE</td>
<td colspan="2">3625 SHAGANAPPI</td>
<td>TRAIL NW</td>
<td></td>
</tr>
<tr>
<td colspan="2">MISSISSAUGA ON L5T2W9</td>
<td colspan="3">CALGARY AB T3A0E2</td>
<td></td>
</tr>
<tr>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2020331754</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52887507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2020862583</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52887507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2021148639</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52887507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2023955969</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52887507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2025703521</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52887507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2029520042</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52887507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 33 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/26</td>
<td>1ZG7093D2030486800</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2030561531</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2034296991</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2034908016</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2036476622</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2038547579</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039958945</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951 UserID: NAFF1234</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887507</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


Shaded area denotes 6 package shipment

1ZG7093D2026440232


<table>
<tr>
<td colspan="2" rowspan="2">Standard Customer Weight</td>
<td>S4PQJ5</td>
<td rowspan="2">205</td>
<td rowspan="2">168 lbs 138 lbs</td>
<td rowspan="2">342.72</td>
<td rowspan="2">236.48</td>
<td rowspan="2">106.24</td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td colspan="2">Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>82.26</td>
<td>56.76</td>
<td>25.50</td>
</tr>
<tr>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>424.98</td>
<td>293.24</td>
<td>131.74</td>
</tr>
</table>


1st ref: 68951

2nd ref: 52887483

UserID: NAFF 1234

Sender : BUNZL

BUNZL CO PENDANT
375 PENDANT DRIVE
MISSISSAUGA ON L5T2W9

Receiver: LULULEMON CANADA 432
LULULEMON CANADA 432
2114 11TH AVE
REGINA SK S4P0J5

Message Codes: ad

1ZG7093D2020258272

1st ref: 68951

2nd ref: 52887483

UserID: NAFF 1234

1ZG7093D2020515645

1st ref: 68951

2nd ref: 52887483

UserID: NAFF1234

1ZG7093D2020628667

1st ref: 68951

2nd ref: 52887483

UserID: NAFF1234

1ZG7093D2020886450

1st ref: 68951

2nd ref: 52887483

UserID: NAFF1234

1ZG7093D2021331289

1st ref: 68951

2nd ref: 52887483

UserID: NAFF 1234

1ZG7093D2026440232

1st ref: 68951

2nd ref: 52887483

UserID: NAFF1234

<!-- PageBreak -->


<figure>

Ups

TM

</figure>


### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 34 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th colspan="2">Postal Code</th>
<th>Zone</th>
<th colspan="2">Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<th></th>
<th>Shaded</th>
<th>area denotes</th>
<th colspan="5">4 package shipment</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td>01/26</td>
<td>1ZG7093D2031693414</td>
<td>Standard</td>
<td colspan="2">L9A4X5</td>
<td>201</td>
<td>116</td>
<td>lbs</td>
<td>155.35</td>
<td>-107.19</td>
<td>48.16</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td colspan="2"></td>
<td></td>
<td colspan="2">92 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>37.29</td>
<td>25.72</td>
<td>11.57</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>192.64</td>
<td>132.91</td>
<td>59.73</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd</td>
<td>ref:</td>
<td colspan="2">52887490</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2">Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 218</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>LULULEMON</td>
<td>CANADA 218</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="2"></td>
<td></td>
<td colspan="2">999</td>
<td>UPPER</td>
<td>WENTWORTH ST</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>HAMILTON ON</td>
<td>L9A4X5</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025253446</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52887490</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2031693414</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52887490</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2036726030</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td colspan="2">2nd</td>
<td>ref:</td>
<td colspan="2">52887490</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2036938025</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td colspan="2">2nd</td>
<td>ref:</td>
<td colspan="2">52887490</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="8">Shaded area denotes 3 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2034771833</td>
<td>Standard</td>
<td colspan="2">H3B4G5</td>
<td>203</td>
<td colspan="2">76 lbs</td>
<td>148.35</td>
<td>-102.36</td>
<td>45.99</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td></td>
<td>75.5</td>
<td>lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>35.60</td>
<td>-24.56</td>
<td>11.04</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>183.95</td>
<td>126.92</td>
<td>57.03</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52887514</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="3">Receiver: LULULEMON</td>
<td>CANADA 263</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 263 CAD</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>705</td>
<td>SAINT-CATHERINE</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>MONTREAL QC</td>
<td>H3B4G5</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025586051</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52887514</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2032151248</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887514</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2034771833</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd</td>
<td rowspan="2">ref:</td>
<td colspan="2" rowspan="2">52887514</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Shaded area denotes</td>
<td colspan="6">13 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035589726</td>
<td>Standard</td>
<td colspan="2">T4A0G3</td>
<td>207</td>
<td colspan="2">341 lbs</td>
<td>722.92</td>
<td>-498.81</td>
<td>224.11</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td></td>
<td>265</td>
<td>lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>173.56</td>
<td>119.79</td>
<td>53.77</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>896.48</td>
<td>618.60</td>
<td>277.88</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td colspan="2">52887516</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>Receiver:</td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 360</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>LULULEMON</td>
<td>CANADA 360 LL360</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="2"></td>
<td></td>
<td colspan="2">261055</td>
<td>CROSSIRON</td>
<td>BLVD</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td colspan="2"></td>
<td></td>
<td colspan="2">ROCKY</td>
<td>VIEW</td>
<td>COUNTY AB T4A0G3</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

UPS

TM

</figure>


#### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 35 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th colspan="2">Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/26</td>
<td>1ZG7093D2020566215</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887516</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2022142839</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887516</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023957001</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887516</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2030621145</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887516</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035499190</td>
<td></td>
<td></td>
<td colspan="2" rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52887516</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035589726</td>
<td></td>
<td></td>
<td colspan="2" rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52887516</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035661950</td>
<td></td>
<td></td>
<td colspan="2" rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52887516</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035773777</td>
<td></td>
<td></td>
<td colspan="2" rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52887516</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2036916781</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887516</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039042826</td>
<td></td>
<td></td>
<td colspan="2" rowspan="3">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52887516</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039262240</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887516</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039675732</td>
<td></td>
<td></td>
<td colspan="2" rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52887516</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039874160</td>
<td></td>
<td></td>
<td colspan="2" rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52887516</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


Shaded area denotes 18 package shipment


<table>
<tr>
<th>1ZG7093D2036956256</th>
<th>Standard</th>
<th colspan="2">L3R4M9 200 522 lbs</th>
<th>344.52</th>
<th>-179.15</th>
<th>165.37</th>
</tr>
<tr>
<td></td>
<td>Customer Weight</td>
<td colspan="2">414 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Fuel Surcharge</td>
<td colspan="2"></td>
<td>82.62</td>
<td>42.99</td>
<td>39.63</td>
</tr>
<tr>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td>427.14</td>
<td>222.14</td>
<td>205.00</td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON CANADA</td>
<td>213</td>
<td></td>
</tr>
<tr>
<td colspan="2">BUNZL CO PENDANT</td>
<td colspan="2"></td>
<td>LULULEMON CANADA</td>
<td>213</td>
<td></td>
</tr>
<tr>
<td colspan="2">375 PENDANT DRIVE</td>
<td colspan="3">5000 HIGHWAY 7 E</td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">MISSISSAUGA ON L5T2W9</td>
<td colspan="3">MARKHAM ON L3R4M9</td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">Message Codes: ad</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2020034183</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1ZG7093D2020175174</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref: 52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

UPS

TM

</figure>


#### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 36 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/26</td>
<td>1ZG7093D2020999561</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023424229</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023712515</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2024677080</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2026011124</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2026372593</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2026432072</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2026761305</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2027613133</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2028471615</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2029226405</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2032110461</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2036956256</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2037114547</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2038241498</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039351359</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td rowspan="2">52887485</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

UPS

TM

</figure>


#### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 37 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th colspan="2">Postal Code Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<th></th>
<th>Shaded</th>
<th>area denotes</th>
<th colspan="3">6 package shipment</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td>01/26</td>
<td>1ZG7093D2037701153</td>
<td>Standard</td>
<td colspan="2">L4M4Z8 201</td>
<td>198 lbs</td>
<td>269.28</td>
<td>-185.80</td>
<td>83.48</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td colspan="2"></td>
<td>138 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td colspan="2"></td>
<td></td>
<td>64.62</td>
<td>44.58</td>
<td>20.04</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td>333.90</td>
<td>230.38</td>
<td>103.52</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="3">2nd ref: 52887489</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td colspan="3">Receiver:</td>
<td>LULULEMON CANADA</td>
<td>217</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">BUNZL CO PENDANT</td>
<td colspan="2"></td>
<td></td>
<td>LULULEMON CANADA</td>
<td>217</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="2"></td>
<td>509</td>
<td>BAYFIELD ST</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td colspan="2"></td>
<td>BARRIE</td>
<td>ON L4M4Z8</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023028970</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="3">2nd ref: 52887489</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023650396</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td colspan="2">ref: 52887489</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025436203</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887489</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2037701153 1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887489</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2037961364</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887489</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039259987</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="3" rowspan="2">2nd ref: 52887489</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="6">Shaded area denotes 5 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/27</td>
<td>1ZG7093D2014336252</td>
<td>Standard</td>
<td colspan="2">R2M5E5 204</td>
<td>122 lbs</td>
<td>236.80</td>
<td>-163.39</td>
<td>73.41</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>110 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>56.84</td>
<td>-39.22</td>
<td>17.62</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td>293.64</td>
<td>202.61</td>
<td>91.03</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="3">2nd ref: 52887518</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td colspan="2">Receiver:</td>
<td>LULULEMON USA</td>
<td>INC</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td colspan="2"></td>
<td></td>
<td>LULULEMON USA</td>
<td>INC. 00970</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="2"></td>
<td>1225</td>
<td>ST MARY'S</td>
<td>RD</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td colspan="2"></td>
<td>WINNIPEG</td>
<td>MB</td>
<td>R2M5E5</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2008208296</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="3">2nd ref: 52887518</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009431284</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887518</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2013260273 1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887518</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2014336252</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887518</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2016095269</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887518</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


#### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 38 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th colspan="2">Postal Code Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td></td>
<td>Shaded</td>
<td>area denotes</td>
<td colspan="4">13 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/27</td>
<td>1ZG7093D2015415129</td>
<td>Standard</td>
<td colspan="2">L3Y4Z1 200</td>
<td>357 lbs</td>
<td>235.62</td>
<td>-122.52</td>
<td>113.10</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td colspan="2"></td>
<td>276.4 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td colspan="2"></td>
<td></td>
<td>56.51</td>
<td>29.40</td>
<td>27.11</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td>292.13</td>
<td>151.92</td>
<td>140.21</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="3">2nd ref: 52887510</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td colspan="4">Receiver: LULULEMON</td>
<td>CANADA 275</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td colspan="2"></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 275</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td colspan="2"></td>
<td>17600</td>
<td>YONGE ST</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td colspan="2"></td>
<td></td>
<td>NEWMARKET ON</td>
<td>L3Y4Z1</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002183145</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887510</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002636236</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887510</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002880178</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887510</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2004383247</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887510</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2004496134</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887510</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2005495222</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887510</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2005708199</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887510</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009360217</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887510</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2010631207</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887510</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2010991186</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887510</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2012076153</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887510</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2015415129</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887510</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2017775166</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52887510</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


## Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 39 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<th></th>
<th>Shaded</th>
<th>area denotes</th>
<th colspan="3">3 package shipment</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td>01/27</td>
<td>1ZG7093D2016175324</td>
<td>Standard</td>
<td>L1V1B8</td>
<td>200</td>
<td>177 lbs</td>
<td>116.82</td>
<td>60.75</td>
<td>56.07</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>91.2 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>28.05</td>
<td>14.58</td>
<td>13.47</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>144.87</td>
<td>-75.33</td>
<td>69.54</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref: 52887521</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td colspan="2">Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 136</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 136</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td>1355</td>
<td>KINGSTON</td>
<td>ST</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>PICKERING ON</td>
<td>L1V1B8</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2001376331</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref: 52887521</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2007183341</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887521</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2016175324</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2" rowspan="2">2nd ref: 52887521</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="6">Shaded area denotes 2 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2017196354</td>
<td>Standard</td>
<td>H3B4G5</td>
<td>203</td>
<td>118 lbs</td>
<td>214.20</td>
<td>-147.80</td>
<td>66.40</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>69.2 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>51.41</td>
<td>35.47</td>
<td>15.94</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>265.61</td>
<td>-183.27</td>
<td>82.34</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref: 52894978</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td colspan="2">Receiver: HUGO</td>
<td>BOSS</td>
<td>CANADA 522</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td></td>
<td></td>
<td>HUGO</td>
<td>BOSS</td>
<td>CANADA 5220</td>
<td>HBFC5</td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td>705</td>
<td>RUE</td>
<td>SAINT-CATHERINE ST</td>
<td>OUEST</td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>MONTREAL QC</td>
<td>H3B4G5</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2015015365</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref: 52894978</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2017196354</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td rowspan="2"></td>
<td colspan="2" rowspan="2">2nd ref: 52894978</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="6">Shaded area denotes 5 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020730984</td>
<td>Standard</td>
<td>K7L</td>
<td>1B5 202</td>
<td>174 lbs</td>
<td>309.72</td>
<td>-213.71</td>
<td>96.01</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>113.4 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>74.33</td>
<td>51.28</td>
<td>23.05</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>384.05</td>
<td>264.99</td>
<td>119.06</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref: 52887501</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td colspan="2">Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 268</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 268</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td>270</td>
<td>PRINCESS ST</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>KINGSTON ON</td>
<td>K7L1B5</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020730984</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref: 52887501</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2022969027 1st ref: 68951 UserID: NAFF 1234</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887501</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 40 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/27</td>
<td>1ZG7093D2025184413</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887501</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2029987209</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887501</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2038861390</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887501</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="6">Shaded area denotes 10 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2022897033</td>
<td>Standard</td>
<td colspan="2">L 1J2K5 200</td>
<td>252 lbs</td>
<td>166.32</td>
<td>86.49</td>
<td>79.83</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>204 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>39.88</td>
<td>20.74</td>
<td>19.14</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td colspan="2"></td>
<td></td>
<td>206.20</td>
<td>107.23</td>
<td>98.97</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887505</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 274</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 274</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td>419</td>
<td>KING ST W</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>OSHAWA ON L</td>
<td>1J2K5</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2022207251</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887505</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2022712302</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887505</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2022897033</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887505</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023164448</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887505</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2024301467</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887505</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2024603515</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887505</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025548084</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887505</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2028852490</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887505</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2029163072</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887505</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035442124</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887505</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

UPS

TM

</figure>


### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 41 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<th></th>
<th>Shaded</th>
<th>area denotes</th>
<th>4 package</th>
<th colspan="2">shipment</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td>01/27</td>
<td>1ZG7093D2025454694</td>
<td>Standard</td>
<td>K2A0E8</td>
<td>202</td>
<td>116 lbs</td>
<td>206.20</td>
<td>-142.28</td>
<td>63.92</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>92 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>49.49</td>
<td>34.16</td>
<td>15.33</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>255.69</td>
<td>-176.44</td>
<td>79.25</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887497</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 240</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 240</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td colspan="2">340 RICHMOND</td>
<td>RD</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td colspan="2">OTTAWA ON</td>
<td>K2A0E8</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2021408321</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887497</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025454694</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887497</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2027582506</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887497</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2037661714</td>
<td></td>
<td></td>
<td></td>
<td rowspan="3">52887497</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="6">Shaded area denotes 6 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2031411236</td>
<td>Standard</td>
<td>N8X3Y8</td>
<td>202</td>
<td>174 lbs</td>
<td>309,72</td>
<td>-213.71</td>
<td>96.01</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>138 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>74.34</td>
<td>51.30</td>
<td>23.04</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>384.06</td>
<td>265.01</td>
<td>119.05</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887504</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 252</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 252</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td>3100</td>
<td>HOWARD</td>
<td>AVE</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>WINDSOR ON</td>
<td>N8X3Y8</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2021002287</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887504</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2027619664</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887504</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2028937452</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887504</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2029226647</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887504</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2029789272</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887504</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2031411236</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887504</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

UPS

TM

</figure>


## Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 42 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<th>Shaded</th>
<th>area denotes</th>
<th>6 package</th>
<th colspan="2">shipment</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td>01/27</td>
<td>1ZG7093D2031727600</td>
<td>Standard</td>
<td>M1P4P5</td>
<td>200</td>
<td>174 lbs</td>
<td>114.84</td>
<td>59.72</td>
<td>55.12</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>138 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>27.54</td>
<td>14.33</td>
<td>13.21</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>142.38</td>
<td>-74.05</td>
<td>68.33</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td colspan="2">ref: 52887502</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td colspan="2">Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 272</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 272</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td>300</td>
<td>BOROUGH DR</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td colspan="2"></td>
<td>SCARBOROUGH</td>
<td>ON M1P4P5</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023300817</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td colspan="2">ref: 52887502</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025448843</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td colspan="2">ref: 52887502</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2026901421</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td>2nd</td>
<td colspan="2">ref: 52887502</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2031727600</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td colspan="2">ref: 52887502</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035685434</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td colspan="2">ref: 52887502</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2036227650</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td colspan="2">ref: 52887502</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="6">Shaded area denotes 4 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2032383597</td>
<td>Standard</td>
<td>L1V1B8</td>
<td>200</td>
<td>116 lbs</td>
<td>83.65</td>
<td>43.50</td>
<td>40.15</td>
</tr>
<tr>
<td rowspan="2"></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>92 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>20.08</td>
<td>-10.44</td>
<td>9.64</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td colspan="2"></td>
<td>103.73</td>
<td>53.94</td>
<td>49.79</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td colspan="2">ref: 52887517</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td colspan="2">Receiver:</td>
<td>LULULEMON CANADA</td>
<td>136</td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON CANADA</td>
<td>136</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td>1355</td>
<td>KINGSTON</td>
<td>ST</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>PICKERING ON</td>
<td>L1V1B8</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2032383597</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td colspan="2">ref: 52887517</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2036255227</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887517</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2036577406 1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887517</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2036762616</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td>2nd</td>
<td>ref:</td>
<td>52887517</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

UPS

TM

</figure>


## Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 43 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<th></th>
<th>Shaded</th>
<th>area denotes</th>
<th colspan="3">7 package shipment</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td>01/27</td>
<td>1ZG7093D2033578330</td>
<td>Standard</td>
<td>K2B8C1</td>
<td>202</td>
<td>179 lbs</td>
<td>318.62</td>
<td>219.85</td>
<td>98.77</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>142.7 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>76.48</td>
<td>52.77</td>
<td>23.71</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>395.10</td>
<td>272.62</td>
<td>122.48</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887506</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON CANADA</td>
<td>215</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">BUNZL CO PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON CANADA</td>
<td>215</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td>100</td>
<td>BAYSHORE DR</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td>NEPEAN</td>
<td>ON K2B8C1</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2021388764</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887506</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023639382</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887506</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2024065795</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887506</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2033578330 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887506</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035567740</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887506</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035612379</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52887506</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2037012559 1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td rowspan="2">52887506</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="5">Shaded area denotes 5 package shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2037897863</td>
<td>Standard</td>
<td>J7J0T1</td>
<td>203</td>
<td>180 lbs</td>
<td>325.80</td>
<td>-224.80</td>
<td>101.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>140 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>78.20</td>
<td>53.94</td>
<td>24.26</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>404.00</td>
<td>278.74</td>
<td>125.26</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52894979</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td>Receiver: HUGO</td>
<td>OUTLET 1734</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>BUNZL CO</td>
<td>PENDANT</td>
<td></td>
<td></td>
<td>HUGO</td>
<td>OUTLET</td>
<td>1734</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td>19001</td>
<td>CH NOTRE-DAME</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td>MIRABEL</td>
<td>QC J7J0T1</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2024216489</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52894979</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2024216890 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52894979</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025012705</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52894979</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2037897863 1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52894979</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


## Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 44 of 103" -->

Outbound
Shipping API (continued)


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>01/27</td>
<td>1ZG7093D2039775473</td>
<td></td>
<td></td>
<td rowspan="3">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td rowspan="2"></td>
<td>52894979</td>
<td rowspan="2"></td>
<td></td>
<td rowspan="2"></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="6">Shaded area denotes 12 package shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/28</td>
<td>1ZG7093D2029679917</td>
<td>Standard</td>
<td>L7G0J1</td>
<td>200</td>
<td>420 lbs</td>
<td>277.20</td>
<td>-144.14</td>
<td>133.06</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>66.48</td>
<td>-34.54</td>
<td>31.94</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td>343.68</td>
<td>178.68</td>
<td>165.00</td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52895755</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender : BUNZL</td>
<td></td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 189</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">BUNZL CO PENDANT</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 189</td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT</td>
<td>DRIVE</td>
<td></td>
<td></td>
<td>13850</td>
<td>STEELES</td>
<td>AVE</td>
<td></td>
</tr>
<tr>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>GEORGETOWN</td>
<td>ON L7G0J1</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2"></td>
<td>1ZG7093D2021907998</td>
<td></td>
<td></td>
<td colspan="2" rowspan="2">2nd ref: 52895755</td>
<td rowspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2022582757</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52895755</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2022907629</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52895755</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023437804</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52895755</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2028734528</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52895755</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2029679917</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52895755</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2032799013</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52895755</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2033146967</td>
<td></td>
<td></td>
<td colspan="2" rowspan="2">2nd ref: 52895755</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2033732538</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52895755</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2034869943</td>
<td></td>
<td></td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>52895755</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2038278575</td>
<td></td>
<td></td>
<td colspan="2" rowspan="2">2nd ref: 52895755</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2"></td>
<td>1ZG7093D2038733582</td>
<td></td>
<td rowspan="2"></td>
<td colspan="2" rowspan="3">2nd ref: 52895755</td>
<td rowspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>UserID: NAFF 1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Total for</td>
<td>Internet-ID: NAFF1234</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>26,600.67</td>
<td>-17,795.79</td>
<td>8,804.88</td>
</tr>
<tr>
<td>Total Shipping</td>
<td>API</td>
<td></td>
<td>490</td>
<td></td>
<td>Package(s)</td>
<td>26,600.67</td>
<td>-17,795.79</td>
<td>8,804.88</td>
</tr>
<tr>
<td>Total Outbound</td>
<td></td>
<td></td>
<td>490</td>
<td></td>
<td>Package(s)</td>
<td>26,600.67</td>
<td>-17,795.79</td>
<td>8,804.88</td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


Page 45 of 103

Inbound
Collect


<table>
<tr>
<th>Pickup Date</th>
<th>Pickup Record</th>
<th>Entry</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th></th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Shaded</td>
<td>area denotes</td>
<td colspan="4">2 package shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/28</td>
<td>2509588023</td>
<td></td>
<td></td>
<td>Standard Collect</td>
<td>L7L0E8</td>
<td>201</td>
<td>22 lbs</td>
<td></td>
<td>53.45</td>
<td>-36.88</td>
<td>16.57</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>14 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Freight Collect / Third</td>
<td>Party Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>6.50</td>
<td>6.50</td>
<td>0.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>12.83</td>
<td>8.85</td>
<td>3.98</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>72.78</td>
<td>52.23</td>
<td>20.55</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>1st ref: 211365</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>211365</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Sender :</td>
<td></td>
<td></td>
<td colspan="4">Receiver: PO#1303326</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>LENBROOK</td>
<td>INDUSTRIES</td>
<td></td>
<td></td>
<td></td>
<td>Bunzl</td>
<td>Canada Inc</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>633 GRANITE</td>
<td>CRT</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">4240 Harvester Rd.</td>
<td>Unit 3</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>PICKERING</td>
<td>ON L1W3K1</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Burlington ON L7L0E8</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>7</td>
<td>1ZR7122W2043252195</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>1st ref: 211365</td>
<td></td>
<td></td>
<td colspan="3">2nd ref: 211365</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>8</td>
<td>1ZR7122W2043273207</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>1st ref: 211365</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>211365</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Shaded</td>
<td>area denotes</td>
<td colspan="4">2 package shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Standard Collect</td>
<td>T5V1T4</td>
<td>206</td>
<td>13 lbs</td>
<td></td>
<td>78.70</td>
<td>54.30</td>
<td>24.40</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Customer Weight</td>
<td></td>
<td></td>
<td>9 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Freight Collect / Third</td>
<td>Party Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>6.50</td>
<td>6.50</td>
<td>0.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>18.88</td>
<td>13.03</td>
<td>5.85</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>104.08</td>
<td>73.83</td>
<td>30.25</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>1st ref: 211372</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>211372</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Sender : LENBROOK</td>
<td>INDUSTRIES</td>
<td></td>
<td colspan="4">Receiver: BUNZL RETAIL</td>
<td>SERVICES</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>633 GRANITE</td>
<td>CRT</td>
<td></td>
<td></td>
<td></td>
<td>12642</td>
<td>184 ST. NW</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>PICKERING</td>
<td>ON L1W3K1</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>EDMONTON AB</td>
<td>T5V1T4</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Message Codes: ad</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>9</td>
<td>1ZR7122W2044008813</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>1st ref: 211372</td>
<td></td>
<td></td>
<td colspan="3">2nd ref: 211372</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>10</td>
<td>1ZR7122W2044175026</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>1st ref: 211372</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>211372</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Total for</td>
<td>Shipper</td>
<td>: 0000R7122W</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>176.86</td>
<td>-126.06</td>
<td>50.80</td>
</tr>
<tr>
<td colspan="2">Total Collect</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>4</td>
<td>Package(s)</td>
<td></td>
<td>176.86</td>
<td>-126.06</td>
<td>50.80</td>
</tr>
<tr>
<td>Total</td>
<td>Inbound</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>4</td>
<td>Package(s)</td>
<td></td>
<td>176.86</td>
<td>-126.06</td>
<td>50.80</td>
</tr>
</table>


Adjustments & Other Charges
Address Corrections


<table>
<tr>
<th>Tracking Number</th>
<th>Service</th>
<th>Number of Packages</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>1ZG7093D2011269607</td>
<td>Standard</td>
<td>2</td>
<td>39.30</td>
<td></td>
<td>39.30</td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52881034</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th>Recorded: LULULEMON</th>
<th>CANADA 600</th>
<th colspan="3">Corrected: LULULEMON CANADA 600</th>
<th rowspan="3"></th>
</tr>
<tr>
<th colspan="2">LULULEMON CANADA 600</th>
<th colspan="3" rowspan="2">LULULEMON CANADA 600 555 STERLING LYON PKWY WINNIPEG MB R3P2S8</th>
</tr>
<tr>
<th colspan="2">555 STERLING LYON PKWY #302, O WINNIPEG MB R3P1J9</th>
</tr>
<tr>
<td>1ZG7093D2015989304</td>
<td>Standard</td>
<td>29</td>
<td>569.85</td>
<td></td>
<td>569.85</td>
</tr>
<tr>
<td>1st ref: 68951</td>
<td></td>
<td>2nd ref: 52848013</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Recorded: LULULEMON</td>
<td>CANADA 600</td>
<td colspan="3">Corrected: LULULEMON CANADA 600</td>
<td></td>
</tr>
<tr>
<td colspan="2">LULULEMON CANADA 600</td>
<td colspan="3" rowspan="2">LULULEMON CANADA 600 555 STERLING LYON PKWY WINNIPEG MB R3P2S8</td>
<td rowspan="2"></td>
</tr>
<tr>
<td colspan="2">555 STERLING LYON PKWY #302, O WINNIPEG MB R3P1J9</td>
</tr>
<tr>
<td></td>
<td></td>
<td>31</td>
<td>609.15</td>
<td></td>
<td>609.15</td>
</tr>
</table>


Total Address Corrections

<!-- PageBreak -->


<figure>

Ups

TM

</figure>


## Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 46 of 103" -->

Adjustments & Other Charges
Packages Delivered but not Previously Billed


<table>
<tr>
<th>Delivery Date</th>
<th>Tracking Number</th>
<th>Service</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
</tr>
<tr>
<td>12/24</td>
<td>1ZG7093D2008191125</td>
<td>Standard</td>
<td>200</td>
<td>32 lbs</td>
<td>37.95</td>
<td>-19.73</td>
<td>18.22</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Missing PLD Fee</td>
<td></td>
<td></td>
<td>4.05</td>
<td></td>
<td>4.05</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Surge Fee - Com</td>
<td></td>
<td></td>
<td>1.00</td>
<td>-0.40</td>
<td>0.60</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td>10.32</td>
<td>-5.33</td>
<td>4.99</td>
</tr>
<tr>
<td rowspan="2"></td>
<td></td>
<td colspan="2" rowspan="2">Audited Dimensions = 21 x 16 x 13 in Audited Dimensions = 20.8 x 15.8 x 13.4 in</td>
<td rowspan="2"></td>
<td rowspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td>53.32</td>
<td>-25.46</td>
<td>27.86</td>
</tr>
<tr>
<td rowspan="4"></td>
<td>Receiver: LULULEMON</td>
<td>CANADA 267</td>
<td>Sender</td>
<td colspan="3">: BRS CANADA C/O NAFFI</td>
<td></td>
</tr>
<tr>
<td colspan="2">100 CITY CENTRE</td>
<td></td>
<td>375</td>
<td>PENDANT</td>
<td>DRIVE</td>
<td></td>
</tr>
<tr>
<td>MISSISSAUGA</td>
<td>ON L5B2C9</td>
<td></td>
<td></td>
<td>MISSISSAUGA ON</td>
<td>L5T2W9</td>
<td></td>
</tr>
<tr>
<td colspan="2">Message Codes:ad w dd</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/22</td>
<td>1ZG7093D2033976196</td>
<td>Missing PLD Fee</td>
<td></td>
<td></td>
<td>4.05</td>
<td></td>
<td>4.05</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total</td>
<td></td>
<td></td>
<td>4.05</td>
<td></td>
<td>4.05</td>
</tr>
<tr>
<td></td>
<td>Receiver:</td>
<td></td>
<td></td>
<td colspan="3">Sender : BRS CANADA C/O NAFFI</td>
<td></td>
</tr>
<tr>
<td rowspan="2"></td>
<td colspan="2">3100 HOWARD</td>
<td></td>
<td>375</td>
<td colspan="2">PENDANT DRIVE</td>
<td></td>
</tr>
<tr>
<td colspan="2">WINDSOR ON N8X</td>
<td></td>
<td></td>
<td colspan="2">MISSISSAUGA ON L5T2W9</td>
<td></td>
</tr>
<tr>
<td colspan="2">Total Packages Delivered but not Previously</td>
<td>Billed</td>
<td>2</td>
<td>Package(s)</td>
<td>57.37</td>
<td>-25.46</td>
<td>31.91</td>
</tr>
</table>


Shipping Charge Corrections Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th colspan="2">Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Shaded area</td>
<td>denotes</td>
<td></td>
<td colspan="2">multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/12</td>
<td colspan="2">1ZG7093D2001047562</td>
<td>Standard</td>
<td>T2H0K8</td>
<td>206</td>
<td>624 lbs</td>
<td>1,310.40</td>
<td>904.18</td>
<td>406.22</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>T2H0K8</td>
<td>206</td>
<td>830.0 lbs</td>
<td>1,743.00</td>
<td>-1,202.67</td>
<td>540.33</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>101.80</td>
<td>-70.26</td>
<td>31.54</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 332</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 332</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>6455 MACLEOD</td>
<td>TRAIL SW</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>CALGARY</td>
<td>AB T2H0K8</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2001047562</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.4 × 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009592575</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 × 15.4</td>
<td>× 14.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2005143585</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>31.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 15 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.4 x 15</td>
<td>× 14.8 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2011300590</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.4 x</td>
<td>15.2 × 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 47 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th rowspan="2">Tracking Number</th>
<th rowspan="2"></th>
<th rowspan="2">Original Service/ Corrected Service</th>
<th rowspan="2">Postal Code</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th rowspan="2">Published Charge</th>
<th rowspan="2">Incentive Credit</th>
<th rowspan="2">Billed Charge</th>
<th>Adjustment</th>
</tr>
<tr>
<th>Amount</th>
</tr>
<tr>
<td>01/12</td>
<td colspan="2">1ZG7093D2011663609</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="3">Audited Dimensions = 18.2 x 15.2×14.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009407622</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x</td>
<td>15,2 × 14.6 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2013988630</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.4 x</td>
<td>15.4 × 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1 st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52806499</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2007175645</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.4 x</td>
<td>15.4 × 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th>1st</th>
<th>ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52806499</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2012568658</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>30.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 18 x 15 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 ×</td>
<td>15 × 14.6 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1 st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52806499</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2013767664</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.4 x</td>
<td>15.2 × 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2014372678</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 19 × 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.4×14.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2008623702</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 21 x</td>
<td>15,4 x 13.8 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2002852716</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 20.8 x</td>
<td>15.6×13.6in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2014487723</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.2 ×</td>
<td>16 × 13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 48 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th rowspan="2">Tracking Number</th>
<th>Original Service/</th>
<th rowspan="2">Postal Code</th>
<th></th>
<th rowspan="2">Weight</th>
<th rowspan="2">Published Charge</th>
<th rowspan="2">Incentive Credit</th>
<th></th>
<th>Billed</th>
<th colspan="2">Adjustment</th>
</tr>
<tr>
<th>Corrected Service</th>
<th>Zone</th>
<th></th>
<th>Charge</th>
<th></th>
<th>Amount</th>
</tr>
<tr>
<td>01/12</td>
<td>1ZG7093D2004375747</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.6 x</td>
<td>15.8× 13.6</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009828758</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 × 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.4 x</td>
<td>15.4 × 13.8</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2007087768</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Audited Dimensions = 20.8 x 15.8×13.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2019752776</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 21 x 15.8 Customer Entered Dimensions</td>
<td>x 13.6 in = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011423789</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.6 x 16</td>
<td>× 13.6 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2005700795</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 17 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.4 ×</td>
<td>16.2 × 13.8</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2006183807</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 17 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Audited Dimensions = 20.4 × 16.2×13.6in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2016472815</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">165.65</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 21 x 15.8 Customer Entered Dimensions</td>
<td>21 x 16 × x 13.2 in = 20 × 16</td>
<td>14 in × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806499</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="6">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002175841</td>
<td>Standard</td>
<td>T3A0E2</td>
<td>206</td>
<td>378 lbs</td>
<td>793.80</td>
<td>547.72</td>
<td colspan="2">246.08</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>T3A0E2</td>
<td>206</td>
<td>490.0 lbs</td>
<td>1,029.00</td>
<td>710.01</td>
<td></td>
<td>318.99</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>55.35</td>
<td>-38.21</td>
<td></td>
<td>17.14</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806512</td>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td colspan="3">CANADA 321</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA</td>
<td>321</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>3625</td>
<td>SHAGANAPPI TRAIL</td>
<td colspan="2">NW</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>CALGARY</td>
<td>AB T3A0E2</td>
<td colspan="2"></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


#### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 49 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th></th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/12</td>
<td colspan="2">1ZG7093D2005732877</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 × Audited Dimensions = 20.6 x 15.6× 13.6</td>
<td>14 in in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806512</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2005463882</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="3">Billable Audited Dimensions = 21 x 16 × 14 in Audited Dimensions = 21 x 16 × 13.8 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806512</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2003800896</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 17 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.6 x 16.2 ×13.6in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 x 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52806512</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2004343905</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.4 x 15.6 x 13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806512</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2010692919</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions =</td>
<td>20.8 × 15.8×13.6in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 x 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th>1 st</th>
<th>ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52806512</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2006447924</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 21 × 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.6 x 15.8 × 13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806512</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2015208933</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.6 x 15.8× 13.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806512</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2000575949</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = Customer Entered</td>
<td>20.4 x 15.8 × 13.2 Dimensions = 20 ×</td>
<td>in 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806512</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2006148953</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>30.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 15 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>18 x 14.8 x 14.6</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806512</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2015527964</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 19 × 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>18.2 × 15.2 × 14.6</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806512</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


#### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 50 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th colspan="2">Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th></th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/12</td>
<td colspan="2">1ZG7093D2012312978</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td colspan="3"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.4 x</td>
<td>15.2× 14.2</td>
<td>in</td>
<td colspan="3"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 16</td>
<td>× 10 in</td>
<td colspan="3"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th>1st</th>
<th>ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th></th>
<th>52806512</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2000103985</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>30.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>90.05</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>18 × 15 ×</td>
<td>15 in</td>
<td colspan="3"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x 15 Customer Entered Dimensions</td>
<td>× 14.4 in = 20 × 16</td>
<td>× 10 in</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52806512</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="7">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2004388359</td>
<td>Standard</td>
<td>T8V3Y2</td>
<td>211</td>
<td>237 lbs</td>
<td></td>
<td>533.25</td>
<td>-367.94</td>
<td>165.31</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>T8V3Y2</td>
<td>211</td>
<td>291 0 lbs</td>
<td></td>
<td>654.75</td>
<td>-451.78</td>
<td>202.97</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>28.56</td>
<td>-19.69</td>
<td>8.87</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td colspan="3">2nd ref: 52806507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td colspan="2">Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 359</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>LULULEMON</td>
<td>CANADA 359</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>11801 100</td>
<td>ST</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td colspan="4">GRANDE PRAIRIE AB T8V3Y2</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2004388359</td>
<td></td>
<td></td>
<td></td>
<td>14 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>21.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 26.2 x 18</td>
<td>27 x 18 x × 5.8 in</td>
<td>6 in</td>
<td colspan="3"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 14 × 10</td>
<td>× 4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td></td>
<td>52806507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2001263382</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td colspan="3"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.6 x Customer Entered Dimensions</td>
<td>15.6 × 13.6 = 20 × 16</td>
<td>in × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td></td>
<td>52806507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2019300398</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.4 x Customer Entered Dimensions</td>
<td>21 x 16 × 15.4 × 13.4 = 20 × 16</td>
<td>14 in in × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1 st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td></td>
<td>52806507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2005592411</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 18.4 x Customer Entered Dimensions</td>
<td>19 x 16 × 15.4 × 14.2in = 20 × 16</td>
<td>15 in × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td></td>
<td>52806507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009508433</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.6 x</td>
<td>15.6× 14.2</td>
<td>in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td></td>
<td>52806507</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2014575440</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>46.53</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 × Customer Entered Dimensions</td>
<td>15.6×14.4in = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52806507</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 51 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th colspan="2">Adjustment Amount</th>
</tr>
<tr>
<td></td>
<td></td>
<td>Shaded area</td>
<td colspan="4">denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/12</td>
<td>1ZG7093D2005129252</td>
<td>Standard</td>
<td>T2S0B6</td>
<td>206</td>
<td>277 lbs</td>
<td>581.70</td>
<td>401.37</td>
<td>180.33</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>T2S0B6</td>
<td>206</td>
<td>312.0 lbs</td>
<td>655.20</td>
<td>452.09</td>
<td>203.11</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>17.29</td>
<td>-11.92</td>
<td>5.37</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref: 52806510</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 311</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 311</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>727 17 AVE</td>
<td>SW</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>CALGARY</td>
<td>AB T2S0B6</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2005129252</td>
<td></td>
<td></td>
<td></td>
<td>15 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>30.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>17 x 17 x</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 17 x 16.4</td>
<td>× 13.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 12 × 10</td>
<td>× 10</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806510</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2007624285</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x 15,4</td>
<td>x 14.2 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806510</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002201295</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.4 x</td>
<td>15.6× 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806510</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002984306</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.4 x Customer Entered Dimensions</td>
<td>21 x 16 × 15.6×13.4 = 20 × 15</td>
<td>14 in in × 13</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806510</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2013573319</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 x</td>
<td>13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.6 x</td>
<td>16 × 12.6 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806510</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2018569333</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">28.15</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.8 x Customer Entered Dimensions</td>
<td>15.6×13.2in = 20 x 15</td>
<td>× 13</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806510</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="6">Shaded area denotes multi-piece shipment</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009823208</td>
<td>Standard</td>
<td>V3R7C1</td>
<td>207</td>
<td>203 lbs</td>
<td>430.36</td>
<td>-296.95</td>
<td>133.41</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>V3R7C1</td>
<td>207</td>
<td>224.0 lbs</td>
<td>474.88</td>
<td>327.67</td>
<td>147.21</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>10.44</td>
<td>-7.21</td>
<td>3.23</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref: 52806508</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 162</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 162</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>10355 152</td>
<td>ST</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>SURREY BC</td>
<td>V3R7C1</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 52 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th rowspan="2">Tracking Number</th>
<th rowspan="2">Original Service/ Corrected Service</th>
<th rowspan="2">Postal Code</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th rowspan="2">Published Charge</th>
<th rowspan="2">Incentive Credit</th>
<th>Billed</th>
<th>Adjustment</th>
</tr>
<tr>
<th>Charge</th>
<th>Amount</th>
</tr>
<tr>
<td>01/12</td>
<td>1ZG7093D2009823208</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x</td>
<td>15.2× 14.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2003752215</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>31.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.8 x</td>
<td>15.4 x14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2007428238</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18 × 15.4</td>
<td>× 14.6 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2004375247</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.4 x</td>
<td>15.6 x 13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009528251</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.8 x</td>
<td>15.6×13.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2006487266</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>17.03</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.8 x Customer Entered Dimensions</td>
<td>15.6 x 13 in = 20 x 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806508</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Shaded area denotes</td>
<td colspan="3">multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2010467832</td>
<td>Standard</td>
<td>A1B1W3</td>
<td>211</td>
<td>261 lbs</td>
<td>587.25</td>
<td>-405.20</td>
<td>182.05</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>A1B1W3</td>
<td>211</td>
<td>293.0 lbs</td>
<td>659.25</td>
<td>454.88</td>
<td>204.37</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>16.96</td>
<td>-11.71</td>
<td>5.25</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806478</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 720</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 720</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>48 KENMOUNT</td>
<td>RD</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>ST. JOHN'S</td>
<td>NL A1B1W3</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2010467832</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 × Customer Entered Dimensions</td>
<td>15.2 × 14.6 = 20 × 15</td>
<td>in × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806478</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011174843</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>30.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x 15.8</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806478</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


###### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 53 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th rowspan="2">Tracking Number</th>
<th rowspan="2">Original Service/ Corrected Service</th>
<th rowspan="2">Postal Code</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th rowspan="2">Published Charge</th>
<th rowspan="2">Incentive Credit</th>
<th>Billed</th>
<th colspan="2">Adjustment</th>
</tr>
<tr>
<th>Charge</th>
<th></th>
<th>Amount</th>
</tr>
<tr>
<td>01/12</td>
<td>1ZG7093D2008806863</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.8 x</td>
<td>15.6×13.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806478</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2012931871</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 × 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 21 ×</td>
<td>15.6 × 13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806478</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2012062882</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.8 × Customer Entered Dimensions</td>
<td colspan="2">21 x 16 × 14 in 15.8×13.6in = 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806478</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009799898</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.6 x Customer Entered Dimensions</td>
<td>15.8 x = 20 ×</td>
<td>13.6in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806478</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009742902</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.6 x</td>
<td>15.8×13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806478</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2015491912</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>31.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">27.57</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 × 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 19 x Customer Entered Dimensions</td>
<td>15.6 x 14 in = 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806478</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2016953215</td>
<td>Standard</td>
<td>B3J1G1</td>
<td>209</td>
<td>116 lbs</td>
<td>251.70</td>
<td>-173.67</td>
<td>78.03</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>B3J1G1</td>
<td>209</td>
<td>124.0 lbs</td>
<td>268.60</td>
<td>-185.33</td>
<td>83.27</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>3.97</td>
<td>-2.72</td>
<td>1.25</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806505</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 710</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 710</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>5445 SPRING</td>
<td>GARDEN RD</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>HALIFAX NS</td>
<td>B3J1G1</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2016953215</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 18 x Customer Entered Dimensions</td>
<td>18 x 16 15.2 x 14.2 = 20 ×</td>
<td>× 15 in in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806505</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2001829235</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">6.49</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 21 x 16 Customer Entered Dimensions 1st ref: 68951</td>
<td colspan="2">21 x 16 × 14 in × 13.2 in = 20 × 15 × 13 in</td>
<td>2nd ref:</td>
<td>52806505</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


####### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 54 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th colspan="2">Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Shaded area</td>
<td colspan="5">denotes multi-piece shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/12</td>
<td colspan="2">1ZG7093D2017326963</td>
<td>Standard</td>
<td>V4M0B3</td>
<td>207</td>
<td>416 lbs</td>
<td>881.92</td>
<td>608.52</td>
<td>273.40</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>V4MOB3</td>
<td>207</td>
<td>537 0 lbs</td>
<td>1,138.44</td>
<td>-785.52</td>
<td>352.92</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>60.22</td>
<td>-41.64</td>
<td>18.58</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806479</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 187</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 187</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>5000 CANOE</td>
<td>PASS WAY</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>TSAWWASSEN</td>
<td>BC V4M0B3</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2000702980</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="5">Billable Audited Dimensions = 18 x 16 × 15 in Audited Dimensions = 18 x 15.6 x 14.6 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806479</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2002499993</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Billable Audited Dimensions = Audited Dimensions = 18.2 x Customer Entered Dimensions</td>
<td colspan="2">19 × 16 × 15 in 15.4 × 14.4 in = 20 × 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806479</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2002503003</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Billable Audited Dimensions =</td>
<td colspan="2">19 x 16 × 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Audited Dimensions = 18.2 x</td>
<td colspan="2">15.4× 14.2 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806479</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2004312019</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Audited Dimensions = 18.4 x Customer Entered Dimensions</td>
<td>15.4 × 14.2 = 20 × 16</td>
<td>in × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806479</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2011527024</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x 15.4</td>
<td colspan="2">x 14.2 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806479</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2007748035</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Billable Audited Dimensions =</td>
<td colspan="2">18 x 16 × 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Audited Dimensions = 18 × Customer Entered Dimensions</td>
<td>15.6x 14.4 in = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806479</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1ZG7093D2016575044</td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="5">Billable Audited Dimensions = 18 x 16 × 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="5">Audited Dimensions = 18 x 15.2 × 14.2 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806479</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2001608054</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Billable Audited Dimensions =</td>
<td colspan="2">19 x 16 × 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Audited Dimensions = 18.2 × Customer Entered Dimensions 1st ref: 68951</td>
<td colspan="2">15.4×14.2in = 20 × 16 × 10 in</td>
<td>2nd ref:</td>
<td>52806479</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


####### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 55 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th colspan="2">Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/12</td>
<td>1ZG7093D2006447068</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16</td>
<td>× 15 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.6 x</td>
<td>15.4×14.2in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52806479</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2014692073</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16</td>
<td>× 15 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.4 × 14.2</td>
<td>in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52806479</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009943089</td>
<td></td>
<td></td>
<td>24 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">Billable Audited Dimensions = 19 x 16 × 15 in Audited Dimensions = 18.2 x 15.4 × 14.2 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>16 × 10 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52806479</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2015863109</td>
<td></td>
<td></td>
<td>24 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 × 16</td>
<td>× 15 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x 15.4 Customer Entered Dimensions</td>
<td>x 14.2 = 20 ×</td>
<td>in 16 × 10 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52806479</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2013732110</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16</td>
<td>× 15 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.4 x</td>
<td>15.4 ×14.2in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>16 × 10 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52806479</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2013007127</td>
<td></td>
<td></td>
<td>24 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>98.10</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16</td>
<td>× 15 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 × Customer Entered Dimensions</td>
<td>15.4 × 14.4 = 20 ×</td>
<td>in 16 × 10 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52806479</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="7">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2019848459</td>
<td>Standard</td>
<td>T4A0G3</td>
<td>207</td>
<td>242 lbs</td>
<td colspan="2">513.04</td>
<td>-354.00</td>
<td>159.04</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>T4A0G3</td>
<td>207</td>
<td>307.0 lbs</td>
<td></td>
<td>650.84</td>
<td>449.08</td>
<td>201.76</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">32.35</td>
<td>-22.34</td>
<td>10.01</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52806525</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 360</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 360</td>
<td>LL360</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>261055</td>
<td>CROSSIRON BLVD</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>ROCKY VIEW</td>
<td>COUNTY AB</td>
<td>T4A0G3</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2019848459</td>
<td></td>
<td></td>
<td>2 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>5.0 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 10.4 x Customer Entered Dimensions</td>
<td>11 x 10 10 x 5.8 in = 19 x</td>
<td>× 6 in 13 × 1 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52806525</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2005412472</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.4 x Customer Entered Dimensions 1st ref: 68951</td>
<td>15.2×14.2in = 20 ×</td>
<td>16 × 10 in</td>
<td>2nd ref:</td>
<td colspan="2">52806525</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


###### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 56 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th rowspan="2">Tracking Number</th>
<th></th>
<th rowspan="2">Original Service/ Corrected Service</th>
<th rowspan="2">Postal Code</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th rowspan="2">Published Charge</th>
<th rowspan="2">Incentive Credit</th>
<th rowspan="2">Billed Charge</th>
<th>Adjustment</th>
</tr>
<tr>
<th></th>
<th>Amount</th>
</tr>
<tr>
<td>01/12</td>
<td colspan="2">1ZG7093D2012903482</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x 15.4</td>
<td>× 14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52806525</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2015000497</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 × 15,2</td>
<td>× 14.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th colspan="3">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52806525</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2015303508</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>31.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.4 x</td>
<td>15.6× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806525</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2004927525</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 × 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.4 x</td>
<td>15.8 x 13.6</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806525</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2010575546</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.4 x</td>
<td>15.8 ×13.6in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806525</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2015908552</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>52.73</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 × 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.6 x Customer Entered Dimensions</td>
<td>15.8 x 13.2 = 20 × 16</td>
<td>in × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806525</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Shaded area</td>
<td>denotes</td>
<td></td>
<td>multi-piece</td>
<td>shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025597263</td>
<td></td>
<td>Standard</td>
<td>V8Z6E3</td>
<td>209</td>
<td>151 lbs</td>
<td>326.16</td>
<td>-225.05</td>
<td>101.11</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Standard</td>
<td>V8Z6E3</td>
<td>209</td>
<td>164.0 lbs</td>
<td>354.24</td>
<td>244.43</td>
<td>109.81</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>6.60</td>
<td>-4.55</td>
<td>2.05</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806515</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 178</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 178</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>3147 DOUGLAS</td>
<td>ST</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>VICTORIA</td>
<td>BC V8Z6E3</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2024310877</td>
<td></td>
<td></td>
<td></td>
<td>33 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.6 × Customer Entered Dimensions</td>
<td>15.4 × 13.4 = 23 × 15</td>
<td>in × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806515</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2027427880</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 × 15.4</td>
<td>× 14.2 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806515</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


###### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 57 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th colspan="2" rowspan="2">Tracking Number</th>
<th>Original Service/</th>
<th rowspan="2">Postal Code</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th rowspan="2">Published Charge</th>
<th>Incentive</th>
<th></th>
<th>Billed</th>
<th colspan="2">Adjustment</th>
</tr>
<tr>
<th>Corrected Service</th>
<th>Credit</th>
<th></th>
<th>Charge</th>
<th colspan="2">Amount</th>
</tr>
<tr>
<td>01/12</td>
<td colspan="2">1ZG7093D2037544298</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>30.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">18 x 15 × 15 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x 15</td>
<td colspan="2">× 14.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52806515</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2033496106</td>
<td></td>
<td colspan="2"></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">19 x 16 × 15 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.4 ×</td>
<td colspan="2">15.6 × 14.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th colspan="2"></th>
<th>2nd ref:</th>
<th>52806515</th>
<th></th>
<th></th>
<th></th>
<th colspan="2"></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2035959317</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">10.75</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">19 x 16 × 15 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 ×</td>
<td colspan="2">15.8x 14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 x 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52806515</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2030325500</td>
<td>Standard</td>
<td colspan="2">T5G3A6 206</td>
<td>204 lbs</td>
<td>428.40</td>
<td>-295.60</td>
<td></td>
<td>132.80</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td colspan="2">T5G3A6 206</td>
<td>217 0 lbs</td>
<td>455.70</td>
<td>314.43</td>
<td></td>
<td>141.27</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>6.43</td>
<td>-4.43</td>
<td></td>
<td>2.00</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52806500</td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender</td>
<td>: MIKE HALLSTEIN</td>
<td colspan="2"></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td colspan="2">CANADA 345</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td colspan="2"></td>
<td></td>
<td>LULULEMON</td>
<td colspan="2">CANADA 345</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td colspan="2"></td>
<td></td>
<td>227 109 ST</td>
<td colspan="2">NW</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td colspan="2"></td>
<td></td>
<td>EDMONTON</td>
<td colspan="2">AB T5G3A6</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2021824710</td>
<td></td>
<td colspan="2"></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>31.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">19 x 16 × 14 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 x</td>
<td colspan="2">15.4 × 13.6in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<th></th>
<th></th>
<th>1st</th>
<th>ref: 68951</th>
<th colspan="2"></th>
<th>2nd ref:</th>
<th>52806500</th>
<th colspan="2"></th>
<th></th>
<th colspan="2"></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2021791327</td>
<td></td>
<td colspan="2"></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>31.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">19 x 16 × 14 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.4 ×</td>
<td colspan="2">15.4 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52806500</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2036981335</td>
<td></td>
<td colspan="2"></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 18.6 ×</td>
<td colspan="2">19 x 16 × 15 in 15.4×14.2in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52806500</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2020790740</td>
<td></td>
<td colspan="2"></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">10.47</td>
</tr>
<tr>
<td></td>
<td colspan="3">Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.6 x</td>
<td colspan="2">15.2 ×13.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52806500</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


###### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 58 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th colspan="2">Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="7">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/12</td>
<td>1ZG7093D2034270651</td>
<td>Standard</td>
<td>V3A7E9</td>
<td>207</td>
<td colspan="2">241 lbs</td>
<td>510.92</td>
<td>-352.53</td>
<td>158.39</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>V3A7E9</td>
<td>207</td>
<td colspan="2">263.0 lbs</td>
<td>557.56</td>
<td>384.72</td>
<td>172.84</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>10.94</td>
<td>-7.57</td>
<td>3.37</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="3">2nd ref: 52806523</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td colspan="4">Receiver: LULULEMON CANADA 114</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 114</td>
<td>CAD</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>19705 FRASER</td>
<td>HIGHWAY</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>LANGLEY</td>
<td>BC V3A7E9</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Message Codes :ad v</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039360867</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Audited Dimensions = 20.8 x 15.6×13.2in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13</td>
<td colspan="2">in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52806523</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039458477</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0</td>
<td>lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>22 x 16 ×</td>
<td>13 in</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 21.6 x</td>
<td>15.6 x 13 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 15</td>
<td>× 13</td>
<td colspan="2">in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52806523</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2028155707</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0</td>
<td>lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x 15.4</td>
<td>× 14.6 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13</td>
<td colspan="2">in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52806523</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2030242911</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0</td>
<td>lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 x Customer Entered Dimensions</td>
<td>15.2× 14.6 = 20 × 15</td>
<td>in × 13</td>
<td colspan="2">in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52806523</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2021517525</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>31.0</td>
<td>lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 15 ×</td>
<td>15 in</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 x</td>
<td>15 × 14.8 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13</td>
<td colspan="2">in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52806523</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025535534</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0</td>
<td>lbs</td>
<td></td>
<td></td>
<td></td>
<td>17.82</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.4 x Customer Entered Dimensions</td>
<td>15.4 x 14.2 = 20 x 15</td>
<td>in × 13</td>
<td colspan="2">in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52806523</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="8">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2038420213</td>
<td>Standard</td>
<td>T1L1A5</td>
<td>209</td>
<td colspan="2">104 lbs</td>
<td>226.55</td>
<td>-156.32</td>
<td>70.23</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>T1L1A5</td>
<td>209</td>
<td colspan="2">123.0 lbs</td>
<td>266.45</td>
<td>-183.85</td>
<td>82.60</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>9.37</td>
<td>6.46</td>
<td>2.91</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref:</td>
<td>52806502</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td colspan="3">Receiver: LULULEMON</td>
<td>CANADA 351</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 351</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>125 BANFF</td>
<td>AVE</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>BANFF AB</td>
<td>T1L1A5</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Message Codes :ad v</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


###### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 59 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th colspan="2" rowspan="2">Tracking Number</th>
<th>Original Service/</th>
<th>Postal</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th>Published</th>
<th>Incentive</th>
<th></th>
<th>Billed</th>
<th>Adjustment</th>
</tr>
<tr>
<th>Corrected Service</th>
<th>Code</th>
<th>Charge</th>
<th>Credit</th>
<th></th>
<th>Charge</th>
<th>Amount</th>
</tr>
<tr>
<td>01/12</td>
<td colspan="2">1ZG7093D2033656826</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 18.4 x</td>
<td>19 x 16 × 15.8x 14.6in</td>
<td>15 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806502</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2023331052</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>15.28</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 × 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.8 × Customer Entered Dimensions</td>
<td>15.6×13.6in = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806502</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="7">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/13</td>
<td colspan="2">1ZG7093D2008177141</td>
<td>Standard</td>
<td>V6Y2B6</td>
<td>207</td>
<td>168 lbs</td>
<td>356.16</td>
<td colspan="2">-245.75</td>
<td>110.41</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>V6Y2B6</td>
<td>207</td>
<td>200.0 lbs</td>
<td>424.00</td>
<td>292.56</td>
<td></td>
<td>131.44</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>15.93</td>
<td>-11.00</td>
<td></td>
<td>4.93</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806516</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td colspan="2">CANADA 121</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td colspan="2">CANADA 121</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>6551 NO. 3</td>
<td colspan="2">RD</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>RICHMOND</td>
<td colspan="2">BC V6Y2B6</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2014470151</td>
<td></td>
<td></td>
<td></td>
<td>14 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>20.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>27 x 17 x</td>
<td>6 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions - 26.4 x</td>
<td>17 x 6 in</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 15 × 10</td>
<td>× 4 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806516</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2002585185</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 21 x 15.8</td>
<td>21 x 16 × × 14 in</td>
<td>14 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806516</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2013702198</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>31.0 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 15 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.4 x 15</td>
<td>× 14.4 in</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806516</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2015025201</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>25.96</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 × 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.6 x 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806516</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="7">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2021121658</td>
<td>Standard</td>
<td>T5T4J2</td>
<td>206</td>
<td>346 lbs</td>
<td>726.60</td>
<td colspan="2">-501.35</td>
<td>225.25</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>T5T4J2</td>
<td>206</td>
<td>408.0 lbs</td>
<td>856.80</td>
<td>591.19</td>
<td></td>
<td>265.61</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>30.64</td>
<td>21.16</td>
<td></td>
<td>9.48</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806501</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td colspan="2">CANADA 350</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td colspan="2">CANADA 350</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>8882-170</td>
<td colspan="2">ST NW</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>EDMONTON</td>
<td colspan="2">AB T5T4J2</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


###### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 60 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th colspan="2">Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/13</td>
<td>1ZG7093D2023390480</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.4 x</td>
<td>15.6× 14 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 16</td>
<td>× 10 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52806501</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025706706</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 × 16 ×</td>
<td>14 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.4 x</td>
<td>15.6 × 13.4</td>
<td>in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52806501</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020548520</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 x</td>
<td>15.4 × 14.4</td>
<td>in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52806501</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035403943</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>31.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 15 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.4 x</td>
<td>15 x 14.4 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52806501</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2029892570</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x</td>
<td>15.6 x 14.4</td>
<td>in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52806501</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2021507581</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.6 x</td>
<td>15.4 × 14.6</td>
<td>in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52806501</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2026241993</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>49.84</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.6 x</td>
<td>15.2× 14.6in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 16</td>
<td>× 10 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52806501</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="7">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2032976287</td>
<td>Standard</td>
<td>T6H4M6</td>
<td>206</td>
<td>458 lbs</td>
<td colspan="2">961.80</td>
<td>663.64</td>
<td>298.16</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>T6H4M6</td>
<td>206</td>
<td>514.0 lbs</td>
<td></td>
<td>1,079.40</td>
<td>744.79</td>
<td>334.61</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>27.66</td>
<td>-19.09</td>
<td>8.57</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52806513</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td colspan="2">LULULEMON</td>
<td>CANADA 358</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 358</td>
<td>C</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>5015 111</td>
<td>STREET</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>EDMONTON</td>
<td>AB T6H4M6</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2026988697</td>
<td></td>
<td></td>
<td></td>
<td>16 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>22.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>24 x 18 ×</td>
<td>7 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 23.2 × Customer Entered Dimensions 1st ref: 68951</td>
<td>17.2 ×6.2 = 12 ×</td>
<td>in 10 × 8 in</td>
<td>2nd ref:</td>
<td colspan="2">52806513</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


###### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 61 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/13</td>
<td>1ZG7093D2025076503</td>
<td></td>
<td></td>
<td></td>
<td>16 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>18.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">24 x 17 x 6 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 23.4 x</td>
<td colspan="2">16.4 × 6 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 12 × 10 × 8 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52806513</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2030306558</td>
<td></td>
<td colspan="2"></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">19 x 16 × 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.6 ×</td>
<td colspan="2">15.4 ×14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th>1st ref: 68951</th>
<th colspan="2"></th>
<th>2nd ref:</th>
<th>52806513</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2025042763</td>
<td colspan="2"></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">Billable Audited Dimensions = 19 x 16 × 15 in Audited Dimensions = 18.4 x 15.4 × 14.2 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 x 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52806513</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020821608</td>
<td></td>
<td colspan="2"></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.8 x</td>
<td colspan="2">15.8 x 13.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52806513</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039115426</td>
<td></td>
<td colspan="2"></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.4 x</td>
<td colspan="2">15.8×13.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52806513</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2038382845</td>
<td colspan="2"></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>45.02</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">21 × 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.6 x Customer Entered Dimensions</td>
<td colspan="2">15.6 × 13.4 in = 20 × 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52806513</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="4">Shaded area denotes multi-piece</td>
<td>shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035186492</td>
<td>Standard</td>
<td colspan="2">V5H4J2 207</td>
<td>291 lbs</td>
<td>616.92</td>
<td>-425.67</td>
<td>191.25</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td colspan="2">V5H4J2 207</td>
<td>330.0 lbs</td>
<td>699.60</td>
<td>482.72</td>
<td>216.88</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>19.43</td>
<td>-13.43</td>
<td>6.00</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806489</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 160</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 160</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>4800 KINGSWAY</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>BURNABY</td>
<td>BC V5H4J2</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Message Codes :ad v</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2035186492</td>
<td></td>
<td></td>
<td>9 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>13.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 16.2 x Customer Entered Dimensions</td>
<td colspan="2">17 x 17 × 6 in 16.2 × 5.8 in = 12 × 10 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52806489</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2028856129</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.8 x Customer Entered Dimensions 1st ref: 68951</td>
<td colspan="2">21 x 16 × 14 in 15.8×13.6in = 20 × 15 × 13 in</td>
<td>2nd ref:</td>
<td>52806489</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


###### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 62 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/13</td>
<td>1ZG7093D2029758135</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.6 x</td>
<td>15.8x 13.8</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806489</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020559545</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.4 ×</td>
<td>15.8 × 13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806489</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2026096356</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">Billable Audited Dimensions = 19 x 16 × 15 in Audited Dimensions = 18.4 x 15.4 × 14.6 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806489</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039520176</td>
<td></td>
<td></td>
<td></td>
<td>21 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.4 x Customer Entered Dimensions</td>
<td>15.4 × 14.2 = 20 ×</td>
<td>in 13 × 5 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806489</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2026317590</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>31.63</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 x Customer Entered Dimensions</td>
<td>15.4 × 14.2 = 20 x</td>
<td>in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806489</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="4">Shaded area denotes multi-piece</td>
<td>shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th>1ZG7093D2035731802</th>
<th>Standard</th>
<th>STK1J5</th>
<th>205</th>
<th>247 lbs</th>
<th>503.88</th>
<th>-347.68</th>
<th>156.20</th>
<th></th>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>S7K1J5</td>
<td>205</td>
<td>313.0 lbs</td>
<td>638.52</td>
<td>440.58</td>
<td>197.94</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>31.61</td>
<td>-21.85</td>
<td>9.76</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806506</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 430</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 430</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>201 1ST AVE</td>
<td>S</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>SASKATOON</td>
<td>SK S7K1J5</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2034321622</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 17.8 x Customer Entered Dimensions</td>
<td colspan="2">18 x 16 × 15 in 15.2×14.6in = 20 × 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806506</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2038293638</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 18.2 × Customer Entered Dimensions</td>
<td colspan="2">19 x 16 × 15 in 15.4 × 14.4 in = 20 × 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806506</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020171856</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 18.4 x Customer Entered Dimensions 1st ref: 68951</td>
<td colspan="2">19 x 16 × 15 in 15.4 ×14.6in = 20 × 16 × 10 in</td>
<td>2nd ref:</td>
<td>52806506</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


####### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 63 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th colspan="2">Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/13</td>
<td colspan="2">1ZG7093D2033590067</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.4 x</td>
<td>15.8×14in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th>1st</th>
<th>ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52806506</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2029564684</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.6 x</td>
<td>15.4 × 13.6</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806506</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2025073097</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.4 x Customer Entered Dimensions</td>
<td>15.8 × 13.2 = 20 × 16</td>
<td>in × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806506</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2026896901</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>51.50</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.6 x Customer Entered Dimensions</td>
<td>21 x 16 × 16 x 13.4 in = 20 × 16</td>
<td>14 in × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806506</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2036373975</td>
<td>Standard</td>
<td>V8E1H1</td>
<td>210</td>
<td>283 lbs</td>
<td>614.11</td>
<td>-423.74</td>
<td>190.37</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>V8E1H1</td>
<td>210</td>
<td>330.0 lbs</td>
<td>716.10</td>
<td>-494.11</td>
<td>221.99</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>23.97</td>
<td>-16.50</td>
<td>7.47</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806487</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 141</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 141</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>4154 VILLAGE</td>
<td>GREEN</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>WHISTLER</td>
<td>BC V8E 1H1</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2037595395</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 18 x 15.4 Customer Entered Dimensions</td>
<td>18 x 16 × x 14.2 = 20 × 16</td>
<td>15 in in × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806487</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2036783022</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 18.2 x Customer Entered Dimensions</td>
<td>19 x 16 × 15.4× 14.2 = 20 ×</td>
<td>15 in in 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806487</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2025698449</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 21 x 15.6 Customer Entered Dimensions</td>
<td>x 13.6 in = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806487</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2021155461</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.6 x Customer Entered Dimensions</td>
<td>15.8×13.4in = 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806487</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


####### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 64 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th colspan="2" rowspan="2">Tracking Number</th>
<th>Original Service/</th>
<th>Postal</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th>Published</th>
<th>Incentive</th>
<th></th>
<th>Billed</th>
<th>Adjustment</th>
</tr>
<tr>
<th>Corrected Service</th>
<th>Code</th>
<th>Charge</th>
<th>Credit</th>
<th></th>
<th>Charge</th>
<th>Amount</th>
</tr>
<tr>
<td>01/13</td>
<td colspan="2">1ZG7093D2022777074</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>39.09</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 21 x 16</td>
<td>× 13.6 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806487</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/14</td>
<td colspan="2">1ZG7093D2003705007</td>
<td>Standard Undeliverable Return</td>
<td>L5T2W9</td>
<td>200</td>
<td>24 lbs</td>
<td>15.84</td>
<td>-8.24</td>
<td></td>
<td>7.60</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard Undeliverable Return</td>
<td>L5T2W9</td>
<td>200</td>
<td>31.0 lbs</td>
<td>20.46</td>
<td>-10.64</td>
<td></td>
<td>9.82</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 15 x</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 x</td>
<td>15 x 14.8 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions Fuel Surcharge</td>
<td>= 20 x 16</td>
<td>x 10 in</td>
<td></td>
<td>1.09</td>
<td>-0.56</td>
<td></td>
<td>0.53</td>
<td>2.75</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Reason for Return: Service delay</td>
<td>or Return</td>
<td>to</td>
<td>Shipper, Service</td>
<td>Disruption</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52806494</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Returned From: LULULEMON CANADA 262</td>
<td></td>
<td></td>
<td>Returned</td>
<td>To: MIKE</td>
<td>HALLSTEIN</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>BRS CANADA</td>
<td colspan="2">C/O NAFFI</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td rowspan="2">25 THE WEST MALL ETOBICOKE ON M9C1B8</td>
<td></td>
<td></td>
<td></td>
<td>375</td>
<td>PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>MISSISSAUGA</td>
<td colspan="2">ON L5T2W9</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad w</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="7">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/19</td>
<td colspan="2">1ZG7093D1721247903</td>
<td>Expedited</td>
<td>V6Z2E7</td>
<td>307</td>
<td>204 lbs</td>
<td>1,185.24</td>
<td colspan="2">474.10</td>
<td>711 14</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Expedited</td>
<td>V6Z2E7</td>
<td>307</td>
<td>236.0 lbs</td>
<td>1,371.16</td>
<td>548.46</td>
<td></td>
<td>822.70</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>44.16</td>
<td>-17.67</td>
<td></td>
<td>26.49</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52840561</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td colspan="2">CANADA 120</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA</td>
<td>120</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>970 ROBSON</td>
<td>ST</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>VANCOUVER</td>
<td>BC V6Z2E7</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D1721247903</td>
<td></td>
<td></td>
<td></td>
<td>34 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>38.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x 15.6</td>
<td>x 14.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52840561</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D1722203118</td>
<td></td>
<td></td>
<td></td>
<td>34 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>40.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 × 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.8×14.8in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>- 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52840561</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D1736265722</td>
<td></td>
<td></td>
<td></td>
<td>34 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>40.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 x Customer Entered Dimensions</td>
<td>15.4 × 14.6 = 20 x 15</td>
<td>in × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52840561</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D1731791734</td>
<td></td>
<td></td>
<td></td>
<td>34 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>40.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.4 x</td>
<td>15.4 × 14.8in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52840561</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D1727777142</td>
<td></td>
<td></td>
<td></td>
<td>34 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>38.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 17.8 x</td>
<td>15.2×14.6in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52840561</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


####### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 65 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/19</td>
<td>1ZG7093D1735457955</td>
<td></td>
<td></td>
<td></td>
<td>34 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>40.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>138.05</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 18.4 x Customer Entered Dimensions</td>
<td>19 x 16 × 15.6× 14.6 = 20 x</td>
<td>15 in in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52840561</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2000155778</td>
<td>Standard</td>
<td>K1N9J7</td>
<td>202</td>
<td>816 lbs</td>
<td>1,452,48</td>
<td>-1,002.21</td>
<td>450.27</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>K1N9J7</td>
<td>2021080.0</td>
<td>lbs</td>
<td>1,922.40</td>
<td>-1,326.46</td>
<td>595.94</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>110.39</td>
<td>-76.07</td>
<td>34.32</td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 264</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td rowspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 264</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>50 RIDEAU</td>
<td>STREET</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>OTTAWA</td>
<td>ON K1N9J7</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Message</td>
<td>Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2000155778</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 × Audited Dimensions = 20.4 x 16 × 13.4</td>
<td>14 in in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2013626780</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.6 x Customer Entered Dimensions</td>
<td>21 x 16 15.8x 13.4in = 20 ×</td>
<td>× 14 in 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009703794</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.8 x Customer Entered Dimensions</td>
<td>15.8x 13 = 20 ×</td>
<td>in 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011986805</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.8 x Customer Entered Dimensions</td>
<td>16 × 13.4 = 20 ×</td>
<td>in 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2004075811</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.8 x Customer Entered Dimensions</td>
<td>21 x 16 15.8×13.4in = 20 ×</td>
<td>× 14 in 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009570820</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.2 × Customer Entered Dimensions</td>
<td>21 x 16 15.8 × 13.4 = 20 ×</td>
<td>× 14 in in 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2012071836</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951 Billable Audited Dimensions = Audited Dimensions = 20.4 × Customer Entered Dimensions</td>
<td>21 x 17 16.2×13.4in = 20 ×</td>
<td>× 14 in 16 × 10 in</td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


###### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 66 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th></th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/19</td>
<td colspan="2">1ZG7093D2015178841</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 21 × 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 20.8 x 15.6×13.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2002491857</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="3">Billable Audited Dimensions = 21 x 16 × 14 in Audited Dimensions = 20.4 x 15.6 × 13.2 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2017610860</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 ×</td>
<td>13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2">Audited Dimensions = 20.4 x 15.8×13in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th>1st</th>
<th>ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848033</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2004135872</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.6 x 15.8 x 13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2005666887</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions =</td>
<td>20.4 × 15.8×13.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 x</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th>1st</th>
<th>ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848033</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2005803899</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.4 × 15.8 x 13.6</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2008146906</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.4 x 16 × 13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2016295918</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = Customer Entered</td>
<td>20.8 × 15.8×13.2in Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2004411939</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.6 × 16 × 13.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2011578943</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2">Audited Dimensions = 20.4 × 15.8× 13.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


###### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 67 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th rowspan="2">Tracking Number</th>
<th></th>
<th rowspan="2">Original Service/ Corrected Service</th>
<th rowspan="2">Postal Code</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th rowspan="2">Published Charge</th>
<th rowspan="2">Incentive Credit</th>
<th rowspan="2">Billed Charge</th>
<th>Adjustment</th>
</tr>
<tr>
<th></th>
<th>Amount</th>
</tr>
<tr>
<td>01/19</td>
<td colspan="2">1ZG7093D2018951955</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>31.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 19 × 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 x</td>
<td>15.4x14</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2010130963</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions Audited Dimensions = 18.2 ×</td>
<td colspan="2">= 19 x 16 × 15 in 15.6×14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2008715970</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x</td>
<td>15.2 × 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1 st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848033</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2018306983</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.4 x 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2002503996</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x</td>
<td>15.2 × 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1 st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848033</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2004907001</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 19 × 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.4 × 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009116017</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 19 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.2×14.6in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848033</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2017352032</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>30.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 17.8 x Customer Entered Dimensions</td>
<td>15.2×14 = 20 ×</td>
<td>in 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2008579047</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x</td>
<td>15.2 × 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2003251060</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>30.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x Customer Entered Dimensions</td>
<td>15.4 × 14 in = 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


###### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 68 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th colspan="2" rowspan="2">Tracking Number</th>
<th>Original Service/</th>
<th rowspan="2">Postal Code</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th>Published</th>
<th>Incentive</th>
<th rowspan="2"></th>
<th>Billed</th>
<th>Adjustment</th>
</tr>
<tr>
<th>Corrected Service</th>
<th>Charge</th>
<th>Credit</th>
<th>Charge</th>
<th>Amount</th>
</tr>
<tr>
<td>01/19</td>
<td colspan="2">1ZG7093D2019804095</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.6 x</td>
<td>15.4×14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2002267108</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>179.99</td>
</tr>
<tr>
<td></td>
<td colspan="5">Billable Audited Dimensions = 18 x 16 × 15 in Audited Dimensions = 17.8 x 15.2×14.6in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848033</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="3">Shaded area denotes</td>
<td>multi-piece</td>
<td>shipment</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2002178348</td>
<td>Standard</td>
<td>M4P2J2</td>
<td>200</td>
<td>144 lbs</td>
<td>96.65</td>
<td colspan="2">-50.26</td>
<td>46.39</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Standard</td>
<td>M4P2J2</td>
<td>200</td>
<td>186.0 lbs</td>
<td>122.76</td>
<td>-63.84</td>
<td></td>
<td>58.92</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>6.14</td>
<td>-3.17</td>
<td></td>
<td>2.97</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848028</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td colspan="2">CANADA 230</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td colspan="2">CANADA 230</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>2558 YONGE</td>
<td colspan="2">ST</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>TORONTO</td>
<td>ON M4P2J2</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009191356</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.4 x 16</td>
<td>× 13.4 in</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th>1st</th>
<th>ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848028</th>
<th></th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2004010363</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.4 x</td>
<td>15.6 × 13.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848028</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2010235378</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 21 x 15.4</td>
<td>x 13.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848028</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2011466386</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>29.0 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 15 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.6 x 15</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848028</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2011303391</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>31.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>15.50</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 x</td>
<td>15.4 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848028</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


###### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 69 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th colspan="2">Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th></th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th colspan="2">Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="5">Shaded area denotes multi-piece</td>
<td colspan="3">shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/19</td>
<td colspan="2">1ZG7093D2003355216</td>
<td>Standard</td>
<td></td>
<td>M9C1B8</td>
<td>200</td>
<td>319 lbs</td>
<td colspan="2">210.54</td>
<td>-109.48</td>
<td>101.06</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Standard</td>
<td></td>
<td>M9C1B8</td>
<td>200</td>
<td>350.0 lbs</td>
<td colspan="2">231.00</td>
<td>-120.12</td>
<td>110.88</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">4.78</td>
<td>-2.49</td>
<td>2.29</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="4">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52848032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender</td>
<td colspan="2">: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td colspan="2">LULULEMON</td>
<td>CANADA 262</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">LULULEMON</td>
<td>CANADA 262</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">25 THE</td>
<td>WEST MALL</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">ETOBICOKE</td>
<td>ON M9C1B8</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="4">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009378244</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 14 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 20.8 x</td>
<td colspan="2">15.4 x14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Customer Entered Dimensions</td>
<td colspan="2">= 20 × 15 × 13 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td colspan="2">ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td colspan="2">52848032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009255279</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions =</td>
<td>21 x 17 x</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 20.8 x Customer Entered Dimensions</td>
<td colspan="2">16.2 × 13.4 in = 20 × 15 × 13 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52848032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2002426285</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td rowspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 21 x 16 Customer Entered Dimensions</td>
<td>× 13.6 in = 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52848032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2018203290</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = Audited Dimensions = 18 x 15.4</td>
<td>18 x 16 × × 14.4 in</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Customer Entered Dimensions</td>
<td colspan="2">= 20 × 15 × 13 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td colspan="2">ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52848032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2000186306</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="4">Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="4">Audited Dimensions = 18 x 15.4 Customer Entered Dimensions</td>
<td>x 14.6 in = 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52848032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2011975317</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>31.0 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="4">Billable Audited Dimensions =</td>
<td>19 x 15 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 18.8 x Customer Entered Dimensions</td>
<td colspan="2">15× 14.6in = 20 × 15 × 13 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52848032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2017170327</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 18.4 x Customer Entered Dimensions</td>
<td>15.4 x 14.4 = 20 × 15</td>
<td>in × 13 in</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="4">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td colspan="2">52848032</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2019371339</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>31.0 lbs</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>12.11</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions =</td>
<td>19 x 15 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 18.4 × 15 Customer Entered Dimensions</td>
<td>× 14.8in = 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="4">1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td colspan="2">52848032</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


###### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 70 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th colspan="2">Postal Code Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td></td>
<td></td>
<td>Shaded area</td>
<td colspan="4">denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/19</td>
<td>1ZG7093D2004379743</td>
<td>Standard</td>
<td colspan="2">N6G3Y9 202</td>
<td>504 lbs</td>
<td>897.12</td>
<td>619.01</td>
<td>278.11</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>N6G3Y9</td>
<td>202</td>
<td>672.0 lbs</td>
<td>1,196.16</td>
<td>825.35</td>
<td>370.81</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>70.23</td>
<td>-48.38</td>
<td>21.85</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td colspan="2"></td>
<td colspan="2">2nd ref: 52848037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 273</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 273</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>1680</td>
<td>RICHMOND ST N</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>LONDON</td>
<td>ON N6G3Y9</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2012232751</td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">Billable Audited Dimensions = 21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">Audited Dimensions = 20.6 x 15.8×13.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52848037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011891765</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 x</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.6 x Customer Entered Dimensions</td>
<td colspan="2">15.6 × 13.4in = 20 × 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2006956777</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">Billable Audited Dimensions = 21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 21 x 15.6</td>
<td colspan="2">x 13.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2001027780</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.6 x Customer Entered Dimensions</td>
<td colspan="2">15.8×13.2in = 20 × 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52848037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2017704796</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">Billable Audited Dimensions = 21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">Audited Dimensions = 20.6 x 15.6 × 13.2 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2019371820</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">21 × 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.8 x Customer Entered Dimensions</td>
<td colspan="2">15.6×13.2in = 20 × 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52848037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002472832</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">Audited Dimensions = 20.6 × 15.8 ×13.2 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52848037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2006179849</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">21 x 17 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 21 × 16.4 Customer Entered Dimensions 1st ref: 68951</td>
<td colspan="2">× 13.2 in = 20 × 16 × 10 in</td>
<td>2nd ref:</td>
<td>52848037</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


###### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 71 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th></th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/19</td>
<td colspan="2">1ZG7093D2014092855</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="3">Billable Audited Dimensions = 19 x 16 × 15 in Audited Dimensions = 18.2 x 15.4× 14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009811864</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions Audited Dimensions = 18.2 ×</td>
<td>= 19 × 16 × 15.4 × 14.4</td>
<td>15 in in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2016936878</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x</td>
<td>15.6 × 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848037</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2019067883</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x</td>
<td>15,4 x 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th>1st</th>
<th>ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848037</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2019804899</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.6×14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1 st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848037</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2002747901</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 19 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.4 x 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011496915</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 19 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.4 x</td>
<td>15.6×14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848037</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009651920</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 19 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.4 × Customer Entered Dimensions</td>
<td>15.8×14.2in = 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2000812932</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 19 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.6×14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848037</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2008579949</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>31.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>114.55</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 19 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.4 x Customer Entered Dimensions</td>
<td>15.4 × 14 = 20 ×</td>
<td>in 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848037</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


####### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 72 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th colspan="2">Adjustment Amount</th>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td>01/19</td>
<td>1ZG7093D2008010936</td>
<td>Standard</td>
<td>L5B2C9</td>
<td>200</td>
<td>650 lbs</td>
<td>429.00</td>
<td>-223.08</td>
<td>205.92</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>L5B2C9</td>
<td>200</td>
<td>874.0 lbs</td>
<td>576.84</td>
<td>299.96</td>
<td>276.88</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>34.75</td>
<td>-17.93</td>
<td>16.82</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td colspan="4">2nd ref: 52848034</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 267</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 267</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>100 CITY</td>
<td>CENTRE DR</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>MISSISSAUGA</td>
<td>ON L5B2C9</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2011929966</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td colspan="3">21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.6 x</td>
<td colspan="2">15.4× 13.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2009914977</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 21 x 15.6 Customer Entered Dimensions</td>
<td>x 13.4 in = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2018905988</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">19 x 16 × 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.4 x</td>
<td colspan="2">15.4× 14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002502997</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x 15.4 Customer Entered Dimensions</td>
<td>× 14.4 in = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2004306008</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.6 x</td>
<td colspan="2">15.6 × 14.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2007915014</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>31.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.6 x Customer Entered Dimensions</td>
<td>15.4×14in = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2016930025</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 x</td>
<td colspan="2">15.4 × 14.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2014951033</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 × Customer Entered Dimensions 1st ref: 68951</td>
<td colspan="2">15.4×14.2in = 20 × 16 × 10 in</td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


####### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 73 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th rowspan="2">Tracking Number</th>
<th rowspan="2"></th>
<th rowspan="2">Original Service/ Corrected Service</th>
<th rowspan="2">Postal Code</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th rowspan="2">Published Charge</th>
<th rowspan="2">Incentive Credit</th>
<th rowspan="2">Billed Charge</th>
<th>Adjustment</th>
</tr>
<tr>
<th>Amount</th>
</tr>
<tr>
<td>01/19</td>
<td colspan="2">1ZG7093D2005578044</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="3">Audited Dimensions = 18.2 x 15.6× 14.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 x</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2012411058</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>30.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>18 × 15.6 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009095077</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>17.8 x 15.4×14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 x</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2006146080</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.4 x 15.8 x 13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2013803098</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 ×</td>
<td>13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions =</td>
<td>20.6 x 16 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2015666108</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>21 x 15.6 x 13.6</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2015335117</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions =</td>
<td>20.6 × 15.8×13.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2016410122</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>21 x 16 × 13.6 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848034</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2002491133</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>21 x 15.8 x 13.6</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2017178141</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 × 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 20.6 x 15.6 × 13.6</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


###### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 74 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/19</td>
<td>1ZG7093D2004071155</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 × 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.2 x</td>
<td>15.8×13.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2006770164</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Billable Audited Dimensions = 21 × 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.8 x</td>
<td>15.8×13.6in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2008875173</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 × Audited Dimensions = 20.6 x 15.8 ×13.6in</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2013986187</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>22 × 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 21.2 x Customer Entered Dimensions</td>
<td>15.4 × 13.6 = 20 ×</td>
<td>in 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2005703194</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 21 x 15.4</td>
<td>× 13.6</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2007626201</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>87.78</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 × 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.8 x Customer Entered Dimensions</td>
<td>15.4 x 13.6 = 20 × 16</td>
<td>in × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848034</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2012131520</td>
<td>Standard</td>
<td>L9A4X5</td>
<td>201</td>
<td>311 lbs</td>
<td>422.96</td>
<td>-291.84</td>
<td>131.12</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>L9A4X5</td>
<td>201</td>
<td>426.0 lbs</td>
<td>579.36</td>
<td>399.76</td>
<td>179.60</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>36.80</td>
<td>-25.43</td>
<td>11.37</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848018</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 218</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 218</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>999 UPPER</td>
<td>WENTWORTH</td>
<td>ST</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>HAMILTON</td>
<td>ON L9A4X5</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2012131520</td>
<td></td>
<td></td>
<td></td>
<td>3 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>6.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 8.6 x 8.2 Customer Entered Dimensions</td>
<td>9 x 9 x 9 x 8.2 in = 10 × 8</td>
<td>in × 4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848018</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2010312552</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.6 × Customer Entered Dimensions 1st ref: 68951</td>
<td>21 x 16 15.6× = 20 ×</td>
<td>× 14 in 13.6in 16 × 10 in</td>
<td>2nd ref:</td>
<td>52848018</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


####### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 75 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th></th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/19</td>
<td colspan="2">1ZG7093D2017851565</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 × Audited Dimensions = 20.8 x 15.6×13.2in</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848018</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2008796571</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="3">Billable Audited Dimensions = 21 x 16 × 14 in Audited Dimensions = 20.2 × 15.6×13.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848018</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2006747583</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.6 x 15.8×13.6in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1 st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848018</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2015304598</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>21 x 15.8 x 13.2 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848018</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2018067607</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.6 x 15.6×13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th>1st</th>
<th>ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848018</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2018636617</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.8 x 15.8 × 13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848018</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2000611622</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.4 × 15.8× 13.6in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848018</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2007592631</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = Customer Entered</td>
<td>18.4 x 15.4 × 14.2 Dimensions = 20 ×</td>
<td>in 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848018</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2003179649</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>31.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 17 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>18 x 16.2 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848018</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2010972652</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = Customer Entered</td>
<td>18 x 15.4 × 14.4 Dimensions = 20 ×</td>
<td>in 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848018</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


####### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 76 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th colspan="2">Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/19</td>
<td colspan="2">1ZG7093D2014571668</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>59.85</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 17.6 x Customer Entered Dimensions</td>
<td colspan="2">18 x 16 × 15 in 15.4 × 14.6 in = 20 × 16 × 10</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848018</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2013346403</td>
<td>Standard</td>
<td>M3C3R6</td>
<td>200</td>
<td>150 lbs</td>
<td>99.45</td>
<td>51.71</td>
<td>47.74</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>M3C3R6</td>
<td>200</td>
<td>163.0 lbs</td>
<td>107.58</td>
<td>55.94</td>
<td>51.64</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>1.89</td>
<td>0.99</td>
<td>0.90</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848067</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 960</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 960</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>1090 DON</td>
<td>MILLS RD</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>NORTH</td>
<td>YORK ON M3C3R6</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2008711438</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 17.8 x</td>
<td colspan="2">15.4 x 14.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>15 × 13</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848067</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2015578445</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.4 x</td>
<td colspan="2">15.8×13.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848067</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2002651451</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>4.80</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.6 x Customer Entered Dimensions</td>
<td>21 x 16 15.6 x = 20 ×</td>
<td>× 14 in 13.2in 15 × 13</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848067</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="6">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2013672159</td>
<td>Standard</td>
<td>J4Y0B3</td>
<td>203</td>
<td>240 lbs</td>
<td>434.40</td>
<td>-299.74</td>
<td>134.66</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>J4Y0B3</td>
<td>203</td>
<td>294.0 lbs</td>
<td>532.14</td>
<td>-367.18</td>
<td>164.96</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>22.96</td>
<td>-15.82</td>
<td>7.14</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848007</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 518</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 518</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>9140</td>
<td>BOULEVARD LEDUC</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>BROSSARD</td>
<td>QC J4Y0B3</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Message</td>
<td>Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2016971160</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.6 x</td>
<td colspan="2">21 x 16 × 14 in 15.6×13.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>16 × 10</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848007</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2019676171</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>20 × 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951 Audited Dimensions = 20 × 15.8 Customer Entered Dimensions</td>
<td>× 13.6 = 20 ×</td>
<td>in 16 × 10</td>
<td>in 2nd ref:</td>
<td>52848007</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


#### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 77 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th colspan="2">Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/19</td>
<td colspan="2">1ZG7093D2017704198</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 21 x</td>
<td>15.2× 13.6in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848007</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2000227208</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 17.6</td>
<td>x 15.8×14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848007</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2016556216</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions Audited Dimensions = 18.2 Customer Entered Dimensions</td>
<td>= 19 x 16 × x 15.4 x 14.4 = 20 x</td>
<td>15 in in 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848007</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2005032230</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>37.44</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions Audited Dimensions = 18 x Customer Entered Dimensions</td>
<td>= 18 x 16 × 15.6 x 14.2 = 20 ×</td>
<td>15 in in 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848007</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2014370661</td>
<td>Standard</td>
<td>J3V5J5</td>
<td>203</td>
<td>264 lbs</td>
<td>477.84</td>
<td>-329.71</td>
<td>148.13</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>J3V5J5</td>
<td>203</td>
<td>280.0 lbs</td>
<td>506.80</td>
<td>-349.69</td>
<td>157.11</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>6.78</td>
<td>-4.69</td>
<td>2.09</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848063</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 766</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 766</td>
<td>LL766</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>1 BOUL DES</td>
<td>PROMENADES</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>SAINT-BRUNO</td>
<td>QC J3V5J5</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2005890723</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions Audited Dimensions = 17.8 Customer Entered Dimensions</td>
<td>= 18 x 16 × x 15.6 x 14.2 = 20 ×</td>
<td>15 in in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848063</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2000331738</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions Audited Dimensions = 20.8 Customer Entered Dimensions</td>
<td>= 21 x 16 × x 15.6×13 = 20 x</td>
<td>13 in in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848063</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2019378743</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.8 Customer Entered Dimensions</td>
<td>× 15.8 x 13.4 = 20 ×</td>
<td>in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848063</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2005690761</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>11.07</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.6 Customer Entered Dimensions</td>
<td>x 15.6×13.2in = 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848063</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 78 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th colspan="2">Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/19</td>
<td colspan="2">1ZG7093D2018787302</td>
<td>Standard</td>
<td>L3R4M9</td>
<td>200</td>
<td>405 lbs</td>
<td>267.30</td>
<td>-139.00</td>
<td>128.30</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>L3R4M9</td>
<td>200</td>
<td>550.0 lbs</td>
<td>363.00</td>
<td>-188.76</td>
<td>174.24</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>22.51</td>
<td>-11.62</td>
<td>10.89</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref: 52848011</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 213</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 213</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>5000 HIGHWAY</td>
<td>7 E</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>MARKHAM</td>
<td>ON L3R4M9</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2018787302</td>
<td></td>
<td></td>
<td></td>
<td>14 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>19.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="5">Billable Audited Dimensions = 18 x 12 × 12 in Audited Dimensions = 17.4 x 11.8× 11.6in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Customer Entered Dimensions</td>
<td>= 12 × 10</td>
<td>× 8 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848011</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2016971320</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Billable Audited Dimensions = Audited Dimensions = 18.2 × Customer Entered Dimensions</td>
<td colspan="2">19 x 16 × 15 in 15.6× 14.2 in = 20 x 16 × 10</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848011</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2019772334</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Audited Dimensions = 18.2 x</td>
<td colspan="2">15.4× 14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848011</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2003179345</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Audited Dimensions = 18.2 × Customer Entered Dimensions</td>
<td>15.2× 14.4 = 20 × 16</td>
<td>in × 10</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848011</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2010792356</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Audited Dimensions = 18.2 x</td>
<td colspan="2">15.4 x 14.2 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848011</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2006211366</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>30.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Audited Dimensions = 18 x 15.4 Customer Entered Dimensions</td>
<td>× 14 in = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848011</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2013036373</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Audited Dimensions = 18.2 ×</td>
<td colspan="2">15.8 x 14.2 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848011</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2014867385</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Audited Dimensions = 18.4 x Customer Entered Dimensions 1st ref: 68951</td>
<td>15.4×14.4in = 20 × 16</td>
<td>× 10</td>
<td>in 2nd ref:</td>
<td>52848011</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 79 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/19</td>
<td>1ZG7093D2015304392</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x 15.6</td>
<td>x 14.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848011</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2017947408</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Billable Audited Dimensions = 21 × 17 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.2 ×</td>
<td>16.2×13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848011</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2006396417</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Audited Dimensions = 20.6 x 15.8×13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848011</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2004251424</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.4 x 16 Customer Entered Dimensions</td>
<td>x 13.2 in = 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848011</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2015112438</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.6 ×</td>
<td>15.6×13.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848011</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002579441</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Audited Dimensions = 20.4 x 16 × 13.2 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848011</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2010252457</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.4 ×</td>
<td>15.8×13.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848011</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2001731465</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>56.83</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 × Audited Dimensions = 20.2 × 15.8×14 in Customer Entered Dimensions = 20 × 16</td>
<td>14 in × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848011</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th>1ZG7093D2022233053</th>
<th>Standard</th>
<th>G1V2L1</th>
<th>203</th>
<th>457 lbs</th>
<th>827.17</th>
<th>570.75</th>
<th>256.42</th>
<th></th>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>G1V2L 1</td>
<td>203</td>
<td>516.0 lbs</td>
<td>933.96</td>
<td>-644.43</td>
<td>289.53</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>25.03</td>
<td>-17.34</td>
<td>7.69</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848010</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 519</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 519</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>2450 BLVD</td>
<td>LAURIER</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>QUEBEC</td>
<td>QC G1V2L1</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


#### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 80 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th rowspan="2">Tracking Number</th>
<th rowspan="2"></th>
<th rowspan="2">Original Service/ Corrected Service</th>
<th rowspan="2">Postal Code</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th rowspan="2">Published Charge</th>
<th rowspan="2">Incentive Credit</th>
<th rowspan="2">Billed Charge</th>
<th>Adjustment</th>
</tr>
<tr>
<th>Amount</th>
</tr>
<tr>
<td>01/19</td>
<td colspan="2">1ZG7093D2025569883</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 ×</td>
<td colspan="2">15.4× 14.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848010</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2031166298</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="3">Billable Audited Dimensions = 19 x 16 × 15 in Audited Dimensions = 18.2 × 15.4 × 14.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848010</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2033798101</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 x</td>
<td>15.4 × 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1 st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848010</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2022141312</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x</td>
<td>15,4 x 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848010</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2036311924</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x</td>
<td>15.6 × 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848010</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2025399343</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 17</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.8 ×</td>
<td>16.2 × 13.6</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848010</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2020148159</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 21 x 16</td>
<td>× 13.6 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848010</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2027588368</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Audited Dimensions = 20.6 x Customer Entered Dimensions</td>
<td>16 × 13.4 = 20 ×</td>
<td>in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848010</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2029035979</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 17</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 21 x</td>
<td>16.4 × 13.8</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848010</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2038846988</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 17</td>
<td>x 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.6 × Customer Entered Dimensions</td>
<td>16.4 × 13.4 = 20 ×</td>
<td>in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848010</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


#### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 81 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th colspan="2" rowspan="2">Tracking Number</th>
<th>Original Service/</th>
<th rowspan="2">Postal Code</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th>Published</th>
<th>Incentive</th>
<th></th>
<th>Billed</th>
<th>Adjustment</th>
</tr>
<tr>
<th>Corrected Service</th>
<th>Charge</th>
<th>Credit</th>
<th></th>
<th>Charge</th>
<th>Amount</th>
</tr>
<tr>
<td>01/19</td>
<td colspan="2">1ZG7093D2022017395</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 × Audited Dimensions = 20.6 x 16 × 13.4in</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848010</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2035783202</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>40.80</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 × 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.2 × Customer Entered Dimensions</td>
<td>15.8×13.8in = 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848010</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="6">Shaded area denotes multi-piece shipment</td>
<td colspan="2"></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2022845026</td>
<td>Standard</td>
<td>L6J1J3</td>
<td>200</td>
<td>142 lbs</td>
<td>95.70</td>
<td>49.76</td>
<td></td>
<td>45.94</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>L6J1J3</td>
<td>200</td>
<td>175.0 lbs</td>
<td>115.50</td>
<td>-60.06</td>
<td></td>
<td>55.44</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>4.65</td>
<td>-2.40</td>
<td></td>
<td>2.25</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848029</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA</td>
<td>250</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA</td>
<td>250</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>291 LAKESHORE</td>
<td>RD E</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>OAKVILLE</td>
<td>ON L6J1J3</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2035520441</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 18 x 15.4 x 14.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848029</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2025203259</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>31.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 18.4 x</td>
<td colspan="2">19 x 16 × 14 in 15.4 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848029</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2039537462</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 x</td>
<td>15.6 × 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848029</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2022239075</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>11.75</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 x 16</td>
<td>× 14.2 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848029</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="6">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2026493211</td>
<td>Standard</td>
<td>R2M5E5</td>
<td>204</td>
<td>37 lbs</td>
<td>108.60</td>
<td>-74.93</td>
<td></td>
<td>33.67</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>R2M5E5</td>
<td>204</td>
<td>44.0 lbs</td>
<td>117.80</td>
<td>-81.28</td>
<td></td>
<td>36.52</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>2.16</td>
<td>-1.49</td>
<td></td>
<td>0.67</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848068</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>USA INC</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>USA INC.</td>
<td>00970</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>1225 ST</td>
<td>MARY'S RD</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>WINNIPEG</td>
<td>MB R2M5E5</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


#### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 82 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/19</td>
<td>1ZG7093D2026493211</td>
<td></td>
<td></td>
<td></td>
<td>11 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>16.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 17.4 x</td>
<td>18 x 12 × 11.6× 9.2in</td>
<td>10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 12 × 10</td>
<td>× 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848068</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023349829</td>
<td></td>
<td></td>
<td></td>
<td>26 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>28.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>3.52</td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td colspan="2">2nd ref: 52848068</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="6">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2027888374</td>
<td>Standard</td>
<td>L7S2J8</td>
<td>201</td>
<td>240 lbs</td>
<td>326.40</td>
<td>-225.22</td>
<td>101.18</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>L7S2J8</td>
<td>201</td>
<td>305.0 lbs</td>
<td>414.80</td>
<td>286.21</td>
<td>128.59</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>20.80</td>
<td>-14.37</td>
<td>6.43</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848008</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 290</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 290</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>900 MAPLE</td>
<td>AVE</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>BURLINGTON</td>
<td>ON L7S2J8</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2027888374</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.6 x</td>
<td>15.8 × 13.8in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848008</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020821797</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>22 × 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 21,2 x</td>
<td>15.6 x 13.6</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848008</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2032377424</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x 15.4</td>
<td>× 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 16</td>
<td>× 10</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848008</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2024601437</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x 15.4</td>
<td>× 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848008</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2031404842</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.4 ×</td>
<td>15.4×14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848008</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2036823658</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 18.2 ×</td>
<td>19 x 16 15.4 × 14.4</td>
<td>× 15 in in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848008</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 83 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th colspan="2">Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/19</td>
<td colspan="2">1ZG7093D2034733866</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>33.84</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.4×14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>16 × 10</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848008</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2030096722</td>
<td>Standard</td>
<td>K7L1B5</td>
<td>202</td>
<td>140 lbs</td>
<td>249.55</td>
<td>-172.19</td>
<td>77.36</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>K7L1B5</td>
<td>202</td>
<td>166.0 lbs</td>
<td>295.48</td>
<td>-203.88</td>
<td>91.60</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>10.80</td>
<td>-7.48</td>
<td>3.32</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848035</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 268</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 268</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>270 PRINCESS</td>
<td>ST</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>KINGSTON</td>
<td>ON K7L1B5</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2031901162</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.8 x</td>
<td>15.8×13.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>16 × 10</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848035</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2020180775</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x 15.4</td>
<td colspan="2">× 14.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848035</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2030903788</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>17.56</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x 15.2</td>
<td>× 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848035</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2030408493</td>
<td>Standard</td>
<td>C1E1H6</td>
<td>210</td>
<td>332 lbs</td>
<td>720.44</td>
<td>497.10</td>
<td>223.34</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>C1E1H6</td>
<td>210</td>
<td>364.0 lbs</td>
<td>789.88</td>
<td>545.02</td>
<td>244.86</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>-11.34</td>
<td>-11.21</td>
<td>22.55</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848066</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 769</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 769</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>670 UNIVERSITY</td>
<td>AVE</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>CHARLOTTETOWN</td>
<td>PE</td>
<td>C1E1H6</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2030408493</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 × 8 ×</td>
<td>5 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.6 x</td>
<td>7.4 × 4.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 96 ×</td>
<td>20 × 5 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Large Package Surcharge - Length</td>
<td>+ Girth</td>
<td>210</td>
<td></td>
<td>-117.70</td>
<td></td>
<td>-117.70</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848066</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2025039517</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x 15.2</td>
<td>× 14.6</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951 Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13</td>
<td>in 2nd ref:</td>
<td>52848066</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 84 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/19</td>
<td>1ZG7093D2021718120</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 18.2 x</td>
<td>19 x 16 × 15 15.2×14.2in</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 x 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52848066</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2034900130</td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">18 x 16 × 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x 15.4</td>
<td>× 14.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52848066</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2021181549</td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">19 x 16 × 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 x</td>
<td>15.4 × 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 x 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52848066</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2033398356</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.8 x</td>
<td>15.8 x 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848066</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2026226563</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.6 x</td>
<td>16 × 13.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 x 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848066</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025782179</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 × 14</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 21 x 15.8</td>
<td>x 13.6 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848066</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023221180</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>-118.73</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 × 14</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions - 20.8 x</td>
<td>16 × 13.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 15 ×</td>
<td>13 in</td>
<td rowspan="2">2nd ref:</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>52848066</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2031249583</td>
<td>Standard</td>
<td colspan="2">M1P4P5 200</td>
<td>188 lbs</td>
<td>124.08</td>
<td>-64.52</td>
<td>59.56</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>M1P4P5</td>
<td>200</td>
<td>251.0 lbs</td>
<td>165.66</td>
<td>-86.14</td>
<td>79.52</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>9.77</td>
<td>-5.04</td>
<td>4.73</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848036</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 272</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 272</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>300 BOROUGH</td>
<td>DR</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>SCARBOROUGH</td>
<td>ON M1P4P5</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2035633801</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 21 x 16 Customer Entered Dimensions 1st ref: 68951</td>
<td colspan="2">× 13.2 in = 20 × 16 × 10 in</td>
<td>2nd ref:</td>
<td>52848036</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 85 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th rowspan="2">Tracking Number</th>
<th rowspan="2">Original Service/ Corrected Service</th>
<th>Postal</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th rowspan="2">Published Charge</th>
<th rowspan="2">Incentive Credit</th>
<th>Billed</th>
<th colspan="2" rowspan="2">Adjustment Amount</th>
</tr>
<tr>
<th>Code</th>
<th>Charge</th>
</tr>
<tr>
<td>01/19</td>
<td>1ZG7093D2025235019</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.4 x</td>
<td>21 x 16 15.6× 13.4</td>
<td>× 14 in in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848036</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2021183627</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">Billable Audited Dimensions = 21 x 16 × 14 in Audited Dimensions = 20.4 x 16 × 13.2 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848036</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2037435638</td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">Billable Audited Dimensions = 19 x 16 × 15 in Audited Dimensions = 18.2 × 15.4 x 14.6 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848036</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2022587047</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x</td>
<td>15.6 x 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848036</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2021473859</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 17.8 ×</td>
<td>15.6×14.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848036</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020772064</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">24.69</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x 15.4 Customer Entered Dimensions</td>
<td>x 14.2 = 20 ×</td>
<td>in 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848036</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2031715917</td>
<td>Standard</td>
<td>T5G3A6</td>
<td>206</td>
<td>92 lbs</td>
<td>196.90</td>
<td>-135.86</td>
<td>61.04</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>T5G3A6</td>
<td>206</td>
<td>118.0 lbs</td>
<td>247.80</td>
<td>-170.98</td>
<td>76.82</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>11.97</td>
<td>-8.26</td>
<td>3.71</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848039</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 345</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 345</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>227 109 ST</td>
<td>NW</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>EDMONTON</td>
<td>AB T5G3A6</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025048534</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.8 x Customer Entered Dimensions</td>
<td colspan="2">21 x 16 × 14 in 15.6×13.2 in = 20 × 16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848039</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2039225941</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18 ×</td>
<td>15.8 × 14.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848039</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 86 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th colspan="2" rowspan="2">Tracking Number</th>
<th rowspan="2">Original Service/ Corrected Service</th>
<th>Postal</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th>Published</th>
<th rowspan="2">Incentive Credit</th>
<th>Billed</th>
<th>Adjustment</th>
</tr>
<tr>
<th>Code</th>
<th>Charge</th>
<th>Charge</th>
<th>Amount</th>
</tr>
<tr>
<td>01/19</td>
<td colspan="2">1ZG7093D2037578752</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>19.49</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 18 x 15.6</td>
<td>18 x 16 × × 14.2in</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>16 × 10 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848039</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="6">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/20</td>
<td colspan="2">1ZG7093D2002477819</td>
<td>Standard</td>
<td>H3B4G5</td>
<td>203</td>
<td>316 lbs</td>
<td>571.96</td>
<td>-394.65</td>
<td>177.31</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>H3B4G5</td>
<td>203</td>
<td>362.0 lbs</td>
<td>655.22</td>
<td>452.10</td>
<td>203.12</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>19.51</td>
<td>-13.51</td>
<td>6.00</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848060</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 263</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 263</td>
<td>CAD</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td rowspan="2">375 PENDANT DRIVE MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>705</td>
<td>SAINT-CATHERINE</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>MONTREAL</td>
<td>QC H3B4G5</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009172822</td>
<td></td>
<td></td>
<td></td>
<td>24 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>25.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848060</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2012873836</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x 15.4</td>
<td colspan="2">× 14.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848060</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2017180843</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions - 18.2 ×</td>
<td>15.4×</td>
<td>14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848060</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2005693857</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.4 x Customer Entered Dimensions</td>
<td>15.6 x 14.2 = 20 ×</td>
<td>in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848060</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2002012865</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.4 x</td>
<td>15.4 × 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848060</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009737874</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.8 ×</td>
<td>16×13.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848060</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2012468882</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.8 x</td>
<td>21 x 16 15.8×13.4in</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848060</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 87 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th colspan="2">Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/20</td>
<td colspan="2">1ZG7093D2013805890</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.4 x</td>
<td colspan="2">21 x 16 × 14 in 15.8×13.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848060</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2017348903</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.4 x</td>
<td>15.6 ×</td>
<td>13.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848060</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2006697913</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.6 x Customer Entered Dimensions</td>
<td>21 x 16 15.8×13.4in = 20 x</td>
<td>× 14 in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848060</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2005452929</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>31.81</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.6 x Customer Entered Dimensions</td>
<td>21 x 16 15.6 × 13.2 = 20 ×</td>
<td>× 14 in in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848060</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2003597572</td>
<td>Standard</td>
<td>L1J2K5</td>
<td>200</td>
<td>203 lbs</td>
<td>133.98</td>
<td>69.67</td>
<td>64.31</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>L 1J2K5</td>
<td>200</td>
<td>237 0 lbs</td>
<td>156.42</td>
<td>-81.34</td>
<td>75.08</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>5.24</td>
<td>-2.73</td>
<td>2.51</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848046</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 274</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 274</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>419 KING</td>
<td>ST W</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>OSHAWA</td>
<td>ON L 1J2K5</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2003597572</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.8 x Customer Entered Dimensions</td>
<td>21 x 16 16 x 13.6 = 20 ×</td>
<td>× 14 in in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848046</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2002148586</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 21.2 × Customer Entered Dimensions</td>
<td>22 × 16 16 × 13.6 = 20 x</td>
<td>× 14 in in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848046</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2011305595</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.8 x Customer Entered Dimensions</td>
<td>15.8×13.6in = 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848046</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2014668608</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>22 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 21.2 × Customer Entered Dimensions</td>
<td>15.8× = 20 ×</td>
<td>13.6in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848046</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 88 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th colspan="2" rowspan="2">Tracking Number</th>
<th rowspan="2">Original Service/ Corrected Service</th>
<th rowspan="2">Postal Code</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th rowspan="2">Published Charge</th>
<th rowspan="2">Incentive Credit</th>
<th>Billed</th>
<th>Adjustment</th>
</tr>
<tr>
<th>Charge</th>
<th>Amount</th>
</tr>
<tr>
<td>01/20</td>
<td colspan="2">1ZG7093D2015837610</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x 15.4</td>
<td>× 14.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848046</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2018412626</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 17.8 x</td>
<td>15.4 × 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848046</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2005993630</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>13.28</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.8 x 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848046</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2012393355</td>
<td>Standard</td>
<td>H9R5J2</td>
<td>203</td>
<td>311 lbs</td>
<td>562.91</td>
<td>-388.41</td>
<td>174.50</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>H9R5J2</td>
<td>203</td>
<td>353.0 lbs</td>
<td>638.93</td>
<td>440.86</td>
<td>198.07</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>17.83</td>
<td>-12.34</td>
<td>5.49</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848042</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 513</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 513</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>6815</td>
<td>TRANSCANADA HWY</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>POINTE-CLAIRE</td>
<td>QC H9R5J2</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2008412369</td>
<td></td>
<td></td>
<td></td>
<td>28 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>29.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848042</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2019305393</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 x</td>
<td>15.4 × 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848042</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2002548402</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.4 × 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848042</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2011597413</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 × Customer Entered Dimensions</td>
<td>15.4×14.2in = 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848042</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2010052422</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.6 × 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848042</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 89 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th colspan="2" rowspan="2">Tracking Number</th>
<th>Original Service/</th>
<th>Postal</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th rowspan="2">Published Charge</th>
<th rowspan="2">Incentive Credit</th>
<th>Billed</th>
<th>Adjustment</th>
</tr>
<tr>
<th>Corrected Service</th>
<th>Code</th>
<th>Charge</th>
<th>Amount</th>
</tr>
<tr>
<td>01/20</td>
<td colspan="2">1ZG7093D2001513432</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.6 x</td>
<td colspan="2">15.6×13.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Customer Entered Dimensions</td>
<td colspan="2">= 20 x 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848042</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009580444</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Audited Dimensions = 20.4 x</td>
<td colspan="2">15.6 ×13.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Customer Entered Dimensions</td>
<td colspan="2">= 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th colspan="3">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848042</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2017853456</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Audited Dimensions = 20.4 x</td>
<td colspan="2">15.6 × 13.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848042</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009932466</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 21 x</td>
<td colspan="2">15.8 x 13.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848042</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009417479</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>29.06</td>
</tr>
<tr>
<td></td>
<td colspan="3">Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.8 × Customer Entered Dimensions</td>
<td>15.6×13.2in = 20 x</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848042</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="3">Shaded area denotes</td>
<td>multi-piece</td>
<td>shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2019613050</td>
<td></td>
<td>Standard</td>
<td>T2H0K8</td>
<td>206</td>
<td>870 lbs</td>
<td>1,827.00</td>
<td>-1,260.63</td>
<td>566.37</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Standard</td>
<td>T2H0K8</td>
<td>206</td>
<td>1000.0 lbs</td>
<td>2,100.00</td>
<td>-1,449.00</td>
<td>651.00</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>64.22</td>
<td>-44.25</td>
<td>19.97</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 332</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 332</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>6455 MACLEOD</td>
<td>TRAIL SW</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>CALGARY</td>
<td>AB T2H0K8</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2019613050</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">19 × 16 × 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 × Customer Entered Dimensions</td>
<td>15.4× 14.4 = 20 x</td>
<td>in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2007452069</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">18 x 16 × 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x Customer Entered Dimensions</td>
<td>15,4 x 14.2 = 20 ×</td>
<td>in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2018697070</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">18 x 16 × 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951 Audited Dimensions = 18 × Customer Entered Dimensions</td>
<td>15.4 × 14.4in = 20 ×</td>
<td>15 × 13 in</td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 90 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th rowspan="2">Tracking Number</th>
<th></th>
<th rowspan="2">Original Service/ Corrected Service</th>
<th rowspan="2">Postal Code</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th rowspan="2">Published Charge</th>
<th rowspan="2">Incentive Credit</th>
<th rowspan="2">Billed Charge</th>
<th>Adjustment</th>
</tr>
<tr>
<th></th>
<th>Amount</th>
</tr>
<tr>
<td>01/20</td>
<td colspan="2">1ZG7093D2016948089</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x</td>
<td>15.4×14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848038</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2005805093</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="3">Billable Audited Dimensions = 18 x 16 × 15 in Audited Dimensions = 18 x 15.4 × 14.6 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2008868109</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 19 × 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.2×14.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1 st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848038</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009737114</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 17.8 x</td>
<td>15.4 × 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2012012122</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 19 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.4×14.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1 st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848038</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2019293138</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 17.2 ×</td>
<td>15.2 × 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2015180141</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x</td>
<td>15.4 × 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848038</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2003273153</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 17.8 × Customer Entered Dimensions</td>
<td>15.4 × = 20 ×</td>
<td>14.6in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2007172166</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 18 × 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x</td>
<td>15.4 x 14.6</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2010477170</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 17.6 x Customer Entered Dimensions</td>
<td>15.4 × 14.6 = 20 ×</td>
<td>in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 91 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th rowspan="2">Tracking Number</th>
<th></th>
<th>Original Service/</th>
<th rowspan="2">Postal Code</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th rowspan="2">Published Charge</th>
<th rowspan="2">Incentive Credit</th>
<th>Billed</th>
<th>Adjustment</th>
</tr>
<tr>
<th></th>
<th>Corrected Service</th>
<th>Charge</th>
<th>Amount</th>
</tr>
<tr>
<td>01/20</td>
<td colspan="2">1ZG7093D2016788181</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="3">Audited Dimensions = 18.2 x 15.4 × 14.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 x 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009705194</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 21 x 17 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.8 x 16.2×13.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2012828206</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.2 x 16 × 13.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 x 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1 st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848038</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2009757218</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 21 × 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.6 x 16 × 13.6 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848038</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2004092221</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions =</td>
<td>20.4 × 16 × 13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 x</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848038</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2019433236</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.6 x 15.8 x 13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2019380249</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.8 x 16 × 13.6</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2007533258</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.8 × 15.8×13.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848038</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2007492267</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 17 x</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions =</td>
<td>20.4 x 16.2×13.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2002857275</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 20.6 × 16 × 13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 92 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th rowspan="2">Tracking Number</th>
<th rowspan="2">Original Service/ Corrected Service</th>
<th>Postal</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th rowspan="2">Published Charge</th>
<th rowspan="2">Incentive Credit</th>
<th rowspan="2">Billed Charge</th>
<th rowspan="2">Adjustment Amount</th>
</tr>
<tr>
<th>Code</th>
</tr>
<tr>
<td>01/20</td>
<td>1ZG7093D2017228284</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Billable Audited Dimensions = 21 × 16 Audited Dimensions = 20.6 x 15.8×13.4</td>
<td>× 14 in in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2014205296</td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.4 ×</td>
<td>15.8 x</td>
<td>13.8in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2017388307</td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.6 x</td>
<td>15.6×13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2010377313</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.4 x</td>
<td>15.6 x 13.6</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2016772321</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.8 x</td>
<td>15.4×13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2000173338</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.6 x</td>
<td>15.8 x 13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2004180340</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>104.60</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.8 x Customer Entered Dimensions</td>
<td>15.4×13.2in = 20 x</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848038</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="6">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th>1ZG7093D2019908483</th>
<th>Standard</th>
<th>B3J1G1</th>
<th>209</th>
<th>214 lbs</th>
<th>462.24</th>
<th>-318.95</th>
<th>143,29</th>
<th></th>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>B3J1G1</td>
<td>209</td>
<td>235.0 lbs</td>
<td>507.60</td>
<td>350.24</td>
<td>157.36</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>10.65</td>
<td>-7.35</td>
<td>3.30</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848043</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 710</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 710</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>5445 SPRING</td>
<td>GARDEN RD</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>HALIFAX NS</td>
<td>B3J1G1</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2003453539</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x 15.4</td>
<td>× 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848043</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 93 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections(continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th colspan="2">Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/20</td>
<td colspan="2">1ZG7093D2015580549</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 x</td>
<td>15.6× 14.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th>1st</th>
<th>ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848043</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2003913550</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>22 × 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 21.2 ×</td>
<td>16 × 13.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848043</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2012052562</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>17.37</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 17 x</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 21 x 16.4 Customer Entered Dimensions</td>
<td>× 13.8 in = 20 x 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848043</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="6">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2023930511</td>
<td>Standard</td>
<td>T2S0B6</td>
<td>206</td>
<td>320 lbs</td>
<td>672.00</td>
<td>463.68</td>
<td>208.32</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>T2SOB6</td>
<td>206</td>
<td>347 0 lbs</td>
<td>728.70</td>
<td>502.80</td>
<td>225.90</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>13.34</td>
<td>9.19</td>
<td>4.15</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848047</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 311</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 311</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>727 17 AVE</td>
<td>SW</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>CALGARY</td>
<td>AB T2S0B6</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2032492540</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 x Customer Entered Dimensions</td>
<td>15.4 ×14.2 = 20 x 15</td>
<td>in × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848047</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2028049359</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Billable Audited Dimensions = Audited Dimensions = 18 x 15.6 Customer Entered Dimensions</td>
<td>18 x 16 × x 14.2 in = 20 × 15</td>
<td>15 in × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848047</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2023817564</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Billable Audited Dimensions = Audited Dimensions = 17.8 x Customer Entered Dimensions</td>
<td>18 x 16 × 15.4×14.2in = 20 × 15</td>
<td>15 in × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848047</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2029913172</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.2 ×</td>
<td>15.6 x 13.8</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848047</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2021492187</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Audited Dimensions = 20.4 x Customer Entered Dimensions 1st ref: 68951</td>
<td>15.6×13.8in = 20 × 15</td>
<td>× 13 in</td>
<td>2nd ref:</td>
<td>52848047</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 94 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th colspan="2">Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/20</td>
<td colspan="2">1ZG7093D2036350598</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>21.73</td>
</tr>
<tr>
<td></td>
<td colspan="3">Billable Audited Dimensions = Audited Dimensions = 21.2 x Customer Entered Dimensions</td>
<td colspan="2">22 × 16 × 14 in 15.8x 13.6 in = 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52848047</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2024949107</td>
<td>Standard</td>
<td colspan="2">T3A0E2 206</td>
<td>290 lbs</td>
<td>609.00</td>
<td>-420.21</td>
<td>188.79</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>T3A0E2</td>
<td>206</td>
<td>339.0 lbs</td>
<td>711.90</td>
<td>491.21</td>
<td>220.69</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>24.21</td>
<td>-16.68</td>
<td>7.53</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td colspan="2"></td>
<td colspan="2">2nd ref: 52848049</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender</td>
<td>: MIKE HALLSTEIN</td>
<td colspan="2"></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 321</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td colspan="2"></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 321</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td colspan="2"></td>
<td></td>
<td>3625</td>
<td>SHAGANAPPI TRAIL</td>
<td>NW</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td colspan="2"></td>
<td></td>
<td>CALGARY</td>
<td>AB T3A0E2</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2024949107</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>37.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.8 x</td>
<td colspan="2">21 x 16 × 15 in 15.6×14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848049</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2026232314</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.6 x Customer Entered Dimensions</td>
<td colspan="2">15.4 × 13.8 in = 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52848049</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2036942921</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td>37.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.4 x Customer Entered Dimensions</td>
<td colspan="2">15.4 × 14.2in = 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52848049</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2026236936</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.8 x Customer Entered Dimensions</td>
<td colspan="2">15.4 ×13.4 in = 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52848049</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2025910342</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td colspan="2">21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.2 × Customer Entered Dimensions</td>
<td colspan="2">15.4×13.8in = 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52848049</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2031999157</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Billable Audited Dimensions = Audited Dimensions = 17.8 x Customer Entered Dimensions</td>
<td colspan="2">18 x 16 × 15 in 15.2 × 14.4 in = 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td colspan="2"></td>
<td>2nd ref:</td>
<td>52848049</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2030379364</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st</td>
<td>ref: 68951 Billable Audited Dimensions = Audited Dimensions = 18.4 × Customer Entered Dimensions</td>
<td colspan="2">19 × 16 × 15 in 15.4×14.6in = 20 × 15 × 13 in</td>
<td>2nd ref:</td>
<td>52848049</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups

TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 95 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th colspan="2" rowspan="2">Tracking Number</th>
<th rowspan="2">Original Service/ Corrected Service</th>
<th rowspan="2">Postal Code</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th rowspan="2">Published Charge</th>
<th rowspan="2">Incentive Credit</th>
<th>Billed</th>
<th>Adjustment</th>
</tr>
<tr>
<th>Charge</th>
<th>Amount</th>
</tr>
<tr>
<td>01/20</td>
<td colspan="2">1ZG7093D2026366975</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 18.2 x 15.4×14.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Customer Entered Dimensions = 20 x 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848049</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2038317988</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 19 × 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 18.2 × 15.4 × 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered</td>
<td>Dimensions = 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th>1st</th>
<th>ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848049</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2035228393</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>39.43</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 17.8 x 15.4 × 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered</td>
<td>Dimensions = 20 x 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848049</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2028977294</td>
<td>Standard</td>
<td>T1L1A5</td>
<td>209</td>
<td>29 lbs</td>
<td>117.20</td>
<td>-80.87</td>
<td>36.33</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>T1L1A5</td>
<td>209</td>
<td>33.0 lbs</td>
<td>124.00</td>
<td>-85.56</td>
<td>38.44</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 19 x 16 x</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 18.2 x 15.4 x 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 x 15</td>
<td>x 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>1.60</td>
<td>-1.11</td>
<td>0.49</td>
<td>2.60</td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848041</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


Sender : MIKE HALLSTEIN

BRS CANADA C/O NAFFI

375 PENDANT DRIVE

MISSISSAUGA ON L5T2W9

Receiver: LULULEMON CANADA 351
LULULEMON CANADA 351
125 BANFF AVE
BANFF AB T1L1A5

Message Codes :ad w
Shaded area denotes multi-piece shipment


<table>
<tr>
<th colspan="2">1ZG7093D2030008424</th>
<th>Standard</th>
<th>L7G0J1</th>
<th>200</th>
<th>514 lbs</th>
<th>339.24</th>
<th>-176.40</th>
<th>162.84</th>
</tr>
<tr>
<td colspan="2"></td>
<td>Standard</td>
<td>L7G0J1</td>
<td>200</td>
<td>574.0 lbs</td>
<td>378.84</td>
<td>-197.00</td>
<td>181.84</td>
</tr>
<tr>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>9.27</td>
<td>-4.81</td>
<td>4.46</td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848054</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 189</td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 189</td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>13850 STEELES</td>
<td>AVE</td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>GEORGETOWN</td>
<td>ON L7G0J1</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">1ZG7093D2030008424</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.4 x 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Customer Entered Dimensions = 20 x 15</td>
<td>× 13</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848054</th>
<th></th>
<th></th>
</tr>
<tr>
<td colspan="2">1ZG7093D2028915841</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>30.0 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x 15.2</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848054</td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">1ZG7093D2025674652</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>31.0 lbs</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.4 ×14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848054</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


###### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 96 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th rowspan="2">Tracking Number</th>
<th></th>
<th rowspan="2">Original Service/ Corrected Service</th>
<th rowspan="2">Postal Code</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th rowspan="2">Published Charge</th>
<th rowspan="2">Incentive Credit</th>
<th rowspan="2">Billed Charge</th>
<th>Adjustment</th>
</tr>
<tr>
<th></th>
<th>Amount</th>
</tr>
<tr>
<td>01/20</td>
<td colspan="2">1ZG7093D2034524869</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18 x</td>
<td>15.4 × 14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848054</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2032782478</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="3">Billable Audited Dimensions = 18 × 16 × 15 in Audited Dimensions = 18 × 15.4 × 14.2 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848054</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2030803485</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2</td>
<td>× 15.4 × 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1 st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848054</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2029583896</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 19 × 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2</td>
<td>× 15.4 × 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848054</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2022359703</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.4</td>
<td>× 15.4×14.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848054</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2020206916</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 18 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 17.8 x</td>
<td>15.4 × 14.2</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848054</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2021641524</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>31.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 19 x 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.4 ×</td>
<td>15.4 ×</td>
<td>13.6in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848054</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2032136943</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 19 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 Customer Entered Dimensions</td>
<td>× 15.4× 14.4 = 20 ×</td>
<td>in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848054</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2037829758</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions</td>
<td>= 19 × 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 ×</td>
<td>15.4× 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848054</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2027573963</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Dimensions</td>
<td>= 19 × 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions = 18.2 × Customer Entered Dimensions</td>
<td>15.4 ×14.4 = 20 ×</td>
<td>in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848054</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


###### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 97 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup</th>
<th rowspan="2">Tracking Number</th>
<th>Original Service/</th>
<th>Postal</th>
<th rowspan="2">Zone</th>
<th rowspan="2">Weight</th>
<th>Published</th>
<th>Incentive</th>
<th></th>
<th>Billed</th>
<th>Adjustment</th>
</tr>
<tr>
<th>Date</th>
<th>Corrected Service</th>
<th>Code</th>
<th>Charge</th>
<th>Credit</th>
<th></th>
<th>Charge</th>
<th>Amount</th>
</tr>
<tr>
<td>01/20</td>
<td>1ZG7093D2021085573</td>
<td></td>
<td></td>
<td></td>
<td>21 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Audited Dimensions = 18 x 15.4</td>
<td>× 14.2in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Customer Entered Dimensions</td>
<td>= 20 × 13</td>
<td>× 5 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848054</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2027120586</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Audited Dimensions = 18 x 15.4</td>
<td>× 14.4 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848054</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2021074996</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>23.46</td>
</tr>
<tr>
<td></td>
<td colspan="2">Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Audited Dimensions = 18.2 × Customer Entered Dimensions</td>
<td>15.4 × 14.2 = 20 × 15</td>
<td>in × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848054</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2032588714</td>
<td>Standard</td>
<td>P3A1Z2</td>
<td>203</td>
<td>287 lbs</td>
<td>519.47</td>
<td>-358.43</td>
<td></td>
<td>161.04</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>P3A1Z2</td>
<td>203</td>
<td>326.0 lbs</td>
<td>590.06</td>
<td>407.14</td>
<td></td>
<td>182.92</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>16.55</td>
<td>-11.44</td>
<td></td>
<td>5.11</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848055</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td colspan="2">CANADA 219</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td colspan="2">CANADA 219</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>1349 LASALLE</td>
<td>BLVD</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>SUDBURY</td>
<td>ON P3A1Z2</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025234743</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 18 x 15,6 Customer Entered Dimensions</td>
<td>18 × 16 × x 14.6 in = 20 × 15</td>
<td>15 in × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848055</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020659553</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Billable Audited Dimensions = Audited Dimensions = 18.2 x</td>
<td>19 × 16 × 15.2× 14.2</td>
<td>15 in in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848055</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2020215764</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Audited Dimensions = 18 × 15.6x Customer Entered Dimensions</td>
<td>14.4 in = 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848055</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2038819374</td>
<td></td>
<td></td>
<td></td>
<td>23 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Audited Dimensions = 18 x 15.8 Customer Entered Dimensions</td>
<td>x 14.2 in = 15 × 13</td>
<td>× 2 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848055</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2028426389</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Billable Audited Dimensions = Audited Dimensions = 21 × 15.6 Customer Entered Dimensions 1st ref: 68951</td>
<td>21 x 16 × × 13.8 in = 20 × 15</td>
<td>14 in × 13 in</td>
<td>2nd ref:</td>
<td>52848055</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


###### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 98 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th colspan="2">Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/20</td>
<td colspan="2">1ZG7093D2035632795</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 × 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 21 x</td>
<td>15.6x 13.2 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th>1st</th>
<th>ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848055</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2023274605</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 20.8 ×</td>
<td>15.6×13.8in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848055</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2036027812</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>26.99</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 17 x</td>
<td>13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 21 x 16.2 Customer Entered Dimensions</td>
<td>x 13 in = 20 x 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848055</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="6">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2036524409</td>
<td>Standard</td>
<td>K2B8C1</td>
<td>202</td>
<td>293 lbs</td>
<td>521,54</td>
<td>-359.86</td>
<td>161.68</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td>K2B8C1</td>
<td>202</td>
<td>332.0 lbs</td>
<td>590.96</td>
<td>407.76</td>
<td>183.20</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>16.31</td>
<td>-11.24</td>
<td>5.07</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848048</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender</td>
<td>: MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 215</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 215</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>100 BAYSHORE</td>
<td>DR</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>NEPEAN ON</td>
<td>K2B8C1</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2033889610</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.4 x Customer Entered Dimensions</td>
<td>15.4 x 14.2 = 20 × 15</td>
<td>in × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848048</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2039762227</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 18 x 15.4 Customer Entered Dimensions</td>
<td>18 x 16 × × 14.2 in = 20 × 15</td>
<td>15 in × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848048</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2038498239</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions = Audited Dimensions = 18.4 x Customer Entered Dimensions</td>
<td>19 x 16 × 15.4 × 14.2in = 20 × 15</td>
<td>15 in × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848048</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2025093646</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions = 18.4 x Customer Entered Dimensions</td>
<td>15.6 x 14.2 = 20 × 15</td>
<td>in × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848048</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2023196271</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951 Audited Dimensions = 20.6 x Customer Entered Dimensions</td>
<td>15.8×13.6in = 20 × 15</td>
<td>× 13 in</td>
<td>2nd ref:</td>
<td>52848048</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 99 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th rowspan="2">Pickup Date</th>
<th rowspan="2">Tracking Number</th>
<th>Original Service/</th>
<th>Postal</th>
<th></th>
<th rowspan="2">Weight</th>
<th rowspan="2">Published Charge</th>
<th>Incentive</th>
<th></th>
<th>Billed</th>
<th>Adjustment</th>
</tr>
<tr>
<th>Corrected Service</th>
<th>Code</th>
<th>Zone</th>
<th>Credit</th>
<th></th>
<th>Charge</th>
<th>Amount</th>
</tr>
<tr>
<td>01/20</td>
<td>1ZG7093D2023989281</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 21.4 x</td>
<td>22 × 16 × 14 15.6 x 13.6 in</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td colspan="2">= 20 x 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848048</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2023221699</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Billable Audited Dimensions =</td>
<td colspan="2">22 × 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Audited Dimensions = 21.2 x</td>
<td colspan="2">16 × 13.8 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Customer Entered Dimensions</td>
<td colspan="2">= 20 × 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848048</th>
<th></th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td>1ZG7093D2033329500</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>26.59</td>
</tr>
<tr>
<td></td>
<td colspan="2">Billable Audited Dimensions =</td>
<td>21 × 16 × 14</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Audited Dimensions = 21 x 15.8 Customer Entered Dimensions</td>
<td>x 13.8 in = 20 × 15 ×</td>
<td>13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848048</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2037806086</td>
<td>Standard</td>
<td>M5B2H6</td>
<td>200</td>
<td>155 lbs</td>
<td>102.30</td>
<td>53.20</td>
<td></td>
<td>49.10</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>M5B2H6 200</td>
<td></td>
<td>180.0 lbs</td>
<td>118.80</td>
<td>-61.78</td>
<td></td>
<td>57.02</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>3.86</td>
<td>2.01</td>
<td></td>
<td>1.85</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848031</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td colspan="2">CANADA 261</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td colspan="2">CANADA 261</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>218 YONGE</td>
<td>STEEET</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>TORONTO</td>
<td>ON M5B2H6</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2021630492</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 18.4 x Customer Entered Dimensions</td>
<td>19 x 16 × 15 15.4 x 14.2 in = 20 x 15 ×</td>
<td>in 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848031</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2024810309</td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Billable Audited Dimensions = Audited Dimensions = 18.2 ×</td>
<td>19 x 16 × 15 15.4 × 14.4 in</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 15 ×</td>
<td>13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848031</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2036821516</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Billable Audited Dimensions =</td>
<td>21 x 16 × 14</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 20.8 × Customer Entered Dimensions</td>
<td>15.8×13.4in = 20 x 15 ×</td>
<td>13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848031</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2030580127</td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Billable Audited Dimensions =</td>
<td>21 x 16 × 14</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">Audited Dimensions = 20.8 x Customer Entered Dimensions</td>
<td>15.8× 13.4 in = 20 × 15 ×</td>
<td>13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848031</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2036042135</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>9.77</td>
</tr>
<tr>
<td></td>
<td colspan="2">Billable Audited Dimensions = Audited Dimensions = 21 × 16.2 Customer Entered Dimensions 1st ref: 68951</td>
<td>21 x 17 × 14 × 13.2 in = 20 × 15 ×</td>
<td>in 13 in</td>
<td>2nd ref:</td>
<td>52848031</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 100 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th colspan="2">Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th></th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th colspan="2">Adjustment Amount</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="6">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td>01/20</td>
<td colspan="2">1ZG7093D2037850153</td>
<td>Standard</td>
<td></td>
<td>M5T1G1</td>
<td>200</td>
<td>371 lbs</td>
<td>244.86</td>
<td>-127.33</td>
<td>117.53</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Standard</td>
<td></td>
<td>M5T1G1</td>
<td>200</td>
<td>434.0 lbs</td>
<td>286.44</td>
<td>-148.95</td>
<td>137.49</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>9.71</td>
<td>5.05</td>
<td>4.66</td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="4">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848027</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 220</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 220</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2" rowspan="2">375 PENDANT DRIVE MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>2 BLOOR</td>
<td>STREET WEST</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>TORONTO</td>
<td>ON M5T1G1</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="4">Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2037850153</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="4">Billable Audited Dimensions = 21 x 16 × 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="4">Audited Dimensions = 20.8 x 15.6×13.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Customer Entered Dimensions</td>
<td colspan="2">= 20 x 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848027</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2027170362</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 20.8 x 16 Customer Entered Dimensions</td>
<td>× 13.2 in = 20 x 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848027</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2037697972</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = Audited Dimensions = 20.8 x Customer Entered Dimensions</td>
<td>21 x 16 × 15.6x 13.6in = 20 × 15</td>
<td>14 in × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848027</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2031788983</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>23 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = Audited Dimensions = 20.6 x</td>
<td>21 × 16 × 15.8 x 13.8</td>
<td>14 in in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Customer Entered Dimensions</td>
<td>= 20 × 13</td>
<td>× 5 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st</td>
<td colspan="2">ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848027</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2022439395</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="4">Billable Audited Dimensions = Audited Dimensions = 20.8 x Customer Entered Dimensions</td>
<td>21 x 16 × 15.8× 13.4 = 20 × 15</td>
<td>14 in in × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st</td>
<td colspan="2">ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848027</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2034885201</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="4">Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 20.8 x Customer Entered Dimensions</td>
<td>16× 13.4 in = 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">1st</td>
<td colspan="2">ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2032202415</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="5">Billable Audited Dimensions = 21 x 17 x</td>
<td>13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 20.8 x Customer Entered Dimensions</td>
<td>16.6 × 12.8 = 20 × 15</td>
<td>in × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="4">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848027</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2024907027</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions =</td>
<td>21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 20.6 × Customer Entered Dimensions</td>
<td>15.8×13.4in = 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="3">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848027</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

ups
TM

</figure>


##### Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 101 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/20</td>
<td>1ZG7093D2024555032</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.4 x</td>
<td>15.2×14.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2021342446</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18 × 15.4</td>
<td>× 14.6 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2025705252</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Billable Audited Dimensions = 18 x 16 × Audited Dimensions = 18 × 15.6 × 14.6 in</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Customer Entered Dimensions</td>
<td>= 20 x 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1 st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2033919462</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>19 × 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18.4 x Customer Entered Dimensions</td>
<td>15.4 x 14.8 = 20 × 15</td>
<td>in × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2037701073</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>24.62</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions =</td>
<td>18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Audited Dimensions = 18 x 15.4 Customer Entered Dimensions</td>
<td>× 14.6 in = 20 × 15</td>
<td>× 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="5">Shaded area denotes multi-piece shipment</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th>1ZG7093D2038334209</th>
<th>Standard</th>
<th>T4A0G3</th>
<th>207</th>
<th>319 lbs</th>
<th>676.28</th>
<th>-466.63</th>
<th>209.65</th>
<th></th>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>T4A0G3</td>
<td>207</td>
<td>369.0 lbs</td>
<td>782.28</td>
<td>539.77</td>
<td>242.51</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>24.89</td>
<td>-17.21</td>
<td>7.68</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848062</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Sender : MIKE HALLSTEIN</td>
<td></td>
<td></td>
<td>Receiver:</td>
<td>LULULEMON</td>
<td>CANADA 360</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>BRS CANADA C/O NAFFI</td>
<td></td>
<td></td>
<td></td>
<td>LULULEMON</td>
<td>CANADA 360</td>
<td>LL360</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>375 PENDANT DRIVE</td>
<td></td>
<td></td>
<td></td>
<td>261055</td>
<td>CROSSIRON BLVD</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>MISSISSAUGA ON L5T2W9</td>
<td></td>
<td></td>
<td></td>
<td>ROCKY VIEW</td>
<td>COUNTY AB</td>
<td>T4A0G3</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Message Codes :ad v</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2038334209</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.4 x Customer Entered Dimensions</td>
<td>21 x 16 × 15.8 ×13.6in = 20 x 15</td>
<td>14 in × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848062</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2026711412</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 21 x 15.8 Customer Entered Dimensions</td>
<td>21 x 16 × x 14 in = 20 × 15</td>
<td>14 in × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848062</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>1ZG7093D2026876021</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>36.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Billable Audited Dimensions = Audited Dimensions = 20.8 x Customer Entered Dimensions 1st ref: 68951</td>
<td>21 × 17 × 16.4×13.6in = 20 × 15</td>
<td>14 in × 13 in</td>
<td>2nd ref:</td>
<td>52848062</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups
TM

</figure>


# Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 102 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th colspan="2">Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/20</td>
<td>1ZG7093D2026384035</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 21 x 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 20.6 x 15.8x 13.6</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2">Customer Entered Dimensions = 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848062</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2031431447</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited</td>
<td>Dimensions = 21 × 16</td>
<td>× 14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions</td>
<td>= 20.4 x 15.8× 13.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848062</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2028454250</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>34.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 21 × 16 ×</td>
<td>14 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 20.6 x 15.6 × 13.8in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848062</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2029728462</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 19 × 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Audited Dimensions = 18.4 x 15.4 x 14.6</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Customer Entered Dimensions = 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th></th>
<th colspan="2">1st ref: 68951</th>
<th></th>
<th></th>
<th>2nd ref:</th>
<th>52848062</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2022970079</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="2">Billable Audited Dimensions = 18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions</td>
<td>= 18 x 15.4 × 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer Entered</td>
<td>Dimensions = 20 x</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848062</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2024935087</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>32.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited</td>
<td>Dimensions = 18 x 16 ×</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Audited Dimensions</td>
<td>= 18 x 15.4 x 14.4</td>
<td>in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848062</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2039019496</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Billable Audited</td>
<td>Dimensions = 19 x 16</td>
<td>× 15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Audited Dimensions</td>
<td>= 18.2 × 15.4×14.4in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td>Customer Entered</td>
<td>Dimensions = 20 ×</td>
<td>15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>1st</td>
<td>ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848062</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">1ZG7093D2036859307</td>
<td></td>
<td></td>
<td></td>
<td>29 lbs</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>33.0 lbs</td>
<td></td>
<td></td>
<td></td>
<td>40.54</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Billable Audited Audited Dimensions Customer Entered</td>
<td>Dimensions = 19 x 16 = 18.4 x 15.4 × 14.4 Dimensions = 20 ×</td>
<td>× 15 in in 15 × 13 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">1st ref: 68951</td>
<td></td>
<td></td>
<td>2nd ref:</td>
<td>52848062</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

Ups

TM

</figure>


Delivery Service Invoice


<table>
<tr>
<td>Invoice Date</td>
<td>January 31, 2026</td>
</tr>
<tr>
<td>Invoice Number</td>
<td>0000G7093D056</td>
</tr>
<tr>
<td>Account Number</td>
<td>G7093D</td>
</tr>
</table>


<!-- PageNumber="Page 103 of 103" -->

Adjustments & Other Charges
Shipping Charge Corrections (continued) Learn how to avoid future shipping charge corrections. Visit www.ups.com/avoidcharges.


<table>
<tr>
<th>Pickup Date</th>
<th>Tracking Number</th>
<th>Original Service/ Corrected Service</th>
<th>Postal Code</th>
<th>Zone</th>
<th>Weight</th>
<th>Published Charge</th>
<th>Incentive Credit</th>
<th>Billed Charge</th>
<th>Adjustment Amount</th>
</tr>
<tr>
<td>01/26</td>
<td>1ZG7093D2006390806</td>
<td>Standard</td>
<td>T1L1A5</td>
<td>209</td>
<td>29 lbs</td>
<td>117.20</td>
<td>-80.87</td>
<td>36.33</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Standard</td>
<td>T1L1A5</td>
<td>209</td>
<td>33.0 lbs</td>
<td>124.00</td>
<td>-85.56</td>
<td>38.44</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2" rowspan="3">Billable Audited Dimensions = 19 x 16 x Audited Dimensions = 18.4 x 15.4 x 14.2 Customer Entered Dimensions = 20 x 15</td>
<td>15 in</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2"></td>
<td rowspan="2"></td>
<td rowspan="2">in x 13 in</td>
<td rowspan="2"></td>
<td rowspan="2"></td>
<td rowspan="2"></td>
<td rowspan="2"></td>
<td></td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Fuel Surcharge</td>
<td></td>
<td></td>
<td></td>
<td>1.63</td>
<td>-1.12</td>
<td>0.51</td>
<td>2.62</td>
</tr>
</table>


1st ref: 68951

Sender : MIKE HALLSTEIN

BRS CANADA C/O NAFFI

375 PENDANT DRIVE

MISSISSAUGA ON L5T2W9

Message Codes :ad w

2nd ref: 52887503
Receiver: LULULEMON CANADA 351
LULULEMON CANADA 351
125 BANFF AVE
BANFF AB T1L1A5


<table>
<tr>
<td>Total Shipping Charge Corrections</td>
<td>459 Package(s) 1,997.77</td>
</tr>
<tr>
<td>Total Adjustments &amp; Other Charges</td>
<td>2,638.83</td>
</tr>
</table>


Tax

GST R105453328


<table>
<tr>
<th>Service</th>
<th>Rate</th>
<th>Net Taxable Amt</th>
<th>Tax Charge</th>
</tr>
<tr>
<td>Shipping API</td>
<td>5.00 %</td>
<td>5,187.55</td>
<td>259.35</td>
</tr>
<tr>
<td>Freight Collect</td>
<td>5.00 %</td>
<td>30.25</td>
<td>1.51</td>
</tr>
<tr>
<td>Address Corrections</td>
<td>5.00 %</td>
<td>609.15</td>
<td>30.46</td>
</tr>
<tr>
<td>Weight &amp; Size Adjustments</td>
<td>5.00 %</td>
<td>1,318.36</td>
<td>65.91</td>
</tr>
<tr>
<td>Total Taxes GST R105453328</td>
<td></td>
<td></td>
<td>357.23</td>
</tr>
</table>


HST R105453328


<table>
<tr>
<th>Service</th>
<th>Rate</th>
<th>Net Taxable Amt</th>
<th>Tax Charge</th>
</tr>
<tr>
<td>Shipping API</td>
<td>13.00 %</td>
<td>2,941.31</td>
<td>382.36</td>
</tr>
<tr>
<td>Freight Collect</td>
<td>13.00 %</td>
<td>20.55</td>
<td>2.67</td>
</tr>
<tr>
<td>Packages Delivered but not Previously Billed</td>
<td>13.00 %</td>
<td>23.81</td>
<td>3.10</td>
</tr>
<tr>
<td>Weight &amp; Size Adjustments</td>
<td>13.00 %</td>
<td>746.71</td>
<td>97.08</td>
</tr>
<tr>
<td>Shipping API</td>
<td>14.00 %</td>
<td>240.80</td>
<td>33.71</td>
</tr>
<tr>
<td>Weight &amp; Size Adjustments</td>
<td>14.00 %</td>
<td>23.86</td>
<td>3.35</td>
</tr>
<tr>
<td>Shipping API</td>
<td>15.00 %</td>
<td>435.22</td>
<td>65.29</td>
</tr>
<tr>
<td>Weight &amp; Size Adjustments</td>
<td>15.00 %</td>
<td>-91.16</td>
<td>-13.67</td>
</tr>
<tr>
<td>Total Taxes HST R105453328</td>
<td></td>
<td></td>
<td>573.89</td>
</tr>
<tr>
<td>Total Taxes</td>
<td></td>
<td></td>
<td>931.12</td>
</tr>
</table>


Invoice Messaging


<table>
<tr>
<th>Code</th>
<th>Message</th>
</tr>
<tr>
<td>ad</td>
<td>Shipment Pricing</td>
</tr>
<tr>
<td>r w dd v</td>
<td>Dimensional weight applied UPS Calculated Dimensional Weight applied based upon UPS Audit Identical tracking number used on multiple packages Weight adjustment based on UPS audit</td>
</tr>
</table>


<!-- PageBreak -->


