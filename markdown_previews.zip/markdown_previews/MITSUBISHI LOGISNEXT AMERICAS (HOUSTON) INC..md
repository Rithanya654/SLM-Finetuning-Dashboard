# MITSUBISHI LOGISNEXT AMERICAS (HOUSTON) INC..pdf

<figure>

Logisnext

</figure>


<table>
<tr>
<td rowspan="2">BUYER:</td>
<td>15300 Wiese USA (Central)</td>
</tr>
<tr>
<td>1435 Woodson Road St. Louis, MO 63132 USA</td>
</tr>
<tr>
<td>DELIVERY ADDRESS:</td>
<td></td>
</tr>
<tr>
<td>TERMS:</td>
<td>A3 Net 30 from Inv</td>
</tr>
</table>


# INVOICE


<table>
<tr>
<td>SP</td>
<td>1249383</td>
</tr>
<tr>
<td>PAGE</td>
<td>1</td>
</tr>
</table>


SELLER:

Mitsubishi Logisnext Americas Inc.

Houston Campus

2121 West Sam Houston Parkway North

Houston, TX 77043-2305

REMIT TO:

Mitsubishi Logisnext Americas Inc.

Houston Campus

Dept 3054

PO Box 123054

Dallas, TX 75312 - 3054

SHIP TO:

Wiese USA (South)

2547 Commerce Circle

Birmingham, AL 35217

USA

CURRENCY:

US Dollars


<table>
<tr>
<th>CUSTOMER PO</th>
<th>CO NUMBER</th>
<th>BILL OF LADING</th>
<th>SHIP DATE</th>
<th>PRICE EFF.DATE</th>
<th>INVOICE DATE</th>
</tr>
<tr>
<td>95654Z/29311</td>
<td>1631626</td>
<td>98367</td>
<td>1/31/26</td>
<td>4/10/25</td>
<td>1/31/26</td>
</tr>
</table>


<table>
<tr>
<th>ITEM NUMBER</th>
<th>DESCRIPTION</th>
<th>QTY</th>
<th>INST</th>
<th>AMOUNT</th>
</tr>
<tr>
<td>GC70K7/01631626</td>
<td rowspan="2">CATERPILLAR 15500 LB IC CUSHION S/N: AT89C10051 CATERPILLAR</td>
<td rowspan="2">1</td>
<td rowspan="2"></td>
<td rowspan="2"></td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td></td>
<td>GC70K7-LE 15,500 lb. Capacity LP</td>
<td>1</td>
<td>Y</td>
<td>100,735.00</td>
</tr>
<tr>
<td></td>
<td>VLV44MCC35I 4-Section Valve with Cowl Mounted Leve</td>
<td>1</td>
<td>Y</td>
<td>645.00</td>
</tr>
<tr>
<td></td>
<td>C70A47 MST TRI MFH 187.5 OAL 100 FFH 51.5 TLT 6F/5</td>
<td>1</td>
<td>Y</td>
<td>16,645.00</td>
</tr>
<tr>
<td></td>
<td>4VTRI0HFC35I Dual Function Internal Hosing - Tripl</td>
<td>1</td>
<td>Y</td>
<td>1,165.00</td>
</tr>
<tr>
<td></td>
<td>FKHP4870I 2.5" X 6.0" X 48.0" Hook Type Pallet</td>
<td>2</td>
<td>Y</td>
<td>2,540.00</td>
</tr>
<tr>
<td></td>
<td>AIRCLDEC40I Dual Element Air Cleaner</td>
<td>1</td>
<td>Y</td>
<td>365.00</td>
</tr>
<tr>
<td></td>
<td>FBPPC35I Foundry/Brick Protection Package</td>
<td>1</td>
<td>Y</td>
<td>1,980.00</td>
</tr>
<tr>
<td></td>
<td>TC2117I Quintolubric 888-46 Hydraulic Fluid</td>
<td>1</td>
<td>Y</td>
<td>1,835.00</td>
</tr>
<tr>
<td></td>
<td>SEATFSVSTD1I Full Suspension Vinyl Seat</td>
<td>1</td>
<td>Y</td>
<td>NO CHARGE</td>
</tr>
<tr>
<td></td>
<td>RVWMIRRI Dual Panaromic Rear View Mirror Kit</td>
<td>1</td>
<td>Y</td>
<td>290.00</td>
</tr>
<tr>
<td></td>
<td>FIREEXTC35I Fire Extinguisher - Mounted To OHG Leg</td>
<td>1</td>
<td>Y</td>
<td>255.00</td>
</tr>
<tr>
<td></td>
<td>LANGENGAM1I English Language Markings North/South</td>
<td>1</td>
<td>Y</td>
<td>NO CHARGE</td>
</tr>
<tr>
<td></td>
<td>EPASTD1I EPA Compliant</td>
<td>1</td>
<td>Y</td>
<td>NO CHARGE</td>
</tr>
<tr>
<td></td>
<td>2STMSTD1I Two Speed Powershift Transmission</td>
<td>1</td>
<td>Y</td>
<td>NO CHARGE</td>
</tr>
<tr>
<td></td>
<td>DRSC60STD1I Smooth Drive Tires 28 x 12 x 22</td>
<td>1</td>
<td>Y</td>
<td>NO CHARGE</td>
</tr>
<tr>
<td></td>
<td>STSC60STD1I Smooth Steer Tires 22 x 8 x 16</td>
<td>1</td>
<td>Y</td>
<td>NO CHARGE</td>
</tr>
<tr>
<td></td>
<td>CARR51C60STD1I 51.0" Wide ITA Class IV Hook Type C</td>
<td>1</td>
<td>Y</td>
<td>NO CHARGE</td>
</tr>
<tr>
<td></td>
<td>LBRSTD1I 48" High Load Backrest Extension</td>
<td>1</td>
<td>Y</td>
<td>NO CHARGE</td>
</tr>
<tr>
<td></td>
<td>OHGC7STD1I Standard Overhead Guard - 88.8" To Top</td>
<td>1</td>
<td>Y</td>
<td>NO CHARGE</td>
</tr>
<tr>
<td></td>
<td>SLDC35STD1I LCD/LED Display With Auxiliary Indicat</td>
<td>1</td>
<td>Y</td>
<td>NO CHARGE</td>
</tr>
<tr>
<td></td>
<td>EPSDSTD1I Engine Protection System</td>
<td>1</td>
<td>Y</td>
<td>NO CHARGE</td>
</tr>
<tr>
<td></td>
<td>SBIPSTD1I Separate Brake &amp; Inching Pedals</td>
<td>1</td>
<td>Y</td>
<td>NO CHARGE</td>
</tr>
<tr>
<td></td>
<td>PFRSTD1I Plate Fin Radiator</td>
<td>1</td>
<td>Y</td>
<td>NO CHARGE</td>
</tr>
<tr>
<td></td>
<td>EBUKLRMSTD1I Electronic Back-up Alarm</td>
<td>1</td>
<td>Y</td>
<td>NO CHARGE</td>
</tr>
<tr>
<td></td>
<td>WKLTSTD1I Two Forward LED Working Lights On OHG</td>
<td>1</td>
<td>Y</td>
<td>NO CHARGE</td>
</tr>
<tr>
<td></td>
<td>WKLTCLEDPSTD1I Rear LED Stop/Tail/Back-up Combinat</td>
<td>1</td>
<td>Y</td>
<td>NO CHARGE</td>
</tr>
<tr>
<td></td>
<td>OSBSTD1I Orange Seat Belt</td>
<td>1</td>
<td>Y</td>
<td>NO CHARGE</td>
</tr>
</table>


Formerly Mitsubishi Logisnext Americas (Houston) Inc.

CONTINUED

<!-- PageBreak -->

Logisnext


# INVOICE


<table>
<tr>
<td>SP</td>
<td>1249383</td>
</tr>
<tr>
<td>PAGE</td>
<td>2</td>
</tr>
</table>


<table>
<tr>
<th>CUSTOMER PO</th>
<th colspan="2">CO NUMBER BILL OF LADING</th>
<th>SHIP DATE</th>
<th>PRICE EFF.DATE</th>
<th>INVOICE DATE</th>
<th colspan="2"></th>
</tr>
<tr>
<th></th>
<th colspan="2"></th>
<th></th>
<th></th>
<th></th>
<th colspan="2"></th>
</tr>
<tr>
<th>ITEM NUMBER</th>
<th colspan="2">DESCRIPTION</th>
<th></th>
<th>QTY</th>
<th>INST</th>
<th colspan="2">AMOUNT</th>
</tr>
<tr>
<td></td>
<td></td>
<td>RFMSTD1I Rubber Floor Mat</td>
<td></td>
<td>1</td>
<td>Y</td>
<td>NO</td>
<td>CHARGE</td>
</tr>
<tr>
<td></td>
<td colspan="2">DBPSTD1I Drawbar Pin</td>
<td></td>
<td>1</td>
<td>Y</td>
<td colspan="2">NO CHARGE</td>
</tr>
<tr>
<td></td>
<td colspan="2">LPBRKTSTD1I Horizontal Tank Bracket</td>
<td></td>
<td>1</td>
<td>Y</td>
<td colspan="2">NO CHARGE</td>
</tr>
<tr>
<td></td>
<td colspan="2">ULSTD1I UL Approved</td>
<td></td>
<td>1</td>
<td>Y</td>
<td colspan="2">NO CHARGE</td>
</tr>
<tr>
<td></td>
<td colspan="2">4XSTD1I PSI 4X 4.3L V6 LPG Engine</td>
<td></td>
<td>1</td>
<td>Y</td>
<td colspan="2">NO CHARGE</td>
</tr>
<tr>
<td></td>
<td colspan="2">BULASC35I Amber Strobe Light - Mounted</td>
<td>Below OHG</td>
<td>1</td>
<td>Y</td>
<td colspan="2">495.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td>RVSABSLI Reverse Activated Blue</td>
<td>Spotlight</td>
<td>1</td>
<td>Y</td>
<td colspan="2">465.00</td>
</tr>
<tr>
<td></td>
<td colspan="2">FWDABSLI Forward Activated Blue</td>
<td>Spotlight</td>
<td>1</td>
<td>Y</td>
<td colspan="2">565.00</td>
</tr>
<tr>
<td></td>
<td colspan="2">TOTAL LIST</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">127,980.00</td>
</tr>
<tr>
<td></td>
<td colspan="3">TRADE DISCOUNT @ 20.00 % GC70K7/01631626</td>
<td></td>
<td></td>
<td colspan="2">25,596.00-</td>
</tr>
<tr>
<td></td>
<td colspan="2">TOTAL NET</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">102,384.00</td>
</tr>
<tr>
<td></td>
<td>444404</td>
<td colspan="2">24.00 GC70K7/01631626 SALES PROMO - WIESE (AL)</td>
<td></td>
<td></td>
<td colspan="2">24,572.16-</td>
</tr>
<tr>
<td></td>
<td colspan="3">WAR60DDD Extended Full Coverage Warranty - 60 Mont</td>
<td></td>
<td></td>
<td colspan="2">1,760.00</td>
</tr>
<tr>
<td></td>
<td colspan="2">PREPAID FREIGHT</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">1,520.00</td>
</tr>
<tr>
<td></td>
<td colspan="2">INVOICE GRAND TOTAL</td>
<td></td>
<td></td>
<td></td>
<td colspan="2">81,091.84</td>
</tr>
</table>


<!-- PageFooter="Formerly Mitsubishi Logisnext Americas (Houston) Inc." -->
