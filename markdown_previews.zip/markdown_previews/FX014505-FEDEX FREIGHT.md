# FX014505-FEDEX FREIGHT.pdf

EBDA


<figure>

FedEx ®
Freight

</figure>


# STATEMENT

Send payment to: DEPT CH PO BOX 10306 PALATINE IL 60055-0306
Direct Billing Inquiries to 2200 Forward Dr Harrison AR 72602-0840
EMAIL customersolutions@fedex.com
PHONE 870.741.9000
FAX 870.365.4354

WEBSITE www.fedex.com
TOLL-FREE 866.393.4585

Bill To / Payment Due From

NEW FLYER % INTELLIGENT AUDIT

Ste 455

365 W PASSAIC ST STE 455

ROCHELLE PARK NJ 07662-3005

<!-- PageNumber="PAGE 1OF 1" -->

Statement Number

AB62722046

Customer Number

934710835

Statement Date

01/27/2026

TO ACCESS YOUR FEDEX FREIGHT ACCOUNT AND REVIEW
OPEN INVOICES, GO TO ACCOUNT MANAGEMENT TOOLS
UNDER THE SUPPORT MENU ON FEDEX.COM.


<table>
<tr>
<th>FREIGHT BILL DATE</th>
<th>FREIGHT BILL NUMBER</th>
<th>SRVC</th>
<th>AMOUNT DUE</th>
<th>FREIGHT BILL DATE</th>
<th>FREIGHT BILL NUMBER</th>
<th>SRVC</th>
<th>AMOUNT DUE</th>
</tr>
<tr>
<td>12/09/2025</td>
<td>7414532952</td>
<td></td>
<td>295.42</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/14/2026</td>
<td>7414531165</td>
<td></td>
<td>717.58</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>01/21/2026</td>
<td>5783919724</td>
<td></td>
<td>228.73</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>TOTAL</td>
<td>STATEMENT CHARGES</td>
<td></td>
<td>1,241.73</td>
</tr>
</table>


FedEx®
®
Freight

Remittance Advice
PLEASE RETURN THIS PORTION WITH YOUR PAYMENT
Payment Due From Account # 934710835

Send to: DEPT CH PO BOX 10306
PALATINE IL 60055-0306
☐
Address change? Please check the appropriate box and fill out the information
on the reverse side of this form.

FXF

#BWNFZGZ

NEW FLYER % INTELLIGENT AUDIT

Ste 455

365 W PASSAIC ST STE 455

ROCHELLE PARK NJ 07662-3005

STATEMENT NUMBER
AB62722046

STATEMENT DATE
01/27/2026

CUSTOMER NUMBER

934710835

TOTAL STATEMENT CHARGES
1,241.73

<!-- PageFooter="Thank You!" -->
<!-- PageBreak -->

EBDA


<figure>

FedEx®
®
Freight

</figure>


# ORIGINAL INVOICE FXFE PRIORITY

Send payment to: DEPT CH PO BOX 10306 PALATINE IL 60055-0306
Direct Billing Inquiries to 2200 Forward Dr Harrison AR 72602-0840
EMAIL customersolutions@fedex.com WEBSITE www.fedex.com
PHONE 870.741.9000 FAX 870.365.4354 TOLL-FREE 866.393.4585

Shipper

NEW FLYER OF AMERICA

ANNISTON REGION

106 NATIONAL DR

ANNISTON AL 36207

Consignee

SPOKANE TRANSIT AUTH

1229 WEST BOONE

SPOKANE WA 99201

<!-- PageNumber="PAGE 1OF 1" -->


<table>
<tr>
<td>Freight Bill Number</td>
<td>7414532952</td>
</tr>
<tr>
<td>Ship Date/Invoice Date</td>
<td>12/09/2025 / 01/27/2026</td>
</tr>
<tr>
<td>Bill of Lading Number</td>
<td></td>
</tr>
<tr>
<td>P.O. Number</td>
<td></td>
</tr>
<tr>
<td>Shipper Reference Number</td>
<td></td>
</tr>
<tr>
<td>I/L PRO Number</td>
<td></td>
</tr>
<tr>
<td>Terms</td>
<td>PREPAID</td>
</tr>
<tr>
<td>Origin /Destination</td>
<td>ANB / SPO</td>
</tr>
<tr>
<td>Total Amount Due</td>
<td>295.42</td>
</tr>
<tr>
<td>Payment Due Date</td>
<td>02/11/2026</td>
</tr>
</table>


Bill To / Payment Due From

NEW FLYER % INTELLIGENT AUDIT

Ste 455

365 W PASSAIC ST STE 455

ROCHELLE PARK NJ 07662-3005

Account# 934710835


<table>
<tr>
<th>PIECES</th>
<th>PALLETS</th>
<th>HM</th>
<th>DESCRIPTION</th>
<th>WT(LBS)</th>
<th>NMFC</th>
<th>CLASS</th>
<th>RATE</th>
<th>TOTAL CHARGES</th>
</tr>
<tr>
<td>1</td>
<td></td>
<td>X ☒</td>
<td>BOX, UN3480,LITHIUM ION BATTERIES,9, EMERGENCY CONTACT 12566768020 ERI PROVIDER: NEW FLYER OF AMERICA *FXF PZONE01/06/25 ILS 11142 CHANGE PER CUSTOMER LETTER OF 005931 FUEL SURCHG LTL SHPT 33.30%</td>
<td>270</td>
<td>060680-01</td>
<td>070</td>
<td>680.060</td>
<td>1,836.16 59.31</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>005800 HAZARDOUS MATERIAL CHARGE 903 LESS DISCOUNT</td>
<td rowspan="2"></td>
<td></td>
<td></td>
<td rowspan="2">.903</td>
<td rowspan="2">58.00 1,658.05-</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>NONMFC ON BOL 548055335-102-0-424 02 ZONE NUMBER</td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2"></td>
<td rowspan="2"></td>
<td rowspan="2"></td>
<td rowspan="2">Invoicing Summary Original Invoice Amount Less Amount Paid</td>
<td rowspan="2"></td>
<td></td>
<td></td>
<td rowspan="2"></td>
<td rowspan="2">295.42</td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Less Freight Bill Adjustments</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2">1</td>
<td></td>
<td rowspan="2"></td>
<td rowspan="2">Totals / Amount Due by (02/11/2026)</td>
<td rowspan="2">270</td>
<td rowspan="2"></td>
<td rowspan="2"></td>
<td rowspan="2"></td>
<td rowspan="2">295.42</td>
</tr>
<tr>
<td></td>
</tr>
</table>


Rate Tariff : 548055335-102-0

FedEx ®
Freight

Remittance Advice
PLEASE RETURN THIS PORTION WITH YOUR PAYMENT
Payment Due From Account # 934710835

Send to: DEPT CH PO BOX 10306
PALATINE IL 60055-0306
☐
Address change? Please check the appropriate box and fill out the information
on the reverse side of this form.

FXF

#BWNFZGZ

NEW FLYER % INTELLIGENT AUDIT

Ste 455

365 W PASSAIC ST STE 455

ROCHELLE PARK NJ 07662-3005


<table>
<tr>
<td></td>
<td>FREIGHT BILL NUMBER 7414532952</td>
</tr>
<tr>
<td colspan="2">SHIP DATE/INVOICE DATE 12/09/2025 / 01/27/2026</td>
</tr>
<tr>
<td colspan="2">TERMS PREPAID</td>
</tr>
<tr>
<td colspan="2">PAYMENT DUE DATE 02/11/2026</td>
</tr>
<tr>
<td colspan="2">PLEASE PAY THIS AMOUNT 295.42</td>
</tr>
</table>


Thank You!

7414532952 000000029542 01272026 4

<!-- PageBreak -->


<figure>
</figure>


# UNIFORM STRAIGHT BILL OF LADING ORIGINAL --- NOT NEGOTIABLE SUBJECT TO THE TERMS AND CONDITIONS OF THE UNIFORM BILL OF LADING --- QUESTIONS? CALL 1.866.393.4585

FedEx.
Freight

741453295-2


<table>
<tr>
<th>Date 12/09/2025</th>
<th>Purchase Order #</th>
</tr>
<tr>
<td>Shipper #</td>
<td>Shipper # SO20142638</td>
</tr>
</table>


<table>
<tr>
<td>REQUIRED: Please select a service type</td>
<td>OPTIONAL: - You may select a money-back guarantee delivery (charges and tariff limitations may apply).</td>
</tr>
<tr>
<td>☒ FedEx Freight® ☐ FedEx Freight® Priority Economy</td>
<td>☐ A.M. Delivery ☐ Close of Business Delivery</td>
</tr>
</table>


<table>
<tr>
<th></th>
<th>SHIPPER (from)</th>
<th colspan="2">Please provide ZIP</th>
<th colspan="2">codes and phone numbers.</th>
<th colspan="3">CONSIGNEE (to)</th>
</tr>
<tr>
<th colspan="2">Shipper Maria Aguilar</th>
<th colspan="2">FXF Acct. # 6747-96269</th>
<th>Consignee ☐</th>
<th colspan="2">SPOKANE TRANSIT AUTHORITY</th>
<th colspan="2">FXF Acct. #</th>
</tr>
<tr>
<td colspan="2">Attn. to New Flyer</td>
<td>Area Code 256</td>
<td>Phone Number 241-1213</td>
<td colspan="3">Attn. to NEW FLYER(JEREMY-LEMM)</td>
<td>Area Code</td>
<td>Phone Number</td>
</tr>
</table>


Address
106 National Drive

Address

Address (Store, Dept., Ste., Flr., Apt., Div.)

Address (Store, Dept., Ste., Flr., Apt., Div.}

Address

Address

1229 W BOONE AVE

City

Anniston

City

SPOKANE


<table>
<tr>
<th>State/Province AL</th>
<th>ZIP/Postal Code 36207</th>
<th>Country</th>
<th>State/Province WA</th>
<th>ZIP/Postal Code 99201</th>
<th>Country US</th>
</tr>
<tr>
<td colspan="2">Accessorial Charges ☐ Liftgate ☐ Inside Pickup ☐ Limited Access</td>
<td></td>
<td colspan="2">Accessorial Charges ☐ Liftgate ☐ Inside Delivery ☐ Limited Access</td>
<td></td>
</tr>
<tr>
<td>Shipper Bill of Lading #</td>
<td></td>
<td></td>
<td>☐ Custom Delivery Window:</td>
<td></td>
<td></td>
</tr>
</table>


Special Instructions


<table>
<tr>
<th>BILL FREIGHT CHARGES TO (if different than above):</th>
<th></th>
<th colspan="2"></th>
<th></th>
<th colspan="2"></th>
</tr>
<tr>
<th>Name</th>
<th colspan="2">FXF Acct. # 326471207</th>
<th colspan="4">Mailing Address</th>
</tr>
<tr>
<td>City</td>
<td>State</td>
<td colspan="2">ZIP/Postal Code</td>
<td>Country</td>
<td>Area Code</td>
<td>Phone Number</td>
</tr>
</table>


<table>
<tr>
<td>Freight charges are PREPAID unless</td>
<td rowspan="3">☐ USD ☐ CAD</td>
<td>C.O.D.</td>
<td>1.</td>
<td>The letters "C.O.D." must appear in box before consignee's name above.</td>
</tr>
<tr>
<td>marked collect.</td>
<td></td>
<td>2.</td>
<td>C.O.D. funds to be collected as: ☐ Certified Funds ☐ Company Check ☐ Personal Check</td>
</tr>
<tr>
<td>CHECK BOX IF COLLECT ☒</td>
<td>AMOUNT</td>
<td>3.</td>
<td>C.O.D. fee to be paid by: ☐ Shipper ☐ Consignee</td>
</tr>
</table>


<table>
<tr>
<th colspan="2">REMIT C.O.D. TO {if different than shipper above):</th>
<th></th>
<th></th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<th colspan="2">Name</th>
<th colspan="5">Mailing Address</th>
</tr>
<tr>
<td>City</td>
<td>State</td>
<td>ZIP/Postal Code</td>
<td>Country</td>
<td>Country Code</td>
<td>Area Code</td>
<td>Phone Number</td>
</tr>
</table>


RECEIVED, subject to individually dstermined rates or contracts that have been agreed upon in wanting between the carner and shipper, if applicable, otherwise to therates, classifications and rules that have been established by the carrier and are available to the shipper, on request, and to all applicable state and federal regulations,
the property described below, in apprent good order, except as noted (contents and condition of contents of packages unknown} marked, cons:gned and destined as shown hereon, which said camer agrees to carry to destination, if on its route, or otherwise to deliver to another carrier on the route to destination. Every service to be
performed hereunder stall bo subject to all the conditions not prohibited by law, whather printed or written, herein contained, including the conditions on the back hereof, and the conditions of the FXF 100 Series Rules Tariff, or otherwise referenced, which are hereby agreed to by the shipper and accepted for himself and his assigns.


<table>
<tr>
<th rowspan="2">HANDLING UNITS (H/U)</th>
<th rowspan="2">H/U PKG. TYPE</th>
<th rowspan="2">PIECES</th>
<th rowspan="2">HM (X)</th>
<th rowspan="2">DESCRIPTION OF ARTICLES, KIND OF PACKAGE, SPECIAL MARKS AND EXCEPTIONS (subject to correction)</th>
<th>WEIGHT IN LBS.</th>
<th>NMFC ITEM #</th>
<th>CLASS</th>
<th>CUBE</th>
</tr>
<tr>
<th></th>
<th>(subject to correction)</th>
<th></th>
<th></th>
</tr>
<tr>
<td>1</td>
<td>Plt</td>
<td>1</td>
<td>☒</td>
<td>UN 3480 LITHIUM ION BATTERIES CLASS 9</td>
<td>270</td>
<td></td>
<td>9</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>EMERGENCY 24HRS PHONE-#760-476-362</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>ACCESS CODE:333477</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


TOTAL H/U:
*
MARK "X" OR "RQ" IN THE HM COLUMN TO DESIGNATE HAZARDOUS MATERIALS OR REPORTABLE QUANTITY AS DEFINED IN DOT REGULATIONS.

HM EMERGENCY CONTACT PHONE NUMBER ( 256 ) 676-8020

HM EMERGENCY RESPONSE PROVIDER PERSON or CONTRACT #
Jerry Dempsey

EEI/SED Number or Exception
Broker Name

Phone #

AREA CODE

Fax #

NOTE (1) Where the rate and carrier's liability for loss or damage may be dependent on value, shippers
must state specifically in writing the agreed or declared value of the property as follows: "The agreed
or declared value of the property is specifically stated by the shipper to be not exceeding
per

Note (2) liability limitation for loss or damage on this shipment shall be applicable as provided by
contract or in the current NMFC or this carrier's governing tariffs. See FXF 100 Series Rules Tariff
for complete limited liability provisions. Carrier's maximum standard liability is limited to $25 per pound
per package for NEW articles and $.50 per pound per package for its equivalent in Mexican Pesos (MXN)
or Canadian Dollars (CAD), at the rate of exchange which is in effect at the place and on the date of
shipment) for USED or RECONDITIONED articles. In no case shall carrier liability exceed $100,000 per occurrence
(or its equivalent in MXN or CAD at the rate of exchange which is in effect at the place and on the date
of shipment) for NEW articles or $10,000 per occurrence (or its equivalent in MXN or CAD at the rate of
exchange which is in effect at the place and on the date of shipment) for USED or RECONDITIONED articles.
For availability and limits of excess liability coverage and applicable rates and charges, please refer to FXF 100
Series Rules Tariff. Not selecting an additional coverage option is considered to be a waiver of same and standard
liability coverage will apply.
☐
Articles are NEW, and require Excess Liability Coverage in the amount of
☐
USD
☐
CAD

FOR FREIGHT COLLECT SHIPMENTS
Subject to Section 7 of conditions of applicable Bill of Lading. If this shipment is to be delivered to the consignee.
without recourse on the consignor, the consignor shall sign the following statement. The carrier may decline to
make delivery of this shipment without payment of freight and all other lawful charges.

Consignor Signature

SHIPPER CERTIFICATION

This is to certify that the above named materials are properly classified, described, packaged, marked and labeled, and
are in proper condition for transportation according to the applicable regulations of the Department of Transportation.
Shipper Signature
Maria Aquila

Date

12/9/2025

CARRIER CERTIFICATION

Carrier acknowledges receipt of packages and required placards. Carrier certifies emergency response information
was made available and/or carrier has the DOT emergency response guidebook or equivalent document in the vehicle.

☐ ☐
MXN per
☐
b. or
kg. Additional charges will apply.
☐
Articles are USED or RECONDITIONED and require Excess Liability Coverage. Additional charges will apply.
NOTE (3) Commodities requiring special or additional care or attention in handling or stowing must be so
marked and packaged as to ensure safe transportation with ordinary care. See Sec. 2(e) of NMFC Item 360.

Create your next Bill of Lading online at fedex.com/us/freight/main/


<table>
<tr>
<th>DATE</th>
<th>DRIVER/EMPLOYEE NUMBER</th>
<th>PIECE COUNT</th>
<th>TRAILER #</th>
</tr>
<tr>
<td>12-09-25</td>
<td>2606925</td>
<td>15cl</td>
<td>480354</td>
</tr>
</table>


FedEx Freight

CO202/711-FXF

AFFA ULOT

AREA CODE

<!-- PageBreak -->

XALT + Energy"


## SAFETY DATA SHEET

a brand of
FREUDENBERG


<table>
<tr>
<th>1. Identification</th>
<th></th>
</tr>
<tr>
<td>Product identifier</td>
<td>XALTIM LITHIUM ION BATTERY CELL</td>
</tr>
<tr>
<td rowspan="2">Other means of identification Product code</td>
<td></td>
</tr>
<tr>
<td>Part Nos. beginning with F900 and F930.</td>
</tr>
<tr>
<td>Recommended use</td>
<td>Rechargeable type battery</td>
</tr>
<tr>
<td>Recommended restrictions</td>
<td>None known.</td>
</tr>
<tr>
<td colspan="2">Manufacturer/Importer/Supplier/Distributor information</td>
</tr>
<tr>
<td>Company name</td>
<td>XALT Energy, LLC</td>
</tr>
<tr>
<td rowspan="3">Address</td>
<td>2700 S. Saginaw Rd.</td>
</tr>
<tr>
<td>Midland, MI 48640</td>
</tr>
<tr>
<td>US</td>
</tr>
<tr>
<td>Telephone</td>
<td>989-486-8501</td>
</tr>
<tr>
<td>Emergency phone number</td>
<td>+760-476-3962</td>
</tr>
<tr>
<td></td>
<td>Access code: 333477</td>
</tr>
<tr>
<td>2. Hazard(s) identification</td>
<td></td>
</tr>
<tr>
<td>Physical hazards</td>
<td>Not classified.</td>
</tr>
<tr>
<td>Health hazards</td>
<td>Not classified.</td>
</tr>
<tr>
<td>OSHA defined hazards</td>
<td>Not classified.</td>
</tr>
<tr>
<td colspan="2">Note: XALT ™ lithium ion batteries / cells are by definition an article and not subject to the 29 CFR 1910.1200 OSHA requirements, Canadian WHMIS requirements or GHS requirements.</td>
</tr>
<tr>
<td>Label elements</td>
<td></td>
</tr>
<tr>
<td>Hazard symbol</td>
<td>None.</td>
</tr>
<tr>
<td>Signal word</td>
<td>None.</td>
</tr>
<tr>
<td>Hazard statement</td>
<td>The product does not meet the criteria for classification. Under normal conditions of processing and use, exposure to the chemical constituents in this product is unlikely. The battery should not be opened or burned. Exposure to the ingredients contained within or their combustion products could be harmful. In the event of damage resulting in a leak of exposed materials, avoid contact with contents of an open or damaged cell or battery.</td>
</tr>
<tr>
<td>Precautionary statement</td>
<td></td>
</tr>
<tr>
<td>Prevention</td>
<td>Use personal protective equipment as required. Observe good industrial hygiene practices.</td>
</tr>
<tr>
<td>Response</td>
<td>Get medical advice/attention if you feel unwell.</td>
</tr>
<tr>
<td>Storage</td>
<td>Store away from incompatible materials.</td>
</tr>
<tr>
<td>Disposal</td>
<td>Dispose of contents/container in accordance with local/regional/national/international regulations.</td>
</tr>
<tr>
<td rowspan="2">Hazard(s) not otherwise classified (HNOC)</td>
<td>None known.</td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td>Supplemental information</td>
<td>In the event of damage resulting in a leak of exposed materials, avoid contact with contents of an open or damaged cell or battery.</td>
</tr>
</table>


### 3. Composition/information on ingredients

Mixtures


<table>
<tr>
<th>Chemical name</th>
<th>CAS number</th>
<th>%</th>
</tr>
<tr>
<td>Cobalt Lithium Manganese Nickel Oxide</td>
<td>182442-95-1</td>
<td>28 - 40</td>
</tr>
<tr>
<td>Graphite</td>
<td>7782-42-5</td>
<td>15 - 25</td>
</tr>
<tr>
<td>Copper</td>
<td>7440-50-8</td>
<td>10 - 20</td>
</tr>
<tr>
<td>Aluminum</td>
<td>7429-90-5</td>
<td>5 - 10</td>
</tr>
<tr>
<td>Ethyl Methyl Carbonate</td>
<td>623-53-0</td>
<td>5 - 10-</td>
</tr>
</table>


XALT™ LITHIUM ION BATTERY CELL

929282
Version #: 03
Revision date: 12-August-2021

Issue date: 07-October-2015

SDS US

<!-- PageNumber="1 / 8" -->
<!-- PageBreak -->


<table>
<tr>
<th>Chemical name</th>
<th>CAS number</th>
<th>%</th>
</tr>
<tr>
<td>Carbon black</td>
<td>1333-86-4</td>
<td>1 - 5</td>
</tr>
<tr>
<td>Ethylene Carbonate</td>
<td>96-49-1</td>
<td>1 - 5</td>
</tr>
<tr>
<td>Lithium Hexaflurophosphate</td>
<td>21324-40-3:</td>
<td>155</td>
</tr>
<tr>
<td>Polyethene</td>
<td>9002-88-4</td>
<td>1 5</td>
</tr>
<tr>
<td>Polypropylene</td>
<td>9003-07-0</td>
<td>+-5.</td>
</tr>
<tr>
<td>Polyvinylidené Fluoride</td>
<td>24937-79-9</td>
<td>=17-5</td>
</tr>
<tr>
<td>Proprietary Additive*</td>
<td>Proprietary*</td>
<td>&lt; 0.4</td>
</tr>
</table>


<- 6.3

Other components below reportable levels

*Designates that a specific chemical identity and/or percentage of composition has been withheld as a trade secret.
The identities of the materials in this product are withheld as a trade secret (29CFR1910.1210(i)) and are available to a physician or
paramedical personnel in a emergency situation.


<table>
<tr>
<td colspan="2">4. First-aid measures</td>
</tr>
<tr>
<td>Inhalation</td>
<td>If contents of an opened battery are inhaled, remove source of contamination or move victim to" fresh air. Seek medical advice.</td>
</tr>
<tr>
<td>Skin contact</td>
<td>If skin contact with contents of an open battery occurs, immediately flush with lukewarm water for at least 30 minutes. Thoroughly wash (or discard) clothing and shoes before reuse. If skin irritation occurs, get medical advice/attention.</td>
</tr>
<tr>
<td>Eye contact</td>
<td>If eye comes in contact with contents of an open or damaged cell or battery, immediately flush the contaminated eye(s) with lukewarm water for at least 30 minutes. Get medical attention immediately. Rinse eye with calcium gluconate solution (1%) until arrival of doctor. Continue rinsing.</td>
</tr>
<tr>
<td>Ingestion</td>
<td>If ingestion of contents of an open battery occurs, rinse mouth thoroughly with water. DO NOT induce vomiting. If victim is fully conscious, give a cupful of water. Never give anything by mouth to an unconscious person. If vomiting occurs, keep head lower than the hips to help prevent aspiration. Call a physician or poison control center immediately.</td>
</tr>
<tr>
<td>Most important symptoms/effects, acute and delayed</td>
<td>Under normal conditions of intended use, this material does not pose a risk to health.</td>
</tr>
<tr>
<td>Indication of immediate medical attention and special treatment needed</td>
<td>In case of shortness of breath, give oxygen. Keep victim warm. Keep victim under observation. Symptoms may be delayed.</td>
</tr>
<tr>
<td rowspan="2">General information 5. Fire-fighting measures</td>
<td>First aid personnel must be aware of own risk during rescue.</td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td>Suitable extinguishing media</td>
<td>In the event that a fire occurs and a cell or battery is involved, water, carbon dioxide, clean agent, and /or fire blankets suitable for the surrounding materials should be used. Laboratory testing of cells exposed to flame has demonstrated suppression with clean agent type suppression system such as FM200.</td>
</tr>
<tr>
<td>Unsuitable extinguishing media</td>
<td>In the event that a battery is ruptured and the internal components are exposed, DO NOT EXPOSE BATTERY TO WATER. However, if a cell or battery is involved in a fire copious amounts of water can be used to extinguish.</td>
</tr>
<tr>
<td>Specific hazards arising from the chemical</td>
<td>In the event of fire and/or explosion do not breathe fumes. The evolved combustion products may contain carbon oxides, metal oxides, hydrogen fluoride, and should be considered hazardous.</td>
</tr>
<tr>
<td>Special protective equipment and precautions for firefighters</td>
<td>Wear full protective clothing, including helmet, self-contained positive pressure or pressure demand breathing apparatus, protective clothing and face mask. Fight fire from a protected location. Prevent entry into waterways, sewers, basements or confined areas.</td>
</tr>
<tr>
<td>Fire fighting equipment/instructions</td>
<td>Move containers from fire area if you can do so without risk.</td>
</tr>
<tr>
<td>Specific methods</td>
<td>Use standard firefighting procedures and consider the hazards of other involved materials.</td>
</tr>
<tr>
<td>General fire hazards</td>
<td>Under normal use, the battery does not exhibit flammable properties. In the event that the battery is abused and disassembly of the battery occurs resulting in exposure of internal components, the exposed solution, may be flammable and/or corrosive. Exposure to excessive heat may lead to venting or rupture of the sealed battery, exposing the internal components which may be corrosive and/or flammable. Vented gas would be flammable when in sufficient-concentration.</td>
</tr>
<tr>
<td colspan="2">6. Accidental release measures</td>
</tr>
</table>


Personal precautions,
protective equipment and
emergency procedures

None under normal use conditions. In the event of damage resulting in a leak of exposed
materials, avoid contact with contents of an open or damaged cell or battery. Wear protective
clothing as described in Section 8 of this safety data sheet.


<table>
<tr>
<td>XALT™ LITHIUM ION BATTERY CELL</td>
<td>SDS US</td>
</tr>
<tr>
<td>929282 Version #: 03 Revision date: 12-August-2021 Issue date: 07-October-2015</td>
<td>2 / 8</td>
</tr>
</table>


<!-- PageBreak -->


#### Methods and materials for containment and cleaning up


#### Environmental precautions 7. Handling and storage Precautions for safe handling

Conditions for safe storage,
including any incompatibilities

Leak from a damaged or opened battery: Contain spillage with sand or earth. Collect with
absorbent, non-combustible material into suitable containers. For waste disposal, see section 13
of the SDS.

Avoid allowing material from exposed battery to contaminate soil, sanitary sewers, or waterways.

Do not open, disassemble, crush or burn battery. Do not expose battery to extreme heat or fire
Elevated temperatures can result in reduced battery service life. Precautions shall be taken to
prevent electrical short between cell or battery terminals. Precautions shall be taken to prevent
damage which may result in physical damage to the pouch.
Store in a cool, dry place. Keep at room temperature. Keep out of reach of children. In the event
of damage resulting in a leak or exposed materials, water is to be avoided.


<table>
<tr>
<th colspan="2">8. Exposure controls/personal protection</th>
</tr>
<tr>
<th rowspan="2">Occupational exposure limits Biological limit values</th>
<th>No-exposure-limits-noted-for-ingredient(s)</th>
</tr>
<tr>
<td>No biological exposure limits noted for the ingredient(s).</td>
</tr>
<tr>
<td>Exposure guidelines</td>
<td>This product is an article and is not expected to release hazardous chemicals under normal conditions of use.</td>
</tr>
<tr>
<td>Appropriate engineering controls</td>
<td>If user operations generate dust, fumes, or mist, use ventilation to keep exposure to airborne contaminants below the exposure limit.</td>
</tr>
<tr>
<td colspan="2">Individual protection measures, such as personal protective equipment</td>
</tr>
<tr>
<td>Eye/face protection</td>
<td>Not necessary under normal conditions. In the event that cell or battery is damaged, open, or leaking, wear chemical goggles and/or a face shield if handling an open or leaking cell or battery.</td>
</tr>
<tr>
<td>Skin protection Hand protection</td>
<td>Not necessary under normal conditions. In the event that cell or battery is damaged, open, or leaking, wear chemical resistant gloves if handling. Butyl, Trilite, latex gloves are recommended. Do not use Nitrile.</td>
</tr>
<tr>
<td>Other</td>
<td>leaking battery. Not necessary under normal conditions. Wear chemical resistant gloves if handling an open or</td>
</tr>
<tr>
<td>Respiratory protection</td>
<td>Not necessary under normal conditions. In the event that cell or battery is damaged, open, or leaking, respiratory protection should be worn where there is a potential to exceed the exposure limit requirements or guidelines.</td>
</tr>
<tr>
<td>Thermal hazards</td>
<td>Wear appropriate thermal protective clothing, when necessary.</td>
</tr>
<tr>
<td>General hygiene considerations</td>
<td>Do not store food, drink and tobacco near the product. Practice good housekeeping.</td>
</tr>
<tr>
<td colspan="2">9. Physical and chemical properties</td>
</tr>
<tr>
<td>Appearance</td>
<td>Pouch battery.</td>
</tr>
<tr>
<td>Physical state</td>
<td>Solid.</td>
</tr>
<tr>
<td>Form</td>
<td>Solid.</td>
</tr>
<tr>
<td>Color</td>
<td>Silver</td>
</tr>
<tr>
<td>Odor</td>
<td>Odorless.</td>
</tr>
<tr>
<td>Odor threshold</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>pH</td>
<td>Not applicable (The material is non soluble in water).</td>
</tr>
<tr>
<td>Melting point/freezing point</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Initial boiling point and boiling range</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Flash point</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Evaporation rate</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Flammability (solid, gas)</td>
<td>Not available.</td>
</tr>
<tr>
<td colspan="2">Upper/lower flammability or explosive limits</td>
</tr>
<tr>
<td>Explosive limit - lower (%)</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Explosive limit - upper (%)</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Vapor pressure</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Vapor density</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Solubility(ies)</td>
<td></td>
</tr>
<tr>
<td>Solubility (water)</td>
<td>Insolube</td>
</tr>
</table>


SDS US

<!-- PageNumber="3/ 8" -->

XALT™ LITHIUM ION BATTERY CELL
929282 Version #: 03 Revision date: 12-August-2021
Issue date: 07-October-2015

<!-- PageBreak -->


<table>
<tr>
<th rowspan="2">Partition coefficient (n-octanol/water)</th>
<th>Not applicable, product is a mixture.</th>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td>Auto-ignition temperature</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Decomposition temperature</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Viscosity</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Other information</td>
<td></td>
</tr>
<tr>
<td>Density</td>
<td>Not determined.</td>
</tr>
<tr>
<td>Explosive properties</td>
<td>Not explosive.</td>
</tr>
<tr>
<td>Oxidizing properties</td>
<td>Not oxidizing.</td>
</tr>
<tr>
<td>10. Stability and reactivity</td>
<td></td>
</tr>
<tr>
<td>Reactivity</td>
<td>The product is stable and non-reactive under normal conditions of use, storage and transport.</td>
</tr>
<tr>
<td>Chemical stability</td>
<td>Material is stable under normal conditions:</td>
</tr>
<tr>
<td>Possibility of hazardous- reactions</td>
<td>Under-normal conditions of storage and use,-hazardous polymerization-will-net-occur.</td>
</tr>
<tr>
<td>Conditions to avoid</td>
<td>Heat, sparks, flames, elevated temperatures. Physical damage.</td>
</tr>
<tr>
<td>Incompatible materials</td>
<td>None known.</td>
</tr>
<tr>
<td>Hazardous decomposition products</td>
<td>Under normal conditions none known, irritating and/or toxic fumes and gases may be emitted upon decomposition of the product.</td>
</tr>
<tr>
<td colspan="2">11. Toxicological information</td>
</tr>
<tr>
<td colspan="2">Information on likely routes of exposure</td>
</tr>
<tr>
<td>Inhalation</td>
<td>No inhalation hazard under normal conditions.</td>
</tr>
<tr>
<td>Skin contact</td>
<td>Under normal conditions of intended use, this product does not pose a skin hazard. In the event that cell or battery is damaged, open, or leaking - brief contact may cause skin burns with possible symptoms including pain, local redness, and tissue damage.</td>
</tr>
<tr>
<td>Eye contact</td>
<td>Under normal conditions of intended use, this product does not pose an eye hazard. In the event that cell or battery is damaged, open, or leaking - irritation with injury resulting in permanent impairment of vision and chemical burn may occur.</td>
</tr>
<tr>
<td>ingestion</td>
<td>Under normal conditions of intended use, this material does not pose a risk to health.</td>
</tr>
<tr>
<td>Symptoms related to the physical, chemical and toxicological characteristics</td>
<td>Exposure not expected under normal use conditions. In the event that cell or battery is damaged, open, or leaking - inhalation, skin contact, and/or eye contact may be considered for routes of exposure.</td>
</tr>
<tr>
<td colspan="2">Information on toxicological effects</td>
</tr>
<tr>
<td>Acute toxicity</td>
<td>No toxicological impacts are expected under normal use conditions. Risk of irritation occurs only if the cell is mechanically, thermally, or electrically abused to the point of compromising the enclosure. If this occurs, irritation to the skin, eyes and respiratory tract may occur.</td>
</tr>
<tr>
<td>Skin corrosion/irritation</td>
<td>Not classified.</td>
</tr>
<tr>
<td>Serious eye damage/eye</td>
<td>Not classified.</td>
</tr>
<tr>
<td>irritation</td>
<td></td>
</tr>
<tr>
<td>Respiratory or skin sensitization</td>
<td></td>
</tr>
<tr>
<td>ACGIH sensitization</td>
<td></td>
</tr>
<tr>
<td colspan="2">Cobalt and inorganic compounds, as Co Dermal sensitization (CAS 182442-95-1)</td>
</tr>
<tr>
<td></td>
<td>Respiratory sensitization</td>
</tr>
<tr>
<td>Respiratory sensitization</td>
<td>Not a respiratory sensitizer.</td>
</tr>
<tr>
<td>Skin sensitization</td>
<td>Risk of sensitization only occurs if the cell is mechanically, thermally, or electrically abused to the point of compromising the enclosure. If this occurs, battery contains ingredients may cause sensitization.</td>
</tr>
<tr>
<td>Germ cell mutagenicity</td>
<td>No data available to indicate product or any components present at greater than 0.1% are mutagenic or genotoxic.</td>
</tr>
<tr>
<td>Carcinogenicity</td>
<td>Under normal handling and storage conditions, the exposure to carcinogenic components is not expected. Risk of adverse effects occurs only if the cell is mechanically, thermally or electrically abused to the point of compromising the enclosure.</td>
</tr>
<tr>
<td colspan="2">IARC Monographs. Overall Evaluation of Carcinogenicity</td>
</tr>
<tr>
<td colspan="2">Carbon black (CAS 1333-86-4) 2B Possibly carcinogenic to humans.</td>
</tr>
<tr>
<td colspan="2">XALT™ LITHIUM ION BATTERY CELL SDS US 929282 Version #: 03 Revision date: 12-August-2021 Issue date: 07-October-2015 4/ 8</td>
</tr>
</table>


<!-- PageBreak -->

Proprietary Additive (CAS Proprietary)
NTP Report on Carcinogens
Carbon black (CAS 1333-86-4)
Cobalt Lithium Manganese Nickel Oxide
(CAS 182442-95-1)

2A Probably carcinogenic to humans.

Known To Be Human Carcinogen.
Known To Be Human Carcinogen.

Reasonably Anticipated to be a Human Carcinogen
Reasonably Anticipated to be a Human Carcinogen

Proprietary Additive (CAS Proprietary)

OSHA Specifically Regulated Substances (29 CFR 1910.1001-1053)
Not listed.


<table>
<tr>
<td>Reproductive toxicity</td>
<td>This product is not expected to cause reproductive or developmental effects.</td>
</tr>
<tr>
<td>Specific target organ toxicity - single exposure</td>
<td>Not classified.</td>
</tr>
<tr>
<td>Specific target organ toxicity - repeated exposure</td>
<td>Not classified.</td>
</tr>
<tr>
<td>Aspiration hazard.</td>
<td>Not.classified</td>
</tr>
<tr>
<td>Chronic effects</td>
<td>Under normal handling and storage conditions, the exposure to carcinogenic components is not expected. Risk of adverse effects-occurs only if the cell is mechanically, thermally or electrically abused to the point of compromising the enclosure.</td>
</tr>
<tr>
<td>Further information</td>
<td>This product has no known adverse effect on human health.</td>
</tr>
<tr>
<td>12. Ecological information</td>
<td></td>
</tr>
<tr>
<td>Ecotoxicity</td>
<td>No ecological impacts expected under normal use conditions.</td>
</tr>
<tr>
<td>Persistence and degradability</td>
<td>No data is available on the degradability of this product.</td>
</tr>
<tr>
<td>Bioaccumulative potential</td>
<td>No data available.</td>
</tr>
<tr>
<td>Mobility in soil</td>
<td>The product is not mobile in soil.</td>
</tr>
<tr>
<td>Other adverse effects</td>
<td>No data available.</td>
</tr>
<tr>
<td colspan="2">13. Disposal considerations</td>
</tr>
<tr>
<td>Disposal instructions</td>
<td>Do not dispose in fire. Dispose waste and residues in accordance with applicable federal, state, and local regulations.</td>
</tr>
<tr>
<td>Local disposal regulations</td>
<td>Dispose in accordance with all applicable regulations.</td>
</tr>
<tr>
<td>Hazardous waste code</td>
<td>Hazardous waste code should be determined in accordance with hazardous waste regulatory authorities.</td>
</tr>
<tr>
<td>Waste from residues / unused products</td>
<td>Dispose in accordance with all local, state and federal regulations.</td>
</tr>
<tr>
<td>Contaminated packaging</td>
<td>Since emptied containers may retain product residue, follow label warnings even after container is emptied. Empty containers should be taken to an approved waste handling site for recycling or disposal.</td>
</tr>
<tr>
<td rowspan="2">14. Transport information DOT</td>
<td></td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td>UN number</td>
<td>UN3480</td>
</tr>
<tr>
<td>UN proper shipping name Transport hazard class(es)</td>
<td>Lithium ion batteries including lithium ion polymer batteries</td>
</tr>
<tr>
<td>Class Subsidiary risk Label(s)</td>
<td>9 - 9</td>
</tr>
<tr>
<td>Packing group</td>
<td>II</td>
</tr>
<tr>
<td rowspan="2">Special precautions for user Packaging exceptions</td>
<td>Read safety instructions, SDS and emergency procedures before handling ..</td>
</tr>
<tr>
<td>185</td>
</tr>
<tr>
<td>Packaging non bulk</td>
<td>185</td>
</tr>
<tr>
<td>Packaging bulk</td>
<td>185</td>
</tr>
<tr>
<td>IATA</td>
<td></td>
</tr>
<tr>
<td>UN number</td>
<td>UN3480</td>
</tr>
<tr>
<td rowspan="3">UN proper shipping name Transport hazard class(es) Class Subsidiary risk</td>
<td>Lithium ion batteries (including lithium polymer batteries)</td>
</tr>
<tr>
<td>9</td>
</tr>
<tr>
<td>-</td>
</tr>
<tr>
<td>XALT™ LITHIUM ION BATTERY CELL</td>
<td>SDS US 5/8</td>
</tr>
</table>


<!-- PageFooter="929282 Version #: 03 Revision date: 12-August-2021 Issue date: 07-October-2015" -->
<!-- PageBreak -->

Packing group
II

Environmental hazards
No.

ERG Code

9FZ

Special precautions for user Read safety instructions, SDS and emergency procedures before handling
IMDG
UN number:
UN3480

UN proper shipping name

LITHIUM ION BATTERIES (including lithium ion polymer batteries)

Transport hazard class(es)

Class

9

Subsidiary risk

\-

Packing group
HI

Environmental hazards

Marine pollutant

No.

EmS

Special precautions for user
Transport in bulk according to
Annex Il of MARPOL 73/78 and

F-A,-S-I-
Read safety instructions, SDS and emergency procedures before handling.
Not applicable.

the IBC Code

General information

The dangerous goods regulations require that each cell and battery design be subject to tests
contained in Part III, subsection 38.3 of the UN Manual of Tests and Criteria prior to being offered
for transport. Batteries containing these cells should be transported as Class 9 hazardous
materials, except for those battery types declared to be exempt.


### 15. Regulatory information

US federal regulations

This product is an article pursuant to 29 CFR 1910.1200 and, as such, is not subject to the OSHA
Hazard Communication Standard.

TSCA Section 12(b) Export Notification (40 CFR 707, Subpt. D)

Cobalt Lithium Manganese Nickel Oxide
(CAS 182442-95-1)

0.1 % One-Time Export Notification only.

CERCLA Hazardous Substance List (40 CFR 302.4)

Copper (CAS 7440-50-8)
Listed.
Proprietary Additive (CAS Proprietary)
Listed.
SARA 304 Emergency release notification

Not regulated.
OSHA Specifically Regulated Substances (29 CFR 1910.1001-1053)

Not listed.

Toxic-Substances Control Act (TSCA)
All components are listed on or exempt from the U.S. EPA TSCA Inventory
List.

Superfund Amendments and Reauthorization Act of 1986 (SARA)

SARA 302 Extremely hazardous substance
Not listed.

SARA 311/312 Hazardous
No
chemical


<table>
<tr>
<th>SARA 313 (TRI reporting) Chemical name</th>
<th>CAS number</th>
<th>% by wt.</th>
</tr>
<tr>
<td>Aluminum</td>
<td>7429-90-5</td>
<td>5 - 10</td>
</tr>
<tr>
<td>Copper</td>
<td>7440-50-8</td>
<td>10 - 20</td>
</tr>
<tr>
<td>Proprietary Additive</td>
<td>Proprietary</td>
<td>&lt; 0.4</td>
</tr>
</table>


Other federal regulations

Clean Air Act (CAA) Section 112 Hazardous Air Pollutants (HAPs) List
Proprietary Additive (CAS Proprietary)

Clean Air Act (CAA) Section 112(r) Accidental Release Prevention (40 CFR 68.130)
Not regulated.
Safe Drinking Water Act
Not regulated.
(SDWA)


<table>
<tr>
<td>XALT™ LITHIUM ION BATTERY CELL</td>
<td>SDS US</td>
</tr>
<tr>
<td>929282 Version #: 03 Revision date: 12-August-2021 Issue date: 07-October-2015</td>
<td>6 / 8</td>
</tr>
</table>


<!-- PageBreak -->

US state regulations

US. Massachusetts RTK - Substance List

Aluminum (CAS 7429-90-5)
Carbon black (CAS:1333-86-4)

Copper (CAS 7440-50-8)

Ethylene Carbonate (CAS 96-49-1)
Graphite (CAS 7782-42-5).
Proprietary Additive (CAS Proprietary)

US. New Jersey Worker and Community Right-to-Know Act
Aluminum (CAS 7429-90-5)
Carbon black (CAS 1333-86-4)
Copper (CAS 7440-50-8)
Graphite (CAS 7782-42-5)

Proprietary Additive (CAS Proprietary)


#### US. Pennsylvania Worker and Community Right-to-Know Law

Aluminum (CAS7429-90-5)

Carbon black (CAS 1333-86-4)
Cobalt Lithium Manganese Nickel Oxide (CAS 182442-95-1)

Copper (CAS 7440-50-8)
Ethylene Carbonate (CAS 96-49-1)
Graphite (CAS 7782-42-5)

Proprietary Additive (CAS Proprietary)

US. Rhode Island RTK

Aluminum (CAS 7429-90-5)

Carbon black (CAS 1333-86-4)
Copper (CAS 7440-50-8)
Graphite (CAS 7782-42-5)

Proprietary Additive (CAS Proprietary)

California Proposition 65
WARNING: WARNING: This product contains a chemical known to the State of California to cause cancer. For
more information go to www.P65Warnings.ca.gov.

!


<table>
<tr>
<td colspan="2">California Proposition 65 - CRT: Listed date/Carcinogenic substance</td>
</tr>
<tr>
<td>Carbon black (CAS 1333-86-4)</td>
<td>Listed: February 21, 2003</td>
</tr>
<tr>
<td>Cobalt Lithium Manganese Nickel Oxide</td>
<td>Listed: May 7, 2004</td>
</tr>
<tr>
<td>(CAS 182442-95-1)</td>
<td></td>
</tr>
<tr>
<td>Proprietary Additive (CAS Proprietary)</td>
<td>Listed: January 1, 1988</td>
</tr>
</table>


US. California. Candidate Chemicals List. Safer Consumer Products Regulations (Cal. Code Regs, tit. 22, 69502.3,
subd. (a))

Aluminum (CAS 7429-90-5)

Carbon black (CAS 1333-86-4)
Cobalt Lithium Manganese Nickel Oxide (CAS 182442-95-1)

Copper (CAS 7440-50-8)
Proprietary Additive (CAS Proprietary)


##### International Inventories


<table>
<tr>
<th>Country(s) or region</th>
<th>Inventory name</th>
<th>On inventory (yes/no)*</th>
</tr>
<tr>
<td>Australia</td>
<td>Australian Inventory of Industrial Chemicals (AICIS)</td>
<td>No</td>
</tr>
<tr>
<td>Canada</td>
<td>Domestic Substances List (DSL)</td>
<td>No</td>
</tr>
<tr>
<td>Canada</td>
<td>Non-Domestic Substances List (NDSL)</td>
<td>No</td>
</tr>
<tr>
<td>China</td>
<td>Inventory of Existing Chemical Substances in China (IECSC)</td>
<td>No</td>
</tr>
<tr>
<td>Europe</td>
<td>European Inventory of Existing Commercial Chemical Substances (EINECS)</td>
<td>No</td>
</tr>
<tr>
<td>Europe</td>
<td>European List of Notified Chemical Substances (ELINCS)</td>
<td>No</td>
</tr>
<tr>
<td>Japan</td>
<td>Inventory of Existing and New Chemical Substances (ENCS)</td>
<td>No</td>
</tr>
<tr>
<td>Korea</td>
<td>Existing Chemicals List (ECL)</td>
<td>Yes</td>
</tr>
<tr>
<td>New Zealand</td>
<td>New Zealand Inventory</td>
<td>No</td>
</tr>
<tr>
<td>Philippines</td>
<td>Philippine Inventory of Chemicals and Chemical Substances (PICCS)</td>
<td>No</td>
</tr>
<tr>
<td>Taiwan</td>
<td>Taiwan Chemical Substance Inventory (TCSI)</td>
<td>Yes</td>
</tr>
</table>


<table>
<tr>
<th>XALT™ LITHIUM ION BATTERY CELL</th>
<th>SDS US</th>
</tr>
<tr>
<td>929282 Version #: 03 Revision date: 12-August-2021 Issue date: 07-October-2015</td>
<td>7 / 8</td>
</tr>
</table>


<!-- PageBreak -->

Country(s) or region

United States & Puerto Rico

Inventory name

On inventory (yes/no)*

Yes

Toxic Substances Control Act (TSCA) Inventory

*A"Yes" indicates that all components of this product comply with the inventory requirements administered by the governing country(s).
A."No" indicates that one or more components of the product are not listed or exempt from listing on the inventory administered by the governing
country(s)

16\. Other information, including date of preparation or last revision


<table>
<tr>
<td>Issue date</td>
<td>07-October-2015</td>
</tr>
<tr>
<td>Revision date</td>
<td>12-August-2021</td>
</tr>
<tr>
<td>Version #</td>
<td>03</td>
</tr>
<tr>
<td>Further information</td>
<td>HMIS® is a registered trade and service mark of the NPCA.</td>
</tr>
<tr>
<td>HMIS® ratings</td>
<td>Health: 1</td>
</tr>
</table>


Flammability:

Physical hazard: 0

Personal protection: E

NFPA ratings


<figure>

1

0

0

</figure>


Disclaimer

XALT Energy, LLC cannot anticipate all conditions under which this information and its product, or
the products of other manufacturers in combination with its product, may be used. It is the user's
responsibility to ensure safe conditions for handling, storage and disposal of the product, and to
assume liability for loss, injury, damage or expense due to improper use. The information in the
sheet was written based on the best knowledge and experience currently available.


<table>
<tr>
<td>XALT™ LITHIUM ION BATTERY CELL</td>
<td>SDS US</td>
</tr>
<tr>
<td>929282 Version #: 03 Revision date: 12-August-2021 Issue date: 07-October-2015</td>
<td>8 / 8</td>
</tr>
</table>


<!-- PageBreak -->


<figure>

FedEx
0

Freight

</figure>


2200 FORWARD DRIVE
HARRISON, AR 72601

fedex.com 1 866 393.4585

DELIVERY RECEIPT

<!-- PageNumber="Page 1 of 1" -->

Freight Bill 7414532952 R0


<table>
<tr>
<td>Ship Date 12/09/2025</td>
<td>Bill of Lading</td>
</tr>
<tr>
<td>PO</td>
<td>Shipper Reference</td>
</tr>
<tr>
<td>Origin ANB</td>
<td>Destination SPO</td>
</tr>
</table>


Trailer # 661853

Consignee

SPOKANE TRANSIT AUTH

1229 WEST BOONE

SPOKANE

WA 99201

US

Shipper

NEW FLYER OF AMERICA

106 NATIONAL DR

ANNISTON REGION

ANNISTON

AL 36207

US

FedEx Freight Priority


<table>
<tr>
<th>PIECES</th>
<th>PKG</th>
<th>HJU</th>
<th>HM</th>
<th>DESCRIPTION</th>
<th></th>
<th>WTILBS)</th>
<th>NMFC</th>
<th>PCF</th>
<th>CLASS</th>
<th>RATE</th>
<th>TOTAL CHARGES</th>
</tr>
<tr>
<td>1</td>
<td>BOX</td>
<td></td>
<td>X ☒</td>
<td rowspan="2">UN3480, LITHIUM ION BATTERIES, 9, EMERGENCY CONTACT 12566768020 ERI PROVIDER: NEW FLYER OF AMERICA</td>
<td rowspan="2"></td>
<td>270</td>
<td>060680-01</td>
<td></td>
<td>070</td>
<td>680 060</td>
<td>1836 16</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>005800 HAZARDOUS MATERIAL CHARGE</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>58 00</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>012840FUEL SURCHG LTL SHPT 33.30%</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>128.40</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>790 LESS DISCOUNT 1283377089-104-01-3 * FXF PZONE01/06/25 LC 11142</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>0.790</td>
<td>- 1450.57</td>
</tr>
<tr>
<td></td>
<td>. BY</td>
<td>ACCEPTING</td>
<td>THE</td>
<td>SHIPMENT YOU AGREE TO BE FULLY RESPONSIBLE FOR ANY ADDITIONAL</td>
<td>APPLICABLE</td>
<td>CHARGES FOR</td>
<td>DELIVERY SERVICES</td>
<td></td>
<td>RENDERED</td>
<td>INCLUDING BUT NOT</td>
<td>LIMITED TO DETENTION</td>
</tr>
<tr>
<td>1</td>
<td></td>
<td>1</td>
<td></td>
<td>COLLECT - WILL INVOICE CONSIGNEE</td>
<td></td>
<td>270</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<table>
<tr>
<th colspan="4">ACCESSORIAL SERVICES PERFORMED.</th>
</tr>
<tr>
<th></th>
<th>☐ INSIDE DELIVERY</th>
<th>☐ SORT &amp; SEGREGATE</th>
<th>☐ DETENTION</th>
</tr>
<tr>
<td></td>
<td>☐ RESIDENTIA! - LIMITED ACCESS</td>
<td>☐ LIFT GATE</td>
<td>☐ OTHERS</td>
</tr>
</table>


COLLECT - WILL INVOICE
RESPONSIBLE PARTY
DRIVER COL REL AUTH #52T329


<table>
<tr>
<th colspan="4">Delv. Driver &amp; # 5897941</th>
</tr>
<tr>
<th>Date:</th>
<th>12-15-25</th>
<th>Arrive 919</th>
<th>Depart 924</th>
</tr>
<tr>
<td colspan="2"># of Skids</td>
<td># of Pcs</td>
<td>OS&amp;D #</td>
</tr>
</table>


Shipment received in apparent good order with-wrap-intact unless otherwise noted

-1928 +. Horsington

Received by'
☐
Over
☐
Damage
☐
Short
☐
Wrap Broken

9 Exceptions

Customer Requirements/Appointment Instruction

DRIVER COPY

<!-- PageBreak -->

EBDA


<figure>

FedEx®
®
Freight

</figure>


## ORIGINAL INVOICE FXFE PRIORITY

Send payment to: DEPT CH PO BOX 10306 PALATINE IL 60055-0306
Direct Billing Inquiries to 2200 Forward Dr Harrison AR 72602-0840
EMAIL customersolutions@fedex.com WEBSITE www.fedex.com
PHONE 870.741.9000 FAX 870.365.4354 TOLL-FREE 866.393.4585

Shipper

NEW FLYER OF AMERICA

ANNISTON REGION

106 NATIONAL DR

ANNISTON AL 36207

Consignee

PIONEER VALLEY TRANSIT AUTHORITY

665 COTTAGE STREET

SPRINGFIELD MA 01105

<!-- PageNumber="PAGE 1OF 2" -->


<table>
<tr>
<td>Freight Bill Number</td>
<td>7414531165</td>
</tr>
<tr>
<td>Ship Date/Invoice Date</td>
<td>01/14/2026 / 01/27/2026</td>
</tr>
<tr>
<td>Bill of Lading Number</td>
<td></td>
</tr>
<tr>
<td>P.O. Number</td>
<td></td>
</tr>
<tr>
<td>Shipper Reference Number</td>
<td></td>
</tr>
<tr>
<td>I/L PRO Number</td>
<td></td>
</tr>
<tr>
<td>Terms</td>
<td>COLLECT</td>
</tr>
<tr>
<td>Origin /Destination</td>
<td>ANB /HFD</td>
</tr>
<tr>
<td>Total Amount Due</td>
<td>717.58</td>
</tr>
<tr>
<td>Payment Due Date</td>
<td>02/11/2026</td>
</tr>
</table>


Bill To / Payment Due From

NEW FLYER % INTELLIGENT AUDIT

Ste 455

365 W PASSAIC ST STE 455

ROCHELLE PARK NJ 07662-3005

Account# 934710835


<table>
<tr>
<th>PIECES</th>
<th>PALLETS</th>
<th>HM</th>
<th>DESCRIPTION</th>
<th>WT(LBS)</th>
<th>NMFC</th>
<th>CLASS</th>
<th>RATE</th>
<th>TOTAL CHARGES</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>20143585 SO#</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>11</td>
<td></td>
<td>X ☒</td>
<td>NO PKG, SKID, UN 3480,LITHIUM ION BATTERIES,9, EMERGENCY CONTACT 12566768020 ERI PROVIDER: JERRY DEMPSEY</td>
<td>2,140</td>
<td>060680-01</td>
<td>070</td>
<td>214.150</td>
<td>4,582.81</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>*FXF PZONE01/05/26 PLS 11124 0005000 CORRECTION FEE COLLECT</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>50.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>CHANGE PER CUSTOMER LETTER OF</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>004500 DEMAND SURCHARGE TIER 2</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>45.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>013033 FUEL SURCHG LTL SHPT 31.60%</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>130.33</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>006100 HAZARDOUS MATERIAL CHARGE</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>61.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>910 LESS DISCOUNT</td>
<td></td>
<td></td>
<td></td>
<td>.910</td>
<td>4,170.36-</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>NONMFC ON BOL</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2"></td>
<td></td>
<td></td>
<td>000084155 ORIGINAL REVENUE</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>002900 ORIGINAL WEIGHT 548055335-102-0-425 ** SHIPMENT REWEIGHED AS ABOVE ** ANB INSPECTING TERMINAL</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2"></td>
<td></td>
<td></td>
<td>0001880 WEIGHT VALIDATION FEE 01 ZONE NUMBER 01 ZONE NUMBER</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>18.80</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Continued on next page **</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


Rate Tariff : 548055335-102-0

FedEx®
®®
Freight

Remittance Advice
PLEASE RETURN THIS PORTION WITH YOUR PAYMENT
Payment Due From Account # 934710835

Send to: DEPT CH PO BOX 10306
PALATINE IL 60055-0306
☐
Address change? Please check the appropriate box and fill out the information
on the reverse side of this form.

FXF

#BWNFZGZ

NEW FLYER % INTELLIGENT AUDIT

Ste 455

365 W PASSAIC ST STE 455

ROCHELLE PARK NJ 07662-3005


<table>
<tr>
<td></td>
<td>FREIGHT BILL NUMBER 7414531165</td>
</tr>
<tr>
<td colspan="2">SHIP DATE/INVOICE DATE 01/14/2026 / 01/27/2026</td>
</tr>
<tr>
<td colspan="2">TERMS COLLECT</td>
</tr>
<tr>
<td colspan="2">PAYMENT DUE DATE 02/11/2026</td>
</tr>
<tr>
<td colspan="2">PLEASE PAY THIS AMOUNT 717.58</td>
</tr>
</table>


Thank You!

7414531165 000000071758 01272026 5

<!-- PageBreak -->

EBDA


<figure>

FedEx®
®
Freight

</figure>


## ORIGINAL INVOICE FXFE PRIORITY

Send payment to: DEPT CH PO BOX 10306 PALATINE IL 60055-0306
Direct Billing Inquiries to 2200 Forward Dr Harrison AR 72602-0840
EMAIL customersolutions@fedex.com WEBSITE www.fedex.com
PHONE 870.741.9000 FAX 870.365.4354 TOLL-FREE 866.393.4585

Shipper

NEW FLYER OF AMERICA

ANNISTON REGION

106 NATIONAL DR

ANNISTON AL 36207

Consignee

PIONEER VALLEY TRANSIT AUTHORITY

665 COTTAGE STREET

SPRINGFIELD MA 01105

<!-- PageNumber="PAGE 2OF 2" -->


<table>
<tr>
<td>Freight Bill Number</td>
<td>7414531165</td>
</tr>
<tr>
<td>Ship Date/Invoice Date</td>
<td>01/14/2026 / 01/27/2026</td>
</tr>
<tr>
<td>Bill of Lading Number</td>
<td></td>
</tr>
<tr>
<td>P.O. Number</td>
<td></td>
</tr>
<tr>
<td>Shipper Reference Number</td>
<td></td>
</tr>
<tr>
<td>I/L PRO Number</td>
<td></td>
</tr>
<tr>
<td>Terms</td>
<td>COLLECT</td>
</tr>
<tr>
<td>Origin /Destination</td>
<td>ANB /HFD</td>
</tr>
<tr>
<td>Total Amount Due</td>
<td>717.58</td>
</tr>
<tr>
<td>Payment Due Date</td>
<td>02/11/2026</td>
</tr>
</table>


Bill To / Payment Due From

NEW FLYER % INTELLIGENT AUDIT

Ste 455

365 W PASSAIC ST STE 455

ROCHELLE PARK NJ 07662-3005

Account# 934710835


<table>
<tr>
<th>PIECES</th>
<th>PALLETS</th>
<th>HM</th>
<th>DESCRIPTION</th>
<th>WT(LBS)</th>
<th>NMFC</th>
<th>CLASS</th>
<th>RATE</th>
<th>TOTAL CHARGES</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Invoicing Summary Original Invoice Amount Less Amount Paid Less Freight Bill Adjustments</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>717.58</td>
</tr>
<tr>
<td>11</td>
<td></td>
<td></td>
<td>Totals / Amount Due by (02/11/2026)</td>
<td>2,140</td>
<td></td>
<td></td>
<td></td>
<td>717.58</td>
</tr>
</table>


Rate Tariff : 548055335-102-0


<figure>

FedEx ®
Freight

</figure>


Remittance Advice
PLEASE RETURN THIS PORTION WITH YOUR PAYMENT
Payment Due From Account # 934710835

Send to: DEPT CH PO BOX 10306
PALATINE IL 60055-0306
☐
Address change? Please check the appropriate box and fill out the information
on the reverse side of this form.

FXF

#BWNFZGZ

NEW FLYER % INTELLIGENT AUDIT

Ste 455

365 W PASSAIC ST STE 455

ROCHELLE PARK NJ 07662-3005


<table>
<tr>
<th></th>
<th>FREIGHT BILL NUMBER 7414531165</th>
</tr>
<tr>
<th></th>
<th>SHIP DATE/INVOICE DATE 01/14/2026 / 01/27/2026</th>
</tr>
<tr>
<td colspan="2">TERMS COLLECT</td>
</tr>
<tr>
<td colspan="2">PAYMENT DUE DATE 02/11/2026</td>
</tr>
<tr>
<td colspan="2">PLEASE PAY THE AMOUNT SHOWN ON PAGE 1</td>
</tr>
</table>


Thank You!

7414531165 000000071758 01272026 5

<!-- PageBreak -->


<figure>

FedEx
irog11

</figure>


863.393.4585


## WEIGHT VALIDATION CERTIFICATE Freight Bill Number: 7414531165

RO


<table>
<tr>
<th>Date</th>
<th>Location</th>
<th>Billed Weight</th>
<th>Ship Date</th>
<th>Origin</th>
<th>Dest</th>
</tr>
<tr>
<td>2026-01-15</td>
<td>ANB</td>
<td>2900 lbs</td>
<td>2026-01-14</td>
<td>ANB</td>
<td>HFD</td>
</tr>
</table>


CONSIGNEE

PIONEER VALLEY TRANSIT

AUTHORI

SHIPPER

NEW FLYER OF AMERICA

ANNISTON REGION

106 NATIONAL DR

ANNISTON

AL

36207

665 COTTAGE ST
SPRINGFIELD
MA
01104


<table>
<tr>
<th>Description</th>
<th>Scale</th>
<th>Operator</th>
<th>Weight</th>
</tr>
<tr>
<td>1 HANDLING UNIT(S)</td>
<td>FORKLIFT #FL15028</td>
<td>6512702</td>
<td>2140 lbs</td>
</tr>
<tr>
<td></td>
<td></td>
<td>TOTAL ACTUAL VERIFIED WEIGHT</td>
<td>2140 lbs</td>
</tr>
</table>


Verification of the actual weight of this shipment was
accomplished in accordance with FedEx Freight Rules
Tariff.


<table>
<tr>
<td>Total Billed Weight:</td>
<td>2900 lbs</td>
</tr>
<tr>
<td>Total Actual Verified Weight:</td>
<td>2140 lbs</td>
</tr>
<tr>
<td>Weight Difference:</td>
<td>-760 lbs</td>
</tr>
</table>


<!-- PageBreak -->

7
៛


## UNIFORM STRAIGHT BILL OF LADING ORIGINAL --- NOT NEGOTIABLE SUBJECT TO THE TERMS AND CONDITIONS OF THE UNIFORM BILL OF LADING --- QUESTIONS? CALL 1.866.393.4585

FedEx®

741453116-5
Freight


<table>
<tr>
<td>Date 1/14/2026</td>
<td>Purchase Order #</td>
</tr>
<tr>
<td>Shipper #</td>
<td>Shipper # SO20143585</td>
</tr>
<tr>
<td>REQUIRED: Please select a service type ☒ FedEx Freight® ☐ FedEx Freight® Priority Economy</td>
<td>OPTIONAL: You may select a money-back guarantee delivery (charges and tariff limitations may apply). ☐ A.M. Delivery ☐ Close of Business Delivery</td>
</tr>
</table>


<table>
<tr>
<th></th>
<th>SHIPPER (from)</th>
<th colspan="4">Please provide ZIP codes and phone numbers.</th>
<th colspan="3">CONSIGNEE (to)</th>
</tr>
<tr>
<td colspan="2">Shipper Maria Aguilar</td>
<td>FXF Acct. #</td>
<td>6747-96269</td>
<td>Consignee</td>
<td colspan="2">PIONEER VALLEY TRANSIT</td>
<td colspan="2">FXF Acct. #</td>
</tr>
<tr>
<td colspan="2">Attn, 10 New Flyer</td>
<td>Area Code 256</td>
<td>Phone Number 241-1213</td>
<td colspan="3">Attn. to DON BESAW ☐</td>
<td>Area Code 204</td>
<td>Phone Number 224-6714</td>
</tr>
<tr>
<td>Address</td>
<td></td>
<td></td>
<td></td>
<td>Address</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
</table>


106 National Drive

Address (Store, Dept., Ste., Flr., Apt., Div.}

Address (Store, Dept., Ste., Fir., Apt., Div.)

Address

Address
665 COTTAGE STREET

City

Anniston

City

SPRINGFIELD


<table>
<tr>
<th>State/Province AL</th>
<th>ZIP/Postal Code 36207</th>
<th>Country</th>
<th>State/Province MA</th>
<th>ZIP/Postal Code 01104</th>
<th>Country US</th>
</tr>
<tr>
<td colspan="2">Accessorial Charges ☐ Liftgate ☐ Inside Pickup ☐ Limited Access</td>
<td></td>
<td colspan="3">Accessorial Charges ☐ Liftgate ☐ Inside Delivery ☐ Limited Access</td>
</tr>
<tr>
<td>Shipper Bill of Lading #</td>
<td></td>
<td></td>
<td>☐ Custom Delivery Window:</td>
<td></td>
<td></td>
</tr>
</table>


Special Instructions

BILL FREIGHT CHARGES TO (if different than above):

Name

FXF Acct. #

326471207

Mailing Address

City

State

ZIP/Postal Code

Country

Area Code

Phone Number


<table>
<tr>
<th rowspan="2">Freight charges are PREPAID unless marked collect.</th>
<th rowspan="2">☐ USD CAD</th>
<th>C.O.D.</th>
<th>1.</th>
<th>The letters "C.O.D." must appear in box before consignee's name above.</th>
</tr>
<tr>
<td></td>
<td>2.</td>
<td>C.O.D. funds to be collected as: ☐ Certified Funds ☐ Company Check ☐ Personal Check</td>
</tr>
<tr>
<td>CHECK BOX IF COLLECT ☒</td>
<td>☐</td>
<td>AMOUNT</td>
<td>3.</td>
<td>C.O.D. fee to be paid by: ☐ Shipper ☐ Consignee</td>
</tr>
</table>


REMIT C.O.D. TO (if different than shipper above):


<table>
<tr>
<th colspan="2">Name</th>
<th colspan="5">Mailing Address</th>
</tr>
<tr>
<th>City</th>
<th>State</th>
<th>ZIP/Postal Code</th>
<th>Country</th>
<th>Country Code</th>
<th>Area Code</th>
<th>Phone Number</th>
</tr>
</table>


RECEIVED. s. ihect to :nd. / dually determine diate, orcontracts that have been agreed upon an whiting between the carrier ard shipper, if applicable, otherwise to therate., classifications cod rules that have been established by the carrier and are available to the shopper, onrequest, and to all applicable state and federal regulations.
thepropertydescribedbelow, hopperent goodorder. exceptas nutedicontents and conditionof content. of par,kages unknown}marked, cons:gned and dastired as chown hereon, which sa'd carrier agrees tucarry lu dest natinn, iten its route, or otherwise to deliver tu anather carrier on the route tu dastination, Every service tohe
pertonnedieteurdie ;hallbart;2stto c]:te cere.tienano:prohibited by law, whether printed or written, hereincontained, including the cend'tons on the back hareof, and thecond tions of the FAF 100 Series Bulas Tariff, or otherwise referenced, whichare hereby agreed to by the shipper and accepted for himself endt:, osalgr .:


<table>
<tr>
<th rowspan="2">HANDUNG UNITS (H/U)</th>
<th rowspan="2">H/U PKG. TYPE</th>
<th rowspan="2">PIECES</th>
<th rowspan="2">HM (X)</th>
<th rowspan="2">DESCRIPTION OF ARTICLES, KIND OF PACKAGE, SPECIAL MARKS AND EXCEPTIONS {subject to correction)</th>
<th>WEIGHT IN LBS.</th>
<th>NMFC ITEM #</th>
<th>CLASS</th>
<th>CUBE</th>
</tr>
<tr>
<th></th>
<th>(subject to correction)</th>
<th></th>
<th></th>
</tr>
<tr>
<td>1</td>
<td>Plt</td>
<td>11</td>
<td>☒</td>
<td>UN 3480 LITHIUM ION BATTERIES CLASS 9</td>
<td>2900</td>
<td></td>
<td>9</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>EMERGENCY 24HRS PHONE-#760-476-362</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>ACCESS CODE:333477</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


TOTAL H/U:

\* MARK "X" OR "RQ" IN THE HM COLUMN TO DESIGNATE HAZARDOUS MATERIALS OR REPORTABLE QUANTITY AS DEFINED IN DOT REGULATIONS.

HM EMERGENCY CONTACT PHONE NUMBER (_ 256 | 676-8020

HM EMERGENCY RESPONSE PROVIDER PERSON or CONTRACT #
Jerry Dempsey

EEI/SED Number or Exception

Broker Name

Phone #

AREA CODE

1

Fax #

FOR FREIGHT COLLECT SHIPMENTS

Subject to Section 7 of conditions of applicable Bill of Lading. if this shipment is to be delivered to the consignee,
without recourse on the consignor, the consignor shall sign the following statement. The carrier may decline to
make delivery of this shipment without payment of freight and all other lawful charges.

Consignor Signature

SHIPPER CERTIFICATION

This is to certify that the above named materials are properly classified, described, packaged, marked and labeled, and
are in proper condition for transportation According to the applicable regulations of the Departmentof Transportation.
Shipper Signature
Maria Regular

Date
1/14/2026

CARRIER CERTIFICATION

Carrier acknowledges receipt of packages and required placards. Carrier certifies emergency response information
was made available and/or carrier has the DOT emergency response guidebook or equivalent document in the vehicle.

☐
USD
☐
CAD
☐

☐
g. Additional charges will apply.
MXN per
☐
1b. Of
g
☐
Articles are USED or RECONDITIONED andrequire Excess Liability Coverage. Additional charges will apply.

NOTE (3) Commodities requiring special or additional care or attention in handling or stowing must be so
marked and packaged as to ensure safe transportation with ordinary care. See Sec. 2(e) of NMFC Item 360.


<table>
<tr>
<th>DATE</th>
<th>DRIVER/EMPLOYEE NUMBER</th>
<th>PIECE COUNT</th>
<th>TRAILER #</th>
</tr>
<tr>
<td>1-1725</td>
<td>118471)</td>
<td>104</td>
<td>480511</td>
</tr>
</table>


Create your next Bill of Lading online at fedex.com/us/freight/main/

FedEx Freight

C0202/711-FXF

NOTE (1) Where the rate and carrier's liability for loss or damage may be dependent on value, shippers
must state specifically in writing the agreed or declared value of the property as follows: "The agreed
or declared value of the property is specifically stated by the shipper to be not exceeding.
per

Note (2) liability limitation for loss or damage on this shipment shall be applicable as provided by
contract or in the current NMFC or this carrier's governing tariffs. See FXF 100 Series Rules Tariff
for complete limited liability provisions. Carrier's maximum standard liability is limited to $25 per pound
per package for NEW articles and $.50 per pound per package for its equivalent in Mexican Pesos (MXN)
or Canadian Dollars (CAD), at the rate of exchange which is in effect at the place and on the date of
shipment) for USED or RECONDITIONED articles. Inno case shall carrier liability exceed $100,000 per occurrence
(or its equivalent in MXN or CAD at the rate of exchange which is in effect at the place and on the date
of shipment) for NEW articles or $10,000 per occurrence (or its equivalent in MXN or CAD at the rate of
exchange which is in offect at the place and on the date of shipment) for USED or RECONDITIONED articles.
For availability and limits of excess liability coverage and applicable rates and charges, please refer to FXF 100
Series Rules Tariff, Not selecting an additional coverage option is considered to be a waiver of same and standard
liability coverage will apply.
☐
Articles are NEW, and require Excess Liability Coverage in the amount of

AREA CODE

<!-- PageBreak -->


## SAFETY DATA SHEET

<!-- PageHeader="a brand of FREUDENBERG" -->

XALT- Energy®


### 1. Identification


<table>
<tr>
<td>Product identifier</td>
<td>XALT™ LITHIUM ION BATTERY CELL</td>
</tr>
<tr>
<td>Other means of identification</td>
<td></td>
</tr>
<tr>
<td>Product code</td>
<td>Part Nos. beginning with F900 and F930.</td>
</tr>
<tr>
<td>Recommended use</td>
<td>Rechargeable type battery</td>
</tr>
<tr>
<td>Recommended restrictions</td>
<td>None known.</td>
</tr>
<tr>
<td colspan="2">Manufacturer/Importer/Supplier/Distributor information</td>
</tr>
<tr>
<td>Company name</td>
<td>XALT Energy, LLC</td>
</tr>
<tr>
<td rowspan="3">Address</td>
<td>2700 S. Saginaw Rd.</td>
</tr>
<tr>
<td>Midland, MI 48640</td>
</tr>
<tr>
<td>US</td>
</tr>
<tr>
<td>Telephone</td>
<td>989-486-8501</td>
</tr>
<tr>
<td>Emergency phone number</td>
<td>+760-476-3962</td>
</tr>
<tr>
<td></td>
<td>Access code: 333477</td>
</tr>
</table>


### 2. Hazard(s) identification

Physical hazards

Not classified.

Health hazards

Not classified.

OSHA defined hazards

Not classified.

Note: XALT ™ lithium ion batteries / cells are by definition an article and not subject to the 29 CFR 1910.1200 OSHA
requirements, Canadian WHMIS requirements or GHS requirements.


<table>
<tr>
<td>Label elements</td>
<td></td>
</tr>
<tr>
<td>Hazard symbol</td>
<td>None.</td>
</tr>
<tr>
<td>Signal word</td>
<td>None.</td>
</tr>
<tr>
<td>Hazard statement</td>
<td>The product does not meet the criteria for classification. Under normal conditions of processing and use, exposure to the chemical constituents in this product is unlikely. The battery should not be opened or burned. Exposure to the ingredients contained within or their combustion products - could be harmful. In the event of damage resulting in a leak of exposed materials, avoid contact with contents of an open or damaged cell or battery.</td>
</tr>
<tr>
<td>Precautionary statement</td>
<td></td>
</tr>
<tr>
<td>Prevention</td>
<td>Use personal protective equipment as required. Observe good industrial hygiene practices.</td>
</tr>
<tr>
<td>Response</td>
<td>Get medical advice/attention if you feel unwell.</td>
</tr>
<tr>
<td>Storage</td>
<td>Store away from incompatible materials.</td>
</tr>
<tr>
<td>Disposal</td>
<td>Dispose of contents/container in accordance with local/regional/national/international regulations.</td>
</tr>
<tr>
<td>Hazard(s) not otherwise classified (HNOC)</td>
<td>None known.</td>
</tr>
<tr>
<td>Supplemental information</td>
<td>In the event of damage resulting in a leak of exposed materials, avoid contact with contents of an open or damaged cell or battery.</td>
</tr>
</table>


### 3. Composition/information on ingredients


#### Mixtures


<table>
<tr>
<th>Chemical name</th>
<th>CAS number</th>
<th>%</th>
</tr>
<tr>
<td>Cobalt Lithium Manganese Nickel Oxide</td>
<td>182442-95-1</td>
<td>28 - 40</td>
</tr>
<tr>
<td>Graphite</td>
<td>7782-42-5</td>
<td>15 - 25</td>
</tr>
<tr>
<td>Copper</td>
<td>7440-50-8</td>
<td>10 - 20</td>
</tr>
<tr>
<td>Aluminum</td>
<td>7429-90-5</td>
<td>5 - 10</td>
</tr>
<tr>
<td>Ethyl Methyl Carbonate</td>
<td>623-53-0</td>
<td>5 - 10</td>
</tr>
</table>


<!-- PageFooter="XALT™ LITHIUM ION BATTERY CELL" -->

SDS US

<!-- PageFooter="929282 Version #: 03 Revision date: 12-August-2021 Issue date: 07-October-2015" -->
<!-- PageNumber="1 / 8" -->
<!-- PageBreak -->


<table>
<tr>
<th>Chemical name</th>
<th>CAS number</th>
<th>%</th>
</tr>
<tr>
<td>Carbon black</td>
<td>1333-86-4</td>
<td>1 - 5</td>
</tr>
<tr>
<td>Ethylene Carbonate</td>
<td>96-49-1</td>
<td>1 - 5</td>
</tr>
<tr>
<td>Lithium Hexaflurophosphate</td>
<td>21324-40-3</td>
<td>1 - 5</td>
</tr>
<tr>
<td>Polyethene</td>
<td>9002-88-4</td>
<td>1 - 5</td>
</tr>
<tr>
<td>Polypropylene</td>
<td>9003-07-0</td>
<td>1 - 5</td>
</tr>
<tr>
<td>Polyvinylidene Fluoride</td>
<td>24937-79-9</td>
<td>1 - 5</td>
</tr>
<tr>
<td>Proprietary Additive*</td>
<td>Proprietary*</td>
<td>&lt; 0.4</td>
</tr>
</table>


Other components below reportable levels
< - 6.3

*Designates that a specific chemical identity and/or percentage of composition has been withheld as a trade secret.
The identities of the materials in this product are withheld as a trade secret (29CFR1910.1210(i)) and are available to a physician or
paramedical personnel in a emergency situation.


### 4. First-aid measures


<table>
<tr>
<td>Inhalation</td>
<td>If contents of an opened battery are inhaled, remove source of contamination or move victim to fresh air. Seek medical advice.</td>
</tr>
<tr>
<td>Skin contact</td>
<td>If skin contact with contents of an open battery occurs, immediately flush with lukewarm water for at least 30 minutes. Thoroughly wash (or discard) clothing and shoes before reuse. If skin irritation occurs, get medical advice/attention.</td>
</tr>
<tr>
<td>Eye contact</td>
<td>If eye comes in contact with contents of an open or damaged cell or battery, immediately flush the contaminated eye(s) with lukewarm water for at least 30 minutes. Get medical attention immediately. Rinse eye with calcium gluconate solution (1%) until arrival of doctor. Continue rinsing.</td>
</tr>
<tr>
<td>Ingestion</td>
<td>If ingestion of contents of an open battery occurs, rinse mouth thoroughly with water. DO NOT induce vomiting. If victim is fully conscious, give a cupful of water. Never give anything by mouth to an unconscious person. If vomiting occurs, keep head lower than the hips to help prevent aspiration. Call a physician or poison control center immediately.</td>
</tr>
<tr>
<td>Most important symptoms/effects, acute and delayed</td>
<td>Under normal conditions of intended use, this material does not pose a risk to health.</td>
</tr>
<tr>
<td>Indication of immediate medical attention and special treatment needed</td>
<td>In case of shortness of breath, give oxygen. Keep victim warm. Keep victim under observation. Symptoms may be delayed.</td>
</tr>
<tr>
<td rowspan="2">General information 5. Fire-fighting measures</td>
<td>First aid personnel must be aware of own risk during rescue.</td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td>Suitable extinguishing media 1</td>
<td>In the event that a fire occurs and a cell or battery is involved, water, carbon dioxide, clean agent, and /or fire blankets suitable for the surrounding materials should be used. Laboratory testing of cells exposed to flame has demonstrated suppression with clean agent type suppression system such as FM200.</td>
</tr>
<tr>
<td>Unsuitable extinguishing media</td>
<td>In the event that a battery is ruptured and the internal components are exposed, DO NOT EXPOSE BATTERY TO WATER. However, if a cell or battery is involved in a fire copious amounts of water can be used to extinguish.</td>
</tr>
<tr>
<td>Specific hazards arising from the chemical</td>
<td>In the event of fire and/or explosion do not breathe fumes. The evolved combustion products may contain carbon oxides, metal oxides, hydrogen fluoride, and should be considered hazardous.</td>
</tr>
<tr>
<td>Special protective equipment and precautions for firefighters</td>
<td>Wear full protective clothing, including helmet, self-contained positive pressure or pressure demand breathing apparatus, protective clothing and face mask. Fight fire from a protected location. Prevent entry into waterways, sewers, basements or confined areas.</td>
</tr>
<tr>
<td>Fire fighting equipment/instructions</td>
<td>Move containers from fire area if you can do so without risk.</td>
</tr>
<tr>
<td rowspan="2">Specific methods General fire hazards</td>
<td>Use standard firefighting procedures and consider the hazards of other involved materials.</td>
</tr>
<tr>
<td>Under normal use, the battery does not exhibit flammable properties. In the event that the battery is abused and disassembly of the battery occurs resulting in exposure of internal components, the exposed solution, may be flammable and/or corrosive. Exposure to excessive heat may lead to venting or rupture of the sealed battery, exposing the internal components which may be corrosive and/or flammable. Vented gas would be flammable when in sufficient concentration.</td>
</tr>
</table>


### 6. Accidental release measures

Personal precautions,
protective equipment and
emergency procedures

None under normal use conditions. In the event of damage resulting in a leak or exposed
materials, avoid contact with contents of an open or damaged cell or battery. Wear protective
clothing as described in Section 8 of this safety data sheet.


<table>
<tr>
<td>XALT™ LITHIUM ION BATTERY CELL</td>
<td>SDS US</td>
</tr>
<tr>
<td>929282 Version #: 03 Revision date: 12-August-2021 Issue date: 07-October-2015</td>
<td>2/ 8</td>
</tr>
</table>


<!-- PageBreak -->


<table>
<tr>
<td>Methods and materials for containment and cleaning up</td>
<td>Leak from a damaged or opened battery: Contain spillage with sand or earth. Collect with absorbent, non-combustible material into suitable containers. For waste disposal, see section 13 of the SDS.</td>
</tr>
<tr>
<td rowspan="2">Environmental precautions 7. Handling and storage</td>
<td>Avoid allowing material from exposed battery to contaminate soil, sanitary sewers, or waterways.</td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td>Precautions for safe handling</td>
<td>Do not open, disassemble, crush or burn battery. Do not expose battery to extreme heat or fire. Elevated temperatures can result in reduced battery service life. Precautions shall be taken to prevent electrical short between cell or battery terminals. Precautions shall be taken to prevent damage which may result in physical damage to the pouch.</td>
</tr>
<tr>
<td>Conditions for safe storage, including any incompatibilities</td>
<td>Store in a cool, dry place. Keep at room temperature. Keep out of reach of children. In the event of damage resulting in a leak or exposed materials, water is to be avoided.</td>
</tr>
<tr>
<td colspan="2">8. Exposure controls/personal protection</td>
</tr>
<tr>
<td>Occupational exposure limits</td>
<td>No exposure limits noted for ingredient(s).</td>
</tr>
<tr>
<td>Biological limit values</td>
<td>No biological exposure limits noted for the ingredient(s).</td>
</tr>
<tr>
<td>Exposure guidelines</td>
<td>This product is an article and is not expected to release hazardous chemicals under normal conditions of use.</td>
</tr>
<tr>
<td>Appropriate engineering controls</td>
<td>If user operations generate dust, fumes, or mist, use ventilation to keep exposure to airborne contaminants below the exposure limit.</td>
</tr>
<tr>
<td>Individual protection measures,</td>
<td>such as personal protective equipment</td>
</tr>
<tr>
<td>Eye/face protection</td>
<td>Not necessary under normal conditions. In the event that cell or battery is damaged, open, or leaking, wear chemical goggles and/or a face shield if handling an open or leaking cell or battery.</td>
</tr>
<tr>
<td>Skin protection Hand protection</td>
<td>Not necessary under normal conditions. In the event that cell or battery is damaged, open, or leaking, wear chemical resistant gloves if handling. Butyl, Trilite, latex gloves are recommended. Do not use Nitrile.</td>
</tr>
<tr>
<td>Other</td>
<td>Not necessary under normal conditions. Wear chemical resistant gloves if handling an open or leaking battery.</td>
</tr>
<tr>
<td>Respiratory protection</td>
<td>Not necessary under normal conditions. In the event that cell or battery is damaged, open, or leaking, respiratory protection should be worn where there is a potential to exceed the exposure limit requirements or guidelines.</td>
</tr>
<tr>
<td>Thermal hazards</td>
<td>Wear appropriate thermal protective clothing, when necessary.</td>
</tr>
<tr>
<td rowspan="2">General hygiene considerations</td>
<td>Do not store food, drink and tobacco near the product. Practice good housekeeping.</td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td colspan="2">9. Physical and chemical properties</td>
</tr>
<tr>
<td>Appearance</td>
<td>Pouch battery.</td>
</tr>
<tr>
<td>Physical state</td>
<td>Solid.</td>
</tr>
<tr>
<td>Form</td>
<td>Solid.</td>
</tr>
<tr>
<td>Color</td>
<td>Silver</td>
</tr>
<tr>
<td>Odor</td>
<td>Odorless.</td>
</tr>
<tr>
<td>Odor threshold</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>pH</td>
<td>Not applicable (The material is non soluble in water).</td>
</tr>
<tr>
<td>Melting point/freezing point</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Initial boiling point and boiling range</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Flash point</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Evaporation rate</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Flammability (solid, gas)</td>
<td>Not available.</td>
</tr>
<tr>
<td colspan="2">Upper/lower flammability or explosive limits</td>
</tr>
<tr>
<td rowspan="2">Explosive limit - lower (%) Explosive limit - upper (%)</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Not Applicable</td>
</tr>
<tr>
<td>Vapor pressure</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Vapor density</td>
<td>Not Applicable</td>
</tr>
<tr>
<td rowspan="2">Solubility(ies) Solubility (water)</td>
<td></td>
</tr>
<tr>
<td>Insolube</td>
</tr>
<tr>
<td colspan="2">XALT™ LITHIUM ION BATTERY CELL SDS US 929282 Version #: 03 Revision date: 12-August-2021 Issue date: 07-October-2015 3/ 8</td>
</tr>
</table>


<!-- PageBreak -->

..


<table>
<tr>
<th>Partition coefficient (n-octanol/water)</th>
<th>Not applicable, product is a mixture.</th>
</tr>
<tr>
<td>Auto-ignition temperature</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Decomposition temperature</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Viscosity</td>
<td>Not Applicable</td>
</tr>
<tr>
<td>Other information</td>
<td></td>
</tr>
<tr>
<td>Density</td>
<td>Not determined.</td>
</tr>
<tr>
<td>Explosive properties</td>
<td>Not explosive.</td>
</tr>
<tr>
<td>Oxidizing properties</td>
<td>Not oxidizing.</td>
</tr>
</table>


### 10. Stability and reactivity

Reactivity
The product is stable and non-reactive under normal conditions of use, storage and transport.

Chemical stability
Material is stable under normal conditions.

Under normal conditions of storage and use, hazardous polymerization will not occur.

Possibility of hazardous
reactions
Conditions to avoid
Heat, sparks, flames, elevated temperatures. Physical damage.

Incompatible materials
None known.

Hazardous decomposition
Under normal conditions none known, irritating and/or toxic fumes and gases may be emitted upon
decomposition of the product.

products


### 11. Toxicological information

Information on likely routes of exposure


<table>
<tr>
<td>Inhalation</td>
<td>No inhalation hazard under normal conditions.</td>
</tr>
<tr>
<td>Skin contact</td>
<td>Under normal conditions of intended use, this product does not pose a skin hazard. In the event that cell or battery is damaged, open, or leaking - brief contact may cause skin burns with possible symptoms including pain, local redness, and tissue damage.</td>
</tr>
<tr>
<td>Eye contact</td>
<td>Under normal conditions of intended use, this product does not pose an eye hazard. In the event that cell or battery is damaged, open, or leaking - irritation with injury resulting in permanent impairment of vision and chemical burn may occur.</td>
</tr>
<tr>
<td>Ingestion</td>
<td>Under normal conditions of intended use, this material does not pose a risk to health.</td>
</tr>
<tr>
<td>Symptoms related to the physical, chemical and toxicological characteristics</td>
<td>Exposure not expected under normal use conditions. In the event that cell or battery is damaged, open, or leaking - inhalation, skin contact, and/or eye contact may be considered for routes of exposure.</td>
</tr>
</table>


Information on toxicological effects

Acute toxicity

No toxicological impacts are expected under normal use conditions. Risk of irritation occurs only if
the cell is mechanically, thermally, or electrically abused to the point of compromising the
enclosure. If this occurs, irritation to the skin, eyes and respiratory tract may occur.

Skin corrosion/irritation

Not classified.

Serious eye damage/eye
irritation

Not classified.

Respiratory or skin sensitization

ACGIH sensitization
Cobalt and inorganic compounds, as Co
(CAS 182442-95-1)

Dermal sensitization

Respiratory sensitization


<table>
<tr>
<td>Respiratory sensitization</td>
<td>Not a respiratory sensitizer.</td>
</tr>
<tr>
<td>Skin sensitization</td>
<td>Risk of sensitization only occurs if the cell is mechanically, thermally, or electrically abused to the point of compromising the enclosure. If this occurs, battery contains ingredients may cause sensitization.</td>
</tr>
<tr>
<td>Germ cell mutagenicity</td>
<td>No data available to indicate product or any components present at greater than 0.1% are mutagenic or genotoxic.</td>
</tr>
<tr>
<td>Carcinogenicity</td>
<td>Under normal handling and storage conditions, the exposure to carcinogenic components is not expected. Risk of adverse effects occurs only if the cell is mechanically, thermally or electrically abused to the point of compromising the enclosure.</td>
</tr>
</table>


#### IARC Monographs. Overall Evaluation of Carcinogenicity

Carbon black (CAS 1333-86-4)
2B Possibly carcinogenic to humans.


<table>
<tr>
<td>XALT™ LITHIUM ION BATTERY CELL</td>
<td>SDS US</td>
</tr>
<tr>
<td>929282 Version #: 03 Revision date: 12-August-2021 Issue date: 07-October-2015</td>
<td>4 / 8</td>
</tr>
</table>


<!-- PageBreak -->

Proprietary Additive (CAS Proprietary)
NTP Report on Carcinogens
Carbon black (CAS 1333-86-4)
Cobalt Lithium Manganese Nickel Oxide
(CAS 182442-95-1)

2A Probably carcinogenic to humans.

Known To Be Human Carcinogen.
Known To Be Human Carcinogen.

Reasonably Anticipated to be a Human Carcinogen.
Reasonably Anticipated to be a Human Carcinogen.


### Proprietary Additive (CAS Proprietary) OSHA Specifically Regulated Substances (29 CFR 1910.1001-1053)


<table>
<tr>
<th>Not listed.</th>
<th></th>
</tr>
<tr>
<td>Reproductive toxicity</td>
<td>This product is not expected to cause reproductive or developmental effects.</td>
</tr>
<tr>
<td>Specific target organ toxicity - single exposure</td>
<td>Not classified.</td>
</tr>
<tr>
<td>Specific target organ toxicity - repeated exposure</td>
<td>Not classified.</td>
</tr>
<tr>
<td>Aspiration hazard</td>
<td>Not classified.</td>
</tr>
<tr>
<td>Chronic effects</td>
<td>Under normal handling and storage conditions, the exposure to carcinogenic components is not expected. Risk of adverse effects occurs only if the cell is mechanically, thermally or electrically abused to the point of compromising the enclosure.</td>
</tr>
<tr>
<td>Further information</td>
<td>This product has no known adverse effect on human health.</td>
</tr>
<tr>
<td>12. Ecological information</td>
<td></td>
</tr>
<tr>
<td>Ecotoxicity</td>
<td>No ecological impacts expected under normal use conditions.</td>
</tr>
<tr>
<td>Persistence and degradability</td>
<td>No data is available on the degradability of this product.</td>
</tr>
<tr>
<td>Bioaccumulative potential</td>
<td>No data available.</td>
</tr>
<tr>
<td>Mobility in soil</td>
<td>The product is not mobile in soil.</td>
</tr>
<tr>
<td>Other adverse effects</td>
<td>No data available.</td>
</tr>
<tr>
<td>13. Disposal considerations</td>
<td></td>
</tr>
<tr>
<td>Disposal instructions</td>
<td>Do not dispose in fire. Dispose waste and residues in accordance with applicable federal, state, and local regulations.</td>
</tr>
<tr>
<td>Local disposal regulations</td>
<td>Dispose in accordance with all applicable regulations.</td>
</tr>
<tr>
<td>Hazardous waste code</td>
<td>Hazardous waste code should be determined in accordance with hazardous waste regulatory authorities.</td>
</tr>
<tr>
<td>Waste from residues / unused products</td>
<td>Dispose in accordance with all local, state and federal regulations.</td>
</tr>
<tr>
<td>Contaminated packaging</td>
<td>Since emptied containers may retain product residue, follow label warnings even after container is emptied. Empty containers should be taken to an approved waste handling site for recycling or disposal.</td>
</tr>
<tr>
<td>14. Transport information DOT</td>
<td></td>
</tr>
<tr>
<td>UN number</td>
<td>UN3480</td>
</tr>
<tr>
<td>UN proper shipping name Transport hazard class(es)</td>
<td>Lithium ion batteries including lithium ion polymer batteries</td>
</tr>
<tr>
<td>Class Subsidiary risk Label(s)</td>
<td>9 - 9</td>
</tr>
<tr>
<td>Packing group</td>
<td>II</td>
</tr>
<tr>
<td rowspan="2">Special precautions for user Packaging exceptions</td>
<td>Read safety instructions, SDS and emergency procedures before handling.</td>
</tr>
<tr>
<td>185</td>
</tr>
<tr>
<td>Packaging non bulk</td>
<td>185</td>
</tr>
<tr>
<td rowspan="2">Packaging bulk IATA</td>
<td>185</td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td>UN number</td>
<td>UN3480</td>
</tr>
<tr>
<td>UN proper shipping name Transport hazard class(es) Class Subsidiary risk</td>
<td>Lithium ion batteries (including lithium polymer batteries) 9 -</td>
</tr>
<tr>
<td>XALT™ LITHIUM ION BATTERY CELL</td>
<td>SDS US</td>
</tr>
</table>


<!-- PageFooter="929282 Version #: 03 Revision date: 12-August-2021 Issue date: 07-October-2015" -->
<!-- PageNumber="5/ 8" -->
<!-- PageBreak -->

Packing group
11

Environmental hazards
No.

ERG Code

9FZ

Special precautions for user

Read safety instructions, SDS and emergency procedures before handling.

IMDG

UN number

UN3480

UN proper shipping name

LITHIUM ION BATTERIES (including lithium ion polymer batteries)

Transport hazard class(es)

Class

9

Subsidiary risk

\-

Packing group

II

Environmental hazards

Marine pollutant

No.

EmS

F-A, S-I

Special precautions for user
Transport in bulk according to
Annex Il of MARPOL 73/78 and

Read safety instructions, SDS and emergency procedures before handling.

Not applicable.

the IBC Code

General information
The dangerous goods regulations require that each cell and battery design be subject to tests
contained in Part III, subsection 38.3 of the UN Manual of Tests and Criteria prior to being offered
for transport. Batteries containing these cells should be transported as Class 9 hazardous
materials, except for those battery types declared to be exempt.


### 15. Regulatory information

US federal regulations
This product is an article pursuant to 29 CFR 1910.1200 and, as such, is not subject to the OSHA
Hazard Communication Standard.

TSCA Section 12(b) Export Notification (40 CFR 707, Subpt. D)

Cobalt Lithium Manganese Nickel Oxide
(CAS 182442-95-1)

0.1 % One-Time Export Notification only.

CERCLA Hazardous Substance List (40 CFR 302.4)

Copper (CAS 7440-50-8)
Listed.
Proprietary Additive (CAS Proprietary)
Listed.
SARA 304 Emergency release notification

Not regulated.

OSHA Specifically Regulated Substances (29 CFR 1910.1001-1053)

Not listed.
Toxic Substances Control Act (TSCA)
All components are listed on or exempt from the U.S. EPA TSCA Inventory
List.

Superfund Amendments and Reauthorization Act of 1986 (SARA)

SARA 302 Extremely hazardous substance
Not listed.

SARA 311/312 Hazardous
No
chemical

SARA 313 (TRI reporting)


<table>
<tr>
<th>Chemical name</th>
<th>CAS number</th>
<th>% by wt.</th>
</tr>
<tr>
<td>Aluminum</td>
<td>7429-90-5</td>
<td>5 - 10</td>
</tr>
<tr>
<td>Copper</td>
<td>7440-50-8</td>
<td>10 - 20</td>
</tr>
<tr>
<td>Proprietary Additive</td>
<td>Proprietary</td>
<td>&lt; 0.4</td>
</tr>
<tr>
<td>Other federal regulations</td>
<td></td>
<td></td>
</tr>
</table>


Clean Air Act (CAA) Section 112 Hazardous Air Pollutants (HAPs) List
Proprietary Additive (CAS Proprietary)
Clean Air Act (CAA) Section 112(r) Accidental Release Prevention (40 CFR 68.130)
Not regulated.
Safe Drinking Water Act
Not regulated.
(SDWA)


<table>
<tr>
<td>XALT™ LITHIUM ION BATTERY CELL</td>
<td>SDS US</td>
</tr>
<tr>
<td>929282 Version #: 03 Revision date: 12-August-2021 Issue date: 07-October-2015</td>
<td>6/ 8</td>
</tr>
</table>


<!-- PageBreak -->

US state regulations

US. Massachusetts RTK - Substance List

Aluminum (CAS 7429-90-5)

Carbon black (CAS 1333-86-4)

Copper (CAS 7440-50-8)
Ethylene Carbonate (CAS 96-49-1)
Graphite (CAS 7782-42-5)

Proprietary Additive (CAS Proprietary)

US. New Jersey Worker and Community Right-to-Know Act

Aluminum (CAS 7429-90-5)
Carbon black (CAS 1333-86-4)

Copper (CAS 7440-50-8)

Graphite (CAS 7782-42-5)

Proprietary Additive (CAS Proprietary)

US. Pennsylvania Worker and Community Right-to-Know Law

Aluminum (CAS 7429-90-5)

Carbon black (CAS 1333-86-4)

Cobalt Lithium Manganese Nickel Oxide (CAS 182442-95-1)

Copper (CAS 7440-50-8)

Ethylene Carbonate (CAS 96-49-1)

Graphite (CAS 7782-42-5)

Proprietary Additive (CAS Proprietary)

US. Rhode Island RTK

Aluminum (CAS 7429-90-5)

Carbon black (CAS 1333-86-4)

Copper (CAS 7440-50-8)

Graphite (CAS 7782-42-5)

Proprietary Additive (CAS Proprietary)

California Proposition 65


<figure>

!

</figure>


WARNING: WARNING: This product contains a chemical known to the State of California to cause cancer. For
more information go to www.P65Warnings.ca.gov.

California Proposition 65 - CRT: Listed date/Carcinogenic substance

Carbon black (CAS 1333-86-4)

Listed: February 21, 2003

Cobalt Lithium Manganese Nickel Oxide

Listed: May 7, 2004

(CAS 182442-95-1)

Proprietary Additive (CAS Proprietary)
Listed: January 1, 1988

US. California. Candidate Chemicals List. Safer Consumer Products Regulations (Cal. Code Regs, tit. 22, 69502.3,
subd. (a))

Aluminum (CAS 7429-90-5)

Carbon black (CAS 1333-86-4)

Cobalt Lithium Manganese Nickel Oxide (CAS 182442-95-1)

Copper (CAS 7440-50-8)

Proprietary Additive (CAS Proprietary)


#### International Inventories


<table>
<tr>
<th>Country(s) or region</th>
<th>Inventory name</th>
<th>On inventory (yes/no)*</th>
</tr>
<tr>
<td>Australia</td>
<td>Australian Inventory of Industrial Chemicals (AICIS)</td>
<td>No</td>
</tr>
<tr>
<td>Canada</td>
<td>Domestic Substances List (DSL)</td>
<td>No</td>
</tr>
<tr>
<td>Canada</td>
<td>Non-Domestic Substances List (NDSL)</td>
<td>No</td>
</tr>
<tr>
<td>China</td>
<td>Inventory of Existing Chemical Substances in China (IECSC)</td>
<td>No</td>
</tr>
<tr>
<td>Europe</td>
<td>European Inventory of Existing Commercial Chemical Substances (EINECS)</td>
<td>No</td>
</tr>
<tr>
<td>Europe</td>
<td>European List of Notified Chemical Substances (ELINCS)</td>
<td>No</td>
</tr>
<tr>
<td>Japan</td>
<td>Inventory of Existing and New Chemical Substances (ENCS)</td>
<td>No</td>
</tr>
<tr>
<td>Korea</td>
<td>Existing Chemicals List (ECL)</td>
<td>Yes</td>
</tr>
<tr>
<td>New Zealand</td>
<td>New Zealand Inventory</td>
<td>No</td>
</tr>
<tr>
<td>Philippines</td>
<td>Philippine Inventory of Chemicals and Chemical Substances (PICCS)</td>
<td>No</td>
</tr>
<tr>
<td>Taiwan</td>
<td>Taiwan Chemical Substance Inventory (TCSI)</td>
<td>Yes</td>
</tr>
</table>


<table>
<tr>
<td>XALT™ LITHIUM ION BATTERY CELL</td>
<td>SDS US</td>
</tr>
<tr>
<td>929282 Version #: 03 Revision date: 12-August-2021 Issue date: 07-October-2015</td>
<td>7 / 8</td>
</tr>
</table>


<!-- PageBreak -->

Country(s) or region

Inventory name

United States & Puerto Rico

Toxic Substances Control Act (TSCA) Inventory

On inventory (yes/no)*
Yes

"A "Yes" indicates that all components of this product comply with the inventory requirements administered by the governing country(s)
A "No" indicates that one or more components of the product are not listed or exempt from listing on the inventory administered by the governing
country(s).


### 16. Other information, including date of preparation or last revision


<table>
<tr>
<td>Issue date</td>
<td>07-October-2015</td>
</tr>
<tr>
<td>Revision date</td>
<td>12-August-2021</td>
</tr>
<tr>
<td>Version #</td>
<td>03</td>
</tr>
<tr>
<td>Further information</td>
<td>HMIS® is a registered trade and service mark of the NPCA.</td>
</tr>
<tr>
<td rowspan="2">HMIS® ratings</td>
<td>Health: 1</td>
</tr>
<tr>
<td>Flammability: 1 Physical hazard: 0 Personal protection: E</td>
</tr>
<tr>
<td>NFPA ratings</td>
<td>1 0</td>
</tr>
<tr>
<td>Disclaimer</td>
<td>XALT Energy, LLC cannot anticipate all conditions under which this information and its product, or the products of other manufacturers in combination with its product, may be used. It is the user's responsibility to ensure safe conditions for handling, storage and disposal of the product, and to assume liability for loss, injury, damage or expense due to improper use. The information in the sheet was written based on the best knowledge and experience currently available.</td>
</tr>
</table>


<figure>
</figure>


<table>
<tr>
<td>XALT™ LITHIUM ION BATTERY CELL</td>
<td>SDS US</td>
</tr>
<tr>
<td>929282 Version #: 03 Revision date: 12-August-2021 Issue date: 07-October-2015</td>
<td>8/ 8</td>
</tr>
</table>


<!-- PageBreak -->

FedEx.
O
Freight

2200 FORWARD DRIVE
HARRISON, AR 72601

fedex.com 1 866.393.4585


## DELIVERY RECEIPT

Freight Bill 7414531165 RO

<!-- PageNumber="Page 2 of 2" -->


<table>
<tr>
<td>Ship Date 01/14/2026</td>
<td>Bill of Lading</td>
</tr>
<tr>
<td>PO</td>
<td>Shipper Reference</td>
</tr>
<tr>
<td>Origin ANB</td>
<td>Destination HFD</td>
</tr>
</table>


Trailer # X15537

Consignee

PIONEER VALLEY TRANSIT AUTHORI

665 COTTAGE ST

SPRINGFIELD

MA 01104

US

Shipper

NEW FLYER OF AMERICA

106 NATIONAL DR

ANNISTON REGION

ANNISTON

AL 36207

US

FedEx Freight Priority

DRIVER COPY


<table>
<tr>
<th>PIECES</th>
<th>PKG</th>
<th>HAU</th>
<th>HM</th>
<th>DESCRIPTION</th>
<th>WTILBS)</th>
<th>NMFC</th>
<th>PCF CLASS</th>
<th>RATE</th>
<th>TOTAL CHARGES</th>
</tr>
<tr>
<td rowspan="2"></td>
<td rowspan="2">* * BY</td>
<td rowspan="2">ACCEPTING</td>
<td colspan="2" rowspan="2">*FXF PZONE01/05/26 LS 11124 01 ZONE NUMBER THE SHIPMENT, YOU AGREE TO BE FULLY RESPONSIBLE FOR ANY ADDITIONAL</td>
<td></td>
<td></td>
<td rowspan="2">RENDERED</td>
<td></td>
<td rowspan="2">LIMITED TO DETENTION .</td>
</tr>
<tr>
<td>APPLICABLE CHARGES FOR</td>
<td>DELIVERY SERVICES</td>
<td>INCLUDING BUT NOT</td>
</tr>
<tr>
<td>11</td>
<td></td>
<td>1</td>
<td></td>
<td>COLLECT - WILL INVOICE CONSIGNEE</td>
<td>2140</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


ACCESSORIAL SERVICES PERFORMED.
☐
INSIDE DELIVERY
☐
RESIDENTIAL LIMITED ACCESS
☐
LIFT GATE
☐
OTHERS

☐
SORT & SEGREGATE
☐
DETENTION


<table>
<tr>
<th colspan="4">Delv Driver &amp; #1 2398353</th>
</tr>
<tr>
<th>Date</th>
<th>1/16/26</th>
<th>Arrive.</th>
<th>Depart:</th>
</tr>
<tr>
<td colspan="2"># of Skids</td>
<td># of Pcs.</td>
<td>OS&amp;D #:</td>
</tr>
</table>


Shipment received in apparent good order with wrap intact unless otherwise noted

Received by:
☐
Over
☐
Damage
Exceptions
☐
Short
☐
Wrap Broken

COLLECT - WILL INVOICE
RESPONSIBLE PARTY
DRIVER COL REL AUTH #65T311

Customer Requirements/Appointment Instruction

<!-- PageBreak -->

FedEx.
4

Freight

2200 FORWARD DRIVE
HARRISON, AR 72601

fedex.com 1 866 393.4585


# DELIVERY RECEIPT

<!-- PageNumber="Page 1 of 2" -->

Freight Bill 7414531165 RO

as


<table>
<tr>
<td>Ship Date 01/14/2026</td>
<td>Bill of Lading</td>
</tr>
<tr>
<td>PO</td>
<td>Shipper Reference</td>
</tr>
<tr>
<td>Origin ANB</td>
<td>Destination HFD</td>
</tr>
</table>


Consignee

Trailer # X15537

PIONEER VALLEY TRANSIT AUTHORI
665 COTTAGE ST
SPRINGFIELD
MA 01104
US

Shipper

NEW FLYER OF AMERICA

106 NATIONAL DR

ANNISTON REGION

ANNISTON

AL 36207

US

FedEx Freight Priority

DRIVER COPY


<table>
<tr>
<th>PIĘCES</th>
<th>PKG</th>
<th>HJU</th>
<th>HM</th>
<th>DESCRIPTION</th>
<th>WT(LBS)</th>
<th>NMFC</th>
<th>PCF</th>
<th>CLASS</th>
<th>RATE</th>
<th>TOTAL CHARGES</th>
</tr>
<tr>
<td>11</td>
<td>NO PKG</td>
<td></td>
<td>X</td>
<td>UN3480, LITHIUM ION</td>
<td>2140</td>
<td>060680-01</td>
<td></td>
<td>070</td>
<td>214.150</td>
<td>4582.81</td>
</tr>
<tr>
<td></td>
<td>SKID</td>
<td></td>
<td></td>
<td rowspan="2">BATTERIES, 9 EMERGENCY CONTACT 12566768020 ERI PROVIDER: JERRY DEMPSEY</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td rowspan="2"></td>
<td></td>
<td rowspan="2">006100 HAZARDOUS MATERIAL CHARGE 20143585 SO#</td>
<td rowspan="2"></td>
<td rowspan="2"></td>
<td></td>
<td rowspan="2"></td>
<td></td>
<td>61.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>UPDATE PER INSPECTION</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>002900 ORIGINAL WEIGHT</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>** SHIPMENT REWEIGHED AS ABOVE **</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>ANB INSPECTING TERMINAL</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>0001880 WEIGHT VALIDATION FEE</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>18.80</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>004500 DEMAND SURCHARGE TIER 2</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>45.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>013033 FUEL SURCHG LTL SHPT 31.60%</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>130.33</td>
</tr>
<tr>
<td></td>
<td></td>
<td rowspan="2"></td>
<td></td>
<td>910 LESS DISCOUNT</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>0.910</td>
<td>-4170.36</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>548055335-102-0-425</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>** BY</td>
<td>ACCEPTING COLLECT</td>
<td>THE</td>
<td>SHIPMENT, YOU AGREE TO BE FULLY RESPONSIBLE FOR ANY ADDITIONAL - WILL INVOICE CONSIGNEE</td>
<td>APPLICABLE CHARGES FOR</td>
<td>DELIVERY SERVICES</td>
<td></td>
<td>RENDERED</td>
<td>INCLUDING BUT NOT</td>
<td>LIMITED TO DETENTION</td>
</tr>
</table>


ACCESSORIAL SERVICES PERFORMED:


<table>
<tr>
<td>☐ INSIDE DELIVERY</td>
<td>☐ SORT &amp; SEGREGATE</td>
<td>☐ DETENTION</td>
</tr>
<tr>
<td>☐ RESIDENTIAL-LIMITED ACCESS</td>
<td>☐ LIFT GATE</td>
<td>☐ OTHERS</td>
</tr>
</table>


Delv. Driver & #:


<table>
<tr>
<th>Date</th>
<th>Arrive</th>
<th>Depart:</th>
</tr>
<tr>
<td># of Skids.</td>
<td># of Pcs.</td>
<td>OS&amp;D #</td>
</tr>
</table>


Shipment received in apparent good order with wrap intact unless otherwise noted

Received by:
☐
Over
☐
Damage
Exceptions

☐
Short
☐
Wrap Broken

COLLECT - WILL INVOICE
RESPONSIBLE PARTY
DRIVER COL REL AUTH #65T311

Customer Requirements/Appointment Instruction

<!-- PageBreak -->

<!-- PageNumber="PAGE 1OF 1" -->


<figure>

EBDA
FedEx ®
Freight

</figure>


## ORIGINAL INVOICE FXFE PRIORITY

Send payment to: DEPT CH PO BOX 10306 PALATINE IL 60055-0306
Direct Billing Inquiries to 2200 Forward Dr Harrison AR 72602-0840
EMAIL customersolutions@fedex.com WEBSITE www.fedex.com
PHONE 870.741.9000 FAX 870.365.4354 TOLL-FREE 866.393.4585

Shipper

NEW FLYER USA INC

6200 GLENN CARLSON DR

SAINT CLOUD MN 56301-8852

Consignee

SPOKANE TRANSIT AUTH

1229 WEST BOONE

SPOKANE WA 99201


<table>
<tr>
<td>Freight Bill Number</td>
<td>5783919724</td>
</tr>
<tr>
<td>Ship Date/Invoice Date</td>
<td rowspan="2">01/21/2026 / 01/27/2026</td>
</tr>
<tr>
<td>Bill of Lading Number</td>
</tr>
<tr>
<td>P.O. Number</td>
<td></td>
</tr>
<tr>
<td>Shipper Reference Number</td>
<td></td>
</tr>
<tr>
<td>I/L PRO Number</td>
<td></td>
</tr>
<tr>
<td>Terms</td>
<td>PREPAID</td>
</tr>
<tr>
<td>Origin /Destination</td>
<td>STC / SPO</td>
</tr>
<tr>
<td>Total Amount Due</td>
<td>228.73</td>
</tr>
<tr>
<td>Payment Due Date</td>
<td>02/11/2026</td>
</tr>
</table>


Bill To / Payment Due From

NEW FLYER % INTELLIGENT AUDIT

Ste 455

365 W PASSAIC ST STE 455

ROCHELLE PARK NJ 07662-3005

Account# 934710835


<table>
<tr>
<th>PIECES</th>
<th>PALLETS</th>
<th>HM</th>
<th>DESCRIPTION</th>
<th>WT(LBS)</th>
<th>NMFC</th>
<th>CLASS</th>
<th>RATE</th>
<th>TOTAL CHARGES</th>
</tr>
<tr>
<td>1</td>
<td></td>
<td>X ☒</td>
<td>CRATE, UN3480,LITHIUMION BATTERIES,9, EMERGENCY CONTACT 18004249300 ERI PROVIDER: NEW FLYER USA INC *FXF PZONE01/05/26 ILS 11128 0000006 CUBIC FEET</td>
<td>185</td>
<td>060680-01</td>
<td>070</td>
<td>MIN</td>
<td>1,313.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>DIMS:0001HU@ 015.0"X039.0"X017.0" 004037 FUEL SURCHG LTL SHPT 31.70%</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>40.37</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>006100 HAZARDOUS MATERIAL CHARGE 903 LESS DISCOUNT NONMFC ON BOL</td>
<td></td>
<td></td>
<td></td>
<td>.903</td>
<td>61.00 1,185.64-</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>548055335-102-0-425 02 ZONE NUMBER</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Invoicing Summary Original Invoice Amount Less Amount Paid</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>228.73</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Less Freight Bill Adjustments</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2">1</td>
<td></td>
<td></td>
<td rowspan="2">Totals / Amount Due by (02/11/2026)</td>
<td rowspan="2">185</td>
<td rowspan="2"></td>
<td></td>
<td rowspan="2"></td>
<td rowspan="2">228.73</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
</tr>
</table>


Rate Tariff : 548055335-102-0

FedEx ®
Freight

Remittance Advice
PLEASE RETURN THIS PORTION WITH YOUR PAYMENT
Payment Due From Account # 934710835

Send to: DEPT CH PO BOX 10306
PALATINE IL 60055-0306
☐
Address change? Please check the appropriate box and fill out the information
on the reverse side of this form.

FXF

#BWNFZGZ

NEW FLYER % INTELLIGENT AUDIT

Ste 455

365 W PASSAIC ST STE 455

ROCHELLE PARK NJ 07662-3005

FREIGHT BILL NUMBER

5783919724

SHIP DATE/INVOICE DATE
01/21/2026 / 01/27/2026

TERMS

PREPAID

PAYMENT DUE DATE

02/11/2026

PLEASE PAY THIS AMOUNT

228.73

Thank You!

5783919724 000000022873 01272026 7

<!-- PageBreak -->

UNIFORM STRAIGHT BILL OF LADING ORIGINAL --- NOT NEGOTIABLE
ALL SERVICES SUBJECT TO THE TERMS AND CONDITIONS OF THE FXF 100 SERIES RULES TARIFF. SEE FEDEX.COM FOR DETAILS. - QUESTIONS? CALL 1.866.393.4585

FedEx.

578391972-4
Freight


<table>
<tr>
<th>Date 1-21-2026</th>
<th>Purchase Order #</th>
</tr>
<tr>
<td>Shipper # 4127246848</td>
<td>Shipper # 956366</td>
</tr>
<tr>
<td>REQUIRED: Please select a service type ☒ FedEx Freight Priority ☐ FedEx Freight' Economy</td>
<td>OPTIONAL: You may select a money-back guarantee delivery (charges and tariff limitations may apply). ☐ A.M. Delivery ☐ Close of Business Delivery</td>
</tr>
</table>


<table>
<tr>
<th>SHIPPER (from)</th>
<th colspan="2">Please provide ZIP codes and phone in</th>
<th></th>
<th colspan="2">CONSIGNEE (to)</th>
<th></th>
<th colspan="2"></th>
</tr>
<tr>
<td colspan="2">Shipper NEW FLYER SCL</td>
<td colspan="2">FXF Acct. # 212047546</td>
<td>Consignee</td>
<td colspan="2">SPOKANE TRANSIT AUTHORITY</td>
<td colspan="2">FXF Acct. #</td>
</tr>
<tr>
<td colspan="2">Attn. to NICOLE POSTERICK</td>
<td>Area Code 320</td>
<td>Phone Number 316-4990</td>
<td colspan="3">Attn. to</td>
<td>Area Code</td>
<td>Phone Number</td>
</tr>
<tr>
<td colspan="3">Address 6200 GLENN CARLSON DRIVE</td>
<td></td>
<td colspan="3">Address 1229 WEST BOONE AVENUE</td>
<td colspan="2"></td>
</tr>
<tr>
<td colspan="4">Address (Store, Dept., Ste., Flr., Apt., Div.)</td>
<td colspan="3">Address (Store, Dept., Ste., Flr., Apt., Div.)</td>
<td></td>
<td></td>
</tr>
<tr>
<td>Address</td>
<td colspan="2"></td>
<td></td>
<td colspan="2">Address</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>City ST. CLOUD</td>
<td colspan="2"></td>
<td></td>
<td colspan="2">City SPOKANE</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="3">State/Province ZIP/Postal Code MN 56301</td>
<td>Country USA</td>
<td colspan="2">State/Province WAB</td>
<td>ZIP/Postal Code 99201</td>
<td></td>
<td>Country USA</td>
</tr>
<tr>
<td colspan="4">Optional or Additional Service Fees and Charges ☐ Liftgate ☐ Inside Pickup ☐ Limited Access</td>
<td colspan="5">Optional or Additional Service Fees and Charges ☐ Liftgate ☐ Inside Delivery ☐ Limited Access</td>
</tr>
<tr>
<td colspan="4">Shipper Bill of Lading # g0-fp7 20143710</td>
<td colspan="2">☐ Custom Delivery Window:</td>
<td colspan="3"></td>
</tr>
<tr>
<td colspan="9">Special Instructions HAZMAT</td>
</tr>
<tr>
<td colspan="9">BILL FREIGHT CHARGES TO (if different than above):</td>
</tr>
<tr>
<td>Name</td>
<td colspan="2">FXF</td>
<td>Acct. #</td>
<td></td>
<td>Mailing Address</td>
<td></td>
<td colspan="2"></td>
</tr>
<tr>
<td colspan="2">City</td>
<td></td>
<td>State</td>
<td>ZIP/Postal</td>
<td>Code Country</td>
<td>Area Code</td>
<td>Phone</td>
<td>Number</td>
</tr>
<tr>
<td colspan="2">Freight charges are PREPAID unless</td>
<td>C.O.D.</td>
<td colspan="6">1. . The letters "C.O.D." must appear in box before consignee's name above.</td>
</tr>
<tr>
<td colspan="2">marked collect.</td>
<td>☐ USD</td>
<td colspan="4">2. C.O.D. funds to be collected as: ☐ Certified Funds ☐ Company Check</td>
<td colspan="2">☐ Personal Check</td>
</tr>
<tr>
<td colspan="2">CHECK BOX IF COLLECT ☐</td>
<td>☐ CAD AMOUNT</td>
<td colspan="4">3. C.O.D. fee to be paid by: ☐ Shipper ☐ Consignee</td>
<td colspan="2"></td>
</tr>
<tr>
<td colspan="3"></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
</tr>
<tr>
<td colspan="3">Name</td>
<td></td>
<td colspan="2">Mailing Address</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="3">City</td>
<td>State</td>
<td>ZIP/Postal</td>
<td>Code Country Country</td>
<td>Code Area Code</td>
<td colspan="2">Phone Number</td>
</tr>
</table>


RECEIVED, subject to individually determined rates or contracts that have been agreed upon in writing between the carrier and shipper, if applicable, otherwise to the rates, classifications and rules that have been established by the carrier and are available to the shipper, on request, and to all applicable state and
federal regulations, the property described below, in apparent good order, except as noted (contents and condition of contents of packages unknown) marked, consigned and destined as shown hereon, which said carrier agrees to carry to destination, if on its route, or otherwise to deliver to another carrier on the
route to destination. Every service to be performed hereunder shall be subject to all the conditions not prohibited by law, whether printed or written, herein contained, including the conditions on the back hereof, and the conditions of the FXF 100 Series Rules Tariff, or otherwise referenced, which are hereby agreed


<table>
<tr>
<th rowspan="2">HANDLING UNITS (H/U)</th>
<th rowspan="2">H/UPKG. TYPE</th>
<th rowspan="2">PIECES</th>
<th rowspan="2">HM (x)</th>
<th rowspan="2">KIND OF PACKAGE, DESCRIPTION OF ARTICLES, SPECIAL MARKS AND EXCEPTIONS (subject to correction)</th>
<th>WEIGHT IN LBS.</th>
<th>NMFC ITEM #</th>
<th>CLASS</th>
<th>CUBE TOTAL)</th>
</tr>
<tr>
<th>(subject to correction)</th>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td>1</td>
<td>CRT</td>
<td>1</td>
<td>☒</td>
<td>UN3480 / LITHIUM-ION BATTERIES INCLUDING LITHIUM-ION POLYMER</td>
<td>185</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>BATTERIES / 9</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>P/N 956366 QTY 1</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>S/N: N71648N30024014004</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>DIMS: 15X39X17"</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


TOTAL H/U:
1 CRT

MARK "X" OR "RQ" IN THE HM COLUMN TO DESIGNATE HAZARDOUS MATERIALS OR REPORTABLE QUANTITY AS DEFINED IN DOT REGULATIONS.

HM EMERGENCY CONTACT PHONE NUMBER (_800 ) 424-9300

ARLA CODE

CUSTOMER REGISTERED W/EMERGENCY RESPONSE INFO. PROVIDER or CONTRACT #
CHEMTREC

FOR INTERNATIONAL SHIPMENTS INDICATE BROKER NAME, FAX AND PHONE NUMBERS.

AREA CODE

EEI/SED Number or Exception

Phone #

AREA CODE

Broker Name

Fax #

FOR FREIGHT COLLECT SHIPMENTS

Subject to Section 7 of conditions of applicable Bill of Lading. If this shipment is to be delivered to the consignee,
without recourse on the consignor, the consignor shall sign the following statement. The carrier may decline to
make delivery of this shipment without payment of freight and all other lawful charges.

Consignor Signature

SHIPPER CERTIFICATION

Thereby declare that the contents of this consignment are fully and accurately described above by the proper shipping
name, and are classified, packaged, marked and labeled/placarded, and are in all respects in proper condition for
transport according to applicable international and national governmental regulations.

Shipper Signature

Kolbe Pas

Date:

1/21/20

CARRIER CERTIFICATION

Carrier acknowledges receipt of packages and required placards. Carrier certifies emergency response information
was made available and/or carrier has the DOT emergency response guidebook or equivalent document in the vehicle.


<table>
<tr>
<th>DATE</th>
<th>DRIVER/EMPLOYEE NUMBER PIECE COUNT</th>
<th>TRAILER #</th>
</tr>
<tr>
<td>1.21.26</td>
<td>4561856 150</td>
<td>XIGLY</td>
</tr>
</table>


FedEx Freight

CO202/518-FXF 0023776PM

NOTE (1) Where the rate and carrier's liability for loss or damage may be dependent on value, shippers
must state specifically in writing the agreed or declared value of the property as follows: "The agreed
or declared value of the property is specifically stated by the shipper to be not exceeding.
per
Note(2)liability limitation forloss or damage on this shipment shall be applicable as provided by contract
or in the current NMFC or this carrier's governing tariffs. See FXF 100 Series Rules Tariff for complete
limited liability provisions. Carrier's maximum standard liability is limited to $25 per pound per package
for NEW articles and $.50 per pound per package (or its equivalent in Mexican Pesos (MXN) or Canadian
Dollars (CAD), at the rate of exchange which is in effect at the place and on the date of shipment) for USED
or RECONDITIONED articles. In no case shall carrier liability exceed $100,000 per occurrence (oritsequivalent
in MXN or CAD at the rate of exchange which is in effect at the place and on the date of shipment) for NEW
articles or $10,000 per occurrence (orits equivalent in MXN or CAD at the rate of exchange whichisineffect
at the place and on the date of shipment) for USED or RECONDITIONED articles. For availability and limits
of excess liability coverage and applicable rates and charges, please refer to FXF 100 Series Rules Tariff. Not
selecting an additional coverage option is considered to be a waiver of same and standard liability coverage
will apply.
☐
Articles are NEW, and require Excess Liability Coverage in the amount of
☐
USD
☐
CAD

☐
Articlesare USED or RECONDITIONED and require Excess Liability Coverage. Additional charges will apply.
MXN per
☐
lb. or
☐
g. Additional charges willapply.
☐
NOTE (3) Commodities requiring special or additional care or attention in handling or stowing must be so
marked and packaged as to ensure safe transportation with ordinary care. See Sec. 2(e) of NMFCItem 360.

Create your next Bill of Lading online at fedex.com/us/freight/main/

<!-- PageBreak -->

<!-- PageHeader="Missing Image D6656024" -->
