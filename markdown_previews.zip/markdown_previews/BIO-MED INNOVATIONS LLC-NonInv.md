# BIO-MED INNOVATIONS LLC-NonInv.pdf

<figure>

NEW ENGLAND
MEDWØSTE

DATA DESTRUCTION SERVICES

</figure>


Regulated Medical Waste

UN3291, Regulated Medical Waste, n.o.s., 6.2, PGII

<!-- PageNumber="Page: 1 of 2" -->

MANIFEST #
9393545

CODE AREA


<table>
<tr>
<td rowspan="5">GENERATOR</td>
<td>COMPANY NAME Verve Therapeutics, Inc - Brookline 664552</td>
<td colspan="2">TELEPHONE NUMBER (617) 803-0070</td>
</tr>
<tr>
<td colspan="3">ADDRESS 201 Brookline Ave Boston, MA 02215</td>
</tr>
<tr>
<td colspan="3">I certify that the information provided is true and correct, and that the generated materials are properly classified, described, packaged, labeled/placarded; and are in proper condition for transportation according to the applicable regulations of the U.S. Department of Transportation.</td>
</tr>
<tr>
<td colspan="2">MIKE HOULE M ☒</td>
<td>01-30-2026 3:11 PM</td>
</tr>
<tr>
<td colspan="2">NAME OF COMPANY REPRESENTATIVE (Print) SIGNATURE OF REPRESENTATIVE</td>
<td>DATE</td>
</tr>
</table>


<table>
<tr>
<th>NAME(S) OF PERSONS COLLECTING, TRANSPORTING OR UNLOADING WASTE Christine E Tighe</th>
<th>INITIALS CET</th>
<th>REGISTRATION NUMBER</th>
</tr>
<tr>
<td>COMPANY NAME New England MedWaste</td>
<td></td>
<td>TELEPHONE NUMBER (800) 611-4930</td>
</tr>
<tr>
<td>ADDRESS 30 Log Bridge Road Middleton, MA 01949</td>
<td></td>
<td>DATE MEDICAL WASTE COLLECTED 01-30-2026 3:11 PM</td>
</tr>
</table>


<table>
<tr>
<th colspan="2">4.5 CF Box RMW UN3291</th>
<th colspan="2">17 Gal Sharps UN3291</th>
<th colspan="2"></th>
<th colspan="2"></th>
</tr>
<tr>
<th rowspan="2"># cont. 27</th>
<th>wt. #</th>
<th># cont.</th>
<th>wt. #</th>
<th># cont.</th>
<th>wt. #</th>
<th># cont. wt. #</th>
<th># cont. wt. #</th>
</tr>
<tr>
<td>608</td>
<td>9</td>
<td>167</td>
<td></td>
<td></td>
<td colspan="2"></td>
</tr>
</table>


I certify that the information provided above is true and correct and that only untreated medical wastes are contained in this load. I am aware that
falsification of this manifest may result in forfeiture of my transporter's registration and/or the privilege of utilizing State-authorized facilities.

☒

01-30-2026 3:11 PM

NAME OF COMPANY REPRESENTATIVE (Print)

SIGNATURE OF REPRESENTATIVE

DATE

TRANSFER STATION: NAME

REGISTRATION NUMBER

TRANSFER STATION / TRANSPORTER 2


<table>
<tr>
<th>NAME(S) OF PERSONS COLLECTING, TRANSPORTING OR UNLOADING WASTE</th>
<th>INITIALS</th>
<th>REGISTRATION NUMBER</th>
</tr>
<tr>
<td>COMPANY NAME</td>
<td></td>
<td>TELEPHONE NUMBER</td>
</tr>
<tr>
<td>ADDRESS</td>
<td></td>
<td>DATE MEDICAL WASTE COLLECTED</td>
</tr>
</table>


\# cont.

wt. #

\# cont.

wt. #

\# cont.

wt. #

\# cont.

wt. #

\# cont.

wt. #

I certify that the information provided above is true and correct and that only untreated medical wastes are contained in this load. I am aware that
falsification of this manifest may result in forfeiture of my transporter's registration and/or the privilege of utilizing State-authorized facilities.

NAME OF COMPANY REPRESENTATIVE (Print)

SIGNATURE OF REPRESENTATIVE

DATE


<table>
<tr>
<th rowspan="6">TREATMENT FACILITY</th>
<th colspan="2">COMPANY NAME Bio-Med Innovations LLC</th>
<th>TELEPHONE NUMBER (800) 611-4930</th>
</tr>
<tr>
<td colspan="3">ADDRESS 30 Log Bridge Road, Middleton, MA 01949</td>
</tr>
<tr>
<td>PERMIT NUMBER 603136</td>
<td>DATE WASTE WAS DEPOSITED/UNLOADED</td>
<td>TOTAL WEIGHT DEPOSITED/UNLOADED</td>
</tr>
<tr>
<td>DISCREPANCY INDICATION SPACE</td>
<td></td>
<td></td>
</tr>
<tr>
<td>I certify that I have been authorized to accept untreated requirements outlined in that authorization.</td>
<td>medical wastes and that I have received the</td>
<td>above indicated wastes in accordance with the</td>
</tr>
<tr>
<td>NAME OF COMPANY REPRESENTATIVE (Print)</td>
<td colspan="2">SIGNATURE OF REPRESENTATIVE DATE</td>
</tr>
</table>


In case of emergency, call (
800
)
424-9300

(24-hr company or other emergency response group telephone)

PRIMARY TRANSPORTER

Christine E Tighe

<!-- PageBreak -->

<!-- PageNumber="Page: 2 of 2 MANIFEST # 9393545" -->


<table>
<tr>
<td rowspan="4">PRIMARY TRANSPORTER</td>
<td>NAME(S) OF PERSONS COLLECTING, TRANSPORTING OR UNLOADING WASTE Christine E Tighe</td>
<td>INITIALS CET</td>
<td>REGISTRATION NUMBER</td>
</tr>
<tr>
<td>COMPANY NAME New England MedWaste</td>
<td></td>
<td>TELEPHONE NUMBER (800) 611-4930</td>
</tr>
<tr>
<td>ADDRESS 30 Log Bridge Road Middleton, MA 01949</td>
<td></td>
<td>DATE MEDICAL WASTE COLLECTED 01-30-2026 3:11 PM</td>
</tr>
<tr>
<td>MANIFEST NOTES MW165655</td>
<td></td>
<td></td>
</tr>
</table>


<table>
<tr>
<td rowspan="5">TRANSFER STATION / TRANSP</td>
<td>NAME(S) OF PERSONS COLLECTING, TRANSPORTING OR UNLOADING WASTE</td>
<td>INITIALS</td>
<td>REGISTRATION NUMBER</td>
</tr>
<tr>
<td>COMPANY NAME</td>
<td></td>
<td>TELEPHONE NUMBER</td>
</tr>
<tr>
<td>ADDRESS</td>
<td></td>
<td>DATE MEDICAL WASTE RECEIVED</td>
</tr>
<tr>
<td colspan="3">I certify that the information provided above is true and correct and that only untreated medical wastes are contained in this load. I am aware that falsification of this manifest may result in forfeiture of my transporter's registration and/or the privilege of utilizing State-authorized facilities.</td>
</tr>
<tr>
<td>NAME OF COMPANY REPRESENTATIVE (Print) SIGNATURE</td>
<td>OF REPRESENTATIVE</td>
<td>DATE</td>
</tr>
</table>


<table>
<tr>
<td rowspan="5">TRANSFER STATION / TRANSP</td>
<td>NAME(S) OF PERSONS COLLECTING, TRANSPORTING OR UNLOADING WASTE</td>
<td>INITIALS</td>
<td>REGISTRATION NUMBER</td>
</tr>
<tr>
<td>COMPANY NAME</td>
<td></td>
<td>TELEPHONE NUMBER</td>
</tr>
<tr>
<td>ADDRESS</td>
<td></td>
<td>DATE MEDICAL WASTE RECEIVED</td>
</tr>
<tr>
<td colspan="3">I certify that the information provided above is true and correct and that only untreated medical wastes are contained in this load. I am aware that falsification of this manifest may result in forfeiture of my transporter's registration and/or the privilege of utilizing State-authorized facilities.</td>
</tr>
<tr>
<td>NAME OF COMPANY REPRESENTATIVE (Print) SIGNATURE</td>
<td>OF REPRESENTATIVE</td>
<td>DATE</td>
</tr>
</table>


TRANSFER STATION / TRANSP


<table>
<tr>
<th>NAME(S) OF PERSONS COLLECTING, TRANSPORTING OR UNLOADING WASTE</th>
<th>INITIALS</th>
<th>REGISTRATION NUMBER</th>
</tr>
<tr>
<td>COMPANY NAME</td>
<td></td>
<td>TELEPHONE NUMBER</td>
</tr>
<tr>
<td>ADDRESS</td>
<td></td>
<td>DATE MEDICAL WASTE RECEIVED</td>
</tr>
</table>


I certify that the information provided above is true and correct and that only untreated medical wastes are contained in this load. I am aware that
falsification of this manifest may result in forfeiture of my transporter's registration and/or the privilege of utilizing State-authorized facilities.

NAME OF COMPANY REPRESENTATIVE (Print)

SIGNATURE OF REPRESENTATIVE

DATE


<table>
<tr>
<td rowspan="3">OR DESTRUCTION</td>
<td colspan="2">COMPANY NAME</td>
<td>TELEPHONE NUMBER</td>
</tr>
<tr>
<td>ADDRESS</td>
<td></td>
<td></td>
</tr>
<tr>
<td>PERMIT NUMBER</td>
<td>DATE WASTE WAS TREATED OR DESTROYED</td>
<td>TOTAL WEIGHT TREATED OR DESTROYED</td>
</tr>
<tr>
<td rowspan="2">TREATMENT</td>
<td colspan="3">I certify that the waste associated with this manifest has been treated or destroyed.</td>
</tr>
<tr>
<td>NAME OF COMPANY REPRESENTATIVE (Print)</td>
<td>SIGNATURE OF REPRESENTATIVE</td>
<td>DATE</td>
</tr>
</table>
