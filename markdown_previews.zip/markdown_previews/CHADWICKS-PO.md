# CHADWICKS-PO.pdf

<figure>

CHADWICKS
LET'S GET IT DONE

</figure>


The Panelling Centre
kitchens appliances wardrobes

E & I ENGINEERING LTD
BALLYDEROWEN
BURNFOOT
CO. DONEGAL

Goods Delivered
LISNENNAN
KILTOY
LETTERKENNY
F92YF40

CHADWICKS
Port Road Letterkenny CO. DONEGAL
Phone 074 9121055 Email: creditcontroller20@chadwicks.ie


# INVOICE


<table>
<tr>
<td>Account No.</td>
<td>260572</td>
</tr>
<tr>
<td>Page</td>
<td>1 of 1</td>
</tr>
<tr>
<td>Date</td>
<td>22/1/26 02:24 PM</td>
</tr>
<tr>
<td>Salesperson</td>
<td>KIERAN CARLIN</td>
</tr>
<tr>
<td>Job Reference</td>
<td>LISNENNAN KILTOY</td>
</tr>
<tr>
<td>Order Number</td>
<td>14075036565 REV</td>
</tr>
<tr>
<td>LPD Number</td>
<td>31442</td>
</tr>
<tr>
<td>Quotation Number</td>
<td>LISNENNAN KILTOY</td>
</tr>
</table>


Invoice Number LY190374


<table>
<tr>
<th>ITEM</th>
<th>QTY</th>
<th>UNIT</th>
<th>DESCRIPTION</th>
<th>UNIT EXCL. VAT</th>
<th>TOTAL EXCL. VAT</th>
<th>TOTAL INCL. VAT</th>
<th>VAT CODE</th>
</tr>
<tr>
<td>14738</td>
<td>30.00</td>
<td>LENGTH</td>
<td>4.8M 100X75 ROUGH WHITE DEAL FSC Mix 70% NQA-COC-006596</td>
<td>12.78</td>
<td>383.40</td>
<td>383.40</td>
<td>4</td>
</tr>
<tr>
<td>10101</td>
<td>1.00</td>
<td>EACH</td>
<td>CARRIAGE - DELIVERY CHARGE</td>
<td>20.33</td>
<td>20.33</td>
<td>20.33</td>
<td>4</td>
</tr>
</table>


<table>
<tr>
<td colspan="2">Vat Code 4 @ 0%</td>
</tr>
<tr>
<td>Value Ex. Vat</td>
<td>403.73</td>
</tr>
<tr>
<td colspan="2">Vat Amount 0.00</td>
</tr>
<tr>
<td colspan="2">Total 403.73</td>
</tr>
</table>


<table>
<tr>
<td>Total Excl. VAT:</td>
<td>403.73</td>
</tr>
<tr>
<td>VAT:</td>
<td>0.00</td>
</tr>
<tr>
<td>Total Incl. VAT:</td>
<td>EURO 403.73</td>
</tr>
</table>


Registered Office: c/o Grafton Group plc, The Hive, Carmanhall Road, Sandyford Business Park, Dublin 18, D18 Y2C9, Ireland.
Registered Number 3510 VAT REG. No. IE8Q53150B WEEE No. 2572W
