# ALLIANCE LAUNDRY SYSTEMS LLC-Credit.pdf

<!-- PageNumber="Page 1 of 3" -->


# CREDIT MEMO


<figure>

I
Alliance"
Laundry Systems

</figure>


Genuine Parts

Ship To : 100675
MARCONE APPLIANCE PARTS CO
PO BOX 411520
SAINT LOUIS MO
63141

PO Box 990, Shepard Street
Ripon, WI 54971, USA
T | +1 920 748 3121

Invoice To : 100675

MARCONE APPLIANCE PARTS CO

PO BOX 411520

SAINT LOUIS MO

63141


<table>
<tr>
<th>Due Date</th>
<th>Invoice No.</th>
</tr>
<tr>
<td>02/27/2026</td>
<td>7001503961</td>
</tr>
</table>


Please Include Account No. & Invoice No. on Your Remittance. Payable in

USD Funds. Please remit to:

ALLIANCE LAUNDRY SYSTEMS, LLC

PO BOX 775826

CHICAGO IL 60677-5826

Terms

VIA

NET-30

Parts (SP)

PARTS MANAGER


<table>
<tr>
<th>Order No.</th>
<th>Order Date</th>
<th>Sales No.</th>
<th>Incoterms 2010</th>
<th>B/L #</th>
<th>Date</th>
</tr>
<tr>
<td>2559779</td>
<td>01/28/2026</td>
<td>61533343</td>
<td>Prepaid and Add</td>
<td></td>
<td>01/28/2026</td>
</tr>
</table>


<table>
<tr>
<th colspan="2">Quantity</th>
<th colspan="2" rowspan="2">Model Number / Description</th>
<th rowspan="2">List</th>
<th colspan="2">Prices USD</th>
</tr>
<tr>
<th>Ordered</th>
<th>Shipped</th>
<th>Net</th>
<th>Extended</th>
</tr>
<tr>
<td>1.00</td>
<td>1.00</td>
<td colspan="2">36437</td>
<td>6.25</td>
<td>3.12</td>
<td>3.12</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">HINGE LID-RIGHT</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Handling Discount</td>
<td></td>
<td>0.62</td>
<td>0.62</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Model# :AWN632SP116TW02 : 2305033675- Reference: Invoice: 70871079</td>
<td>Serial# 12394;</td>
<td></td>
<td></td>
</tr>
<tr>
<td>1.00</td>
<td>1.00</td>
<td colspan="2">36513</td>
<td>13.07</td>
<td>6.53</td>
<td>6.53</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">HINGE LID-LEFT STOP</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Handling Discount</td>
<td></td>
<td>1.31</td>
<td>1.31</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Model# :AWN632SP116TW02 : 2305033675- Reference: Invoice: 70871079</td>
<td>Serial# 12394;</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageFooter="*Customer agrees that past due receivables may incur interest at a rate of 1% per month or the highest amount allowable under applicable law" -->
<!-- PageBreak -->

<!-- PageNumber="Page 2 of 3" -->


## CREDIT MEMO


<figure>

I
Alliance"
Laundry Systems

</figure>


Genuine Parts

Ship To : 100675
MARCONE APPLIANCE PARTS CO
PO BOX 411520
SAINT LOUIS MO
63141

PO Box 990, Shepard Street
Ripon, WI 54971, USA
T | +1 920 748 3121

Invoice To : 100675

MARCONE APPLIANCE PARTS CO

PO BOX 411520

SAINT LOUIS MO

63141


<table>
<tr>
<th>Due Date</th>
<th>Invoice No.</th>
</tr>
<tr>
<td>02/27/2026</td>
<td>7001503961</td>
</tr>
</table>


Please Include Account No. & Invoice No. on Your Remittance. Payable in

USD Funds. Please remit to:

ALLIANCE LAUNDRY SYSTEMS, LLC

PO BOX 775826

CHICAGO IL 60677-5826

Terms

VIA

NET-30

Parts (SP)

PARTS MANAGER


<table>
<tr>
<th>Order No.</th>
<th>Order Date</th>
<th>Sales No.</th>
<th>Incoterms 2010</th>
<th>B/L #</th>
<th>Date</th>
</tr>
<tr>
<td>2559779</td>
<td>01/28/2026</td>
<td>61533343</td>
<td>Prepaid and Add</td>
<td></td>
<td>01/28/2026</td>
</tr>
</table>


<table>
<tr>
<th colspan="2">Quantity</th>
<th rowspan="2">Model</th>
<th rowspan="2">Number / Description</th>
<th rowspan="2">List</th>
<th colspan="2">Prices USD</th>
</tr>
<tr>
<th>Ordered</th>
<th>Shipped</th>
<th>Net</th>
<th>Extended</th>
</tr>
<tr>
<td>2.00</td>
<td>2.00</td>
<td>33446</td>
<td></td>
<td>5.39</td>
<td>2.70</td>
<td>5.39</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">BUSHING HINGE-LID</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Handling Discount</td>
<td></td>
<td>0.54</td>
<td>1.08</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Model# :AWN632SP116TW02 : 2305033675- Reference: Invoice: 70871079</td>
<td>Serial# 12394;</td>
<td></td>
<td></td>
</tr>
<tr>
<td>2.00</td>
<td>2.00</td>
<td>21685</td>
<td></td>
<td>5.39</td>
<td>2.70</td>
<td>5.39</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">BUMPER, LID</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Handling Discount</td>
<td></td>
<td>0.54</td>
<td>1.08</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2">Model# :AWN632SP116TW02 : 2305033675- Reference: Invoice: 70871079</td>
<td>Serial# 12394;</td>
<td></td>
<td></td>
</tr>
<tr>
<td>Pro Number</td>
<td>:</td>
<td></td>
<td>Seal Number:</td>
<td>Container</td>
<td>ID:</td>
<td></td>
</tr>
</table>


<!-- PageFooter="*Customer agrees that past due receivables may incur interest at a rate of 1% per month or the highest amount allowable under applicable law" -->
<!-- PageBreak -->

<!-- PageNumber="Page 3 of 3" -->


## CREDIT MEMO


<figure>

I
Alliance"
Laundry Systems

</figure>


Genuine Parts

Ship To : 100675
MARCONE APPLIANCE PARTS CO
PO BOX 411520
SAINT LOUIS MO
63141

PO Box 990, Shepard Street
Ripon, WI 54971, USA
T | +1 920 748 3121

Invoice To : 100675

MARCONE APPLIANCE PARTS CO

PO BOX 411520

SAINT LOUIS MO

63141


<table>
<tr>
<th>Due Date</th>
<th>Invoice No.</th>
</tr>
<tr>
<td>02/27/2026</td>
<td>7001503961</td>
</tr>
</table>


Please Include Account No. & Invoice No. on Your Remittance. Payable in

USD Funds. Please remit to:

ALLIANCE LAUNDRY SYSTEMS, LLC

PO BOX 775826

CHICAGO IL 60677-5826

Terms

VIA

NET-30

Parts (SP)

PARTS MANAGER


<table>
<tr>
<th>Order No.</th>
<th>Order Date</th>
<th>Sales No.</th>
<th>Incoterms 2010</th>
<th>B/L #</th>
<th>Date</th>
</tr>
<tr>
<td>2559779</td>
<td>01/28/2026</td>
<td>61533343</td>
<td>Prepaid and Add</td>
<td></td>
<td>01/28/2026</td>
</tr>
</table>


<table>
<tr>
<th colspan="2">Quantity</th>
<th rowspan="2">Model Number</th>
<th rowspan="2">/ Description</th>
<th rowspan="2">List</th>
<th colspan="2">Prices USD</th>
</tr>
<tr>
<th>Ordered</th>
<th>Shipped</th>
<th>Net</th>
<th>Extended</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2">CREDIT MEMO - DO NOT PAY</td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="3" rowspan="2">Service Partner: PATRICK HOEBELHEINRICH HOEBELHEINRICH ARC LLC 115 1ST AVE SW</td>
<td></td>
<td rowspan="2"></td>
<td rowspan="2"></td>
<td rowspan="2"></td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td>LE MARS USA</td>
<td colspan="2">IA 51031</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<table>
<tr>
<td>6.00</td>
<td>6.00</td>
</tr>
<tr>
<td>Total</td>
<td>Units</td>
</tr>
</table>


24.52 USD

Net Amount

<!-- PageFooter="*Customer agrees that past due receivables may incur interest at a rate of 1% per month or the highest amount allowable under applicable law" -->
