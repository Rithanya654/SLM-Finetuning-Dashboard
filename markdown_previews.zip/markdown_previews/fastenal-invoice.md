# fastenal-invoice.pdf

FASTENAL®
®


<table>
<tr>
<td>Cust. No. Cust. P.O.</td>
<td>CATUR1058</td>
</tr>
<tr>
<td>Job No.</td>
<td>1204403</td>
</tr>
<tr>
<td>Contract No.</td>
<td></td>
</tr>
</table>


Sold To

HILMAR CHEESE VENDING (HILMAR)

9001 LANDER AVE

HILMAR, CA 95324

Remit to

Fastenal Company

P.O. Box 1286

Winona, MN 55987-1286


<table>
<tr>
<td>Phone</td>
<td>209/669-6910</td>
</tr>
<tr>
<td>Fax</td>
<td>209/669-6913</td>
</tr>
</table>


INVOICE

<!-- PageNumber="Page 1 of 3" -->


<table>
<tr>
<th>Invoice Date</th>
<th>Invoice No.</th>
</tr>
<tr>
<td>01/30/2026</td>
<td>CATUR203542</td>
</tr>
</table>


<table>
<tr>
<th>For billing questions</th>
<th></th>
<th rowspan="2">Invoice Total</th>
</tr>
<tr>
<th colspan="2">2350 N Walnut Rd</th>
</tr>
<tr>
<td colspan="2">TURLOCK, CA 95382</td>
<td>4,530.61 USD</td>
</tr>
</table>


Final Due Date

(NET45) 03/16/2026

Ship To

HILMAR CHEESE VENDING (HILMAR)

9001 N LANDER AVE

HILMAR, CA 95324

This Order and Document is subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line No</th>
<th>Quantity Ordered</th>
<th>Quantity Shipped</th>
<th></th>
<th>Backordered Quantity</th>
<th>Description</th>
<th>Control No.</th>
<th>Part No.</th>
<th>Price / Hundred</th>
<th>Amount</th>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td colspan="2">1204403 09645</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1</td>
<td>13</td>
<td colspan="2">13</td>
<td>0</td>
<td>18629 Clr MonoGoggle</td>
<td>240318014</td>
<td>1040318</td>
<td>1,694.8000</td>
<td>220.32 T</td>
</tr>
<tr>
<td>2</td>
<td>4</td>
<td>4</td>
<td></td>
<td>0</td>
<td>18629 Clr MonoGoggle</td>
<td>240316856</td>
<td>1040318</td>
<td>1,694.8000</td>
<td>67.79 T</td>
</tr>
<tr>
<td>3</td>
<td>5</td>
<td>5</td>
<td></td>
<td>0</td>
<td>18629 Clr MonoGoggle</td>
<td>240319901</td>
<td>1040318</td>
<td>1,694.8000</td>
<td>84.74 T</td>
</tr>
<tr>
<td>4</td>
<td>24</td>
<td>24</td>
<td></td>
<td>0</td>
<td>L 37-175SolVexPrVP</td>
<td>132200</td>
<td>1000722V01</td>
<td>271.3600</td>
<td>65.13 T</td>
</tr>
<tr>
<td>5</td>
<td>3</td>
<td>3</td>
<td></td>
<td>0</td>
<td>L 2076GM</td>
<td>TKCA23141</td>
<td>921731214</td>
<td>1,000.0000</td>
<td>30.00 T</td>
</tr>
<tr>
<td>6</td>
<td>7</td>
<td>7</td>
<td></td>
<td>0</td>
<td>M 37-175SolVexPrVP</td>
<td>132200</td>
<td>1000721V01</td>
<td>271.3600</td>
<td>19.00 T</td>
</tr>
<tr>
<td>7</td>
<td>1</td>
<td>1</td>
<td></td>
<td>0</td>
<td>2XL 37-175SolVexPrVP</td>
<td>132200</td>
<td>1000724V01</td>
<td>271.3600</td>
<td>2.71 T</td>
</tr>
<tr>
<td>8</td>
<td>4</td>
<td>4</td>
<td></td>
<td>0</td>
<td>M 2076GM</td>
<td>TKCA23367</td>
<td>921731217</td>
<td>1,000.0000</td>
<td>40.00 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td colspan="3">1204403 09657</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>9</td>
<td>4</td>
<td colspan="2">4</td>
<td>0</td>
<td>XL 37-175SolVexPrVP</td>
<td>132200</td>
<td>1000723V01</td>
<td>271.3600</td>
<td>10.85 T</td>
</tr>
<tr>
<td>10</td>
<td>2</td>
<td>2</td>
<td></td>
<td>0</td>
<td>M6/7 PAMInsolePR</td>
<td>131930</td>
<td>1052626</td>
<td>2,065.7700</td>
<td>41.32 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td colspan="2">1204403 10013</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>11</td>
<td>5</td>
<td>5</td>
<td></td>
<td>0</td>
<td>White HDPE 4P P Cap</td>
<td>131930</td>
<td>1092253</td>
<td>775.2200</td>
<td>38.76 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td colspan="2">1204403 10062</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>12</td>
<td>21</td>
<td>21</td>
<td></td>
<td>0</td>
<td>A1GA6 Dp GLV100Ct XL</td>
<td>TKCA23236</td>
<td>924322628</td>
<td>925.0000</td>
<td>194.25 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td colspan="3">1204403 10345</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>13</td>
<td>34</td>
<td>34</td>
<td></td>
<td>0</td>
<td>A1GA6 Dp GLV100Ct LG</td>
<td>TKCA23238</td>
<td>924322638</td>
<td>925.0000</td>
<td>314.50 T</td>
</tr>
<tr>
<td>14</td>
<td>10</td>
<td>10</td>
<td></td>
<td>0</td>
<td>Metal Detectable Pen</td>
<td>TKCAK0032</td>
<td>924414753</td>
<td>269.1800</td>
<td>26.92 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td colspan="2">1204403 10372</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>15</td>
<td>18</td>
<td>18</td>
<td></td>
<td>0</td>
<td>Permanent Marker Ret</td>
<td>TKCAK0021</td>
<td>923712918</td>
<td>544.6400</td>
<td>98.04 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td colspan="2">1204403 11585</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>16</td>
<td>36</td>
<td>36</td>
<td></td>
<td>0</td>
<td>AA Procell Alk Btry</td>
<td>142711</td>
<td>0215008</td>
<td>44.5600</td>
<td>16.04 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td colspan="2">1204403 11646</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>17</td>
<td>12</td>
<td colspan="2" rowspan="2">12 1204403 11977</td>
<td>0</td>
<td>A13MHM-1.5-S Clamp</td>
<td>TKCA23349</td>
<td>4205814</td>
<td>765.8900</td>
<td>91.91 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>18</td>
<td>12</td>
<td>12</td>
<td></td>
<td>0</td>
<td>DETECTABLE WHITEBOAR</td>
<td>TKCAK0012</td>
<td>10953-03491</td>
<td>374.8700</td>
<td>44.98 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td colspan="2">1204403 12553</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>19</td>
<td>2</td>
<td>2</td>
<td></td>
<td>0</td>
<td>9 Knee Boot</td>
<td>TKCA23203</td>
<td>99561941</td>
<td>9,039.3000</td>
<td>180.79 T</td>
</tr>
<tr>
<td>20</td>
<td>10</td>
<td>10</td>
<td></td>
<td>0</td>
<td>1/4 x1/4 M NPTConn</td>
<td>131692</td>
<td>442065</td>
<td>405.6000</td>
<td>40.56 T</td>
</tr>
<tr>
<td>21</td>
<td>25</td>
<td>25</td>
<td></td>
<td>0</td>
<td>1/4 x1/8 M NPTConn</td>
<td>131692</td>
<td>442064</td>
<td>451.3900</td>
<td>112.85 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td colspan="3">1204403 12567</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>22</td>
<td>1</td>
<td>1</td>
<td></td>
<td>0</td>
<td>11 Knee Boot</td>
<td>TKCA22900</td>
<td>99561943</td>
<td>9,039.3000</td>
<td>90.39 T</td>
</tr>
<tr>
<td>23</td>
<td>3</td>
<td>3</td>
<td></td>
<td>0</td>
<td>M12/13 PAMInslPR</td>
<td>240316363</td>
<td>1052629</td>
<td>2,065.7700</td>
<td>61.97 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td colspan="2">1204403 12576</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>24</td>
<td>1</td>
<td>1</td>
<td></td>
<td>0</td>
<td>A13MHM-3-S Clamp</td>
<td>TKCA23142</td>
<td>4205817</td>
<td>1,146.6300</td>
<td>11.47 T</td>
</tr>
<tr>
<td>25</td>
<td>1</td>
<td>1</td>
<td></td>
<td>0</td>
<td>A13MHM-4-S Clamp</td>
<td>TKCA23543</td>
<td>4205818</td>
<td>1,444.7200</td>
<td>14.45 T</td>
</tr>
<tr>
<td>26</td>
<td>1</td>
<td>1</td>
<td></td>
<td>0</td>
<td>GASKET 2 IN,BLK FKM,</td>
<td>TBCA2732</td>
<td>10953-03793</td>
<td>799.9400</td>
<td>8.00 T</td>
</tr>
<tr>
<td>27</td>
<td>1</td>
<td>1</td>
<td></td>
<td>0</td>
<td>GASKET 2 IN,BLK FKM,</td>
<td>TBCA3593</td>
<td>10953-03793</td>
<td>799.9400</td>
<td>8.00 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td colspan="2">1204403 12716</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>28</td>
<td>1</td>
<td>1</td>
<td></td>
<td>0</td>
<td>10 Knee Boot</td>
<td>140117</td>
<td>99561942</td>
<td>9,328.6200</td>
<td>93.29 T</td>
</tr>
<tr>
<td>29</td>
<td>3</td>
<td>3</td>
<td></td>
<td>0</td>
<td>M10/11 PAMInslPR</td>
<td>131930</td>
<td>1052628</td>
<td>1,950.1400</td>
<td>58.50 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td colspan="2">1204403 13110</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

FASTENAL®
®


<table>
<tr>
<td>Cust. No. Cust. P.O.</td>
<td>CATUR1058</td>
</tr>
<tr>
<td>Job No.</td>
<td>1204403</td>
</tr>
<tr>
<td>Contract No.</td>
<td></td>
</tr>
</table>


Sold To

HILMAR CHEESE VENDING (HILMAR)

9001 LANDER AVE

HILMAR, CA 95324

Remit to

Fastenal Company

P.O. Box 1286

Winona, MN 55987-1286


<table>
<tr>
<td>Phone</td>
<td>209/669-6910</td>
</tr>
<tr>
<td>Fax</td>
<td>209/669-6913</td>
</tr>
</table>


INVOICE

<!-- PageNumber="Page 2 of 3" -->


<table>
<tr>
<th>Invoice Date</th>
<th>Invoice No.</th>
</tr>
<tr>
<td>01/30/2026</td>
<td>CATUR203542</td>
</tr>
</table>


<table>
<tr>
<th>For billing questions</th>
<th></th>
<th rowspan="2">Invoice Total</th>
</tr>
<tr>
<th colspan="2">2350 N Walnut Rd</th>
</tr>
<tr>
<td colspan="2">TURLOCK, CA 95382</td>
<td>4,530.61 USD</td>
</tr>
</table>


Final Due Date

(NET45) 03/16/2026

Ship To

HILMAR CHEESE VENDING (HILMAR)

9001 N LANDER AVE

HILMAR, CA 95324

This Order and Document is subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line No</th>
<th>Quantity Ordered</th>
<th>Quantity Shipped</th>
<th></th>
<th>Backordered Quantity</th>
<th>Description</th>
<th>Control No.</th>
<th>Part No.</th>
<th>Price / Hundred</th>
<th>Amount</th>
</tr>
<tr>
<td>30</td>
<td>4</td>
<td>4</td>
<td></td>
<td>0</td>
<td>AAA Procell Alk Btry</td>
<td>142711</td>
<td>0215010</td>
<td>48.5600</td>
<td>1.94 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td colspan="2">1204403 13146</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>31</td>
<td>12</td>
<td>12</td>
<td></td>
<td>0</td>
<td>BWSRflRlSS10005P90Ct</td>
<td>TKCA23237</td>
<td>0624537</td>
<td>1,193.9800</td>
<td>143.28 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td colspan="2">1204403 13191</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>32</td>
<td>3</td>
<td>3</td>
<td></td>
<td>0</td>
<td>8801250 Pliers</td>
<td>135061</td>
<td>0255730</td>
<td>3,110.0000</td>
<td>93.30 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td>1204403</td>
<td>13332</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>33</td>
<td>17</td>
<td>17</td>
<td></td>
<td>0</td>
<td>Metal Detectable Pen</td>
<td>TKCAK0038</td>
<td>924414753</td>
<td>269.1800</td>
<td>45.76 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td>1204403</td>
<td>13788</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>34</td>
<td>2</td>
<td>2</td>
<td></td>
<td>0</td>
<td>18629 Clr MonoGoggle</td>
<td>240315091</td>
<td>1040318</td>
<td>1,694.8000</td>
<td>33.90 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td>1204403</td>
<td>13800</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>35</td>
<td>10</td>
<td>10</td>
<td></td>
<td>0</td>
<td>MD Ntrl DG Glv 100ct</td>
<td>TKCA23238</td>
<td>924672024</td>
<td>925.0000</td>
<td>92.50 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td>1204403</td>
<td>14208</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>36</td>
<td>30</td>
<td>30</td>
<td></td>
<td>0</td>
<td>1/4 Union</td>
<td>131692</td>
<td>442019</td>
<td>409.9500</td>
<td>122.99 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td>1204403</td>
<td>14214</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>37</td>
<td>1</td>
<td>1</td>
<td></td>
<td>0</td>
<td>XL 2076GM</td>
<td>TKCA23367</td>
<td>921731213</td>
<td>1,000.0000</td>
<td>10.00 T</td>
</tr>
<tr>
<td>38</td>
<td>15</td>
<td>15</td>
<td colspan="2">0</td>
<td>1/4x1/8MNPTMElbow</td>
<td>131692</td>
<td>442035</td>
<td>370.9700</td>
<td>55.65 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td>1204403</td>
<td>14355</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>39</td>
<td>1</td>
<td>1</td>
<td></td>
<td>0</td>
<td>12 Knee Boot</td>
<td>TKCA22900</td>
<td>99561944</td>
<td>9,328.6200</td>
<td>93.29 T</td>
</tr>
<tr>
<td>40</td>
<td>1</td>
<td>1</td>
<td colspan="2">0</td>
<td>XL 2076GM</td>
<td>TKCA23241</td>
<td>921731213</td>
<td>1,000.0000</td>
<td>10.00 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td>1204403</td>
<td>14746</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>41</td>
<td>1</td>
<td>1</td>
<td></td>
<td>0</td>
<td>400-768, RED CHART P</td>
<td>TKCA22899</td>
<td>10953-04585</td>
<td>8,809.5700</td>
<td>88.10 T</td>
</tr>
<tr>
<td>42</td>
<td>2</td>
<td>2</td>
<td></td>
<td>0</td>
<td>400-772, GREEN CHART</td>
<td>TKCA23175</td>
<td>10953-04586</td>
<td>6,463.1100</td>
<td>129.26 T</td>
</tr>
<tr>
<td>43</td>
<td>2</td>
<td>2</td>
<td colspan="2">0</td>
<td>5074463D PW 60500804</td>
<td>TKCA22681</td>
<td>10953-04588</td>
<td>27,758.4000</td>
<td>555.17 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td>1204403</td>
<td>14749</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>44</td>
<td>2</td>
<td>2</td>
<td colspan="2">0</td>
<td>A13MHM-2.5-S Clamp</td>
<td>TKCA23044</td>
<td>4205815</td>
<td>1,102.5500</td>
<td>22.05 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td>1204403</td>
<td>14995</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>45</td>
<td>1</td>
<td>1</td>
<td></td>
<td>0</td>
<td>9 Knee Boot</td>
<td>TKCA22609</td>
<td>99561941</td>
<td>9,039.3000</td>
<td>90.39 T</td>
</tr>
<tr>
<td>46</td>
<td>6</td>
<td>6</td>
<td></td>
<td>0</td>
<td>A13MHM-4-S Clamp</td>
<td>TKCA23349</td>
<td>4205818</td>
<td>1,444.7200</td>
<td>86.68 T</td>
</tr>
<tr>
<td>47</td>
<td>1</td>
<td>1</td>
<td></td>
<td>0</td>
<td>A13MHM-4-S Clamp</td>
<td>TKCA23142</td>
<td>4205818</td>
<td>1,444.7200</td>
<td>14.45 T</td>
</tr>
<tr>
<td>48</td>
<td>5</td>
<td>5</td>
<td colspan="2">0</td>
<td>M8/9 PAMInsolePR</td>
<td>131930</td>
<td>1052627</td>
<td>2,065.7700</td>
<td>103.29 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td>1204403</td>
<td>15287</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>49</td>
<td>1</td>
<td>1</td>
<td></td>
<td>0</td>
<td>12.5"BkSlipFtEWRet</td>
<td>PGCA2946</td>
<td>920107297</td>
<td>292.6900</td>
<td>2.93 T</td>
</tr>
<tr>
<td>50</td>
<td>3</td>
<td>3</td>
<td></td>
<td>0</td>
<td>12.5"BkUvFtRpEWRet</td>
<td>TKCA22616</td>
<td>91137706</td>
<td>468.3000</td>
<td>14.05 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td>1204403</td>
<td>15306</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>51</td>
<td>3</td>
<td>3</td>
<td></td>
<td>0</td>
<td>A13MHM-2-S Clamp</td>
<td>TKCA23044</td>
<td>4205816</td>
<td>1,095.9400</td>
<td>32.88 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td>1204403</td>
<td>15801</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>52</td>
<td>1</td>
<td>1</td>
<td></td>
<td>0</td>
<td>KCJ1-MDStnStl Kutter</td>
<td>TKCAK0010</td>
<td>0244867</td>
<td>334.5300</td>
<td>3.35 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td>1204403</td>
<td>16506</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>53</td>
<td>3</td>
<td>3</td>
<td></td>
<td>0</td>
<td>Metal Detectable Pen</td>
<td>TKCAK0034</td>
<td>924414753</td>
<td>269.1800</td>
<td>8.08 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td>1204403</td>
<td>16529</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>54</td>
<td>15</td>
<td>15</td>
<td></td>
<td>0</td>
<td>Polyco 42580 Gown/Si</td>
<td>TKCAK0088</td>
<td>10953-03673</td>
<td>585.0000</td>
<td>87.75 T</td>
</tr>
<tr>
<td></td>
<td>Location:</td>
<td>1204403</td>
<td>16567</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>55</td>
<td>1</td>
<td>1</td>
<td></td>
<td>0</td>
<td>A13MHM-4-S Clamp</td>
<td>TKCA22955</td>
<td>4205818</td>
<td>1,444.7200</td>
<td>14.45 T</td>
</tr>
</table>


<!-- PageBreak -->

FASTENAL®
®


<table>
<tr>
<td>Cust. No.</td>
<td>CATUR1058</td>
</tr>
<tr>
<td>Cust. P.O.</td>
<td></td>
</tr>
<tr>
<td>Job No.</td>
<td>1204403</td>
</tr>
<tr>
<td>Contract No.</td>
<td></td>
</tr>
</table>


Sold To

HILMAR CHEESE VENDING (HILMAR)

9001 LANDER AVE

HILMAR, CA 95324

Remit to

Fastenal Company

P.O. Box 1286

Winona, MN 55987-1286


<table>
<tr>
<td>Phone</td>
<td>209/669-6910</td>
</tr>
<tr>
<td>Fax</td>
<td>209/669-6913</td>
</tr>
</table>


INVOICE

Page 3 of 3


<table>
<tr>
<th>Invoice Date</th>
<th>Invoice No.</th>
</tr>
<tr>
<td>01/30/2026</td>
<td>CATUR203542</td>
</tr>
</table>


<table>
<tr>
<th>For billing questions</th>
<th></th>
<th rowspan="2">Invoice Total</th>
</tr>
<tr>
<th colspan="2">2350 N Walnut Rd</th>
</tr>
<tr>
<td colspan="2">TURLOCK, CA 95382</td>
<td>4,530.61 USD</td>
</tr>
</table>


Final Due Date

(NET45) 03/16/2026

Ship To

HILMAR CHEESE VENDING (HILMAR)

9001 N LANDER AVE

HILMAR, CA 95324

This Order and Document is subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th rowspan="2">Line No</th>
<th rowspan="2">Quantity Ordered</th>
<th>Quantity</th>
<th>Quantity</th>
<th>Control</th>
<th rowspan="2">Part No.</th>
<th rowspan="2">Price / Hundred</th>
<th rowspan="2">Amount</th>
</tr>
<tr>
<th>Shipped</th>
<th>Backordered Description</th>
<th>No.</th>
</tr>
</table>


Received By
PROTEIN
Comments
Contact: Alyssa Gier

Tax Exemption


<table>
<tr>
<td>Subtotal</td>
<td>4,043.02</td>
</tr>
<tr>
<td>Shipping &amp; Handling</td>
<td>161.72</td>
</tr>
<tr>
<td>CA State Tax</td>
<td>252.29</td>
</tr>
<tr>
<td>County Tax</td>
<td>73.58</td>
</tr>
<tr>
<td>City Tax</td>
<td>0.00</td>
</tr>
<tr>
<td>Total</td>
<td>4,530.61</td>
</tr>
</table>


Reasonable collection and attorneys fees will be
assessed to all accounts placed for collection.
If you re-package or re-sell this product, you are required to maintain
integrity of Country of Origin to the consumer of this product.

No materials accepted for return without our permission.
All discrepancies must be reported within 10 days.

Please pay from this invoice.

Invoice:

CATUR203542

Cust:
CATUR1058
