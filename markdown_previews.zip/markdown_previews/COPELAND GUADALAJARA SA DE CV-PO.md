# COPELAND GUADALAJARA SA DE CV-PO.Pdf

<figure>

COPELAND

</figure>


COPELAND GUADALAJARA
ECT841227HS2
Circuito Ingeniero Tomas Limon Gutierrez 3270 Guadalajara
Colonia Higuerillas 1A Seccion
JALISCO
MX 44470

FACTURA / INVOICE

Folio

3874615


<table>
<tr>
<td>Serie:</td>
<td>A</td>
</tr>
<tr>
<td>Aprobación:</td>
<td>836491</td>
</tr>
<tr>
<td>Año Aprobación:</td>
<td>2012</td>
</tr>
<tr>
<td>Fecha / Date:</td>
<td>2026-01-21T15:41:40</td>
</tr>
<tr>
<td>No. Interior:</td>
<td>2012</td>
</tr>
</table>


<table>
<tr>
<td>Método de Pago:</td>
<td>PPD Pago en parcialidades o diferido</td>
</tr>
<tr>
<td>Plazo / Terms:</td>
<td>60</td>
</tr>
<tr>
<td>Moneda:</td>
<td>USD Dólar americano</td>
</tr>
<tr>
<td>Tipo de Cambio:</td>
<td>17.5990</td>
</tr>
<tr>
<td>Tipo de Documento:</td>
<td>FACTURA COMERCIAL</td>
</tr>
<tr>
<td>Versión CFDI:</td>
<td>4.0</td>
</tr>
<tr>
<td>USO CFDI:</td>
<td>S01 Sin efectos fiscales.</td>
</tr>
<tr>
<td>Exportación:</td>
<td>02 Definitiva con clave A1</td>
</tr>
</table>


CLIENTE / CUSTOMER
419936
COPELAND COMFORT CONTROL LP
XEXX010101000
8100 WEST FLORISSANT AVE PO BOX 36922 ST.LOUIS MO USA 63136

Num. Reg. Id Trib: 923576340
Residencia Fiscal: USA Estados Unidos (los)
Domicilio Fiscal Receptor: 44470
Régimen Fiscal Receptor: 616 Sin obligaciones fiscales

LUGAR DE ENTREGA / SHIP TO

COPELAND COMFORT CONTROL LP

1281 Joe Battle Blvd, Suite-B Tax ID# 92-3576340

EL PASO TX USA 79936

Lugar de Expedición: 44470
Régimen: 601 General de Ley Personas Morales

Forma de Pago: 99 Por definir


<table>
<tr>
<th>ZONA</th>
<th>PO CUSTOMER</th>
<th>OC CLIENTE EMERSON</th>
<th>TRANSPORTE</th>
<th>Nº EMBARQUE / SHIPMENT Nº</th>
<th>FECHA DE ENVIO / DATE</th>
</tr>
<tr>
<td></td>
<td>21712151</td>
<td>21712151_SU_00800</td>
<td>Customer Requested Carrier</td>
<td>1372500</td>
<td>2026-01-21T00:00:00</td>
</tr>
</table>


<table>
<tr>
<th colspan="2">PRODUCTO No./PART No.</th>
<th rowspan="2">DESCRIPCION DESCRIPTION</th>
<th rowspan="2">CLAVE PROD</th>
<th rowspan="2">FA HTS</th>
<th rowspan="2">UM</th>
<th rowspan="2">CANTIDAD QTY</th>
<th rowspan="2">PRECIO UNITARIO UNIT PRICE</th>
<th rowspan="2">SUBTOTAL</th>
<th rowspan="2">OBJETO IMPUESTO TAX OBJECT</th>
<th rowspan="2">IVA</th>
<th rowspan="2">TOTAL</th>
</tr>
<tr>
<th>EMERSON</th>
<th>CLIENTE /CUSTOMER</th>
</tr>
<tr>
<td>047613</td>
<td></td>
<td>EK 163 STD (VALY 1433)/LIQUID LINE FILTER DRIER/ FILTRO DESHIDRATADOR/</td>
<td>40142501</td>
<td>8421299999</td>
<td>EA</td>
<td>25</td>
<td>$ 7.18</td>
<td>179.50</td>
<td>01 No objeto de impuesto.</td>
<td>0.00</td>
<td>$ 179.50</td>
</tr>
</table>


Observaciones: DAP EL PASO, TXINCOTERMS@2010


<table>
<tr>
<td>SUBTOTAL</td>
<td>$ 179.50</td>
</tr>
<tr>
<td>DESCUENTO</td>
<td>$ 0.00</td>
</tr>
<tr>
<td>16% IVA</td>
<td>$ 0.00</td>
</tr>
<tr>
<td>Total Impuesto Retenido:</td>
<td>$ 0.00</td>
</tr>
<tr>
<td>Total Impuestos Trasladados:</td>
<td>$ 0.00</td>
</tr>
<tr>
<td>TOTAL USD</td>
<td>$ 179.50</td>
</tr>
</table>


DESTINATION CONTROL STATEMENT
These items are controlled by the U.S. Government and authorized for export only to the country of ultimate destination for use by the ultimate consignee or er
herein identified. They may not be resold, transferred, or otherwise disposed of, to any other country or to any person other than the authorized ultimate con:
end-user(s), either in their original form or after being incorporated into other items, without first obtaining approval from the US. government or asotherwise a
by U.S. law and regulations.
DECLARACION DE CONTROL DE DESTINO
Estos artículos son controlados por el gobierno de Estados Unidos y autorizados para exportacon sólo al país de destino final para su uso por el destinatario
usuario final(es) identificado en el presente documento. No pueden ser revendidos, transferidos, o cedidos de ninguna manera, a cualquier otro pas o a
persona que no sea el destinatario final autorizado o usuario finales), tampoco en la forma original p después de haber sido incorporado en otros artíci
obtener primero la aprobación del gobierno estadounidense o autorizados por las normas y leyes de Estados Unidos.

Importe con letras: CIENTO SETENTA Y NUEVE Dolares50/100USD

TOTAL DE ARTÍCULOS:

0.00

NÚMERO DE PARTIDAS:

\-

Número de Serie del Certificado: 00001000000703884320

Sello Digital Autorizado:
UrErn2MILzD5KAH0UZ2czfTOXwHhQQgQ2X53iwrKwXy0xCCDH7z8IdHjpkwYyEhKDFafX9ujOh9A2lWL+9B
bUJXEVgV6+RQEJQ9wpUFAKbXJBy+4CXdjSwf5kjtqniGIuYA8lyU9xBWKmwpUXQ7b0vd9xuyad2qvFVOzP
HZ5/6m22qdWX22AvwXfxAcWsm2Fu0l1UnVELgQZ6uJDw9R7d2xwUSZBI9PSS3zlbmiFlw0bUvOsbfELoBn
6HPh9k4Iz0s3bMgr9Nix+glx8vjhkMn3itFS8bAWPvE66s0GM2rPvVm0rneTGXoTjTEQtESZKTbtUH/+AeDsX
MffWUVLPKw ==

<!-- PageFooter="Version 1.0" -->
<!-- PageFooter="ESTE DOCUMENTO ES UNA REPRESENTACION IMPRESA DE UN CFDI" -->
<!-- PageNumber="Página 1 de 2" -->
<!-- PageBreak -->


<figure>

COPELAND

</figure>


COPELAND GUADALAJARA
ECT841227HS2
Circuito Ingeniero Tomas Limon Gutierrez 3270 Guadalajara
Colonia Higuerillas 1A Seccion
JALISCO
MX 44470

FACTURA / INVOICE

Folio 3874615


<table>
<tr>
<td>Serie:</td>
<td>A</td>
</tr>
<tr>
<td>Aprobación:</td>
<td>836491</td>
</tr>
<tr>
<td>Año Aprobación:</td>
<td>2012</td>
</tr>
<tr>
<td>Fecha / Date:</td>
<td>2026-01-21T15:41:40</td>
</tr>
<tr>
<td>No. Interior:</td>
<td>2012</td>
</tr>
</table>


<table>
<tr>
<td>Método de Pago:</td>
<td>PPD Pago en parcialidades o diferido</td>
</tr>
<tr>
<td>Plazo / Terms:</td>
<td>60</td>
</tr>
<tr>
<td>Moneda:</td>
<td>USD Dólar americano</td>
</tr>
<tr>
<td>Tipo de Cambio:</td>
<td>17.5990</td>
</tr>
<tr>
<td>Tipo de Documento:</td>
<td>FACTURA COMERCIAL</td>
</tr>
<tr>
<td>Versión CFDI:</td>
<td>4.0</td>
</tr>
<tr>
<td>USO CFDI:</td>
<td>S01 Sin efectos fiscales.</td>
</tr>
<tr>
<td>Exportación:</td>
<td>02 Definitiva con clave A1</td>
</tr>
</table>


CLIENTE / CUSTOMER
419936
COPELAND COMFORT CONTROL LP
XEXX010101000
8100 WEST FLORISSANT AVE PO BOX 36922 ST.LOUIS MO USA 63136

Num. Reg. Id Trib: 923576340

Residencia Fiscal: USA Estados Unidos (los)

Domicilio Fiscal Receptor: 44470

Régimen Fiscal Receptor: 616 Sin obligaciones fiscales

LUGAR DE ENTREGA / SHIP TO

COPELAND COMFORT CONTROL LP

1281 Joe Battle Blvd, Suite-B Tax ID# 92-3576340

EL PASO TX USA 79936

Lugar de Expedición: 44470
Régimen: 601 General de Ley Personas Morales

Forma de Pago: 99 Por definir


<table>
<tr>
<th colspan="2">ZONA</th>
<th>PO CUSTOMER</th>
<th>OC CLIENTE EMERSON</th>
<th colspan="3">TRANSPORTE</th>
<th colspan="2">Nº EMBARQUE / SHIPMENT Nº</th>
<th colspan="2">FECHA DE ENVIO / DATE</th>
</tr>
<tr>
<th colspan="2"></th>
<th>21712151</th>
<th colspan="4">21712151_SU_00800 Customer Requested Carrier</th>
<th colspan="2">1372500</th>
<th colspan="2">2026-01-21T00:00:00</th>
</tr>
<tr>
<th colspan="2">PRODUCTO No./PART No.</th>
<th rowspan="2">DESCRIPCION DESCRIPTION</th>
<th rowspan="2">CLAVE PROD FA HTS</th>
<th rowspan="2">UM</th>
<th rowspan="2">CANTIDAD QTY</th>
<th rowspan="2">PRECIO UNITARIO UNIT PRICE</th>
<th rowspan="2">SUBTOTAL</th>
<th rowspan="2">OBJETO IMPUESTO TAX OBJECT</th>
<th rowspan="2">IVA</th>
<th rowspan="2">TOTAL</th>
</tr>
<tr>
<th>EMERSON</th>
<th>CLIENTE /CUSTOMER</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="3"></td>
<td colspan="8">FOLIO FISCAL: 194A4BB4-E398-4051-83DD-3516E7B205BB</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td colspan="3">EFECTO: I Ingreso</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td colspan="3">SELLO DEL SAT:</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td colspan="7">JzGxiPa+LzRyf/qjiVv/mgn8AmjrEZfe9h+m8HnhDavpHCmZ5PncIn0XJuTaRsPfw7Y/ji5If21Lgh+AjQr/wvlJgfik+TIEcrqAIHtrR IUQMmktDnmEgbMRkbyaovJVgAgUKxN90nux3n/JGi126R2SXyt6h36+o0lwlAKhQuiX9UebIRhI31Bmhdmod+rca9xaqsOa DFdqQm7eyjv/ZPM9PRLqKICPtLVMkgflqYBrO0bDbE24eYYHsbz6R4+VVIesAIMc1/kKDZKuTwSw12kmZ28l2UqOUxh7LX gh8q3Ed3cw12n+8vB4BH1XSP/uSQITd1/b3ncUSMKqJxgITA ==</td>
<td></td>
</tr>
<tr>
<td colspan="2" rowspan="3"></td>
<td></td>
<td colspan="7">CADENA ORIGINAL DEL COMPLEMENTO DE CERTIFICACIÓN DIGITAL DEL SAT: ||1.1|194A4BB4-E398-4051-83DD-3516E7B205BB|2026-01-21T16:44:33|LEV031201SE6|UrErn2MILzD5KAH0UZ2czfTOX wHhQQgQ2X53iwrKwXy0xCCDH7z8IdHjpkwYyEhKDFafX9ujOh9A2lWL+9BbUJXEVgV6+RQEJQ9wpUFAKbXJBy+4CXdj Swf5kjtqniGIuYA8lyU9xBWKmwpUXQ7b0vd9xuyad2qvFVOzPHZ5/6m22qdWX22AvwXfxAcWsm2Fu0l1UnVELgQZ6uJDw 9R7d2xwUSZBI9PSS3zlbmiFlw0bUvOsbfELoBn6HPh9k4Iz0s3bMgr9Nix+glx8vjhkMn3itFS8bAWPvE66s0GM2rPvVm0rne TGXoTjTEQtESZKTbtUH/+AeDsXMffWUVLPKw == |00001000000712418361||</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="7">FECHA Y HORA DE CERTIFICACIÓN: 2026-01-21T16:44:33</td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">NÚMERO DE SERIE DE CSD: 00001000000712418361</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
</tr>
</table>


<!-- PageFooter="ESTE DOCUMENTO ES UNA REPRESENTACION IMPRESA DE UN CFDI" -->
<!-- PageFooter="Version 1.0" -->
<!-- PageNumber="Página 2 de 2" -->
<!-- PageBreak -->

Emisor: COPELAND GUADALAJARA

RFC: ECT841227HS2

Fecha y hora de Emisión: 2026-01-21T15:41:40

UUID: 194A4BB4-E398-4051-83DD-3516E7B205BB
Serie: A
Folio: 3874615


# COMPLEMENTO COMERCIO EXTERIOR V2.0

COMERCIO EXTERIOR

Clave de Pedimento: (A1) IMPORTACION O EXPORTACION DEFINITIVA

Certificado Origen: 0

Incoterm: (DAP) ENTREGADA EN LUGAR.

Tipo Cambio USD: 17.5990

Total USD: 179.50

DOMICILIO EMISOR

Calle: Circuito Ingeniero Tomas Limon Gutierrez

Número Exterior: 3270 Guadalajara
Colonia: (0190) Higuerillas 1a Secc
Localidad: (03) Guadalajara
Municipio: (039) Guadalajara
Estado: (JAL) Jalisco
País: (MEX) México
☒
Código Postal: 44470

RECEPTOR

Número de identificación o registro fiscal del receptor: 923576340
DOMICILIO RECEPTOR
Calle: 8100 WEST FLORISSANT AVE

Colonia: PO BOX 36922
Localidad: ST.LOUIS
Municipio: El Paso
Estado: (MO) Misuri
País: (USA) Estados Unidos (los)

Código Postal: 63136

DESTINATARIO

Número de identificación o registro fiscal del destinatario: 923576340

Nombre: COPELAND COMFORT CONTROL LP

DOMICILIO DEL DESTINATARIO

Calle: 1281 Joe Battle Blvd, Suite-B
Colonia: Tax ID# 92-3576340
Localidad: EL PASO
Municipio: EL PASO
Estado: (TX) Texas
☒
País: (USA) Estados Unidos (los)
Codigo Postal 79936


## MERCANCIAS


<table>
<tr>
<th>No. Identificación</th>
<th>Clave Fracción Arancelaria</th>
<th>Cantidad Aduana</th>
<th>Unidad Aduana</th>
<th>Valor Unitario Aduana</th>
<th>Valor Dólares</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>047613</td>
<td>(8421299999) Los demás.</td>
<td>25</td>
<td>(01) KILO</td>
<td>7.18</td>
<td>179.50</td>
</tr>
</table>


ESTE DOCUMENTO ES UNA REPRESENTACIÓN IMPRESA DE UN CFDI
Página 1 de 2 anexo al documento 194A4BB4-E398-4051-83DD-3516E7B205BB

<!-- PageNumber="v 1.2" -->
<!-- PageBreak -->

Emisor: COPELAND GUADALAJARA

UUID: 194A4BB4-E398-4051-83DD-3516E7B205BB

RFC: ECT841227HS2

Serie: A

Fecha y hora de Emisión: 2026-01-21T15:41:40

Folio: 3874615

COMPLEMENTO COMERCIO EXTERIOR V2.0


## DESCRIPCIONES ESPECÍFICAS


<table>
<tr>
<th>No. Identificación</th>
<th>Marca</th>
<th>Modelo</th>
<th>Sub Modelo</th>
<th>Número Serie</th>
</tr>
<tr>
<td>047613</td>
<td>EMERSON</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageFooter="ESTE DOCUMENTO ES UNA REPRESENTACIÓN IMPRESA DE UN CFDI Página 2 de 2 anexo al documento 194A4BB4-E398-4051-83DD-3516E7B205BB" -->
<!-- PageNumber="v 1.2" -->
