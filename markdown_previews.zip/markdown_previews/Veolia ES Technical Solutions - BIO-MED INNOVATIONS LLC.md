# Veolia ES Technical Solutions - BIO-MED INNOVATIONS LLC.pdf

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE
DATA DESTRUCTION SERVICES

</figure>


# INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 1 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/30/2026</td>
<td>AI Proteins 20 Overland Street, Boston, MA 02215</td>
<td></td>
<td>9393338</td>
<td>5</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>138.57</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>AI Proteins 20 Overland Street, Boston, MA 02215</td>
<td></td>
<td>9393338</td>
<td>5</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>36.48</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Abbott Diagnostics - 584511 14 Washington St, Scarborough, ME 04074</td>
<td></td>
<td>9381919</td>
<td>12</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>68.97</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Abi-Lab 1 - 688349 27 Strathmore Road Ste 123, Natick, MA 01760</td>
<td></td>
<td>9391754</td>
<td>4</td>
<td>43 Gal RMW UN3291 item/service</td>
<td>48.17</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


Please detach and submit the bottom portion with your payment

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949

Payment Voucher

Amount Enclosed


<table>
<tr>
<th>Invoice</th>
<th>Invoice Total</th>
<th>Due Date</th>
<th>Balance Due</th>
</tr>
<tr>
<td>24454</td>
<td>45,715.53</td>
<td>02/15/2026</td>
<td>140,534.44</td>
</tr>
</table>


☐
Check Enclosed
☐
VISA
☐
Mastercard
☐
Discover
☐
AMEX

☐
Sign Up for Autopay

New England MedWaste
30 Log Bridge Road
Ste 108 - Box 16
Middleton MA 01949

Credit Card Number

Exp. Date

Zip Code

Authorized Signature

<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE

DATA DESTRUCTION SERVICES

</figure>


# INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 2 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/30/2026</td>
<td>Abi-Lab 2 - 688351 27 Strathmore Rd Ste 158, Natick, MA 01760</td>
<td></td>
<td>9391760</td>
<td>8</td>
<td>43 Gal RMW UN3291 item/service</td>
<td>84.65</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Abi-Lab 2 - 688351 27 Strathmore Rd Ste 158, Natick, MA 01760</td>
<td></td>
<td>9375391</td>
<td>8</td>
<td>43 Gal RMW UN3291 item/service</td>
<td>81.80</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Abveris Inc Division of Twist Bioscience - 686425 1250 Hancock St 210N, Quincy, MA 02169</td>
<td></td>
<td>9390476</td>
<td>3</td>
<td>5 Gal RMW Path - UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Abveris Inc Division of Twist Bioscience - 686425 1250 Hancock St 210N, Quincy, MA 02169</td>
<td></td>
<td>9390452</td>
<td>10</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>90.06</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Abveris Inc Division of Twist Bioscience - 686425 1250 Hancock St 210N, Quincy, MA 02169</td>
<td></td>
<td>9390452</td>
<td>1</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>26.82</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Aera Therapeutics Inc 300 Technology Square, Cambridge, MA 02139</td>
<td></td>
<td>9391779</td>
<td>1</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>31.29</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Aera Therapeutics Inc 300 Technology Square, Cambridge, MA 02139</td>
<td></td>
<td>9391779</td>
<td>2</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>97.76</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Aera Therapeutics Inc 300 Technology Square, Cambridge, MA 02139</td>
<td></td>
<td>9375402</td>
<td>1</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>37.34</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE
DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 3 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/27/2026</td>
<td>Aera Therapeutics Inc 300 Technology Square, Cambridge, MA 02139</td>
<td></td>
<td>9375397</td>
<td>2</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Agios Pharmaceuticals Inc 88 Sidney St, Cambridge, MA 02139</td>
<td></td>
<td>9382077</td>
<td>2</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>53.64</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Agios Pharmaceuticals Inc 88 Sidney St, Cambridge, MA 02139</td>
<td></td>
<td>9382077</td>
<td>1</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>11.12</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Agios Pharmaceuticals Inc 88 Sidney St, Cambridge, MA 02139</td>
<td></td>
<td>9382077</td>
<td>1</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>8.84</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Akston Biosciences - 678697 100 Cummings Center 454C, Beverly, MA 01915</td>
<td></td>
<td>9382083</td>
<td>1</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>11.97</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Alltrna Inc - 688555 325 Vassar St Ste 1a &amp; 2b, Cambridge, MA 02139</td>
<td></td>
<td>9382090</td>
<td>7</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>84.93</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Alltrna Inc - 688555 325 Vassar St Ste 1a &amp; 2b, Cambridge, MA 02139</td>
<td></td>
<td>9382090</td>
<td>5</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>110.26</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>American Airlines Inc BOSTON 1 Harborside Drive, Boston, MA 02128</td>
<td></td>
<td>9375451</td>
<td>1</td>
<td>10 Gal Sharps UN3291 item/service</td>
<td>17.88</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Antares Therapeutics 1 Winthrop Square, Boston, MA 02110</td>
<td></td>
<td>9382540</td>
<td>5</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>47.60</td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE
DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 4 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/28/2026</td>
<td>Antares Therapeutics 1 Winthrop Square, Boston, MA 02110</td>
<td></td>
<td>9382540</td>
<td>3</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>58.11</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Antares Therapeutics 1 Winthrop Square, Boston, MA 02110</td>
<td></td>
<td>9382540</td>
<td>4</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>29.36</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Arkea Bio Corp 692058 500 Rutherford Ave Suite 3B, Boston, MA 02129</td>
<td></td>
<td>9382101</td>
<td>3</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>83.44</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Arkea Bio Corp 692058 500 Rutherford Ave Suite 3B, Boston, MA 02129</td>
<td></td>
<td>9382101</td>
<td>1</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>9.12</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Arranta Bio MA LLC 650 Pleasant St, Watertown, MA 02472</td>
<td></td>
<td>9375457</td>
<td>5</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>143.04</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Arranta Bio MA LLC 650 Pleasant St, Watertown, MA 02472</td>
<td></td>
<td>9375457</td>
<td>4</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>92.63</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Atavistic Bio 101 Cambridge Park Drive #3000, Cambridge, MA 02140</td>
<td></td>
<td>9390494</td>
<td>4</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>89.40</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Aurion Biotech 686227 150 Cambridge Park Drive, Cambridge, MA 02140</td>
<td></td>
<td>9382114</td>
<td>6</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>33.92</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Aurion Biotech 686227 150 Cambridge Park Drive, Cambridge, MA 02140</td>
<td></td>
<td>9382114</td>
<td>2</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>56.62</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE

DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 5 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/28/2026</td>
<td>Aurion Biotech 686227 150 Cambridge Park Drive, Cambridge, MA 02140</td>
<td></td>
<td>9382108</td>
<td>8</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>60.99</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Aurion Biotech 686227 150 Cambridge Park Drive, Cambridge, MA 02140</td>
<td></td>
<td>9382108</td>
<td>5</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>129.63</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Bexorg Inc - 688802 290 Congress Ave, New Haven, CT 06519</td>
<td></td>
<td>9393345</td>
<td>2</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>33.35</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Bexorg Inc - 688802 290 Congress Ave, New Haven, CT 06519</td>
<td></td>
<td>9393345</td>
<td>1</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>9.41</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>BioNtech US Inc 75 - 683543 75 Sidney Street, Cambridge, MA 02139</td>
<td></td>
<td>9390509</td>
<td>11</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>108.02</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Bioagilytix Labs 525505 c/o Dr. Kristie Hebert 1320 Soldiers Field Road, Boston, MA 02135</td>
<td></td>
<td>9382124</td>
<td>8</td>
<td>5 Gal RMW Path - UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Bioverativ, INC - 678379 225 2nd Ave, Waltham, MA 02451</td>
<td></td>
<td>9391791</td>
<td>13</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>326.31</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Bioverativ, INC - 678379 225 2nd Ave, Waltham, MA 02451</td>
<td></td>
<td>9391791</td>
<td>5</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>92.06</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Bioverativ, INC - 678379 225 2nd Ave, Waltham, MA 02451</td>
<td></td>
<td>9391791</td>
<td>2</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>99.75</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Bioverativ, INC - 678379 225 2nd Ave, Waltham, MA 02451</td>
<td></td>
<td>9390564</td>
<td>18</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>381.44</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE

DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 6 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/30/2026</td>
<td>Bioverativ, INC - 678379 225 2nd Ave, Waltham, MA 02451</td>
<td></td>
<td>9390564</td>
<td>11</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>231.14</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Bioverativ, INC - 678379 225 2nd Ave, Waltham, MA 02451</td>
<td></td>
<td>9390564</td>
<td>3</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>15.68</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Bioverativ, INC - 678379 225 2nd Ave, Waltham, MA 02451</td>
<td></td>
<td>9390564</td>
<td>2</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>110.01</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Bioverativ, INC - 678379 225 2nd Ave, Waltham, MA 02451</td>
<td></td>
<td>9375468</td>
<td>27</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>658.58</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Bioverativ, INC - 678379 225 2nd Ave, Waltham, MA 02451</td>
<td></td>
<td>9375468</td>
<td>10</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>207.20</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Bioverativ, INC - 678379 225 2nd Ave, Waltham, MA 02451</td>
<td></td>
<td>9375468</td>
<td>2</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>97.19</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Bioverativ, INC - 678379 225 2nd Ave, Waltham, MA 02451</td>
<td></td>
<td>9375468</td>
<td>1</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>9.12</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Boston Scientific Quincy- 544374 500 Commander Shea Blvd, Quincy, MA 02171</td>
<td></td>
<td>9382549</td>
<td>2</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>10.83</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>CBSET, Inc - 539709 500 Shire Way, Lexington, MA 02421</td>
<td></td>
<td>9375477</td>
<td>32</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>CBSET, Inc - 539709 500 Shire Way, Lexington, MA 02421</td>
<td></td>
<td>9375477</td>
<td>17</td>
<td>7.0 Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE

DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 7 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/30/2026</td>
<td>Chroma Medicine - 689735 201 Brookline Ave, Boston, MA 02215</td>
<td></td>
<td>9393362</td>
<td>1</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Chroma Medicine - 689735 201 Brookline Ave, Boston, MA 02215</td>
<td></td>
<td>9393353</td>
<td>6</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>48.74</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Chroma Medicine - 689735 201 Brookline Ave, Boston, MA 02215</td>
<td></td>
<td>9376303</td>
<td>3</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>37.91</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Chroma Medicine - 689735 201 Brookline Ave, Boston, MA 02215</td>
<td></td>
<td>9376303</td>
<td>1</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>28.31</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Clasp Therapeutics Inc 1 Kendall Square #7 202, Cambridge, MA 02139</td>
<td></td>
<td>9382132</td>
<td>4</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>23.66</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Clasp Therapeutics Inc 1 Kendall Square #7 202, Cambridge, MA 02139</td>
<td></td>
<td>9382132</td>
<td>4</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>102.81</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Convergent Research LLC 490 Arsenal Way Ste 110, Watertown, MA 02472</td>
<td></td>
<td>9375484</td>
<td>4</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>34.49</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Convergent Research LLC 490 Arsenal Way Ste 110, Watertown, MA 02472</td>
<td></td>
<td>9375484</td>
<td>2</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>49.17</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE
DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 8 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/30/2026</td>
<td>Crispr Therapeutics 105 - 686163 105 West First Street, Boston, MA 02127</td>
<td></td>
<td>9393373</td>
<td>7</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>80.09</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Crispr Therapeutics 105 - 686163 105 West First Street, Boston, MA 02127</td>
<td></td>
<td>9393373</td>
<td>3</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>81.95</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Crispr Therapeutics 105 - 686163 105 West First Street, Boston, MA 02127</td>
<td></td>
<td>9393373</td>
<td>2</td>
<td>10 Gal Sharps UN3291 item/service</td>
<td>40.23</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Crispr Therapeutics 105 - 686163 105 West First Street, Boston, MA 02127</td>
<td></td>
<td>9382569</td>
<td>10</td>
<td>10 Gal Sharps UN3291 item/service</td>
<td>747.98</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Crispr Therapeutics 105 - 686163 105 West First Street, Boston, MA 02127</td>
<td></td>
<td>9382569</td>
<td>2</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>56.62</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Crispr Therapeutics Framingham - 683542 33 NewYork Avenue, Framingham, MA 01701</td>
<td></td>
<td>9390569</td>
<td>4</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>113.24</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Crispr Therapeutics Framingham - 683542 33 NewYork Avenue, Framingham, MA 01701</td>
<td></td>
<td>9390569</td>
<td>2</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>21.95</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Crispr Therapeutics Framingham - 683542 33 NewYork Avenue, Framingham, MA 01701</td>
<td></td>
<td>9390569</td>
<td>1</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>14.82</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE
DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 9 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/27/2026</td>
<td>Cystic Fibrosis Foundation 587943 4550 Montgomery Avenue #1100N, Bethesda, MD 20814</td>
<td></td>
<td>9375540</td>
<td>9</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>72.39</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Cytiva - 14 - 667632 14 Walkup Drive, Westborough, MA 01581</td>
<td></td>
<td>9393385</td>
<td>1</td>
<td>55 Gal RMW Drum UN3291 item/service</td>
<td>21.95</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Dicerna Pharmaceuticals 65 Hayden Ave, Lexington, MA 02421</td>
<td></td>
<td>9390590</td>
<td>4</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>26.51</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Dicerna Pharmaceuticals 65 Hayden Ave, Lexington, MA 02421</td>
<td></td>
<td>9390590</td>
<td>2</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>53.64</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Dicerna Pharmaceuticals 65 Hayden Ave, Lexington, MA 02421</td>
<td></td>
<td>9390583</td>
<td>1</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Dicerna Pharmaceuticals 65 Hayden Ave, Lexington, MA 02421</td>
<td></td>
<td>9390577</td>
<td>6</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Dicerna Pharmaceuticals 65 Hayden Ave, Lexington, MA 02421</td>
<td></td>
<td>9390574</td>
<td>12</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>97.19</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Dicerna Pharmaceuticals 65 Hayden Ave, Lexington, MA 02421</td>
<td></td>
<td>9390574</td>
<td>6</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>162.41</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE
DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 10 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/30/2026</td>
<td>EMD Serono Research &amp; Development 45 Middlesex Turnpike, Billerica, MA 01821</td>
<td></td>
<td>9390615</td>
<td>1</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>EMD Serono Research &amp; Development 45 Middlesex Turnpike, Billerica, MA 01821</td>
<td></td>
<td>9390611</td>
<td>14</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>62.42</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>EMD Serono Research &amp; Development 45 Middlesex Turnpike, Billerica, MA 01821</td>
<td></td>
<td>9390611</td>
<td>6</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>30.78</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Editas Medicine 45 Jackson Road #104, Devens, MA 01434</td>
<td></td>
<td>9390601</td>
<td>8</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>90.63</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Editas Medicine 45 Jackson Road #104, Devens, MA 01434</td>
<td></td>
<td>9390601</td>
<td>3</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>75.99</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Elbit Systems of America 220 Daniel Webster Highway, Merrimack, NH 03054</td>
<td></td>
<td>9382147</td>
<td>10</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>108.59</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Emugen Therapeutics LLC 683391 175 New Boston Street Ste E, Woburn, MA 01801</td>
<td></td>
<td>9382572</td>
<td>3</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>30.50</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Entrada Therapeutics Inc 693147 1 Design Center Place Suite 7-500, Boston, MA 02210</td>
<td></td>
<td>9382579</td>
<td>3</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>72.39</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE

DATA DESTRUCTION SERVICES

</figure>


# INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 11 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/28/2026</td>
<td>Entrada Therapeutics Inc 693147 1 Design Center Place Suite 7-500, Boston, MA 02210</td>
<td></td>
<td>9382579</td>
<td>12</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>303.96</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Entrada Therapeutics Inc 693147 1 Design Center Place Suite 7-500, Boston, MA 02210</td>
<td></td>
<td>9382579</td>
<td>1</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>11.69</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Foghorn Therapeutics 633425 500 Technology Square Ste 700, Cambridge, MA 02139</td>
<td></td>
<td>9393397</td>
<td>19</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>119.42</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Frontier Medicines Corporation 704490 451 D Street #207, Boston, MA 02210</td>
<td></td>
<td>9382585</td>
<td>2</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>43.04</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Generate Biomedicines 28 Landsdowne Street, Boston, MA 02138</td>
<td></td>
<td>9393410</td>
<td>9</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>256.28</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Generate Biomedicines 28 Landsdowne Street, Boston, MA 02138</td>
<td></td>
<td>9393410</td>
<td>5</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>39.62</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Generate Biomedicines 28 Landsdowne Street, Boston, MA 02138</td>
<td></td>
<td>9376324</td>
<td>4</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>13.68</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Generate Biomedicines 28 Landsdowne Street, Boston, MA 02138</td>
<td></td>
<td>9375554</td>
<td>12</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>84.93</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE

DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 12 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/27/2026</td>
<td>Generate Biomedicines 28 Landsdowne Street, Boston, MA 02138</td>
<td></td>
<td>9375554</td>
<td>4</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>128.14</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Genti Bio Inc 706516 150 Cambridge Park Drive, Cambridge, MA 02140</td>
<td></td>
<td>9382160</td>
<td>2</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>23.09</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Genti Bio Inc 706516 150 Cambridge Park Drive, Cambridge, MA 02140</td>
<td></td>
<td>9382160</td>
<td>1</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>26.82</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Gentuity 142 North Road #G, Sudbury, MA 01776</td>
<td></td>
<td>9390682</td>
<td>3</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>25.94</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Genzyme Corporation - 621790 45 New York Ave, Framingham, MA 01701</td>
<td></td>
<td>9390711</td>
<td>8</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>210.09</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Genzyme Corporation - 621790 45 New York Ave, Framingham, MA 01701</td>
<td></td>
<td>9390711</td>
<td>2</td>
<td>7.0 CF Box RMW UN3291 item/service</td>
<td>20.81</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Genzyme Corporation - 621790 45 New York Ave, Framingham, MA 01701</td>
<td></td>
<td>9390711</td>
<td>1</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>56.15</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Genzyme Corporation - 621790 45 New York Ave, Framingham, MA 01701</td>
<td></td>
<td>9375570</td>
<td>7</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>187.74</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Genzyme Corporation - 621790 45 New York Ave, Framingham, MA 01701</td>
<td></td>
<td>9375570</td>
<td>3</td>
<td>7.0 CF Box RMW UN3291 item/service</td>
<td>25.94</td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE
DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 13 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/27/2026</td>
<td>Genzyme Corporation - 621790 45 New York Ave, Framingham, MA 01701</td>
<td></td>
<td>9375570</td>
<td>1</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>44.18</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Genzyme Corporation - 656326 8 New York Avenue, Framingham, MA 01701</td>
<td></td>
<td>9393422</td>
<td>8</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>454.86</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Genzyme Corporation - 656326 8 New York Avenue, Framingham, MA 01701</td>
<td></td>
<td>9390744</td>
<td>5</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>266.19</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Genzyme Corporation - 656326 8 New York Avenue, Framingham, MA 01701</td>
<td></td>
<td>9382591</td>
<td>9</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>507.59</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Genzyme Corporation - 656326 8 New York Avenue, Framingham, MA 01701</td>
<td></td>
<td>9375614</td>
<td>11</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>668.61</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Genzyme Corporation - 656326 8 New York Avenue, Framingham, MA 01701</td>
<td></td>
<td>9375589</td>
<td>13</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>753.26</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Genzyme Corporation - 656327 68 New York Ave, Framingham, MA 01701</td>
<td></td>
<td>9390731</td>
<td>15</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>438.06</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Genzyme Corporation - 656327 68 New York Ave, Framingham, MA 01701</td>
<td></td>
<td>9390731</td>
<td>1</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>37.34</td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE
DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 14 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/27/2026</td>
<td>Genzyme Corporation - 656327 68 New York Ave, Framingham, MA 01701</td>
<td></td>
<td>9375581</td>
<td>15</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>430.61</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Genzyme Corporation - 656327 68 New York Ave, Framingham, MA 01701</td>
<td></td>
<td>9375581</td>
<td>2</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>90.35</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Genzyme Corporation - 656330 76 New York Ave, Framingham, MA 01701</td>
<td></td>
<td>9390715</td>
<td>6</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>153.47</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Genzyme Corporation - 656333 31 New York Ave, Framingham, MA 01701</td>
<td></td>
<td>9390737</td>
<td>2</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>55.13</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Genzyme Corporation - 656333 31 New York Ave, Framingham, MA 01701</td>
<td></td>
<td>9390737</td>
<td>1</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>55.29</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Genzyme Corporation - 656334 49 New York Ave, Framingham, MA 01701</td>
<td></td>
<td>9390726</td>
<td>11</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>286.08</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Genzyme Corporation - 656334 49 New York Ave, Framingham, MA 01701</td>
<td></td>
<td>9390726</td>
<td>2</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>58.43</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Genzyme Corporation - 656334 49 New York Ave, Framingham, MA 01701</td>
<td></td>
<td>9375910</td>
<td>16</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>397.83</td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE

DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 15 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/27/2026</td>
<td>Genzyme Corporation - 656334 49 New York Ave, Framingham, MA 01701</td>
<td></td>
<td>9375910</td>
<td>2</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>49.59</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Glaukos Corporation Inc 30 North Avenue, Burlington, MA 01803</td>
<td></td>
<td>9382606</td>
<td>1</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>7.98</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Greater Boston Gastroenterology - 679723 475 Franklin Street, Framingham, MA 01702</td>
<td></td>
<td>9390752</td>
<td>3</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>19.10</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Greentown Labs 649743 444 Somerville Ave, Somerville, MA 02143</td>
<td></td>
<td>9375919</td>
<td>1</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>4.28</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Indigo Agriculture 500 Rutherford Ave, Charlestown, MA 02129</td>
<td></td>
<td>9375921</td>
<td>8</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>57.57</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Indigo Agriculture 500 Rutherford Ave, Charlestown, MA 02129</td>
<td></td>
<td>9375921</td>
<td>3</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>83.44</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Ingenia Therapeutics 490 Arsenal Way Ste 100B, Watertown, MA 02472</td>
<td></td>
<td>9393427</td>
<td>12</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>84.36</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Kelonia Therapeutics 684224 135 Morrissey Blvd Ste C, Boston, MA 02125</td>
<td></td>
<td>9376320</td>
<td>7</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>164.73</td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE
DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 16 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/27/2026</td>
<td>Kelonia Therapeutics 684224 135 Morrissey Blvd Ste C, Boston, MA 02125</td>
<td></td>
<td>9376309</td>
<td>5</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Kymera Therapeutics Inc 500 North Beacon St, Watertown, MA 02472</td>
<td></td>
<td>9393432</td>
<td>5</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>57.29</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Kymera Therapeutics Inc 500 North Beacon St, Watertown, MA 02472</td>
<td></td>
<td>9393432</td>
<td>8</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>198.17</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Labshares Newton LLC 90 Bridge St, Newton, MA 02458</td>
<td></td>
<td>9375937</td>
<td>9</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>89.21</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Labshares Newton LLC 90 Bridge St, Newton, MA 02458</td>
<td></td>
<td>9375937</td>
<td>5</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>137.08</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Labshares Newton LLC 90 Bridge St, Newton, MA 02458</td>
<td></td>
<td>9375931</td>
<td>3</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>26.22</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Labshares Newton LLC 90 Bridge St, Newton, MA 02458</td>
<td></td>
<td>9375931</td>
<td>1</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>26.82</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Landmark Bio 693444 300 North Beacon St Ste 210, Watertown, MA 02472</td>
<td></td>
<td>9375944</td>
<td>3</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>28.50</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Landmark Bio 693444 300 North Beacon St Ste 210, Watertown, MA 02472</td>
<td></td>
<td>9375944</td>
<td>2</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>43.21</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE

DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 17 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/27/2026</td>
<td>Landmark Bio 693444 300 North Beacon St Ste 210, Watertown, MA 02472</td>
<td></td>
<td>9375944</td>
<td>1</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>19.38</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Landmark Bio 693444 300 North Beacon St Ste 210, Watertown, MA 02472</td>
<td></td>
<td>9375944</td>
<td>1</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>10.26</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Leveragen Inc 2F Gill St, Woburn, MA 01801</td>
<td></td>
<td>9382614</td>
<td>7</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>51.59</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Maine Molecular Quality Controls Inc 23 Mill Brook Road, Saco, ME 04072</td>
<td></td>
<td>9382170</td>
<td>4</td>
<td>7.0 CF Box RMW UN3291 item/service</td>
<td>36.20</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Mariana Oncology 679976 2F Gill St, Woburn, MA 01801</td>
<td></td>
<td>9393445</td>
<td>7</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>38.19</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Mariana Oncology 679976 2F Gill St, Woburn, MA 01801</td>
<td></td>
<td>9393445</td>
<td>1</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>26.82</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Mariana Oncology 679976 2F Gill St, Woburn, MA 01801</td>
<td></td>
<td>9375948</td>
<td>5</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>29.36</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Mariana Oncology 679976 2F Gill St, Woburn, MA 01801</td>
<td></td>
<td>9375948</td>
<td>2</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>56.62</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Medicilon USA 704758 20 Maguire Road #103, Lexington, MA 02421</td>
<td></td>
<td>9390968</td>
<td>20</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>150.77</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Mercy Bioanalytics Inc 22 Strathmore Road Ste 260, Natick, MA 01760</td>
<td></td>
<td>9382630</td>
<td>6</td>
<td>43 Gal RMW UN3291 item/service</td>
<td>60.71</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE
DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 18 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/28/2026</td>
<td>Modex Therapeutics 20 Riverside Road, Weston, MA 02493</td>
<td></td>
<td>9382680</td>
<td>8</td>
<td>43 Gal RMW UN3291 item/service</td>
<td>81.51</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Modex Therapeutics 20 Riverside Road, Weston, MA 02493</td>
<td></td>
<td>9382680</td>
<td>6</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>48.74</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Monte Rosa Therapeutics Inc 321 Harrison Ave, Boston, MA 02118</td>
<td></td>
<td>9382684</td>
<td>15</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>116.00</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Nanite Inc 687964 451 D Street Ste 906, Boston, MA 02210</td>
<td></td>
<td>9393456</td>
<td>1</td>
<td>5 Gal RMW - UN3291 item/service</td>
<td>174.14</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Nanite Inc 687964 451 D Street Ste 906, Boston, MA 02210</td>
<td></td>
<td>9382692</td>
<td>5</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>36.77</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Neosome Life Sciences 686490 3 Forbes Road, Lexington, MA 02421</td>
<td></td>
<td>9376010</td>
<td>5</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Nestle Health Science 9 4th Avenue, Waltham, MA 02451</td>
<td></td>
<td>9382694</td>
<td>4</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>31.07</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Northeast Men's Health 231 Farmington Avenue Ste, Farmington, CT 06032</td>
<td></td>
<td>9393462</td>
<td>2</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>15.96</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Novo Nordisk 300 North Beacon St, Watertown, MA 02472</td>
<td></td>
<td>9376015</td>
<td>6</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>37.34</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Novo Nordisk 300 North Beacon St, Watertown, MA 02472</td>
<td></td>
<td>9376015</td>
<td>3</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>80.46</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE
DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 19 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/30/2026</td>
<td>Obsidian Therapeutics 40 Wiggins Ave Suite 2200, Bedford, MA 01730</td>
<td></td>
<td>9391796</td>
<td>5</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>38.19</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Obsidian Therapeutics 40 Wiggins Ave Suite 2200, Bedford, MA 01730</td>
<td></td>
<td>9391796</td>
<td>2</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>53.64</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Obsidian Therapeutics 40 Wiggins Ave Suite 2200, Bedford, MA 01730</td>
<td></td>
<td>9390998</td>
<td>4</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>23.94</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Obsidian Therapeutics 40 Wiggins Ave Suite 2200, Bedford, MA 01730</td>
<td></td>
<td>9390998</td>
<td>2</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>46.19</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Obsidian Therapeutics 40 Wiggins Ave Suite 2200, Bedford, MA 01730</td>
<td></td>
<td>9376018</td>
<td>3</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>25.65</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Obsidian Therapeutics 40 Wiggins Ave Suite 2200, Bedford, MA 01730</td>
<td></td>
<td>9376018</td>
<td>2</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>49.17</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Odyssey Therapeutics Inc - 686796 51 Sleeper Street, Boston, MA 02210</td>
<td></td>
<td>9376275</td>
<td>1</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Odyssey Therapeutics Inc - 686796 51 Sleeper Street, Boston, MA 02210</td>
<td></td>
<td>9376269</td>
<td>11</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>256.28</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Olink Proteomics Inc 130 Turner St Bldg 2, Waltham, MA 02453</td>
<td></td>
<td>9382697</td>
<td>1</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>10.26</td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE
DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 20 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/30/2026</td>
<td>Organogenesis Inc 65 Dan Road, Canton, MA 02021</td>
<td></td>
<td>9391063</td>
<td>21</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>179.27</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Organogenesis Inc 65 Dan Road, Canton, MA 02021</td>
<td></td>
<td>9391020</td>
<td>21</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>277.59</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Organogenesis Inc 65 Dan Road, Canton, MA 02021</td>
<td></td>
<td>9391020</td>
<td>10</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>124.26</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Organogenesis Inc 65 Dan Road, Canton, MA 02021</td>
<td></td>
<td>9391007</td>
<td>17</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>105.17</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Orogen Therapeutics Inc 12 Gill St, Woburn, MA 01801</td>
<td></td>
<td>9382702</td>
<td>1</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>11.69</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Oxford Biomedica Solutions - 639872 1 Patriots Park, Bedford, MA 01730</td>
<td></td>
<td>9391079</td>
<td>4</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>27.36</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Oxford Biomedica Solutions - 639872 1 Patriots Park, Bedford, MA 01730</td>
<td></td>
<td>9391079</td>
<td>1</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>26.82</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Oxford Biomedica Solutions - 639872 1 Patriots Park, Bedford, MA 01730</td>
<td></td>
<td>9391079</td>
<td>1</td>
<td>7.0 CF Box RMW UN3291 item/service</td>
<td>11.69</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Oxford Biomedica Solutions - 639872 1 Patriots Park, Bedford, MA 01730</td>
<td></td>
<td>9376028</td>
<td>4</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>31.07</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE
DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 21 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/27/2026</td>
<td>Oxford Biomedica Solutions - 639872 1 Patriots Park, Bedford, MA 01730</td>
<td></td>
<td>9376028</td>
<td>1</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>25.33</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>QLD Biotherapeutics Inc 50 Soldiers Field Place, Boston, MA 02135</td>
<td></td>
<td>9393468</td>
<td>15</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>170.15</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>QLD Biotherapeutics Inc 50 Soldiers Field Place, Boston, MA 02135</td>
<td></td>
<td>9393468</td>
<td>6</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>222.01</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>QLD Biotherapeutics Inc 50 Soldiers Field Place, Boston, MA 02135</td>
<td></td>
<td>9376030</td>
<td>1</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Ratio Therapeutics - 692213 19 Drydock Ave Floor 6, Boston, MA 02210</td>
<td></td>
<td>9376306</td>
<td>10</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>81.51</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Ratio Therapeutics - 692213 19 Drydock Ave Floor 6, Boston, MA 02210</td>
<td></td>
<td>9376306</td>
<td>4</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>108.77</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Ratio Therapeutics - 692213 19 Drydock Ave Floor 6, Boston, MA 02210</td>
<td></td>
<td>9376286</td>
<td>3</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Regeneron Cell Medicines 699994 60 Binney Street, Cambridge, MA 02142</td>
<td></td>
<td>9391803</td>
<td>3</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>75.53</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE

DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 22 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/30/2026</td>
<td>Regeneron Cell Medicines 699994 60 Binney Street, Cambridge, MA 02142</td>
<td></td>
<td>9391803</td>
<td>2</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>62.58</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Regeneron Cell Medicines 699994 60 Binney Street, Cambridge, MA 02142</td>
<td></td>
<td>9391803</td>
<td>5</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>62.70</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Regeneron Cell Medicines 699994 60 Binney Street, Cambridge, MA 02142</td>
<td></td>
<td>9376070</td>
<td>3</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>35.34</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Regeneron Cell Medicines 699994 60 Binney Street, Cambridge, MA 02142</td>
<td></td>
<td>9376070</td>
<td>1</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>21.95</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Regeneron Cell Medicines 699994 60 Binney Street, Cambridge, MA 02142</td>
<td></td>
<td>9376070</td>
<td>1</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>26.82</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Regeneron Pharmaceuticals - 26 26 Tech Valley Drive, E. Greenbush, NY 12061</td>
<td></td>
<td>9382204</td>
<td>18</td>
<td>55 Gal RMW Drum UN3291 item/service</td>
<td>262.49</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Regeneron Pharmaceuticals 350 350 Tempel Lane, Rensselaer, NY 12144</td>
<td></td>
<td>9382345</td>
<td>3</td>
<td>55 Gal RMW Drum UN3291 item/service</td>
<td>44.18</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Regeneron Pharmaceuticals 350 350 Tempel Lane, Rensselaer, NY 12144</td>
<td></td>
<td>9382345</td>
<td>1</td>
<td>7.0 CF Box RMW UN3291 item/service</td>
<td>14.82</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE

DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 23 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/30/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9391459</td>
<td>5</td>
<td>5 Gal RMW - UN3291 item/service</td>
<td>236.84</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9391459</td>
<td>1</td>
<td>55 Gal RMW Drum UN3291 item/service</td>
<td>60.99</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9391459</td>
<td>1</td>
<td>30 Gal RMW Drum UN3291 item/service</td>
<td>49.02</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9391267</td>
<td>1</td>
<td>55 Gal RMW Drum UN3291 item/service</td>
<td>55.86</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9391257</td>
<td>3</td>
<td>55 Gal RMW Drum UN3291 item/service</td>
<td>118.85</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9391248</td>
<td>1</td>
<td>55 Gal RMW Drum UN3291 item/service</td>
<td>15.39</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9391248</td>
<td>1</td>
<td>7.0 CF Box RMW UN3291 item/service</td>
<td>7.70</td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE
DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 24 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/30/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9391243</td>
<td>5</td>
<td>55 Gal RMW Drum UN3291 item/service</td>
<td>93.77</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9391235</td>
<td>2</td>
<td>55 Gal RMW Drum UN3291 item/service</td>
<td>28.79</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9391222</td>
<td>6</td>
<td>55 Gal RMW Drum UN3291 item/service</td>
<td>81.80</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9391089</td>
<td>23</td>
<td>55 Gal RMW Drum UN3291 item/service</td>
<td>611.61</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9391089</td>
<td>2</td>
<td>Non Haz Waste Gaylord item/service</td>
<td>282.44</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9382351</td>
<td>12</td>
<td>55 Gal RMW Drum UN3291 item/service</td>
<td>276.17</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9382351</td>
<td>1</td>
<td>7.0 CF Box RMW UN3291 item/service</td>
<td>13.68</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE
DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454
Invoice Date: 01/31/2026

Page: 25 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/28/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9382198</td>
<td>1</td>
<td>55 Gal RMW Drum UN3291 item/service</td>
<td>27.93</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9382198</td>
<td>1</td>
<td>30 Gal RMW Drum UN3291 item/service</td>
<td>21.38</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9382198</td>
<td>1</td>
<td>5 Gal RMW - UN3291 item/service</td>
<td>3.71</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9382180</td>
<td>8</td>
<td>55 Gal RMW Drum UN3291 item/service</td>
<td>385.04</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Regeneron Pharmaceuticals 81- 655041 81 Columbia Turnpike BLDG 85, Rensselaer, NY 12144</td>
<td></td>
<td>9382180</td>
<td>2</td>
<td>Non Haz Waste Gaylord item/service</td>
<td>388.17</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Regeneron Pharmaceuticals 9 9 University Place, Rensselaer, NY 12144</td>
<td></td>
<td>9382324</td>
<td>4</td>
<td>55 Gal RMW Drum UN3291 item/service</td>
<td>46.17</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Replimune INC - 663677 33 New York Avenue, Framingham, MA 01701</td>
<td></td>
<td>9391470</td>
<td>6</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>26.22</td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE

DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 26 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/27/2026</td>
<td>Replimune INC - 663677 33 New York Avenue, Framingham, MA 01701</td>
<td></td>
<td>9376077</td>
<td>6</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>34.49</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Replimune INC - 663677 33 New York Avenue, Framingham, MA 01701</td>
<td></td>
<td>9376077</td>
<td>4</td>
<td>7.0 CF Box RMW UN3291 item/service</td>
<td>30.78</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Restorative Dental Group - 637755 181 Concord Street, Cambridge, MA 02138</td>
<td></td>
<td>9382365</td>
<td>1</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>9.41</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Restorative Dental Group - 637755 181 Concord Street, Cambridge, MA 02138</td>
<td></td>
<td>9382365</td>
<td>1</td>
<td>5 Gal RMW - UN3291 item/service</td>
<td>1.71</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Revvity Inc 68 Elm St, Hopkinton, MA 01748</td>
<td></td>
<td>9393474</td>
<td>4</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>113.24</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Revvity Inc 68 Elm St, Hopkinton, MA 01748</td>
<td></td>
<td>9391477</td>
<td>6</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>28.79</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Revvity Inc 68 Elm St, Hopkinton, MA 01748</td>
<td></td>
<td>9382379</td>
<td>2</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>19.38</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Roslinct 97 South Street, Hopkinton, MA 01748</td>
<td></td>
<td>9393487</td>
<td>4</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>117.71</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Roslinct 97 South Street, Hopkinton, MA 01748</td>
<td></td>
<td>9393487</td>
<td>1</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>29.36</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Sanofi 350 - 686235 350 Water Street, Cambridge, MA 02141</td>
<td></td>
<td>9391811</td>
<td>28</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>816.52</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Sanofi 350 - 686235 350 Water Street, Cambridge, MA 02141</td>
<td></td>
<td>9391811</td>
<td>4</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>204.35</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE
DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 27 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/30/2026</td>
<td>Sanofi 350 - 686235 350 Water Street, Cambridge, MA 02141</td>
<td></td>
<td>9391811</td>
<td>1</td>
<td>10 Gal Sharps UN3291 item/service</td>
<td>16.39</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Sanofi 350 - 686235 350 Water Street, Cambridge, MA 02141</td>
<td></td>
<td>9391486</td>
<td>1</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Sanofi 350 - 686235 350 Water Street, Cambridge, MA 02141</td>
<td></td>
<td>9391483</td>
<td>6</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>310.94</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Sanofi 350 - 686235 350 Water Street, Cambridge, MA 02141</td>
<td></td>
<td>9382709</td>
<td>45</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>1026.61</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Sanofi 350 - 686235 350 Water Street, Cambridge, MA 02141</td>
<td></td>
<td>9382709</td>
<td>2</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>97.76</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Sanofi 350 - 686235 350 Water Street, Cambridge, MA 02141</td>
<td></td>
<td>9376092</td>
<td>5</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>256.79</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Schrodinger Inc 200 Staples Drive Suite 210, Framingham, MA 01702</td>
<td></td>
<td>9376100</td>
<td>2</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Scisafe - 624949 35 Dunham Road Suite 9, Billerica, MA 01821</td>
<td></td>
<td>9376158</td>
<td>1</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Scisafe - 624949 35 Dunham Road Suite 9, Billerica, MA 01821</td>
<td></td>
<td>9376105</td>
<td>2</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Seismic Therapeutic 250 Arsenal St, Watertown, MA 02472</td>
<td></td>
<td>9393502</td>
<td>2</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Seismic Therapeutic 250 Arsenal St, Watertown, MA 02472</td>
<td></td>
<td>9393491</td>
<td>7</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>63.84</td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE

DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 28 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/30/2026</td>
<td>Seismic Therapeutic 250 Arsenal St, Watertown, MA 02472</td>
<td></td>
<td>9393491</td>
<td>1</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>28.31</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Seres - 200 Sidney St - 632947 200 Sidney Street, Cambridge, MA 02119</td>
<td></td>
<td>9376165</td>
<td>12</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>116.00</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Servier Bio Innovations LLC 51 Sleeper St, Boston, MA 02210</td>
<td></td>
<td>9376288</td>
<td>3</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>23.66</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Servier Bio Innovations LLC 51 Sleeper St, Boston, MA 02210</td>
<td></td>
<td>9376288</td>
<td>2</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>47.68</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Seurat Technologies Inc 265 Ballardvale Street, Wilmington, MA 01887</td>
<td></td>
<td>9391513</td>
<td>2</td>
<td>55 Gal RMW Drum UN3291 item/service</td>
<td>178.70</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Skylark Bio 703489 64 Sidney St #5, Cambridge, MA 02139</td>
<td></td>
<td>9376175</td>
<td>1</td>
<td>5 Gal RMW Path - UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Smartlabs 301 301 Binney St Fl 1 Ste 101, Cambridge, MA 02142</td>
<td></td>
<td>9391528</td>
<td>1</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Smartlabs 301 301 Binney St Fl 1 Ste 101, Cambridge, MA 02142</td>
<td></td>
<td>9391521</td>
<td>6</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>107.73</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Smartlabs 301 301 Binney St Fl 1 Ste 101, Cambridge, MA 02142</td>
<td></td>
<td>9391521</td>
<td>1</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>28.31</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Smartlabs 6 Tide 6 Tide St, Boston, MA 02210</td>
<td></td>
<td>9391532</td>
<td>6</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>153.47</td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE

DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 29 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/30/2026</td>
<td>Smartlabs 6 Tide 6 Tide St, Boston, MA 02210</td>
<td></td>
<td>9391532</td>
<td>3</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>157.04</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Smartlabs Boston Landing 40 40 Guest St, Brighton, MA 02135</td>
<td></td>
<td>9393513</td>
<td>1</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Smartlabs Boston Landing 40 40 Guest St, Brighton, MA 02135</td>
<td></td>
<td>9393506</td>
<td>10</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>229.46</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Smartlabs Boston Landing 40 40 Guest St, Brighton, MA 02135</td>
<td></td>
<td>9393506</td>
<td>2</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>100.04</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Solid Biosciences LLC - 686478 500 Rutherford Ave FL 3 Suite 301, Boston, MA 02129</td>
<td></td>
<td>9393519</td>
<td>2</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>16.25</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Solid Biosciences LLC - 686478 500 Rutherford Ave FL 3 Suite 301, Boston, MA 02129</td>
<td></td>
<td>9393519</td>
<td>1</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>23.84</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Solid Biosciences LLC - 686478 500 Rutherford Ave FL 3 Suite 301, Boston, MA 02129</td>
<td></td>
<td>9382715</td>
<td>3</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>26.22</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE

DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 30 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/28/2026</td>
<td>Solid Biosciences LLC - 686478 500 Rutherford Ave FL 3 Suite 301, Boston, MA 02129</td>
<td></td>
<td>9382715</td>
<td>2</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>55.13</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Souffle Therapeutics 77 Chapel St, Newton, MA 02458</td>
<td></td>
<td>9393526</td>
<td>3</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Souffle Therapeutics 77 Chapel St, Newton, MA 02458</td>
<td></td>
<td>9393523</td>
<td>11</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>84.65</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Souffle Therapeutics 77 Chapel St, Newton, MA 02458</td>
<td></td>
<td>9393523</td>
<td>4</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>120.69</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Stoke Therapeutics 631220 45 Wiggins Ave, Bedford, MA 01730</td>
<td></td>
<td>9391542</td>
<td>2</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>317.37</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Stoke Therapeutics 631220 45 Wiggins Ave, Bedford, MA 01730</td>
<td></td>
<td>9391537</td>
<td>10</td>
<td>4.5 CF Box RMW Path UN3291 item/service</td>
<td>0.00</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Strand Therapeutics Inc - 686991 20 Overland Street First Floor, Boston, MA 02215</td>
<td></td>
<td>9393529</td>
<td>15</td>
<td>31 Gal RMW - UN3291 item/service</td>
<td>117.71</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Strand Therapeutics Inc - 686991 20 Overland Street First Floor, Boston, MA 02215</td>
<td></td>
<td>9393529</td>
<td>10</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>214.56</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Stylus Medicine Inc 1 Kendall Square Bldg 400 Ste 14-403, Cambridge, MA 02139</td>
<td></td>
<td>9382719</td>
<td>12</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>88.92</td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE
DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 31 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/28/2026</td>
<td>Stylus Medicine Inc 1 Kendall Square Bldg 400 Ste 14-403, Cambridge, MA 02139</td>
<td></td>
<td>9382719</td>
<td>5</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>123.67</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Tango Therapeutics 201 Brookline Ave, Boston, MA 02215</td>
<td></td>
<td>9376263</td>
<td>2</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>46.17</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Topo Therapeutics 704057 1400 W One Kendall Square Ste 101 First Floor, Cambridge, MA 02139</td>
<td></td>
<td>9393531</td>
<td>10</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>265.22</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Topo Therapeutics 704057 1400 W One Kendall Square Ste 101 First Floor, Cambridge, MA 02139</td>
<td></td>
<td>9393531</td>
<td>6</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>37.34</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Translate Bio a Sanofi Company 688323 200 West Street, Waltham, MA 02451</td>
<td></td>
<td>9391823</td>
<td>4</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>202.92</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Translate Bio a Sanofi Company 688323 200 West Street, Waltham, MA 02451</td>
<td></td>
<td>9391823</td>
<td>24</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>661.56</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Translate Bio a Sanofi Company 688323 200 West Street, Waltham, MA 02451</td>
<td></td>
<td>9391823</td>
<td>1</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>17.10</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Translate Bio a Sanofi Company 688323 200 West Street, Waltham, MA 02451</td>
<td></td>
<td>9382724</td>
<td>18</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>460.41</td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE
DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 32 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/28/2026</td>
<td>Translate Bio a Sanofi Company 688323 200 West Street, Waltham, MA 02451</td>
<td></td>
<td>9382724</td>
<td>2</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>44.46</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Translate Bio a Sanofi Company 688323 200 West Street, Waltham, MA 02451</td>
<td></td>
<td>9382724</td>
<td>4</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>219.74</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Treeline Biosciences Inc - 709457 500 Arsenal St, Watertown, MA 02472</td>
<td></td>
<td>9393541</td>
<td>2</td>
<td>96 Gal RMW - UN3291 item/service</td>
<td>48.74</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Treeline Biosciences Inc - 709457 500 Arsenal St, Watertown, MA 02472</td>
<td></td>
<td>9393541</td>
<td>1</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>23.84</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Triana Biomedicines 689455 1050 Waltham St, Lexington, MA 02421</td>
<td></td>
<td>9391592</td>
<td>26</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>762.88</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Triana Biomedicines 689455 1050 Waltham St, Lexington, MA 02421</td>
<td></td>
<td>9391592</td>
<td>24</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>187.53</td>
</tr>
<tr>
<td>01/31/2026</td>
<td>Veolia ES Technical - OU# 36145 30 Log Bridge Road Ste 107, Middleton, MA 01949</td>
<td></td>
<td></td>
<td>1</td>
<td>Fee added - Week 1-3 of January 2026 Adjustment Price</td>
<td>11310.94</td>
</tr>
<tr>
<td>01/31/2026</td>
<td>Veolia ES Technical - OU# 36145 30 Log Bridge Road Ste 107, Middleton, MA 01949</td>
<td></td>
<td></td>
<td>1</td>
<td>(878) Container Fee - RMW/Sharps container(s) picked up</td>
<td>1536.50</td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE

DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 33 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/31/2026</td>
<td>Veolia ES Technical - OU# 36145 30 Log Bridge Road Ste 107, Middleton, MA 01949</td>
<td></td>
<td></td>
<td>1</td>
<td>(71) Container Fee - 96-Gal RMW container(s) picked up</td>
<td>195.25</td>
</tr>
<tr>
<td>01/31/2026</td>
<td>Veolia ES Technical - OU# 36145 30 Log Bridge Road Ste 107, Middleton, MA 01949</td>
<td></td>
<td></td>
<td>1</td>
<td>(88) Container Fee - 200-Gal RMW container(s) picked up</td>
<td>460.00</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Verve Therapeutics, Inc - Brookline 664552 201 Brookline Ave, Boston, MA 02215</td>
<td></td>
<td>9393545</td>
<td>27</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>173.28</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Verve Therapeutics, Inc - Brookline 664552 201 Brookline Ave, Boston, MA 02215</td>
<td></td>
<td>9393545</td>
<td>9</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>248.83</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Wyeth, LLC - 441673 1 Burtt Road, Andover, MA 01810</td>
<td></td>
<td>9393574</td>
<td>49</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>1345.47</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Wyeth, LLC - 441673 1 Burtt Road, Andover, MA 01810</td>
<td></td>
<td>9393574</td>
<td>3</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>300.39</td>
</tr>
<tr>
<td>01/30/2026</td>
<td>Wyeth, LLC - 441673 1 Burtt Road, Andover, MA 01810</td>
<td></td>
<td>9393574</td>
<td>1</td>
<td>RMW Gaylord - UN3291 item/service</td>
<td>38.48</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Wyeth, LLC - 441673 1 Burtt Road, Andover, MA 01810</td>
<td></td>
<td>9376314</td>
<td>25</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>697.32</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Wyeth, LLC - 441673 1 Burtt Road, Andover, MA 01810</td>
<td></td>
<td>9376314</td>
<td>4</td>
<td>200 Gal RMW UN3291 item/service</td>
<td>262.77</td>
</tr>
<tr>
<td>01/27/2026</td>
<td>Wyeth, LLC - 441673 1 Burtt Road, Andover, MA 01810</td>
<td></td>
<td>9376314</td>
<td>3</td>
<td>RMW Gaylord - UN3291 item/service</td>
<td>95.19</td>
</tr>
</table>


<!-- PageBreak -->

New England MedWaste
30 Log Bridge Road Ste 108 -
Box 16
Middleton MA 01949
(800) 611-4930


<figure>

NEW ENGLAND
MEDWØSTE

DATA DESTRUCTION SERVICES

</figure>


## INVOICE

Invoice Number: 24454

Invoice Date: 01/31/2026

Page: 34 of 34

Invoice Total: 45,715.53

Veolia ES Technical Solutions - OU# 36145
30 Log Bridge Road
Ste 107
Middleton MA 01949


<table>
<tr>
<th>Terms</th>
<th>Due Date</th>
<th>PO Number</th>
</tr>
<tr>
<td>Net 15</td>
<td>02/15/2026</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Customer</th>
<th>Account #</th>
<th>Manifest</th>
<th>Qty</th>
<th>Description</th>
<th>Line Total</th>
</tr>
<tr>
<td>01/28/2026</td>
<td>Xellar Inc 767 Concord Ave #22, Cambridge, MA 02138</td>
<td></td>
<td>9382731</td>
<td>4</td>
<td>4.5 CF Box RMW UN3291 item/service</td>
<td>32.21</td>
</tr>
<tr>
<td>01/28/2026</td>
<td>Xellar Inc 767 Concord Ave #22, Cambridge, MA 02138</td>
<td></td>
<td>9382731</td>
<td>2</td>
<td>17 Gal Sharps UN3291 item/service</td>
<td>53.64</td>
</tr>
<tr>
<td>Thank you for</td>
<td>your business!</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>45,715.53</td>
</tr>
</table>


<table>
<tr>
<th>Current</th>
<th>1-30 Days Overdue</th>
<th>31-60 Days Overdue</th>
<th>61-90 Days Overdue</th>
<th>90+ Days Overdue</th>
<th>Credits</th>
<th>Balance</th>
</tr>
<tr>
<td>106,781.42</td>
<td>33,753.02</td>
<td>0.00</td>
<td>0.00</td>
<td>0.00</td>
<td>-0.00</td>
<td>140,534.44</td>
</tr>
</table>
