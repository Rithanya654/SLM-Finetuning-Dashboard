# TRUCKPRO PARTS AND SERVICE.jpg

TruckPro Holding Corporation
TruckPro, LLC - Fort Smith, AR
29787 Network Place
Chicago, IL 60673-1787
PHONE (479)-646-8901

P: 501-646-8937
F: 501-646-6479
Salesman:
01 - DAVID BURNETT

Ship To:

WIESE

6605 S ZERO ST

FORT SMITH AR 72903


<table>
<tr>
<td>P.O.#:</td>
<td>57132</td>
</tr>
<tr>
<td>Ship via:</td>
<td>W/CALL</td>
</tr>
</table>


Bill To:

WIESE WI031

6605 S ZERO ST

FORT SMITH AR 72903


<figure>

TruckPro

</figure>


Invoice:

004-0358056

CHARGE SALE

02/03/26

<!-- PageNumber="Page 1 of 1" -->


<table>
<tr>
<th>LINE</th>
<th>ORDER</th>
<th>SHIP</th>
<th>PART NUMBER</th>
<th>DESCRIPTION</th>
<th>CORE</th>
<th>UNIT</th>
<th>EXT.</th>
</tr>
<tr>
<td>10</td>
<td>1</td>
<td>1</td>
<td>BH065706</td>
<td>TP VALVE</td>
<td></td>
<td>145.99</td>
<td>145.99</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Vendor Part Number:</td>
<td>WA65706</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<table>
<tr>
<td colspan="3"></td>
</tr>
<tr>
<td>Signature:</td>
<td>SUB-TOTAL</td>
<td>145.99</td>
</tr>
<tr>
<td>Print Name:</td>
<td>SALES TAX</td>
<td>0.00</td>
</tr>
<tr>
<td></td>
<td>INVOICE AMOUNT</td>
<td>145.99</td>
</tr>
</table>


Shop Us OnLine @ TruckPro.com 24/7 Place Orders and Look For Specials

TX 170209 08:41 P01

CART

W G

TERMS: NET 10th PROX.

1\) The only warranties on the goods sold with this invoice ('Goods') are those, if any, made expressly by the manufacturer of such Goods, and specifically set forth by such manufacturer.
TRUCKPRO SPECIFICALLY DISCLAIMS ANY WARRANTIES OF ANY KIND WHATSOEVER ON THE GOODS, WHETHER EXPRESS, IMPLIED, STATUTORY, ORAL OR WRITTEN, INCLUDING WITHOUT LIMITAT
WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE or IMPLIED WARRANTY OF MERCHANTABILITY with respect to any such Goods. Truckpro neither assumes nor authorizes any person to assume on Truckpro's behalf any
other obligation or liability or to make any representation, promise or agreement.

2\) All claims and return goods must be accompanied by this invoice. If this account is not paid when due, I, we, or either of us agree to pay all Attorney Fees and all other costs which may be incurred in the collection of
this account.
3\) All credit balances on charge accounts must be offset with a purchase. Truckpro and customer hereby expressly agree that any credit balance unused by the customer to offset a purchase with one (1) year of the
creation of such credit balance shall be forfeited by customer and shall become the true property of Truckpro.
4\) Truckpro will never request changes to remittance Information via email. If you receive any such request, do not comply and contact us immediately at (800-677-2283 Opt. 3, Opt. 3) to verify the authenticity of the
request.
