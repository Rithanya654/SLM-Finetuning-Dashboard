# FASTENAL EUROPE LTD-PO.pdf

<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


# Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>1</td>
<td>87210720</td>
<td>mouk 18867</td>
<td>M5x12 DIN 965Z A2</td>
<td>284</td>
<td>4.7800</td>
<td>13.58 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-6 Stage 2 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>2</td>
<td>87210720</td>
<td>mouk 18867</td>
<td>M5x12 DIN 965Z A2</td>
<td>216</td>
<td>4.7800</td>
<td>10.32 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-6 Stage 2 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>3</td>
<td>039073C</td>
<td>mouk 18422</td>
<td>M6 X 16MM NUTSERT ST</td>
<td>600</td>
<td>6.2900</td>
<td>37.74 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-6 Stage 16 D</td>
<td></td>
<td></td>
</tr>
<tr>
<td>4</td>
<td>013926C</td>
<td>mouk 18824</td>
<td>10MM NUT CAP</td>
<td>2,000</td>
<td>4.6300</td>
<td>92.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td></td>
<td></td>
<td>Sub Location:</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>5</td>
<td>87682198</td>
<td>mouk 17771</td>
<td>M10 X 25MM SQUARE HE</td>
<td>350</td>
<td>42.2400</td>
<td>147.84 N</td>
</tr>
<tr>
<td>Location:</td>
<td></td>
<td></td>
<td>Sub Location:</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>6</td>
<td>71140016</td>
<td>mouk 18086</td>
<td>DOOR STOP BLACK RUBB</td>
<td>50</td>
<td>383.9100</td>
<td>191.96 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>Stage 16 E</td>
<td></td>
<td></td>
</tr>
<tr>
<td>7</td>
<td>13471-07519</td>
<td>mouk 18458</td>
<td>M6 Wing Nut DIN314 8</td>
<td>500</td>
<td>6.7200</td>
<td>33.60 T</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>6-1 Stage 14 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>8</td>
<td>87380310</td>
<td>530011252</td>
<td>M10 DIN 7980 Zn</td>
<td>500</td>
<td>9.2300</td>
<td>46.15 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-2 Stage 15</td>
<td></td>
<td></td>
</tr>
<tr>
<td>9</td>
<td>86230620</td>
<td>mouk 15476</td>
<td>200X4.6 BLACK 2-PIEC</td>
<td>500</td>
<td>21.6000</td>
<td>108.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-2 RF01-ELB</td>
<td></td>
<td></td>
</tr>
<tr>
<td>10</td>
<td>87230312</td>
<td>660001644</td>
<td>5x20 D7985Z 4.8Zn</td>
<td>500</td>
<td>0.8900</td>
<td>4.45 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-1 RF01-ELB</td>
<td></td>
<td></td>
</tr>
<tr>
<td>11</td>
<td>87380316</td>
<td>mouk 11086</td>
<td>M5 DIN 7980 A1</td>
<td>2,000</td>
<td>0.3100</td>
<td>6.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-3 RF01-ELB</td>
<td></td>
<td></td>
</tr>
<tr>
<td>12</td>
<td>665161</td>
<td>mouk 18654</td>
<td>151-02255 paste mnt</td>
<td>100</td>
<td>26.3000</td>
<td>26.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-2 RF01-ELB</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 1 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


## Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>13</td>
<td>87680639</td>
<td>mouk 17878</td>
<td>M6x25 DIN7500 M-Z Zn</td>
<td>500</td>
<td>2.0500</td>
<td>10.25 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-3 Stage 1</td>
<td></td>
<td></td>
</tr>
<tr>
<td>14</td>
<td>AA-01176</td>
<td>mouk 17891</td>
<td>type-fp20-glazing-pa</td>
<td>200</td>
<td>1.5200</td>
<td>3.04 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-1 Stage 1</td>
<td></td>
<td></td>
</tr>
<tr>
<td>15</td>
<td>86510718</td>
<td>mouk 18236</td>
<td>2 x 32/0.20mm Flat T</td>
<td>1</td>
<td>4,138.9000</td>
<td>41.39 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 5-1 Stage 1</td>
<td></td>
<td></td>
</tr>
<tr>
<td>16</td>
<td>86230607</td>
<td>mouk 18654</td>
<td>151-02255 paste mnt</td>
<td>200</td>
<td>26.3000</td>
<td>52.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-3 Stage 1</td>
<td></td>
<td></td>
</tr>
<tr>
<td>17</td>
<td>037077C</td>
<td>mouk 18128</td>
<td>M6-1.0 x 20 mm ISO 7</td>
<td>300</td>
<td>26.7400</td>
<td>80.22 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-5 Stage 1</td>
<td></td>
<td></td>
</tr>
<tr>
<td>18</td>
<td>87100208</td>
<td>660001861</td>
<td>M8-1.25x30 8.8 HCS Z</td>
<td>200</td>
<td>2.3800</td>
<td>4.76 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-6 Stage 1</td>
<td></td>
<td></td>
</tr>
<tr>
<td>19</td>
<td>8711005N38</td>
<td>660001402</td>
<td>M10x40 DIN933 10.9Zn</td>
<td>50</td>
<td>25.1600</td>
<td>12.58 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-2 RF01-ELB Rack 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>20</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>400</td>
<td>1.2500</td>
<td>5.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-4 RF01-ELB Rack 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>21</td>
<td>86230607</td>
<td>mouk 18654</td>
<td>151-02255 paste mnt</td>
<td>200</td>
<td>26.3000</td>
<td>52.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-1 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>22</td>
<td>87630207</td>
<td>mouk 18213</td>
<td>1/4PTStZnBlindRivet</td>
<td>400</td>
<td>6.8000</td>
<td>27.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-5 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>23</td>
<td>87100208</td>
<td>660001861</td>
<td>M8-1.25x30 8.8 HCS Z</td>
<td>500</td>
<td>2.3800</td>
<td>11.90 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-4 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>24</td>
<td>87102270</td>
<td>mouk 18187</td>
<td>M10x60 D931 A2-70</td>
<td>100</td>
<td>72.3000</td>
<td>72.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-6 Stage 4 B</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 2 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


## Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>25</td>
<td>8732001L20</td>
<td>mouk 17975</td>
<td>VERSA-NUT INS M6 STL</td>
<td>150</td>
<td>26.6100</td>
<td>39.92 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-6 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>26</td>
<td>87110836</td>
<td>moukk0006</td>
<td>M10-1.5 x 25mm DIN 9</td>
<td>300</td>
<td>25.5400</td>
<td>76.62 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-2 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>27</td>
<td>8711002L07</td>
<td>scuk3077</td>
<td>M8-1.25 x 30 mm DIN</td>
<td>50</td>
<td>17.8300</td>
<td>8.92 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-1 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>28</td>
<td>87292119</td>
<td>mouk 17263</td>
<td>M10 Clamp Nut</td>
<td>250</td>
<td>49.8500</td>
<td>124.63 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-4 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>29</td>
<td>87640102</td>
<td>mouk 18153</td>
<td>MONOBOLT 4.80 X 26.3</td>
<td>400</td>
<td>6.9800</td>
<td>27.92 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-6 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>30</td>
<td>8711005N38</td>
<td>660001402</td>
<td>M10x40 DIN933 10.9Zn</td>
<td>55</td>
<td>25.1600</td>
<td>13.84 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-3 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>31</td>
<td>87110001</td>
<td>660000990</td>
<td>M6-1.0x20 8.8 HCS P</td>
<td>600</td>
<td>1.0000</td>
<td>6.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-4 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>32</td>
<td>87100107</td>
<td>660000990</td>
<td>M6-1.0x20 8.8 HCS P</td>
<td>77</td>
<td>1.0000</td>
<td>0.77 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-4 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>33</td>
<td>177773C</td>
<td>mouk 18559</td>
<td>Green Connector Acce</td>
<td>1,500</td>
<td>3.7900</td>
<td>56.85 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-5 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>34</td>
<td>87330106</td>
<td>530014092</td>
<td>M10 DIN125A 140HV Zn</td>
<td>1,000</td>
<td>1.0000</td>
<td>10.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>6-6 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>35</td>
<td>87330106</td>
<td>530014092</td>
<td>M10 DIN125A 140HV Zn</td>
<td>1,000</td>
<td>1.0000</td>
<td>10.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-6 Stage 16 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>36</td>
<td>039419C</td>
<td>660001408</td>
<td>M6x20 DIN 933 A2</td>
<td>400</td>
<td>2.6800</td>
<td>10.72 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-4 Stage 16 A</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 3 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>37</td>
<td>AA-01177</td>
<td>mouk 17495</td>
<td>type-fp24-glazing-pa</td>
<td>60</td>
<td>2.2300</td>
<td>1.34 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-5 Stage 15 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>38</td>
<td>8711006N38</td>
<td>mouk 18679</td>
<td>10x30 DIN933 10.9 Zn</td>
<td>200</td>
<td>7.3200</td>
<td>14.64 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-5 Stage 15</td>
<td></td>
<td></td>
</tr>
<tr>
<td>39</td>
<td>87100715</td>
<td>660001179</td>
<td>M8x25 DIN 933 A2</td>
<td>200</td>
<td>6.6100</td>
<td>13.22 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-3 Stage 15</td>
<td></td>
<td></td>
</tr>
<tr>
<td>40</td>
<td>177783C</td>
<td>mouk 10423</td>
<td>M 0.3-0.6mm Terminal</td>
<td>200</td>
<td>7.5900</td>
<td>15.18 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-2 Stage 14 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>41</td>
<td>87490301</td>
<td>mouk 18355</td>
<td>ALU AVEX CSK RIVET 4</td>
<td>300</td>
<td>1.1200</td>
<td>3.36 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-4 Stage 17</td>
<td></td>
<td></td>
</tr>
<tr>
<td>42</td>
<td>8769001L05</td>
<td>530012874</td>
<td>M8x20 ISO 7380-2 A2</td>
<td>200</td>
<td>4.4100</td>
<td>8.82 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-4 Stage 17</td>
<td></td>
<td></td>
</tr>
<tr>
<td>43</td>
<td>87682238</td>
<td>mouk 18437</td>
<td>M6x25 DIN7500C-TX Zn</td>
<td>200</td>
<td>3.5800</td>
<td>7.16 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-3 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>44</td>
<td>87330123</td>
<td>530009919</td>
<td>M10 DIN 125A A2</td>
<td>1,000</td>
<td>1.2100</td>
<td>12.10 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-6 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>45</td>
<td>87280306</td>
<td>660001960</td>
<td>M10 DIN 982 8 Zn</td>
<td>800</td>
<td>1.8800</td>
<td>15.04 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-3 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>46</td>
<td>87682279</td>
<td>mouk 17647</td>
<td>M6-1.0 x 30 mm DIN 7</td>
<td>500</td>
<td>2.3500</td>
<td>11.75 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-2 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>47</td>
<td>8769001L05</td>
<td>530012874</td>
<td>M8x20 ISO 7380-2 A2</td>
<td>600</td>
<td>4.4100</td>
<td>26.46 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-3 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>48</td>
<td>87640203</td>
<td>mouk 18137</td>
<td>1/4CSStZnBlindRivet</td>
<td>200</td>
<td>8.1700</td>
<td>16.34 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 5-5 Stage 16 B</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 4 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>49</td>
<td>013926C</td>
<td>mouk 18824</td>
<td>10MM NUT CAP</td>
<td>300</td>
<td>4.6300</td>
<td>13.89 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-1 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>50</td>
<td>86832021</td>
<td>mouk 13222</td>
<td>AMP MCP Connector Sy</td>
<td>200</td>
<td>10.5400</td>
<td>21.08 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-1 Stage 16 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>51</td>
<td>8711005N38</td>
<td>660001402</td>
<td>M10x40 DIN933 10.9Zn</td>
<td>100</td>
<td>25.1600</td>
<td>25.16 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-4 Stage 16 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>52</td>
<td>87682198</td>
<td>mouk 17771</td>
<td>M10 X 25MM SQUARE HE</td>
<td>350</td>
<td>42.2400</td>
<td>147.84 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-4 Stage 16 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>53</td>
<td>86230003</td>
<td>mouk 18554</td>
<td>Cabe Tie 190x3.5 PA</td>
<td>500</td>
<td>6.6800</td>
<td>33.40 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-6 Stage 16 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>54</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>600</td>
<td>1.2500</td>
<td>7.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-4 Stage 5 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>55</td>
<td>610808-1</td>
<td>shuk2077</td>
<td>370x7.6mmCblTsPk100</td>
<td>200</td>
<td>10.9300</td>
<td>21.86 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-2 Stage 6</td>
<td></td>
<td></td>
</tr>
<tr>
<td>56</td>
<td>86230607</td>
<td>mouk 18654</td>
<td>151-02255 paste mnt</td>
<td>200</td>
<td>26.3000</td>
<td>52.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-4 Stage 6</td>
<td></td>
<td></td>
</tr>
<tr>
<td>57</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>600</td>
<td>1.2500</td>
<td>7.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-2 Stage 6</td>
<td></td>
<td></td>
</tr>
<tr>
<td>58</td>
<td>8711005N38</td>
<td>660001402</td>
<td>M10x40 DIN933 10.9Zn</td>
<td>100</td>
<td>25.1600</td>
<td>25.16 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-5 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>59</td>
<td>8711002L07</td>
<td>scuk3077</td>
<td>M8-1.25 x 30 mm DIN</td>
<td>300</td>
<td>17.8300</td>
<td>53.49 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-4 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>60</td>
<td>87110001</td>
<td>530004797</td>
<td>M6-1.0x20 8.8 HCS P</td>
<td>250</td>
<td>1.0000</td>
<td>2.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-3 Stage 5</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 5 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


#### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>61</td>
<td>87630201</td>
<td>mouk 18137</td>
<td>MonoRivet6.4x23.7</td>
<td>400</td>
<td>7.1300</td>
<td>28.52 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-3 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>62</td>
<td>87610707</td>
<td>mouk 14360</td>
<td>1/4StlLckbltPinBR/HD</td>
<td>1,000</td>
<td>9.6700</td>
<td>96.70 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-2 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>63</td>
<td>AA-01175</td>
<td>mouk 17384</td>
<td>type-fp24-glazing-pa</td>
<td>100</td>
<td>1.2500</td>
<td>1.25 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-1 Stage 8 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>64</td>
<td>AA-01176</td>
<td>mouk 17891</td>
<td>type-fp20-glazing-pa</td>
<td>100</td>
<td>1.5200</td>
<td>1.52 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-6 Stage 8 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>65</td>
<td>76502233</td>
<td>mouk 18404</td>
<td>RCP 3 POS 5.5mm Crim</td>
<td>250</td>
<td>60.8800</td>
<td>152.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>6-2 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>66</td>
<td>86832025</td>
<td>mouk 18277</td>
<td>TE 1-968851-1</td>
<td>400</td>
<td>11.9800</td>
<td>47.92 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-5 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>67</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>400</td>
<td>1.2500</td>
<td>5.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-6 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>68</td>
<td>87100208</td>
<td>660001861</td>
<td>M8-1.25x30 8.8 HCS Z</td>
<td>400</td>
<td>2.3800</td>
<td>9.52 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-1 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>69</td>
<td>87330002</td>
<td>mouk 18738</td>
<td>M8 BS B Washer</td>
<td>2,000</td>
<td>0.3300</td>
<td>6.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-1 Stage 12 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>70</td>
<td>660217-11</td>
<td>shuk10269</td>
<td>39.3x12mm Hose Clip</td>
<td>30</td>
<td>299.9000</td>
<td>89.97 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-3 Stage 13 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>71</td>
<td>87630207</td>
<td>mouk 18213</td>
<td>1/4PTStZnBlindRivet</td>
<td>500</td>
<td>6.8000</td>
<td>34.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-5 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>72</td>
<td>87660504</td>
<td>mouk 14360</td>
<td>1/4 Steel Collar</td>
<td>500</td>
<td>3.7300</td>
<td>18.65 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-2 Stage 7</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 6 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


#### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>73</td>
<td>87640203</td>
<td>mouk 18137</td>
<td>1/4CSStZnBlindRivet</td>
<td>300</td>
<td>8.1700</td>
<td>24.51 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-6 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>74</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>400</td>
<td>1.2500</td>
<td>5.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-4 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>75</td>
<td>430960</td>
<td>mouk 17992</td>
<td>FORM G WASHER - 6MMD</td>
<td>1,000</td>
<td>1.3500</td>
<td>13.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-4 Stage 8 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>76</td>
<td>87230334</td>
<td>mouk 18723</td>
<td>5x20 D7985Z A2</td>
<td>500</td>
<td>3.9600</td>
<td>19.80 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>6-6 Stage 8 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>77</td>
<td>8769001L05</td>
<td>530012874</td>
<td>M8x20 ISO 7380-2 A2</td>
<td>200</td>
<td>4.4100</td>
<td>8.82 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-2 Stage 8 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>78</td>
<td>87350205</td>
<td>mouk 17520</td>
<td>PENNY WASHER 8MM DIA</td>
<td>200</td>
<td>3.4900</td>
<td>6.98 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-4 Stage 13 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>79</td>
<td>87430313</td>
<td>mouk 18488</td>
<td>4.2mm x 13mm DIN 968</td>
<td>500</td>
<td>1.3300</td>
<td>6.65 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>6-1 Stage 13 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>80</td>
<td>8711002L07</td>
<td>scuk3077</td>
<td>M8-1.25 x 30 mm DIN</td>
<td>300</td>
<td>17.8300</td>
<td>53.49 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>6-5 Stage 13 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>81</td>
<td>430960</td>
<td>mouk 17992</td>
<td>FORM G WASHER - 6MMD</td>
<td>1,000</td>
<td>1.3500</td>
<td>13.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-3 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>82</td>
<td>87280311</td>
<td>530012875</td>
<td>M6 DIN 985 A2</td>
<td>600</td>
<td>1.2900</td>
<td>7.74 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-5 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>83</td>
<td>4012963</td>
<td>mouk 18725</td>
<td>714x35x3mm Neoprene</td>
<td>20</td>
<td>99.0000</td>
<td>19.80 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-2 Stage 2</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 7 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


#### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>84</td>
<td>4012963</td>
<td>mouk 18725</td>
<td>714x35x3mm Neoprene</td>
<td>10</td>
<td>99.0000</td>
<td>9.90 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-3 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>85</td>
<td>87682397</td>
<td>scuk2629</td>
<td>STL TORX PLUS CSK TA</td>
<td>1,000</td>
<td>16.2000</td>
<td>162.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-3 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>86</td>
<td>68250026</td>
<td>shuk2345</td>
<td>JUBILEE CLIP 500-140</td>
<td>20</td>
<td>60.4100</td>
<td>12.08 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>6-6 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>87</td>
<td>68250101</td>
<td>mouk 14074</td>
<td>JUBILEE CLIP - 140-1</td>
<td>10</td>
<td>72.0100</td>
<td>7.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-6 Stage 1 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>88</td>
<td>754240</td>
<td>mouk 16274</td>
<td>Black Butyl Tape 3m</td>
<td>2</td>
<td>936.7900</td>
<td>18.74 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-3 Stage 1 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>89</td>
<td>8741001C55</td>
<td>mouk 10382</td>
<td>M6-1x25DIN7500M-ZA2</td>
<td>500</td>
<td>4.5500</td>
<td>22.75 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>6-1 Stage 1 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>90</td>
<td>87682254</td>
<td>mouk 10056</td>
<td>ST 87682254 ALUMINIU</td>
<td>1,000</td>
<td>0.0000</td>
<td>0.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-6 Stage 1 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>91</td>
<td>87330002</td>
<td>mouk 18738</td>
<td>M8 BS B Washer</td>
<td>1,000</td>
<td>0.3300</td>
<td>3.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-5 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>92</td>
<td>480166</td>
<td>mouk 18589</td>
<td>MILD STEEL WASHER TO</td>
<td>48</td>
<td>35.7600</td>
<td>17.16 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-5 Stage 15 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>93</td>
<td>8732001L05</td>
<td>mouk 17882</td>
<td>M8 X 19 S/S Nutsert</td>
<td>400</td>
<td>20.7600</td>
<td>83.04 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-1 Stage 16 E</td>
<td></td>
<td></td>
</tr>
<tr>
<td>94</td>
<td>053187</td>
<td>530014092</td>
<td>M10 DIN125A 140HV Zn</td>
<td>1,000</td>
<td>1.0000</td>
<td>10.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-2 Stage 16 E</td>
<td></td>
<td></td>
</tr>
<tr>
<td>95</td>
<td>87100109</td>
<td>mouk 16256</td>
<td>M6x25D931CZ3Cl8.8HCS</td>
<td>500</td>
<td>2.5600</td>
<td>12.80 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-4 Stage 16 E</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 8 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


#### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th colspan="2">Description Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>96</td>
<td>87100109</td>
<td>shuk2175</td>
<td>M6x25D931CZ3Cl8.8HCS</td>
<td>332</td>
<td>2.5600</td>
<td>8.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-4 Stage 16 E</td>
<td></td>
<td></td>
</tr>
<tr>
<td>97</td>
<td>013926C</td>
<td>mouk 18824</td>
<td>10MM NUT CAP</td>
<td>250</td>
<td>4.6300</td>
<td>11.58 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-1 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>98</td>
<td>87100712</td>
<td>660001621</td>
<td>M12x40 DIN 931 8.8Zn</td>
<td>200</td>
<td>12.0000</td>
<td>24.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-6 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>99</td>
<td>C9010002</td>
<td>mouk 17794</td>
<td>TP610 15/4-10 Duo Im</td>
<td>1</td>
<td>1,605.0000</td>
<td>16.05 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-2 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>100</td>
<td>4014822</td>
<td>mouk 17086</td>
<td>Natural Neoprene Rub</td>
<td>5</td>
<td>266.0000</td>
<td>13.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 5-1 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>101</td>
<td>87682198</td>
<td>mouk 17771</td>
<td>M10 X 25MM SQUARE HE</td>
<td>350</td>
<td>42.2400</td>
<td>147.84 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-4 Stage 16 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>102</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>500</td>
<td>1.2500</td>
<td>6.25 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-2 Stage 16 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>103</td>
<td>86700448</td>
<td>mouk 18377</td>
<td>Timer Connector Syst</td>
<td>200</td>
<td>18.1100</td>
<td>36.22 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-5 RF01-ELB Rack 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>104</td>
<td>87320008</td>
<td>mouk 18838</td>
<td>TAPPEX GEAR INSET SE</td>
<td>100</td>
<td>18.3000</td>
<td>18.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-4 RF01-ELB Rack 4</td>
<td></td>
<td></td>
</tr>
<tr>
<td>105</td>
<td>76502217</td>
<td>mouk 18559</td>
<td>PL 3 POS 5.5mm Crimp</td>
<td>250</td>
<td>66.6000</td>
<td>166.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-5 Stage 16 D</td>
<td></td>
<td></td>
</tr>
<tr>
<td>106</td>
<td>87682388</td>
<td>mouk 17790</td>
<td>M5 x 60 Male-Female</td>
<td>50</td>
<td>88.5800</td>
<td>44.29 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-5 RF01-ELB</td>
<td></td>
<td></td>
</tr>
<tr>
<td>107</td>
<td>8768021N01</td>
<td>mouk 18624</td>
<td>M4x12 ISO7380-1 10.9</td>
<td>500</td>
<td>4.1200</td>
<td>20.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 5-3 RF01-ELB</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 9 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>108</td>
<td>87110836</td>
<td>moukk0006</td>
<td>M10-1.5 x 25mm DIN 9</td>
<td>400</td>
<td>25.5400</td>
<td>102.16 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-2 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>109</td>
<td>87630207</td>
<td>mouk 17566</td>
<td>1/4PTStZnBlindRivet</td>
<td>300</td>
<td>6.8000</td>
<td>20.40 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-5 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>110</td>
<td>87610707</td>
<td>mouk 14360</td>
<td>1/4StlLckbltPinBR/HD</td>
<td>150</td>
<td>9.6700</td>
<td>14.51 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-2 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>111</td>
<td>87100208</td>
<td>660001861</td>
<td>M8-1.25x30 8.8 HCS Z</td>
<td>400</td>
<td>2.3800</td>
<td>9.52 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-4 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>112</td>
<td>8711005N38</td>
<td>660001402</td>
<td>M10x40 DIN933 10.9Zn</td>
<td>80</td>
<td>25.1600</td>
<td>20.13 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-3 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>113</td>
<td>87630201</td>
<td>mouk 18137</td>
<td>MonoRivet6.4x23.7</td>
<td>250</td>
<td>7.1300</td>
<td>17.83 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-5 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>114</td>
<td>87350205</td>
<td>mouk 17520</td>
<td>PENNY WASHER 8MM DIA</td>
<td>200</td>
<td>3.4900</td>
<td>6.98 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-4 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>115</td>
<td>AA-01177</td>
<td>mouk 17495</td>
<td>type-fp24-glazing-pa</td>
<td>60</td>
<td>2.2300</td>
<td>1.34 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-5 Stage 1</td>
<td></td>
<td></td>
</tr>
<tr>
<td>116</td>
<td>86510718</td>
<td>mouk 18236</td>
<td>2 x 32/0.20mm Flat T</td>
<td>1</td>
<td>4,138.9000</td>
<td>41.39 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 5-1 Stage 1</td>
<td></td>
<td></td>
</tr>
<tr>
<td>117</td>
<td>7675002L05</td>
<td>mouk 15567</td>
<td>SealBoot</td>
<td>32</td>
<td>217.3800</td>
<td>69.56 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-5 Stage 1</td>
<td></td>
<td></td>
</tr>
<tr>
<td>118</td>
<td>8711000N116</td>
<td>mouk 18827</td>
<td>093101000500001201</td>
<td>100</td>
<td>23.5000</td>
<td>23.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 5-6 Stage 5 B</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 10 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>119</td>
<td>87330124</td>
<td>530015803</td>
<td>M8 DIN 125A 140HV Zn</td>
<td>1,000</td>
<td>1.5300</td>
<td>15.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-6 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>120</td>
<td>87100208</td>
<td>660001861</td>
<td>M8-1.25x30 8.8 HCS Z</td>
<td>400</td>
<td>2.3800</td>
<td>9.52 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-2 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>121</td>
<td>87630201</td>
<td>mouk 18137</td>
<td>MonoRivet6.4x23.7</td>
<td>400</td>
<td>7.1300</td>
<td>28.52 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-3 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>122</td>
<td>87110836</td>
<td>moukk0006</td>
<td>M10-1.5 x 25mm DIN 9</td>
<td>300</td>
<td>25.5400</td>
<td>76.62 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-1 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>123</td>
<td>87292119</td>
<td>mouk 17263</td>
<td>M10 Clamp Nut</td>
<td>400</td>
<td>49.8500</td>
<td>199.40 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 5-6 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>124</td>
<td>87330106</td>
<td>530014092</td>
<td>M10 DIN125A 140HV Zn</td>
<td>400</td>
<td>1.0000</td>
<td>4.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 5-1 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>125</td>
<td>87660504</td>
<td>mouk 14360</td>
<td>1/4 Steel Collar</td>
<td>600</td>
<td>3.7300</td>
<td>22.38 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-5 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>126</td>
<td>87630207</td>
<td>mouk 17566</td>
<td>1/4PTStZnBlindRivet</td>
<td>250</td>
<td>6.8000</td>
<td>17.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-4 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>127</td>
<td>86230003</td>
<td>mouk 18554</td>
<td>Cabe Tie 190x3.5 PA</td>
<td>400</td>
<td>6.6800</td>
<td>26.72 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-5 Stage 8 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>128</td>
<td>660217-6</td>
<td>mouk 18541</td>
<td>HIGH TEMP LINED HOSE</td>
<td>20</td>
<td>154.4300</td>
<td>30.89 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-2 Stage 8 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>129</td>
<td>660217-19</td>
<td>mouk 10391</td>
<td>HIGH TEMP LINED HOSE</td>
<td>60</td>
<td>173.3900</td>
<td>104.03 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-5 Stage 8 D</td>
<td></td>
<td></td>
</tr>
<tr>
<td>130</td>
<td>013926C</td>
<td>mouk 18824</td>
<td>10MM NUT CAP</td>
<td>100</td>
<td>4.6300</td>
<td>4.63 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-5 Stage 13 A</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 11 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>131</td>
<td>86230607</td>
<td>mouk 18654</td>
<td>151-02255 paste mnt</td>
<td>200</td>
<td>26.3000</td>
<td>52.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-4 Stage 6</td>
<td></td>
<td></td>
</tr>
<tr>
<td>132</td>
<td>610029-19</td>
<td>mouk 16182</td>
<td>41.9x25mm Hose Clip</td>
<td>15</td>
<td>109.0800</td>
<td>16.36 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-6 Stage 6</td>
<td></td>
<td></td>
</tr>
<tr>
<td>133</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>500</td>
<td>1.2500</td>
<td>6.25 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-2 Stage 6</td>
<td></td>
<td></td>
</tr>
<tr>
<td>134</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>1,000</td>
<td>1.2500</td>
<td>12.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-4 Stage 14 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>135</td>
<td>660217-11</td>
<td>shuk 10269</td>
<td>39.3x12mm Hose Clip</td>
<td>20</td>
<td>299.9000</td>
<td>59.98 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-3 Stage 13 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>136</td>
<td>86230610</td>
<td>mouk 17902</td>
<td>2-Piece Fixing Tie f</td>
<td>100</td>
<td>26.3500</td>
<td>26.35 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-5 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>137</td>
<td>68250273</td>
<td>mouk 10262</td>
<td>PIPE CLIP - 50 - 70</td>
<td>10</td>
<td>42.8400</td>
<td>4.28 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-2 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>138</td>
<td>86230611</td>
<td>mouk 18189</td>
<td>200x4.6mm Black T50R</td>
<td>500</td>
<td>21.6000</td>
<td>108.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-3 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>139</td>
<td>87630207</td>
<td>mouk 18213</td>
<td>1/4PTStZnBlindRivet</td>
<td>150</td>
<td>6.8000</td>
<td>10.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-3 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>140</td>
<td>87630207</td>
<td>mouk 18213</td>
<td>1/4PTStZnBlindRivet</td>
<td>200</td>
<td>6.8000</td>
<td>13.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-5 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>141</td>
<td>86832049</td>
<td>mouk 18168</td>
<td>TE Contact PIN Crimp</td>
<td>200</td>
<td>54.8600</td>
<td>109.72 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-6 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>142</td>
<td>7675002L05</td>
<td>mouk 15567</td>
<td>SealBoot</td>
<td>80</td>
<td>217.3800</td>
<td>173.90 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-5 Stage 1</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 12 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>143</td>
<td>AA-01177</td>
<td>mouk 17495</td>
<td>type-fp24-glazing-pa</td>
<td>90</td>
<td>2.2300</td>
<td>2.01 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-5 Stage 1</td>
<td></td>
<td></td>
</tr>
<tr>
<td>144</td>
<td>021067C</td>
<td>mouk 18681</td>
<td>4.8x25 Peel Rivet</td>
<td>300</td>
<td>2.7400</td>
<td>8.22 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-6 Stage 1</td>
<td></td>
<td></td>
</tr>
<tr>
<td>145</td>
<td>87330120</td>
<td>530008373</td>
<td>M5 DIN 125A A2</td>
<td>6,000</td>
<td>0.2800</td>
<td>16.80 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-3 Stage 4 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>146</td>
<td>87682397</td>
<td>scuk2629</td>
<td>STL TORX PLUS CSK TA</td>
<td>400</td>
<td>16.2000</td>
<td>64.80 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-4 Stage 4 D</td>
<td></td>
<td></td>
</tr>
<tr>
<td>147</td>
<td>87640203</td>
<td>mouk 18137</td>
<td>1/4CSStZnBlindRivet</td>
<td>400</td>
<td>8.1700</td>
<td>32.68 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-2 Stage 4 D</td>
<td></td>
<td></td>
</tr>
<tr>
<td>148</td>
<td>87200317</td>
<td>mouk 18608</td>
<td>3x16 D7985Z A2</td>
<td>500</td>
<td>1.0000</td>
<td>5.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-3 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>149</td>
<td>87330106</td>
<td>530014092</td>
<td>M10 DIN125A 140HV Zn</td>
<td>681</td>
<td>1.0000</td>
<td>6.81 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>6-6 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>150</td>
<td>053184C</td>
<td>160271675</td>
<td>FEND 1/4 X 1 Z</td>
<td>1,000</td>
<td>1.7600</td>
<td>17.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>6-3 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>151</td>
<td>87682377</td>
<td>mouk 18777</td>
<td>M5x25 ISO 7380-2 A2</td>
<td>600</td>
<td>4.8100</td>
<td>28.86 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-1 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>152</td>
<td>WMA-10SP</td>
<td>530014902</td>
<td>M10 ISO7089 200HV Zn</td>
<td>1,000</td>
<td>29.0100</td>
<td>290.10 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-3 Stage 5 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>153</td>
<td>87280305</td>
<td>530013913</td>
<td>M8 DIN 982 8 Zn</td>
<td>800</td>
<td>0.9200</td>
<td>7.36 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-4 Stage 5 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>154</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>600</td>
<td>1.2500</td>
<td>7.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-2 Stage 6</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 13 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>155</td>
<td>177787C</td>
<td>mouk 10423</td>
<td>Cable Mount Strip 0.</td>
<td>200</td>
<td>7.5900</td>
<td>15.18 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-2 Stage 6</td>
<td></td>
<td></td>
</tr>
<tr>
<td>156</td>
<td>404P436H61</td>
<td>660001408</td>
<td>M5x25 ISO4762 A2-70</td>
<td>800</td>
<td>3.4200</td>
<td>27.36 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-4 Stage 6</td>
<td></td>
<td></td>
</tr>
<tr>
<td>157</td>
<td>86230607</td>
<td>mouk 18654</td>
<td>151-02255 paste mnt</td>
<td>200</td>
<td>26.3000</td>
<td>52.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 5-4 Stage 6</td>
<td></td>
<td></td>
</tr>
<tr>
<td>158</td>
<td>87330106</td>
<td>530014092</td>
<td>M10 DIN125A 140HV Zn</td>
<td>1,442</td>
<td>1.0000</td>
<td>14.42 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 5-1 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>159</td>
<td>87280306</td>
<td>660001960</td>
<td>M10 DIN 982 8 Zn</td>
<td>800</td>
<td>1.8800</td>
<td>15.04 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-1 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>160</td>
<td>87330106</td>
<td>530008870</td>
<td>M10 DIN125A 140HV Zn</td>
<td>1,000</td>
<td>1.0000</td>
<td>10.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-4 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>161</td>
<td>87660504</td>
<td>mouk 14360</td>
<td>1/4 Steel Collar</td>
<td>1,772</td>
<td>3.7300</td>
<td>66.10 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-5 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>162</td>
<td>87630207</td>
<td>mouk 18714</td>
<td>1/4PTStZnBlindRivet</td>
<td>700</td>
<td>6.8000</td>
<td>47.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-4 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>163</td>
<td>87630201</td>
<td>mouk 18137</td>
<td>MonoRivet6.4x23.7</td>
<td>400</td>
<td>7.1300</td>
<td>28.52 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-3 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>164</td>
<td>8728002N38</td>
<td>660001197</td>
<td>M10 DIN 982 10 Zn</td>
<td>300</td>
<td>6.6500</td>
<td>19.95 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-6 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>165</td>
<td>702998</td>
<td>mouk 15177</td>
<td>4.8 x 25.0 CRZ FLN C</td>
<td>650</td>
<td>0.8100</td>
<td>5.27 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-2 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>166</td>
<td>87110836</td>
<td>moukk0006</td>
<td>M10-1.5 x 25mm DIN 9</td>
<td>250</td>
<td>25.5400</td>
<td>63.85 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-1 Stage 5</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 14 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>167</td>
<td>8711005N38</td>
<td>660001402</td>
<td>M10x40 DIN933 10.9Zn</td>
<td>300</td>
<td>25.1600</td>
<td>75.48 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-5 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>168</td>
<td>87630207</td>
<td>mouk 18714</td>
<td>1/4PTStZnBlindRivet</td>
<td>400</td>
<td>6.8000</td>
<td>27.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-5 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>169</td>
<td>8728002N38</td>
<td>660001197</td>
<td>M10 DIN 982 10 Zn</td>
<td>166</td>
<td>6.6500</td>
<td>11.04 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-3 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>170</td>
<td>8728002N38</td>
<td>660001404</td>
<td>M10 DIN 982 10 Zn</td>
<td>84</td>
<td>6.6500</td>
<td>5.59 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-3 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>171</td>
<td>87350205</td>
<td>mouk 17520</td>
<td>PENNY WASHER 8MM DIA</td>
<td>400</td>
<td>3.4900</td>
<td>13.96 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-4 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>172</td>
<td>87100208</td>
<td>660001861</td>
<td>M8-1.25x30 8.8 HCS Z</td>
<td>500</td>
<td>2.3800</td>
<td>11.90 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-4 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>173</td>
<td>8711005N38</td>
<td>660001402</td>
<td>M10x40 DIN933 10.9Zn</td>
<td>350</td>
<td>25.1600</td>
<td>88.06 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-3 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>174</td>
<td>87610707</td>
<td>mouk 14360</td>
<td>1/4StlLckbltPinBR/HD</td>
<td>600</td>
<td>9.6700</td>
<td>58.02 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-2 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>175</td>
<td>8732001L05</td>
<td>moukk0001</td>
<td>M8 X 19 S/S Nutsert</td>
<td>3</td>
<td>20.7600</td>
<td>0.62 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-3 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>176</td>
<td>8732001L05</td>
<td>mouk 17882</td>
<td>M8 X 19 S/S Nutsert</td>
<td>600</td>
<td>20.7600</td>
<td>124.56 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-3 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>177</td>
<td>87630201</td>
<td>mouk 18137</td>
<td>MonoRivet6.4x23.7</td>
<td>400</td>
<td>7.1300</td>
<td>28.52 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-5 Stage 4 B</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 15 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>178</td>
<td>8732001L20</td>
<td>mouk 17975</td>
<td>VERSA-NUT INS M6 STL</td>
<td>350</td>
<td>26.6100</td>
<td>93.14 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-6 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>179</td>
<td>87682358</td>
<td>mouk 18019</td>
<td>M6x25 Fastener</td>
<td>120</td>
<td>72.1600</td>
<td>86.59 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-4 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>180</td>
<td>87640102</td>
<td>mouk 18153</td>
<td>MONOBOLT 4.80 X 26.3</td>
<td>650</td>
<td>6.9800</td>
<td>45.37 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-6 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>181</td>
<td>87110836</td>
<td>moukk0006</td>
<td>M10-1.5 x 25mm DIN 9</td>
<td>300</td>
<td>25.5400</td>
<td>76.62 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-2 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>182</td>
<td>86230607</td>
<td>mouk 18654</td>
<td>151-02255 paste mnt</td>
<td>200</td>
<td>26.3000</td>
<td>52.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-2 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>183</td>
<td>87630207</td>
<td>mouk 18714</td>
<td>1/4PTStZnBlindRivet</td>
<td>500</td>
<td>6.8000</td>
<td>34.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-5 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>184</td>
<td>87610711</td>
<td>mouk 17286</td>
<td>1/4StlLckbltPinBR/HD</td>
<td>500</td>
<td>9.5500</td>
<td>47.75 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-3 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>185</td>
<td>86230611</td>
<td>mouk 18189</td>
<td>200x4.6mm Black T50R</td>
<td>170</td>
<td>21.6000</td>
<td>36.72 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-5 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>186</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>1,200</td>
<td>1.2500</td>
<td>15.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-4 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>187</td>
<td>660217-6</td>
<td>SHUK9733</td>
<td>HIGH TEMP LINED HOSE</td>
<td>40</td>
<td>154.4300</td>
<td>61.77 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-2 Stage 8 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>188</td>
<td>AA-01175</td>
<td>mouk 17384</td>
<td>type-fp24-glazing-pa</td>
<td>200</td>
<td>1.2500</td>
<td>2.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-1 Stage 8 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>189</td>
<td>AA-01177</td>
<td>mouk 17495</td>
<td>type-fp24-glazing-pa</td>
<td>90</td>
<td>2.2300</td>
<td>2.01 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-5 Stage 8 C</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 16 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>190</td>
<td>AA-02425</td>
<td>mouk 17473</td>
<td>type-fp24-glazing-pa</td>
<td>200</td>
<td>1.1300</td>
<td>2.26 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-4 Stage 8 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>191</td>
<td>AA-01176</td>
<td>mouk 17891</td>
<td>type-fp20-glazing-pa</td>
<td>136</td>
<td>1.5200</td>
<td>2.07 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-6 Stage 8 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>192</td>
<td>87110690</td>
<td>530010950</td>
<td>M6x16 DIN 933 A2</td>
<td>1,200</td>
<td>2.1600</td>
<td>25.92 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-2 Stage 8 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>193</td>
<td>87280305</td>
<td>530013913</td>
<td>M8 DIN 982 8 Zn</td>
<td>800</td>
<td>0.9200</td>
<td>7.36 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-5 Stage 8 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>194</td>
<td>68250087</td>
<td>mouk17763</td>
<td>35-50/12Torro</td>
<td>30</td>
<td>19.7600</td>
<td>5.93 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-6 Stage 8 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>195</td>
<td>87280420</td>
<td>530009338</td>
<td>M4 DIN 985 A2</td>
<td>1,500</td>
<td>1.2500</td>
<td>18.75 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-2 Stage 8 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>196</td>
<td>8732001L20</td>
<td>mouk 17975</td>
<td>VERSA-NUT INS M6 STL</td>
<td>350</td>
<td>26.6100</td>
<td>93.14 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-5 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>197</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>800</td>
<td>1.2500</td>
<td>10.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-6 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>198</td>
<td>86832025</td>
<td>mouk 18277</td>
<td>TE 1-968851-1</td>
<td>492</td>
<td>11.9800</td>
<td>58.94 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-5 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>199</td>
<td>76502233</td>
<td>mouk 18404</td>
<td>RCP 3 POS 5.5mm Crim</td>
<td>200</td>
<td>60.8800</td>
<td>121.76 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-2 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>200</td>
<td>87100208</td>
<td>660001861</td>
<td>M8-1.25x30 8.8 HCS Z</td>
<td>300</td>
<td>2.3800</td>
<td>7.14 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-1 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>201</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>1,200</td>
<td>1.2500</td>
<td>15.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-4 Stage 14 B</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 17 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


#### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>202</td>
<td>177783C</td>
<td>mouk 10423</td>
<td>M 0.3-0.6mm Terminal</td>
<td>200</td>
<td>7.5900</td>
<td>15.18 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-2 Stage 14 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>203</td>
<td>87410511</td>
<td>moukk0005</td>
<td>3.5x19 DIN7982CZ Zn</td>
<td>2,000</td>
<td>0.4700</td>
<td>9.40 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-6 Stage 11</td>
<td></td>
<td></td>
</tr>
<tr>
<td>204</td>
<td>87200310</td>
<td>mouk 18738</td>
<td>M5x16 ISO7380-1 10.9</td>
<td>600</td>
<td>0.9700</td>
<td>5.82 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-4 Stage 12</td>
<td></td>
<td></td>
</tr>
<tr>
<td>205</td>
<td>87640102</td>
<td>mouk 18153</td>
<td>MONOBOLT 4.80 X 26.3</td>
<td>650</td>
<td>6.9800</td>
<td>45.37 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-1 Stage 12</td>
<td></td>
<td></td>
</tr>
<tr>
<td>206</td>
<td>AA-02425</td>
<td>mouk 17473</td>
<td>type-fp24-glazing-pa</td>
<td>203</td>
<td>1.1300</td>
<td>2.29 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-1 Stage 12</td>
<td></td>
<td></td>
</tr>
<tr>
<td>207</td>
<td>8769001L05</td>
<td>530012874</td>
<td>M8x20 ISO 7380-2 A2</td>
<td>350</td>
<td>4.4100</td>
<td>15.44 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-5 Stage 15</td>
<td></td>
<td></td>
</tr>
<tr>
<td>208</td>
<td>037077C</td>
<td>mouk 18128</td>
<td>M6-1.0 x 20 mm ISO 7</td>
<td>394</td>
<td>26.7400</td>
<td>105.36 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-6 Stage 15</td>
<td></td>
<td></td>
</tr>
<tr>
<td>209</td>
<td>87682397</td>
<td>scuk2629</td>
<td>STL TORX PLUS CSK TA</td>
<td>450</td>
<td>16.2000</td>
<td>72.90 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-4 Stage 13 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>210</td>
<td>87682198</td>
<td>mouk 17771</td>
<td>M10 X 25MM SQUARE HE</td>
<td>350</td>
<td>42.2400</td>
<td>147.84 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-6 Stage 13 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>211</td>
<td>013926C</td>
<td>mouk 18824</td>
<td>10MM NUT CAP</td>
<td>250</td>
<td>4.6300</td>
<td>11.58 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-5 Stage 13 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>212</td>
<td>87692119</td>
<td>mouk 18636</td>
<td>M6-1.0 x 20 mm ISO 7</td>
<td>1,000</td>
<td>5.2700</td>
<td>52.70 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-4 Stage 13 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>213</td>
<td>AA-01177</td>
<td>mouk 17495</td>
<td>type-fp24-glazing-pa</td>
<td>73</td>
<td>2.2300</td>
<td>1.63 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-6 Stage 13 B</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 18 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


#### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>214</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>500</td>
<td>1.2500</td>
<td>6.25 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-6 Stage 13 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>215</td>
<td>667796</td>
<td>mouk 18663</td>
<td>Natural Nylon Flat W</td>
<td>1,000</td>
<td>2.6900</td>
<td>26.90 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-3 Stage 14 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>216</td>
<td>667796</td>
<td>mouk 18663</td>
<td>Natural Nylon Flat W</td>
<td>1,000</td>
<td>2.6900</td>
<td>26.90 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-4 Stage 14 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>217</td>
<td>87190005</td>
<td>mouk 17484</td>
<td>M4x20 DIN 965Z A2</td>
<td>1,000</td>
<td>2.4100</td>
<td>24.10 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-4 Stage 14 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>218</td>
<td>480166</td>
<td>mouk 18589</td>
<td>MILD STEEL WASHER TO</td>
<td>150</td>
<td>35.7600</td>
<td>53.64 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 5-5 Stage 15 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>219</td>
<td>8769001L05</td>
<td>530012874</td>
<td>M8x20 ISO 7380-2 A2</td>
<td>600</td>
<td>4.4100</td>
<td>26.46 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-3 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>220</td>
<td>87280306</td>
<td>660001960</td>
<td>M10 DIN 982 8 Zn</td>
<td>600</td>
<td>1.8800</td>
<td>11.28 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-3 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>221</td>
<td>87682279</td>
<td>mouk 17647</td>
<td>M6-1.0 x 30 mm DIN 7</td>
<td>506</td>
<td>2.3500</td>
<td>11.89 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-2 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>222</td>
<td>87640203</td>
<td>mouk 18137</td>
<td>1/4CSStZnBlindRivet</td>
<td>400</td>
<td>8.1700</td>
<td>32.68 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-5 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>223</td>
<td>87682238</td>
<td>mouk 18437</td>
<td>M6x25 DIN7500C-TX Zn</td>
<td>600</td>
<td>3.5800</td>
<td>21.48 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-3 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>224</td>
<td>87330123</td>
<td>530009919</td>
<td>M10 DIN 125A A2</td>
<td>1,000</td>
<td>1.2100</td>
<td>12.10 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-6 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>225</td>
<td>663169</td>
<td>mouk 18777</td>
<td>2PW0625</td>
<td>800</td>
<td>1.8900</td>
<td>15.12 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-2 Stage 16 B</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 19 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


#### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>226</td>
<td>87230444</td>
<td>mouk 18424</td>
<td>M10x16 ISO 7380-1 A2</td>
<td>200</td>
<td>2.1200</td>
<td>4.24 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-1 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>227</td>
<td>87682198</td>
<td>mouk 17771</td>
<td>M10 X 25MM SQUARE HE</td>
<td>700</td>
<td>42.2400</td>
<td>295.68 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-4 Stage 16 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>228</td>
<td>039584C</td>
<td>mouk 15183</td>
<td>NUT CAPS-M8-12.80MM-</td>
<td>400</td>
<td>3.1400</td>
<td>12.56 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-3 Stage 16 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>229</td>
<td>77280413</td>
<td>mouk 18083</td>
<td>35x4.5mm Nitrile O R</td>
<td>200</td>
<td>9.6000</td>
<td>19.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-4 Stage 17</td>
<td></td>
<td></td>
</tr>
<tr>
<td>230</td>
<td>87280306</td>
<td>660001960</td>
<td>M10 DIN 982 8 Zn</td>
<td>300</td>
<td>1.8800</td>
<td>5.64 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-5 Stage 17</td>
<td></td>
<td></td>
</tr>
<tr>
<td>231</td>
<td>86230003</td>
<td>mouk 18554</td>
<td>Cabe Tie 190x3.5 PA</td>
<td>400</td>
<td>6.6800</td>
<td>26.72 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-4 Stage 17</td>
<td></td>
<td></td>
</tr>
<tr>
<td>232</td>
<td>77280413</td>
<td>mouk 18083</td>
<td>35x4.5mm Nitrile O R</td>
<td>150</td>
<td>9.6000</td>
<td>14.40 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-3 Stage 16 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>233</td>
<td>664156</td>
<td>530007465</td>
<td>M6 ISO 7093-1 A2</td>
<td>500</td>
<td>1.6900</td>
<td>8.45 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-5 Stage 16 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>234</td>
<td>87330106</td>
<td>530008368</td>
<td>M10 DIN125A 140HV Zn</td>
<td>1,160</td>
<td>1.0000</td>
<td>11.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-6 Stage 16 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>235</td>
<td>87330106</td>
<td>530008870</td>
<td>M10 DIN125A 140HV Zn</td>
<td>495</td>
<td>1.0000</td>
<td>4.95 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-6 Stage 16 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>236</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>600</td>
<td>1.2500</td>
<td>7.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-2 Stage 16 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>237</td>
<td>009514C</td>
<td>mouk 18023</td>
<td>M8 DIN 125 A PA</td>
<td>1,000</td>
<td>1.7700</td>
<td>17.70 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-6 Stage 16 A</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 20 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


#### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>238</td>
<td>87110689</td>
<td>530012875</td>
<td>M6x25 D933 A2-70</td>
<td>310</td>
<td>3.3500</td>
<td>10.39 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-4 Stage 16 D</td>
<td></td>
<td></td>
</tr>
<tr>
<td>239</td>
<td>86230609</td>
<td>mouk 16756</td>
<td>200x4.6mm 2-Piece Wi</td>
<td>100</td>
<td>13.5400</td>
<td>13.54 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-2 RF01-ELB Rack 3</td>
<td></td>
<td></td>
</tr>
<tr>
<td>240</td>
<td>86230607</td>
<td>mouk 18654</td>
<td>151-02255 paste mnt</td>
<td>100</td>
<td>26.3000</td>
<td>26.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>6-6 RF01-ELB Rack 3</td>
<td></td>
<td></td>
</tr>
<tr>
<td>241</td>
<td>021067C</td>
<td>mouk 18681</td>
<td>4.8x25 Peel Rivet</td>
<td>400</td>
<td>2.7400</td>
<td>10.96 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-6 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>242</td>
<td>404P436H61</td>
<td>660001408</td>
<td>M5x25 ISO4762 A2-70</td>
<td>500</td>
<td>3.4200</td>
<td>17.10 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-1 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>243</td>
<td>4012963</td>
<td>mouk 18725</td>
<td>714x35x3mm Neoprene</td>
<td>13</td>
<td>99.0000</td>
<td>12.87 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-2 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>244</td>
<td>4012963</td>
<td>mouk 18725</td>
<td>714x35x3mm Neoprene</td>
<td>10</td>
<td>99.0000</td>
<td>9.90 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-3 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>245</td>
<td>87682397</td>
<td>scuk2629</td>
<td>STL TORX PLUS CSK TA</td>
<td>600</td>
<td>16.2000</td>
<td>97.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-3 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>246</td>
<td>C9010002</td>
<td>mouk 17794</td>
<td>TP610 15/4-10 Duo Im</td>
<td>7</td>
<td>1,605.0000</td>
<td>112.35 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-2 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>247</td>
<td>68250026</td>
<td>shuk2345</td>
<td>JUBILEE CLIP 500-140</td>
<td>20</td>
<td>60.4100</td>
<td>12.08 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>6-6 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>248</td>
<td>87692173</td>
<td>mouk 17963</td>
<td>M6 X 50MM A2 SOCKET</td>
<td>250</td>
<td>136.4800</td>
<td>341.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-5 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>249</td>
<td>87110001</td>
<td>660001402</td>
<td>M6-1.0x20 8.8 HCS P</td>
<td>800</td>
<td>1.0000</td>
<td>8.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 5-1 Stage 2 B</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 21 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>250</td>
<td>87380316</td>
<td>mouk 17667</td>
<td>M5 DIN 7980 A1</td>
<td>1,000</td>
<td>0.3100</td>
<td>3.10 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-3 RF01-ELB</td>
<td></td>
<td></td>
</tr>
<tr>
<td>251</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>600</td>
<td>1.2500</td>
<td>7.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-5 RF01-ELB</td>
<td></td>
<td></td>
</tr>
<tr>
<td>252</td>
<td>87320009</td>
<td>mouk 11290</td>
<td>AVDEL VERSA-NUT INS</td>
<td>600</td>
<td>29.4900</td>
<td>176.94 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-2 Stage 1 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>253</td>
<td>8711005N38</td>
<td>660001402</td>
<td>M10x40 DIN933 10.9Zn</td>
<td>541</td>
<td>25.1600</td>
<td>136.12 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-4 Stage 16 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>254</td>
<td>8711005N38</td>
<td>660001402</td>
<td>M10x40 DIN933 10.9Zn</td>
<td>59</td>
<td>25.1600</td>
<td>14.84 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-3 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>255</td>
<td>8711005N38</td>
<td>660001402</td>
<td>M10x40 DIN933 10.9Zn</td>
<td>59</td>
<td>25.1600</td>
<td>14.84 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-4 Stage 16 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>256</td>
<td>87610707</td>
<td>mouk 14360</td>
<td>1/4StlLckbltPinBR/HD</td>
<td>350</td>
<td>9.6700</td>
<td>33.85 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-2 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>257</td>
<td>87330002</td>
<td>mouk 18738</td>
<td>M8 BS B Washer</td>
<td>1,000</td>
<td>0.3300</td>
<td>3.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-3 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>258</td>
<td>053184C</td>
<td>160271675</td>
<td>FEND 1/4 X 1 Z</td>
<td>1,000</td>
<td>1.7600</td>
<td>17.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-1 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>259</td>
<td>87100208</td>
<td>660001861</td>
<td>M8-1.25x30 8.8 HCS Z</td>
<td>300</td>
<td>2.3800</td>
<td>7.14 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-2 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>260</td>
<td>86230607</td>
<td>mouk 18896</td>
<td>151-02255 paste mnt</td>
<td>200</td>
<td>26.3000</td>
<td>52.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-1 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>261</td>
<td>8711005N38</td>
<td>660001402</td>
<td>M10x40 DIN933 10.9Zn</td>
<td>50</td>
<td>25.1600</td>
<td>12.58 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-3 Stage 4 B</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 22 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>262</td>
<td>8711005N38</td>
<td>660001178</td>
<td>M10x40 DIN933 10.9Zn</td>
<td>24</td>
<td>25.1600</td>
<td>6.04 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-3 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>263</td>
<td>87100208</td>
<td>660001861</td>
<td>M8-1.25x30 8.8 HCS Z</td>
<td>400</td>
<td>2.3800</td>
<td>9.52 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-4 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>264</td>
<td>87350205</td>
<td>mouk 17520</td>
<td>PENNY WASHER 8MM DIA</td>
<td>400</td>
<td>3.4900</td>
<td>13.96 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-4 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>265</td>
<td>8711002L07</td>
<td>scuk3077</td>
<td>M8-1.25 x 30 mm DIN</td>
<td>500</td>
<td>17.8300</td>
<td>89.15 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-1 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>266</td>
<td>87420515</td>
<td>moukk0001</td>
<td>ST6.3DIN7981ZnScrw</td>
<td>600</td>
<td>2.4300</td>
<td>14.58 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-1 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>267</td>
<td>87330124</td>
<td>530015803</td>
<td>M8 DIN 125A 140HV Zn</td>
<td>1,000</td>
<td>1.5300</td>
<td>15.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-6 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>268</td>
<td>8733001G26</td>
<td>mouk 18754</td>
<td>M6x20 DIN88104 St Zn</td>
<td>800</td>
<td>0.6500</td>
<td>5.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-1 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>269</td>
<td>87330106</td>
<td>530008368</td>
<td>M10 DIN125A 140HV Zn</td>
<td>500</td>
<td>1.0000</td>
<td>5.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>6-6 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>270</td>
<td>053184C</td>
<td>160271675</td>
<td>FEND 1/4 X 1 Z</td>
<td>1,000</td>
<td>1.7600</td>
<td>17.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>6-3 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>271</td>
<td>87330002</td>
<td>mouk 18738</td>
<td>M8 BS B Washer</td>
<td>300</td>
<td>0.3300</td>
<td>0.99 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-5 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>272</td>
<td>87330002</td>
<td>mouk 18901</td>
<td>M8 BS B Washer</td>
<td>200</td>
<td>0.3300</td>
<td>0.66 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-5 Stage 4 A</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 23 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>273</td>
<td>87280305</td>
<td>530013913</td>
<td>M8 DIN 982 8 Zn</td>
<td>1,012</td>
<td>0.9200</td>
<td>9.31 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-2 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>274</td>
<td>87280304</td>
<td>530011110</td>
<td>M6 DIN 982 8 Zn</td>
<td>1,000</td>
<td>0.5200</td>
<td>5.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-3 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>275</td>
<td>87420523</td>
<td>mouk 18723</td>
<td>ST4.8x25DIN7981C-ZA2</td>
<td>1,000</td>
<td>1.8600</td>
<td>18.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-2 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>276</td>
<td>86230611</td>
<td>mouk 18189</td>
<td>200x4.6mm Black T50R</td>
<td>200</td>
<td>21.6000</td>
<td>43.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-3 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>277</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>600</td>
<td>1.2500</td>
<td>7.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-6 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>278</td>
<td>86832025</td>
<td>mouk 18783</td>
<td>TE 1-968851-1</td>
<td>300</td>
<td>11.9800</td>
<td>35.94 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-5 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>279</td>
<td>87680639</td>
<td>mouk 17878</td>
<td>M6x25 DIN7500 M-Z Zn</td>
<td>750</td>
<td>2.0500</td>
<td>15.38 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-3 Stage 1</td>
<td></td>
<td></td>
</tr>
<tr>
<td>280</td>
<td>86230607</td>
<td>mouk 18896</td>
<td>151-02255 paste mnt</td>
<td>300</td>
<td>26.3000</td>
<td>78.90 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-3 Stage 1</td>
<td></td>
<td></td>
</tr>
<tr>
<td>281</td>
<td>037077C</td>
<td>mouk 18128</td>
<td>M6-1.0 x 20 mm ISO 7</td>
<td>500</td>
<td>26.7400</td>
<td>133.70 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-5 Stage 1</td>
<td></td>
<td></td>
</tr>
<tr>
<td>282</td>
<td>87370110</td>
<td>530010947</td>
<td>M6 DIN 125A A2</td>
<td>600</td>
<td>0.8500</td>
<td>5.10 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-4 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>283</td>
<td>WMA-12SP</td>
<td>530011202</td>
<td>M12 ISO7089 200HV Zn</td>
<td>600</td>
<td>0.8200</td>
<td>4.92 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-1 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>284</td>
<td>8741002C55</td>
<td>mouk 18237</td>
<td>SSTTMWZCSK60040A2</td>
<td>357</td>
<td>13.8500</td>
<td>49.44 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-4 Stage 2</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 24 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>285</td>
<td>87692173</td>
<td>mouk 17963</td>
<td>M6 X 50MM A2 SOCKET</td>
<td>100</td>
<td>136.4800</td>
<td>136.48 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-5 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>286</td>
<td>87682397</td>
<td>scuk2629</td>
<td>STL TORX PLUS CSK TA</td>
<td>633</td>
<td>16.2000</td>
<td>102.55 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-3 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>287</td>
<td>87640102</td>
<td>mouk 18153</td>
<td>MONOBOLT 4.80 X 26.3</td>
<td>600</td>
<td>6.9800</td>
<td>41.88 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-3 Stage 8 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>288</td>
<td>68250101</td>
<td>mouk 14074</td>
<td>JUBILEE CLIP - 140-1</td>
<td>14</td>
<td>72.0100</td>
<td>10.08 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-6 Stage 1 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>289</td>
<td>754240</td>
<td>mouk 16274</td>
<td>Black Butyl Tape 3m</td>
<td>2</td>
<td>936.7900</td>
<td>18.74 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-3 Stage 1 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>290</td>
<td>87682231</td>
<td>mouk 15040</td>
<td>Spring Clip S3</td>
<td>200</td>
<td>36.5300</td>
<td>73.06 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-6 Stage 1 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>291</td>
<td>87290001</td>
<td>530008965</td>
<td>M10 D934 Class 8 Zn</td>
<td>400</td>
<td>1.5300</td>
<td>6.12 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-1 RF01-ELB Rack 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>292</td>
<td>665161</td>
<td>mouk 18896</td>
<td>151-02255 paste mnt</td>
<td>400</td>
<td>26.3000</td>
<td>105.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-2 RF01-ELB</td>
<td></td>
<td></td>
</tr>
<tr>
<td>293</td>
<td>8768021N01</td>
<td>mouk 18624</td>
<td>M4x12 ISO7380-1 10.9</td>
<td>1,000</td>
<td>4.1200</td>
<td>41.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-3 RF01-ELB</td>
<td></td>
<td></td>
</tr>
<tr>
<td>294</td>
<td>WMC-5SP</td>
<td>530013809</td>
<td>M5 DIN127B HRc50 Zn</td>
<td>4,000</td>
<td>0.2100</td>
<td>8.40 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-6 RF01-ELB</td>
<td></td>
<td></td>
</tr>
<tr>
<td>295</td>
<td>754240</td>
<td>mouk 16274</td>
<td>Black Butyl Tape 3m</td>
<td>2</td>
<td>936.7900</td>
<td>18.74 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-4 Stage 2 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>296</td>
<td>87692126</td>
<td>mouk 18441</td>
<td>M6x25 ISO 7380-1 A2</td>
<td>200</td>
<td>3.8100</td>
<td>7.62 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-4 Stage 2 B</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 25 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>297</td>
<td>87322147</td>
<td>mouk 15357</td>
<td>M6 Steel Quad Nut</td>
<td>400</td>
<td>107.3500</td>
<td>429.40 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-1 Stage 2 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>298</td>
<td>87320008</td>
<td>mouk 18838</td>
<td>TAPPEX GEAR INSET SE</td>
<td>1,000</td>
<td>18.3000</td>
<td>183.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-4 RF01-ELB Rack 4</td>
<td></td>
<td></td>
</tr>
<tr>
<td>299</td>
<td>87640203</td>
<td>mouk 18137</td>
<td>1/4CSStZnBlindRivet</td>
<td>400</td>
<td>8.1700</td>
<td>32.68 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-6 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>300</td>
<td>87610707</td>
<td>mouk 14360</td>
<td>1/4StlLckbltPinBR/HD</td>
<td>350</td>
<td>9.6700</td>
<td>33.85 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-1 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>301</td>
<td>87660504</td>
<td>mouk 14360</td>
<td>1/4 Steel Collar</td>
<td>1,500</td>
<td>3.7300</td>
<td>55.95 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-2 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>302</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>600</td>
<td>1.2500</td>
<td>7.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-4 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>303</td>
<td>76502233</td>
<td>mouk 18404</td>
<td>RCP 3 POS 5.5mm Crim</td>
<td>108</td>
<td>60.8800</td>
<td>65.75 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-3 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>304</td>
<td>87100686</td>
<td>660000990</td>
<td>M10X35DN933 HCS 8.8Z</td>
<td>200</td>
<td>4.0800</td>
<td>8.16 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-4 Stage 5 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>305</td>
<td>WMA-10SP</td>
<td>530014902</td>
<td>M10 ISO7089 200HV Zn</td>
<td>1,000</td>
<td>29.0100</td>
<td>290.10 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-3 Stage 5 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>306</td>
<td>87682161</td>
<td>mouk 16811</td>
<td>M6x30 DIN7500 M-Z Zn</td>
<td>350</td>
<td>2.0800</td>
<td>7.28 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-2 Stage 16 D</td>
<td></td>
<td></td>
</tr>
<tr>
<td>307</td>
<td>661990-7</td>
<td>shuk9802</td>
<td>1376708032</td>
<td>20</td>
<td>125.3800</td>
<td>25.08 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-1 Stage 15 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>308</td>
<td>87430511</td>
<td>mouk 12521</td>
<td>3.5mm x 19mm DIN 798</td>
<td>2,000</td>
<td>0.3400</td>
<td>6.80 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-1 Stage 16 A</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 26 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>309</td>
<td>MCS-3606-35P</td>
<td>530013033</td>
<td>M6x35 ISO4762 8.8 Zn</td>
<td>200</td>
<td>3.1200</td>
<td>6.24 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-6 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>310</td>
<td>87100669</td>
<td>530000798</td>
<td>M8x16 D933 A2-70</td>
<td>314</td>
<td>5.2900</td>
<td>16.61 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-5 Stage 12</td>
<td></td>
<td></td>
</tr>
<tr>
<td>311</td>
<td>86230607</td>
<td>mouk 18896</td>
<td>151-02255 paste mnt</td>
<td>100</td>
<td>26.3000</td>
<td>26.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-5 Stage 16 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>312</td>
<td>674029</td>
<td>mouk 17786</td>
<td>M30 DIN Washer</td>
<td>200</td>
<td>18.6700</td>
<td>37.34 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-2 Stage 6</td>
<td></td>
<td></td>
</tr>
<tr>
<td>313</td>
<td>87430513</td>
<td>shuk2192</td>
<td>4.2mm x 19mm DIN 798</td>
<td>1,443</td>
<td>0.8600</td>
<td>12.41 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-4 Stage 14 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>314</td>
<td>009514C</td>
<td>mouk 18023</td>
<td>M8 DIN 125 A PA</td>
<td>2,000</td>
<td>1.7700</td>
<td>35.40 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-2 Stage 15</td>
<td></td>
<td></td>
</tr>
<tr>
<td>315</td>
<td>87330106</td>
<td>530014092</td>
<td>M10 DIN125A 140HV Zn</td>
<td>40</td>
<td>1.0000</td>
<td>0.40 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-6 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>316</td>
<td>4012963</td>
<td>mouk 18725</td>
<td>714x35x3mm Neoprene</td>
<td>10</td>
<td>99.0000</td>
<td>9.90 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-3 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>317</td>
<td>754240</td>
<td>mouk 16274</td>
<td>Black Butyl Tape 3m</td>
<td>2</td>
<td>936.7900</td>
<td>18.74 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-4 Stage 2 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>318</td>
<td>86230607</td>
<td>mouk 18896</td>
<td>151-02255 paste mnt</td>
<td>100</td>
<td>26.3000</td>
<td>26.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-3 Stage 1</td>
<td></td>
<td></td>
</tr>
<tr>
<td>319</td>
<td>MCS-2904-12P</td>
<td>mouk 18410</td>
<td>4x12 D7985Z 4.8Zn</td>
<td>2,000</td>
<td>0.7100</td>
<td>14.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-2 Stage 4 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>320</td>
<td>8732001L05</td>
<td>mouk 17882</td>
<td>M8 X 19 S/S Nutsert</td>
<td>400</td>
<td>20.7600</td>
<td>83.04 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-1 Stage 16 E</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 27 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>321</td>
<td>8711001C55</td>
<td>mouk 17803</td>
<td>M10x50 D933 A2-70</td>
<td>100</td>
<td>68.8600</td>
<td>68.86 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-5 Stage 16 E</td>
<td></td>
<td></td>
</tr>
<tr>
<td>322</td>
<td>87292119</td>
<td>mouk 17263</td>
<td>M10 Clamp Nut</td>
<td>400</td>
<td>49.8500</td>
<td>199.40 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-4 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>323</td>
<td>87420523</td>
<td>mouk 18723</td>
<td>ST4.8x25DIN7981C-ZA2</td>
<td>1,000</td>
<td>1.8600</td>
<td>18.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-6 Stage 7 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>324</td>
<td>86510718</td>
<td>mouk 18791</td>
<td>2 x 32/0.20mm Flat T</td>
<td>1</td>
<td>4,138.9000</td>
<td>41.39 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-1 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>325</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>1,000</td>
<td>1.2500</td>
<td>12.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-4 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>326</td>
<td>87630207</td>
<td>mouk 18213</td>
<td>1/4PTStZnBlindRivet</td>
<td>400</td>
<td>6.8000</td>
<td>27.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-5 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>327</td>
<td>62-5142-000</td>
<td>mouk 18316</td>
<td>CHANNEL NUT SHORT SP</td>
<td>100</td>
<td>18.6400</td>
<td>18.64 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-3 Stage 17 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>328</td>
<td>87110105</td>
<td>660001454</td>
<td>M6-1.0x16 8.8 HCS Z</td>
<td>200</td>
<td>4.6500</td>
<td>9.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-4 Stage 17 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>329</td>
<td>AA-01177</td>
<td>mouk 18966</td>
<td>type-fp24-glazing-pa</td>
<td>50</td>
<td>2.2300</td>
<td>1.12 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-5 Stage 8 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>330</td>
<td>660217-11</td>
<td>shuk 10269</td>
<td>39.3x12mm Hose Clip</td>
<td>10</td>
<td>299.9000</td>
<td>29.99 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-1 Stage 8 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>331</td>
<td>661990-5</td>
<td>mouk 10330</td>
<td>CONSTANT TORQUE HOSE</td>
<td>50</td>
<td>136.4500</td>
<td>68.23 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-1 Stage 15</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 28 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>332</td>
<td>177773C</td>
<td>mouk 18559</td>
<td>Green Connector Acce</td>
<td>500</td>
<td>3.7900</td>
<td>18.95 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-5 Stage 8 D</td>
<td></td>
<td></td>
</tr>
<tr>
<td>333</td>
<td>87320210</td>
<td>mouk 11234</td>
<td>M5 X 13.0 Flange</td>
<td>1,000</td>
<td>3.7500</td>
<td>37.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-6 Stage 8 D</td>
<td></td>
<td></td>
</tr>
<tr>
<td>334</td>
<td>87110205</td>
<td>660001494</td>
<td>M8-1.25x20 8.8 HCS Z</td>
<td>200</td>
<td>2.1100</td>
<td>4.22 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-6 Stage 8 D</td>
<td></td>
<td></td>
</tr>
<tr>
<td>335</td>
<td>8769001L05</td>
<td>530012874</td>
<td>M8x20 ISO 7380-2 A2</td>
<td>350</td>
<td>4.4100</td>
<td>15.44 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-4 Stage 17</td>
<td></td>
<td></td>
</tr>
<tr>
<td>336</td>
<td>68250273</td>
<td>mouk 10262</td>
<td>PIPE CLIP - 50 - 70</td>
<td>5</td>
<td>42.8400</td>
<td>2.14 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-2 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>337</td>
<td>87196588</td>
<td>mouk 18441</td>
<td>M10-1.5 Collar</td>
<td>100</td>
<td>15.7400</td>
<td>15.74 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-5 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>338</td>
<td>86230003</td>
<td>mouk 18554</td>
<td>Cabe Tie 190x3.5 PA</td>
<td>500</td>
<td>6.6800</td>
<td>33.40 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-5 Stage 6</td>
<td></td>
<td></td>
</tr>
<tr>
<td>339</td>
<td>069955C</td>
<td>mouk 18791</td>
<td>2 x 32/0.20mm Flat T</td>
<td>1</td>
<td>4,138.9000</td>
<td>41.39 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-2 Stage 1</td>
<td></td>
<td></td>
</tr>
<tr>
<td>340</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>1,000</td>
<td>1.2500</td>
<td>12.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-6 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>341</td>
<td>652577</td>
<td>mouk 17801</td>
<td>Screw Fixing Mounts</td>
<td>100</td>
<td>16.6000</td>
<td>16.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-5 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>342</td>
<td>86230003</td>
<td>mouk 18554</td>
<td>Cabe Tie 190x3.5 PA</td>
<td>500</td>
<td>6.6800</td>
<td>33.40 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-5 Stage 8 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>343</td>
<td>660217-11</td>
<td>shuk 10269</td>
<td>39.3x12mm Hose Clip</td>
<td>30</td>
<td>299.9000</td>
<td>89.97 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-1 Stage 8 C</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 29 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>344</td>
<td>86230611</td>
<td>mouk 18189</td>
<td>200x4.6mm Black T50R</td>
<td>150</td>
<td>21.6000</td>
<td>32.40 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-5 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>345</td>
<td>86510718</td>
<td>mouk 18791</td>
<td>2 x 32/0.20mm Flat T</td>
<td>1</td>
<td>4,138.9000</td>
<td>41.39 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-1 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>346</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>1,200</td>
<td>1.2500</td>
<td>15.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-6 Stage 13 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>347</td>
<td>86510718</td>
<td>mouk 18791</td>
<td>2 x 32/0.20mm Flat T</td>
<td>2</td>
<td>4,138.9000</td>
<td>82.78 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-5 Stage 8 D</td>
<td></td>
<td></td>
</tr>
<tr>
<td>348</td>
<td>87682198</td>
<td>mouk 17771</td>
<td>M10 X 25MM SQUARE HE</td>
<td>350</td>
<td>42.2400</td>
<td>147.84 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-4 Stage 16 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>349</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>600</td>
<td>1.2500</td>
<td>7.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-2 Stage 16 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>350</td>
<td>87430313</td>
<td>mouk 18488</td>
<td>4.2mm x 13mm DIN 968</td>
<td>1,500</td>
<td>1.3300</td>
<td>19.95 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-1 Stage 13 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>351</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>700</td>
<td>1.2500</td>
<td>8.75 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-3 Stage 18</td>
<td></td>
<td></td>
</tr>
<tr>
<td>352</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>600</td>
<td>1.2500</td>
<td>7.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-3 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>353</td>
<td>4012963</td>
<td>mouk 18725</td>
<td>714x35x3mm Neoprene</td>
<td>10</td>
<td>99.0000</td>
<td>9.90 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-2 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>354</td>
<td>8711006N38</td>
<td>mouk 18901</td>
<td>10x30 DIN933 10.9 Zn</td>
<td>200</td>
<td>7.3200</td>
<td>14.64 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-1 Stage 4 D</td>
<td></td>
<td></td>
</tr>
<tr>
<td>355</td>
<td>8711002L07</td>
<td>scuk3077</td>
<td>M8-1.25 x 30 mm DIN</td>
<td>250</td>
<td>17.8300</td>
<td>44.58 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-4 Stage 5</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 30 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>356</td>
<td>87100208</td>
<td>660001861</td>
<td>M8-1.25x30 8.8 HCS Z</td>
<td>250</td>
<td>2.3800</td>
<td>5.95 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-4 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>357</td>
<td>8711005N38</td>
<td>660001402</td>
<td>M10x40 DIN933 10.9Zn</td>
<td>100</td>
<td>25.1600</td>
<td>25.16 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-3 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>358</td>
<td>87692113</td>
<td>mouk 18282</td>
<td>M8x35 ISO 7380-1 A2</td>
<td>300</td>
<td>9.2800</td>
<td>27.84 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-5 Stage 13 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>359</td>
<td>87692113</td>
<td>mouk 18325</td>
<td>M8x35 ISO 7380-1 A2</td>
<td>100</td>
<td>9.2800</td>
<td>9.28 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-5 Stage 13 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>360</td>
<td>87692113</td>
<td>mouk 18282</td>
<td>M8x35 ISO 7380-1 A2</td>
<td>200</td>
<td>9.2800</td>
<td>18.56 N</td>
</tr>
<tr>
<td>Location:</td>
<td>LST12</td>
<td></td>
<td>Sub Location:</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>361</td>
<td>AA-01177</td>
<td>mouk 18966</td>
<td>type-fp24-glazing-pa</td>
<td>100</td>
<td>2.2300</td>
<td>2.23 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-5 Stage 8 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>362</td>
<td>AA-01176</td>
<td>mouk 17891</td>
<td>type-fp20-glazing-pa</td>
<td>100</td>
<td>1.5200</td>
<td>1.52 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-6 Stage 8 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>363</td>
<td>660217-6</td>
<td>mouk 18541</td>
<td>HIGH TEMP LINED HOSE</td>
<td>30</td>
<td>154.4300</td>
<td>46.33 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-2 Stage 8 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>364</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>1,400</td>
<td>1.2500</td>
<td>17.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-4 Stage 14 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>365</td>
<td>87110685</td>
<td>660001621</td>
<td>M10-1.5x25 8.8 HCS Z</td>
<td>50</td>
<td>4.0200</td>
<td>2.01 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-6 Stage 15</td>
<td></td>
<td></td>
</tr>
<tr>
<td>366</td>
<td>660217-11</td>
<td>shuk10269</td>
<td>39.3x12mm Hose Clip</td>
<td>15</td>
<td>299.9000</td>
<td>44.99 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-3 Stage 13 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>367</td>
<td>87682279</td>
<td>mouk 18712</td>
<td>M6-1.0 x 30 mm DIN 7</td>
<td>200</td>
<td>2.3500</td>
<td>4.70 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-5 Stage 13 B</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 31 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th colspan="2">Description Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>368</td>
<td>8711006N38</td>
<td>mouk 18901</td>
<td colspan="2">10x30 DIN933 10.9 Zn 200</td>
<td>7.3200</td>
<td>14.64 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-5 Stage 16 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>369</td>
<td>661990-7</td>
<td>shuk9802</td>
<td>1376708032</td>
<td>30</td>
<td>125.3800</td>
<td>37.61 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-1 Stage 15 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>370</td>
<td>87280306</td>
<td>660001960</td>
<td colspan="2">M10 DIN 982 8 Zn 600</td>
<td>1.8800</td>
<td>11.28 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-3 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>371</td>
<td>87682397</td>
<td>scuk2629</td>
<td colspan="2">STL TORX PLUS CSK TA 250</td>
<td>16.2000</td>
<td>40.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-4 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>372</td>
<td>62-5142-000</td>
<td>mouk 18316</td>
<td colspan="2">CHANNEL NUT SHORT SP 200</td>
<td>18.6400</td>
<td>37.28 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-2 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>373</td>
<td>87630301</td>
<td>mouk 18234</td>
<td colspan="2">02221-00815StrcRivet 300</td>
<td>11.3900</td>
<td>34.17 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-1 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>374</td>
<td>013926C</td>
<td>mouk 18824</td>
<td>10MM NUT CAP</td>
<td>500</td>
<td>4.6300</td>
<td>23.15 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-1 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>375</td>
<td>87682238</td>
<td>mouk 17361</td>
<td colspan="2">M6x25 DIN7500C-TX Zn 58</td>
<td>3.5800</td>
<td>2.08 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-3 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>376</td>
<td>87682238</td>
<td>mouk 18963</td>
<td>M6x25 DIN7500C-TX Zn</td>
<td>342</td>
<td>3.5800</td>
<td>12.24 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-3 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>377</td>
<td>4012963</td>
<td>mouk 18725</td>
<td colspan="2">714x35x3mm Neoprene 14</td>
<td>99.0000</td>
<td>13.86 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-2 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>378</td>
<td>87682397</td>
<td>scuk2629</td>
<td colspan="2">STL TORX PLUS CSK TA 400</td>
<td>16.2000</td>
<td>64.80 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 5-3 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>379</td>
<td>86230607</td>
<td>mouk 18896</td>
<td colspan="2">151-02255 paste mnt 100</td>
<td>26.3000</td>
<td>26.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-3 Stage 1</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 32 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>380</td>
<td>MCB-112-40P</td>
<td>660001621</td>
<td>M12x40 DIN 931 8.8Zn</td>
<td>75</td>
<td>12.0000</td>
<td>9.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-4 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>381</td>
<td>87280305</td>
<td>530013913</td>
<td>M8 DIN 982 8 Zn</td>
<td>400</td>
<td>0.9200</td>
<td>3.68 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-2 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>382</td>
<td>68250101</td>
<td>mouk 14074</td>
<td>JUBILEE CLIP - 140-1</td>
<td>12</td>
<td>72.0100</td>
<td>8.64 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-6 Stage 1 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>383</td>
<td>754240</td>
<td>mouk 16274</td>
<td>Black Butyl Tape 3m</td>
<td>3</td>
<td>936.7900</td>
<td>28.10 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-3 Stage 1 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>384</td>
<td>87100208</td>
<td>660001861</td>
<td>M8-1.25x30 8.8 HCS Z</td>
<td>600</td>
<td>2.3800</td>
<td>14.28 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-4 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>385</td>
<td>87350205</td>
<td>mouk 17520</td>
<td>PENNY WASHER 8MM DIA</td>
<td>250</td>
<td>3.4900</td>
<td>8.73 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-4 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>386</td>
<td>87110836</td>
<td>moukk0006</td>
<td>M10-1.5 x 25mm DIN 9</td>
<td>300</td>
<td>25.5400</td>
<td>76.62 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-2 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>387</td>
<td>87292119</td>
<td>mouk 17263</td>
<td>M10 Clamp Nut</td>
<td>200</td>
<td>49.8500</td>
<td>99.70 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-4 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>388</td>
<td>660217-11</td>
<td>shuk10269</td>
<td>39.3x12mm Hose Clip</td>
<td>20</td>
<td>299.9000</td>
<td>59.98 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-2 Stage 11</td>
<td></td>
<td></td>
</tr>
<tr>
<td>389</td>
<td>751610</td>
<td>mouk 18480</td>
<td>TOFFEE TAPE - 12 X 1</td>
<td>4</td>
<td>723.0900</td>
<td>28.92 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-4 Stage 11</td>
<td></td>
<td></td>
</tr>
<tr>
<td>390</td>
<td>87100208</td>
<td>660001861</td>
<td>M8-1.25x30 8.8 HCS Z</td>
<td>300</td>
<td>2.3800</td>
<td>7.14 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-2 Stage 5</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 33 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


##### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>391</td>
<td>87350205</td>
<td>mouk 17520</td>
<td>PENNY WASHER 8MM DIA</td>
<td>200</td>
<td>3.4900</td>
<td>6.98 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-6 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>392</td>
<td>87630207</td>
<td>mouk 17566</td>
<td>1/4PTStZnBlindRivet</td>
<td>167</td>
<td>6.8000</td>
<td>11.36 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-4 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>393</td>
<td>87610707</td>
<td>mouk 14360</td>
<td>1/4StlLckbltPinBR/HD</td>
<td>153</td>
<td>9.6700</td>
<td>14.80 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-2 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>394</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>600</td>
<td>1.2500</td>
<td>7.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-4 Stage 5 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>395</td>
<td>87100686</td>
<td>660000990</td>
<td>M10X35DN933 HCS 8.8Z</td>
<td>100</td>
<td>4.0800</td>
<td>4.08 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-4 Stage 5 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>396</td>
<td>86230610</td>
<td>mouk 17510</td>
<td>2-Piece Fixing Tie f</td>
<td>50</td>
<td>26.3500</td>
<td>13.18 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-5 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>397</td>
<td>86230611</td>
<td>mouk 18189</td>
<td>200x4.6mm Black T50R</td>
<td>350</td>
<td>21.6000</td>
<td>75.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-3 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>398</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>400</td>
<td>1.2500</td>
<td>5.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-6 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>399</td>
<td>86230607</td>
<td>mouk 18896</td>
<td>151-02255 paste mnt</td>
<td>100</td>
<td>26.3000</td>
<td>26.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-4 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>400</td>
<td>652577</td>
<td>mouk 17801</td>
<td>Screw Fixing Mounts</td>
<td>50</td>
<td>16.6000</td>
<td>8.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-5 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>401</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>400</td>
<td>1.2500</td>
<td>5.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-2 Stage 6</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 34 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>402</td>
<td>87640203</td>
<td>mouk 18137</td>
<td>1/4CSStZnBlindRivet</td>
<td>200</td>
<td>8.1700</td>
<td>16.34 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-6 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>403</td>
<td>87630207</td>
<td>mouk 17566</td>
<td>1/4PTStZnBlindRivet</td>
<td>400</td>
<td>6.8000</td>
<td>27.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-5 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>404</td>
<td>87610711</td>
<td>mouk 18832</td>
<td>1/4StlLckbltPinBR/HD</td>
<td>250</td>
<td>9.5500</td>
<td>23.88 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-3 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>405</td>
<td>86230611</td>
<td>mouk 18189</td>
<td>200x4.6mm Black T50R</td>
<td>400</td>
<td>21.6000</td>
<td>86.40 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-5 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>406</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>600</td>
<td>1.2500</td>
<td>7.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-4 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>407</td>
<td>86510718</td>
<td>mouk 18791</td>
<td>2 x 32/0.20mm Flat T</td>
<td>2</td>
<td>4,138.9000</td>
<td>82.78 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-1 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>408</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>400</td>
<td>1.2500</td>
<td>5.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-4 RF01-ELB Rack 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>409</td>
<td>87630201</td>
<td>mouk 18137</td>
<td>MonoRivet6.4x23.7</td>
<td>200</td>
<td>7.1300</td>
<td>14.26 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-2 RF01-ELB</td>
<td></td>
<td></td>
</tr>
<tr>
<td>410</td>
<td>MCN-503P</td>
<td>mouk 18430</td>
<td>STL HEX AEROTIGHT NU</td>
<td>1,000</td>
<td>24.6000</td>
<td>246.00 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-6 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>411</td>
<td>4012963</td>
<td>mouk 18725</td>
<td>714x35x3mm Neoprene</td>
<td>10</td>
<td>99.0000</td>
<td>9.90 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-2 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>412</td>
<td>4012963</td>
<td>mouk 18725</td>
<td>714x35x3mm Neoprene</td>
<td>14</td>
<td>99.0000</td>
<td>13.86 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-3 Stage 2</td>
<td></td>
<td></td>
</tr>
<tr>
<td>413</td>
<td>68250101</td>
<td>mouk 14074</td>
<td>JUBILEE CLIP - 140-1</td>
<td>10</td>
<td>72.0100</td>
<td>7.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-6 Stage 1 B</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 35 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>414</td>
<td>754240</td>
<td>mouk 16274</td>
<td>Black Butyl Tape 3m</td>
<td>2</td>
<td>936.7900</td>
<td>18.74 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-3 Stage 1 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>415</td>
<td>87350205</td>
<td>mouk 17520</td>
<td>PENNY WASHER 8MM DIA</td>
<td>450</td>
<td>3.4900</td>
<td>15.71 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-4 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>416</td>
<td>87100208</td>
<td>660001861</td>
<td>M8-1.25x30 8.8 HCS Z</td>
<td>1,000</td>
<td>2.3800</td>
<td>23.80 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-4 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>417</td>
<td>87610707</td>
<td>mouk 14360</td>
<td>1/4StlLckbltPinBR/HD</td>
<td>400</td>
<td>9.6700</td>
<td>38.68 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-2 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>418</td>
<td>87210831</td>
<td>mouk 18460</td>
<td>6x25 D7985Z A2</td>
<td>400</td>
<td>5.0400</td>
<td>20.16 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-1 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>419</td>
<td>86230607</td>
<td>mouk 18896</td>
<td>151-02255 paste mnt</td>
<td>100</td>
<td>26.3000</td>
<td>26.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-1 Stage 4 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>420</td>
<td>87630207</td>
<td>mouk 18714</td>
<td>1/4PTStZnBlindRivet</td>
<td>300</td>
<td>6.8000</td>
<td>20.40 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>5-3 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>421</td>
<td>652577</td>
<td>mouk 17801</td>
<td>Screw Fixing Mounts</td>
<td>100</td>
<td>16.6000</td>
<td>16.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-5 Stage 8 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>422</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>600</td>
<td>1.2500</td>
<td>7.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-2 Stage 6</td>
<td></td>
<td></td>
</tr>
<tr>
<td>423</td>
<td>87100208</td>
<td>660001494</td>
<td>M8-1.25x30 8.8 HCS Z</td>
<td>498</td>
<td>2.3800</td>
<td>11.85 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-2 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>424</td>
<td>87350205</td>
<td>mouk 17520</td>
<td>PENNY WASHER 8MM DIA</td>
<td>450</td>
<td>3.4900</td>
<td>15.71 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-6 Stage 5</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 36 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>425</td>
<td>87610707</td>
<td>mouk 14360</td>
<td>1/4StlLckbltPinBR/HD</td>
<td>300</td>
<td>9.6700</td>
<td>29.01 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-2 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>426</td>
<td>87630201</td>
<td>mouk 18137</td>
<td>MonoRivet6.4x23.7</td>
<td>350</td>
<td>7.1300</td>
<td>24.96 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-3 Stage 5</td>
<td></td>
<td></td>
</tr>
<tr>
<td>427</td>
<td>8711006N38</td>
<td>mouk 18901</td>
<td>10x30 DIN933 10.9 Zn</td>
<td>200</td>
<td>7.3200</td>
<td>14.64 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 5-5 Stage 5 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>428</td>
<td>86510718</td>
<td>mouk 18791</td>
<td>2 x 32/0.20mm Flat T</td>
<td>1</td>
<td>4,138.9000</td>
<td>41.39 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-1 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>429</td>
<td>87630207</td>
<td>mouk 18714</td>
<td>1/4PTStZnBlindRivet</td>
<td>400</td>
<td>6.8000</td>
<td>27.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-5 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>430</td>
<td>86230607</td>
<td>mouk 18896</td>
<td>151-02255 paste mnt</td>
<td>200</td>
<td>26.3000</td>
<td>52.60 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-2 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>431</td>
<td>76502233</td>
<td>mouk 18762</td>
<td>RCP 3 POS 5.5mm Crim</td>
<td>100</td>
<td>60.8800</td>
<td>60.88 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 4-3 Stage 7</td>
<td></td>
<td></td>
</tr>
<tr>
<td>432</td>
<td>86230002</td>
<td>mouk 18638</td>
<td>300mm x 4.8mm Standa</td>
<td>1,000</td>
<td>1.2500</td>
<td>12.50 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-4 Stage 14 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>433</td>
<td>87110685</td>
<td>660001621</td>
<td>M10-1.5x25 8.8 HCS Z</td>
<td>220</td>
<td>4.0200</td>
<td>8.84 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-6 Stage 15</td>
<td></td>
<td></td>
</tr>
<tr>
<td>434</td>
<td>660217-11</td>
<td>shuk10269</td>
<td>39.3x12mm Hose Clip</td>
<td>20</td>
<td>299.9000</td>
<td>59.98 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-3 Stage 13 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>435</td>
<td>AA-01177</td>
<td>mouk 18966</td>
<td>type-fp24-glazing-pa</td>
<td>60</td>
<td>2.2300</td>
<td>1.34 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 1-5 Stage 8 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>436</td>
<td>AA-01175</td>
<td>mouk 17384</td>
<td>type-fp24-glazing-pa</td>
<td>100</td>
<td>1.2500</td>
<td>1.25 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-1 Stage 8 C</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 37 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>437</td>
<td>177797C</td>
<td>mouk 10423</td>
<td>RCP 2 POS 6mm Crimp</td>
<td>100</td>
<td>46.5900</td>
<td>46.59 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-4 Stage 8 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>438</td>
<td>87350205</td>
<td>mouk 17520</td>
<td>PENNY WASHER 8MM DIA</td>
<td>300</td>
<td>3.4900</td>
<td>10.47 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-3 Stage 16 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>439</td>
<td>87682238</td>
<td>mouk 18963</td>
<td>M6x25 DIN7500C-TX Zn</td>
<td>500</td>
<td>3.5800</td>
<td>17.90 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 3-3 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>440</td>
<td>013926C</td>
<td>mouk 18824</td>
<td>10MM NUT CAP</td>
<td>250</td>
<td>4.6300</td>
<td>11.58 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-1 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>441</td>
<td>87196588</td>
<td>mouk 18441</td>
<td>M10-1.5 Collar</td>
<td>200</td>
<td>15.7400</td>
<td>31.48 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>6-5 Stage 16 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>442</td>
<td>87280305</td>
<td>530013913</td>
<td>M8 DIN 982 8 Zn</td>
<td>600</td>
<td>0.9200</td>
<td>5.52 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-2 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>443</td>
<td>87330124</td>
<td>530015803</td>
<td>M8 DIN 125A 140HV Zn</td>
<td>1,000</td>
<td>1.5300</td>
<td>15.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-6 Stage 4 A</td>
<td></td>
<td></td>
</tr>
<tr>
<td>444</td>
<td>86230607</td>
<td>mouk 18896</td>
<td>151-02255 paste mnt</td>
<td>100</td>
<td>26.3000</td>
<td>26.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 6-6 RF01-ELB Rack 3</td>
<td></td>
<td></td>
</tr>
<tr>
<td>445</td>
<td>86230611</td>
<td>mouk 18189</td>
<td>200x4.6mm Black T50R</td>
<td>150</td>
<td>21.6000</td>
<td>32.40 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td colspan="2">Sub Location: 2-4 RF01-ELB</td>
<td></td>
<td></td>
</tr>
<tr>
<td>446</td>
<td>86230607</td>
<td>mouk 18896</td>
<td>151-02255 paste mnt</td>
<td>100</td>
<td>26.3000</td>
<td>26.30 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-3 Stage 1</td>
<td></td>
<td></td>
</tr>
<tr>
<td>447</td>
<td>021067C</td>
<td>mouk 18681</td>
<td>4.8x25 Peel Rivet</td>
<td>200</td>
<td>2.7400</td>
<td>5.48 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>2-6 Stage 1</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 38 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


#### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td>448</td>
<td>754240</td>
<td>mouk 16274</td>
<td>Black Butyl Tape 3m</td>
<td>2</td>
<td>936.7900</td>
<td>18.74 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>3-4 Stage 2 B</td>
<td></td>
<td></td>
</tr>
<tr>
<td>449</td>
<td>87410512</td>
<td>mouk 18661</td>
<td>3.5x25 DIN7982CZ Zn</td>
<td>2,000</td>
<td>0.3900</td>
<td>7.80 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-6 Stage 15 C</td>
<td></td>
<td></td>
</tr>
<tr>
<td>450</td>
<td>87210838</td>
<td>mouk 18025</td>
<td>6x16 D7985Z A2</td>
<td>1,000</td>
<td>15.3100</td>
<td>153.10 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>4-2 Stage 16 E</td>
<td></td>
<td></td>
</tr>
<tr>
<td>451</td>
<td>87430304</td>
<td>mouk 18821</td>
<td>4.2x19 DIN7983CZ A2</td>
<td>1,000</td>
<td>2.1200</td>
<td>21.20 N</td>
</tr>
<tr>
<td>Location:</td>
<td>Larbert Main Building</td>
<td></td>
<td>Sub Location:</td>
<td>1-1 Stage 15 C</td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page 39 of 40" -->
<!-- PageBreak -->


<figure>

FASTENAL®
®
Fastenal Europe Ltd.

</figure>


#### Invoice


<table>
<tr>
<td>Customer #:</td>
<td>UKMOT0197</td>
<td>Reference #:</td>
<td>UKMOT16468</td>
</tr>
<tr>
<td>Cust P.O .:</td>
<td>222720</td>
<td>Date of Issue: (DD/MM/YYYY)</td>
<td>30/06/2025</td>
</tr>
<tr>
<td>Job #:</td>
<td>Larbert OEM June 25</td>
<td>Final Due Date: (DD/MM/YYYY)</td>
<td>NET90 25/09/2025</td>
</tr>
</table>


Sold To:

Alexander Dennis Ltd Larbert

PO Box 401

Finance Shared Services Centre

Cameron House, Priorswood Place

SKELMERSDALE, WN8 9QB GBR

Ship To:

Alexander Dennis Ltd Larbert

9 Central Blvr

Larbert

LARBERT, FK5 4RU GBR

ATTN: Alexander Dennis Ltd Larbert

The store serving you is:

Fastenal Europe Ltd.

Units B - C Glasgow Trade Park

Springhill Parkway

GLASGOW, G69 6GE GBR

Email: UKMOT@stores.fastenal.com

This Order and Document are subject to the "Terms of Purchase" posted on www.fastenal.com.


<table>
<tr>
<th>Line #</th>
<th>Part #</th>
<th>Control #</th>
<th>Description</th>
<th>Quantity Shipped</th>
<th>Price / Hundred</th>
<th>Extended Price</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


Received By:
Comments:
Contact: Alexander Dennis Ltd Larbert


<table>
<tr>
<td>Subtotal:</td>
<td>16,000.23</td>
</tr>
<tr>
<td>Shipping &amp; Handling:</td>
<td>0.00</td>
</tr>
<tr>
<td>VAT 20%:</td>
<td>3,200.12</td>
</tr>
<tr>
<td>VAT ID:</td>
<td>GB 836666490-000</td>
</tr>
<tr>
<td>TOTAL (GBP):</td>
<td>19,200.35</td>
</tr>
</table>


Tax Exemption: No Exemption
Reasonable collection and attorney's fees will be assessed to all accounts placed for collection.
If you re-package or re-sell this product, you are required to maintain integrity of Country of Origin to the consumer of this product.
X indicates part is a hazardous material
\* indicates part was sold at a promotional or special discount price

No materials accepted for return without our permission.
All discrepancies must be reported within 10 days.


<table>
<tr>
<td>Bank Details:</td>
<td>Wells Fargo, N.A London Branch 33 Kind William Street, London, United Kingdom EC4R9AT</td>
</tr>
<tr>
<td>IBAN (GBP):</td>
<td>GB42PNBP16567108228036</td>
</tr>
<tr>
<td>IBAN (EUR):</td>
<td>GB24PNBP16567108228166</td>
</tr>
<tr>
<td>SWIFT Code:</td>
<td>PNBPGB2L</td>
</tr>
<tr>
<td>Account Number</td>
<td>08228036</td>
</tr>
<tr>
<td>(GBP):</td>
<td></td>
</tr>
<tr>
<td>Account Number</td>
<td>08228166</td>
</tr>
<tr>
<td>(EUR):</td>
<td></td>
</tr>
<tr>
<td>Sort Code:</td>
<td>(CHAPS: 165671) (BACS: 405133)</td>
</tr>
</table>


Registered Entity Address:

Fastenal Europe Ltd.

Units B&C Glasgow Trade Park

Springhill Parkway

Glasgow

G69 6GE

United Kingdom

VAT ID: GB984 554376

Company Number: SC370971

<!-- PageFooter="Thank you!" -->
<!-- PageNumber="Page 40 of 40" -->
