# report2558787- DB SCHENKER.xlsx

## Sheet: Sheet1

| Requested by: SYSTEM ADMINISTRATOR | on: 2026/01/30 | at:05:12 |  |  |  |  |  |  |  |  |  |
|---|---|---|---|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |
| K84 Details - (1001357874) BUNZL CANADA INC DBA BUNZL CANADA IMPORTS(882073166RM0005) |  |  |  |  |  |  |  |  |  |  |  |
| SCHENKER OF CANADA LTD |  |  |  |  |  |  |  |  |  |  |  |
| Trans Num | Invoice Num | AcctDate | Vendor Name | PO Number | VFD | Duty | SIMA | Excise Tax | GST | Other | Total |
| 13888500220984 | 4953019279 | 2026/01/29 | SHIANG SHIN CORP | 1132977 | 57002.68 | 8835.42 | 0 | 0 | 3291.92 | 0 | 12127.34 |
|  |  |  | TOTAL |  | 57002.68 | 8835.42 | 0 | 0 | 3291.92 | 0 | 12127.34 |
| This statement is for reference only. For account details and payment information, please access the CBSA CARM Client Portal. |  |  |  |  |  |  |  |  |  |  |  |