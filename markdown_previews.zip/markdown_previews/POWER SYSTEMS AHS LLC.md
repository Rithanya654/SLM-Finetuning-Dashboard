# POWER SYSTEMS AHS LLC.pdf

<figure>

AIR-HYDRAULIC
SYSTEMS

</figure>


An APPLIED® fluid power company
1517 Main Avenue


<table>
<tr>
<td>Fargo,</td>
<td>ND 58103-1529</td>
</tr>
<tr>
<td>Phone:</td>
<td>701-237-4129</td>
</tr>
<tr>
<td>Fax:</td>
<td>701-234-0672</td>
</tr>
</table>


Remit Payment To:

Power Systems AHS, LLC

PO Box 860351

Minneapolis, MN 55486-0351


# INVOICE


<table>
<tr>
<td>Invoice Number</td>
<td>32917752</td>
</tr>
<tr>
<td>Invoice Date</td>
<td>02/02/2026 15:20:45</td>
</tr>
<tr>
<td>Customer ID</td>
<td>171364</td>
</tr>
<tr>
<td>Page</td>
<td>1 of 2</td>
</tr>
<tr>
<td>Order Number</td>
<td>3306588</td>
</tr>
</table>


Bill To:

THE AFTERMARKET PARTS CO LLC
630 KERNAGHAN AVE DOOR 76
WINNIPEG, MB R2C 5G1
CA

Ship To:

NFI PARTS DISTRIBUTION CENTER
630 KERNAGHAN AVE
DOOR 10
WINNIPEG, MB R2C 5G1
CA

Attn: INVOICE SUBMISSION


<table>
<tr>
<th>PO Number</th>
<th>Term Description</th>
<th>Net Due Date</th>
</tr>
<tr>
<td>8885920</td>
<td>NET 30</td>
<td>3/4/2026</td>
</tr>
</table>


<table>
<tr>
<th>Order Date</th>
<th>Pick Ticket No</th>
<th>Primary Salesrep Name</th>
<th>Taker</th>
</tr>
<tr>
<td>12/19/2025</td>
<td>22976069</td>
<td>Scott Starry-NFI</td>
<td>AKOTCHIAN</td>
</tr>
</table>


<table>
<tr>
<th colspan="4">Quantities</th>
<th rowspan="2">Item ID Item Description</th>
<th rowspan="2">Pricing UOM Unit Size</th>
<th rowspan="2">Unit Price</th>
<th rowspan="2">Extended Price</th>
</tr>
<tr>
<th>Ordered</th>
<th>Shipped</th>
<th>Remaining</th>
<th>UOM Unit Size</th>
</tr>
</table>


Delivery Instructions: Please contact: pickup@manitoulintransport
3rd Party Billing Address:
NFI Parts
3229 SAWMILL PKWY
DELAWARE, OH 43015
1-800-265-1485
"USE POWER SYSTEMS BOL FORM"

Carrier: UPS GROUND COLLECT

Tracking #: 1Z5552330378152390


<table>
<tr>
<th>2.0000</th>
<th>2.0000</th>
<th>0.0000</th>
<th>EA</th>
<th>PS-051012-00250-AM12FR0-AM16FR0-000A</th>
<th>EA</th>
<th>44.66000</th>
<th>89.32</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2">1.0 HOSE ASSEMBLY</td>
<td>1.0000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2">Ordered As: 329209</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


Total Lines: 1


<table>
<tr>
<td>SUB-TOTAL:</td>
<td>89.32</td>
</tr>
<tr>
<td>TAX:</td>
<td>0.00</td>
</tr>
<tr>
<td>AMOUNT DUE USD:</td>
<td>89.32</td>
</tr>
</table>


ORIGINAL

ALL SALES OF GOODS OR SERVICES ARE EXPRESSLY AND EXCLUSIVELY SUBJECT TO OUR STANDARD TERMS AND CONDITIONS OF SALE ATTACHED AND/OR
AVAILABLE ON OUR WEBSITE https://www.airhydraulicsystems.com. ANY AND ALL DIFFERENT OR ALTERNATIVE TERMS AND CONDITIONS SET FORTH IN BUYER'S
PURCHASE ORDER OF SIMILAR COMMUNICATIONS ARE OBJECTED TO AND SHALL NOT BE BINDING ON SELLER UNLESS AGREED TO IN WRITING BY A
CORPORATE OFFICER OF SELLER.

<!-- PageBreak -->


# AIR-HYDRAULIC SYSTEMS - STANDARD TERMS AND CONDITIONS OF SALE

ALL SALES OF GOODS OR SERVICES ARE EXPRESSLY AND EXCLUSIVELY SUBJECT TO OUR STANDARD TERMS AND CONDITIONS OF SALE ATTACHED AND'OR AVAILABLE ON OUR WEBSITE https://www.airhydraulicsystems.com.
ANY AND ALL DIFFERENT OR ALTERNATIVE TERMS AND CONDITIONS SET FORTH IN BUYER'S PURCHASE ORDER OF SIMILAR COMMUNICATIONS ARE OBJECTED TO AND SHALL NOT BE BINDING ON SELLER UNLESS
AGREED TO IN WRITING BY A CORPORATE OFFICER OF SELLER.


## STANDARD TERMS AND CONDITIONS OF SALE

GOODS AND SERVICES SOLD BY APPLIED INDUSTRIAL TECHNOLOGIES, INC. OR ITS AFFILIATED COMPANIES ("SELLER") ARE EXPRESSLY SUBJECT TO THE TERMS AND CONDITIONS SET
FORTH BELOW. ANY DIFFERENT OR ADDITIONAL TERMS OR CONDITIONS IN BUYER'S PURCHASE ORDER OR SIMILAR COMMUNICATION ARE OBJECTED TO AND SHALL NOT BE BINDING ON
SELLER UNLESS AGREED TO IN WRITING BY A SELLER CORPORATE OFFICER. BUYER'S ACCEPTANCE OF SHIPMENT OR PERFORMANCE AND/OR PAYMENT FOR THE GOODS OR SERVICES
CONSTITUTES ACCEPTANCE OF SELLER'S TERMS AND CONDITIONS.

PRICE: Prices in effect at time of shipment of goods or performance of services shall prevail. All prices qu oted by
SELLER are subject to correction or change without notice. Prices do not include freight, shipping, handling fees
and/ or duties, any present or future sales, use, excise, value -added or similar taxes. Where applicable, such
taxes shall be billed as a separate item and paid by Buyer. A standard shipping charge is applied to each invoice
for goods to cover the material preparation, packaging, freight and/or any additional costs associated with each
shipment based on value and/or weight of the shipm ent. Additional charges for local delivery may also apply.
Export orders may be subject to other special pricing. PAYMENT TERMS: Unless otherwise agreed in writing,
terms of payment are thirty (30) days net, without setoff or deduction, from date invoice was mailed or goods are
delivered, whichever is earliest, if Buyer's credit has been approved prior to sale. A late payment charge of 1 1/2%
per month (an annual percentage rate of 18%) shall be charged on all past due accounts and Buyer shall pay
SELLER all costs incurred by it in collecting any past due account from Buyer, including, but not limited to, all court
costs and attorney's fees. However, if the foregoing charges exceed that rate which is the maximum permitted by
law, then such charges shall be calculated to be the highest allowable lawful rate. The remittance portion of the
invoice shall accompany payment. Alternatively, payments and other adjustments must reference the invoice
number to assure proper credit.

CREDIT BAL ANCE: Any credit balance issued will be applied within one (1) year of its issuance. IF NOT APPLIED
WITHIN ONE (1) YEAR, THE BALANCE REMAINING SHALL BE CANCELLED, AND SELLER SHALL HAVE NO
FURTHER LIABILITY EXCEPT AS REQUIRED BY APPLICABLE LAW.

DELIVERY: Unless otherwise noted, all domestic sales of goods are made f.o.b. point of shipment (Uniform
Commercial Code) and all international sales of goods are made EXW point of shipment Incoterms® 2010. In all
cases, title shall pass upon delivery and thereafter all risk of loss or dam age shall be upon Buyer. Delivery dates
given in advance of actual shipment of goods or performance of services are estimates and shall not be deemed
to represent fixed or guaranteed delivery dates. Buyer shall notify SELLER of any nonconforming goods wi thin a
commercially reasonable time after Buyer becomes aware of such nonconforming goods.

WARRANTIES: Goods are sold only with such warranties as may be extended by the manufacturer of the goods.
Services performed by third parties are subject only to those warranties extended by such third parties. For
additional warranty information, please review SELLER's Warranty Policy available at WW W.APPLIED.COM or
upon request to SELLER. TO THE

FULLEST EXTENT PERMITTED BY APPLICABLE LAW, SELLER MAKES NO WARRANTIES, EXPRESS OR
IMPLIED, INCLUDING THE WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR
PURPOSE, EXCEPT AS SPECIFICALLY SET FORTH IN THE WARRANTY POLICY. Buyer is responsible for
installation and use in accordance with manufacturer's instructions. Goods are sold for commercial use only and
are not intended for use by consumers. SELLER personnel are not authorized to alter this policy. Buyer shall be
solely responsible for any warranty it grants to its customer.

LIMITATION OF LIABILITY: SELLER takes no responsibility for goods selection, operation, and use, regardless
of any recommendations or suggestions made by the SELLER. Buyer shall make selections based upon its own
analysis with regard to function, material compatibility, fitness for use or intended purpose, and goods ratings. Any
such analysis, including testing, shall be the sole respons ibility of Buyer. Proper installation, operation, and
maintenance are solely the responsibility of Buyer or its customer. Any specifications listed in SELLER's
datasheets, catalog and website are for reference only and are subject to change without notice.
NOTWITHSTANDING ANYTHING TO THE CONTRARY, SELLER'S LIABILITY FOR ANY CLAIM ARISING OUT
OF THIS AGREEMENT OR FROM THE PERFORMANCE OR BREACH THEREOF, OR CONNECTED WITH
ANY GOODS OR SERVICES SUPPLIED HEREUNDER, OR THE SALE, RESALE, OPERATION OR USE OF
GOODS, WHETHER BASED ON CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR
INDEMNITY) OR OTHER GROUNDS, SHALL NOT EXCEED THE PRICE ALLOCABLE TO SUCH GOODS OR
SERVICES OR PART THEREOF INVOLVED IN THE CLAIM, REGARDLESS OF CAUSE OR FAULT. This
limitation of liability reflects a deliberate and bargained -for allocation of risks between SELLER and Buyer and
constitutes the basis of the parties' bargain, without which SELLER would not have agreed to the price or terms of
this agreement. SELLER shall not under any circums tances, be liable for any labor charges without its prior written
consent. SELLER SHALL NOT IN ANY EVENT BE LIABLE WHETHER AS A RESULT OF BREACH OF
CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR INDEMNITY) OR OTHER GROUNDS FOR
CONSEQUENTIAL, INDIRECT, INCIDENTAL, SPECIAL, LIQUIDATED, OR PUNITIVE DAMAGES including, but
not limited to, loss of profits or revenue, loss of use of goods or associated goods, cost of capital, cost of substitute
goods, facilities or services, downtime costs, or claims of customers of Buyer for such damage. If SELLER
furnishes Buyer with advice or other assistance regarding any goods or services supplied hereunder, or any system
or equipment in which any such goods may be installed, and which is not required pursuant to this agreement, the
furnishing of the advice or assistance will not subject SELLER to any liability, whether based on agreement,
warranty, tort (including negligence or indemnity) or other grounds. Buyer agrees to defend, indemnify and hold
Seller harmless from any third party claims arising out of the use, resale, or lease of said furnished goods or
services.

INTELLECTUAL PROPERTY: Each party will retain exclusive interest in and ownership of its intellectual property
developed before this agreement or outside the scope of this agreement. Upon mutual agreement, SELLER hereby
grants to Buyer a non-exclusive, world-wide, non-transferable, non-sublicensable, and royalty-free license to use
SELLER's preexisting intellectual property solely for the purpose of using the goods and service provided by the
SELLER.

Any intellectual property developed under or related to this agreement shall be the sole and exclusive property of
SELLER. SUBSTITUTIONS/INTERCHANGEABILITY: Unless specifically restricted on a purchase order,
SELLER reserves the right to interchange an equivalent available goods in place of the goods ordered where the
interchangeability of the goods is based on form, fit, and function.

EQUAL OPPORTUNITY AND L ABOR PRACTICES: The contract provisions in Section 202 of Executive Order
11246, as amended, and the regulations promulgated thereunder are incorporated by reference as if fully written
with respect to any order. SELLER certifies that the goods covered by this invoice have been produced in
accordance with the Fair Labor Standards Act of 1938, as amended.

SAFETY DATA SHEETS ("SDS"): Unless requested, SELLER will not furnish paper copies of Safety Data Sheets
("SDS"). SDS for OSHA defined hazardous substances are supplied by the manufacturers and/or suppliers a nd
electronically available online at WWW.APPLIED.COM. SELLER MAKES NO WARRANTIES AND EXPRESSLY
DISCLAIMS ALL LIABILITY TO ANY CUSTOMER OR USER WITH RESPECT TO THE ACCURACY OF THE
INFORMATION OR THE SUITABILITY OF THE

INFORMATION IN ANY SDS. CUSTOMER END USER IS SOLELY RESPONSIBLE FOR ANY RELIANCE ON,
OR USE OF, ANY INFORMATION, AND FOR USE OR APPLICATION OF ANY GOODS . SELLER will continue
to furnish paper copies of SDS for those goods for which a SDS is not electronically available. Paper copies of
SDS for all goods may be requested by contacting Seller at 1 -877-279-2799 to receive a copy of any SDS via web,
facsimile or U.S. mail.

HAZARDOUS ACTIVITIES: Unless specifically agreed to in writing by an authori zed officer of SELLER, goods or
services sold hereunder are not intended for use in connection with any nuclear facility or any other application or
hazardous activity which SELLER, in its sole discretion, determines to be high risk or hazardous, or where failure
of a single component could cause substantial harm to persons or property. If so used, SELLER disclaims any and
all liability for any nuclear damage, contamination or other damage or injury and Buyer shall indemnify and hold
SELLER harmless from such liability whether as a result of breach of contract warranty, tort (including negligence
or indemnity) or other grounds. SELLER and its suppliers shall not be liable to Buyer or its insurers based on
agreement, warranty, tort (including negligence or in demnity), or other grounds for onsite damage to property
located at a nuclear facility.

CANCELL ATION AND RETURNS: Buyer may cancel an order by mutual agreement based upon payment to
SELLER of reasonable and proper cancellation charges. Goods shall not be returned by Buyer without SELLER's
prior written authorization and payment by Buyer of a minimum restocking charge of 15%. Authorized returns shall
be returned at Buyer's sole expense, freight prepaid. There are NO returns of special order or made -to-order items.

No returns shall be accepted following 60 days after delivery. No credit will be issued for shipping charges or other
special expenses.

SHORTAGE/OVERAGES: All shortages and/or overages must be identified within 14 days of the date of shipment .
FORCE MAJEURE: SELLER shall not be liable for failure to deliver or for delay in delivery or performance due to: (i)
a cause beyond its reasonable control; (ii) an act of God, act or omission of Buyer, act of civil or military authority,
governmental priority or other allocation or control, fire, strike or other labor difficulty, riot or other civil disturbance,
public health emergency or outbreak, terrorist act, insolvency or other inability to perform by the manufacturer, delay
in transportation; or, (iii) telecommunication outage, power outage, security event, or any other commercial
impracticability. If such a delay occurs, delivery or performance shall be extended for a period equal to the time lost by
reason of delay.

CHANGE IN BUYER'S FINANCIAL CONDITION: SELLER reserves the right by written notice to cancel any order
or require full or partial payment or adequate assurance of performance from Buyer without liability to SELLER in the
event of: (i) Buyer's insolvency, (ii) the filing of a voluntary petition in bankruptcy by Buyer, (iii) the appointment of a
receiver or trustee for Buyer, or (iv) the execution by Buyer of an assignment for the benefit of creditors. SELLER
reserves the right to suspend its performance until payment or adequate as surance of performance has been
received. SELLER also reserves the right to cancel Buyer's credit at any time for any reason. Buyer, in order to
provide security for the payment of the full price of goods furnished hereunder, grants SELLER a security inter est in
the goods and the proceeds thereof. Buyer agrees to execute any documents or furnish information necessary to
perfect this security interest. A copy of the invoice may be filed at any time as a financing and/or chattel mortgage, in
order to perfect SELLER's security interest. SELLER may, in its sole discretion require, and Buyer hereby grants to
SELLER, a continuing purchase money security interest in all inventory, equipment, and goods sold by SELLER to
or for the benefit of Buyer, wherever located, and all accessions and goods and all proceeds from the sale thereof;
and all accounts and accounts receivable which may from time to time hereafter come into existence during the term
of this Security Agreement. SELLER's purchase money security interest i s explicitly limited to outstanding obligations
between SELLER and Buyer.

ASSIGNMENT O R DELEGATION: Buyer shall not assign, transfer or delegate, whether by operation of law or
otherwise, any or all of its duties or rights hereunder without SELLER's prior written consent.

WAIVER, CHOICE OF LAW AND DISPUTE RESOLUTION: The failure of either party to assert a right hereunder
or to insist upon compliance with any term or condition will not constitute a waiver of that right or excuse any
subsequent nonperformance of any such term or condition by the other party. All transactions shall be governed by
the laws of the State of Ohio, United States of America, excluding conflict of law rules. Any dispute with a party
located in U.S. arising out of or relating to transactions hereunder shall be brought only before any state or federal
court with jurisdiction and venue over Cleveland, Ohio, unless all such courts refuse to exercise jurisdiction and
venue, and the parties hereby consent to exclusive jurisdiction in su ch courts. Any claims brought by Buyer shall be
escalated to senior management level within both organizations prior to Buyer filing a lawsuit. Trial by jury is hereby
waived. Any dispute with a party located outside of U.S., except actions by Seller for n onpayment by Buyer of the
purchase price of goods or services sold, shall be settled by binding arbitration in Cleveland, Ohio under Ohio law
administered by the American Arbitration Association under its Commercial Arbitration Rules, and judgment on the
award rendered by the arbitrators may be entered in any court having jurisdiction thereof. The arbitrators will have
the powers a state court judge would have had if the matter had been filed in such court, including equitable powers,
except for the power to award punitive damages, which they shall not have. The provisions of the United Nations
Convention on Contracts for the International Sale of Goods shall not apply.

COMPLIANCE WITH L AWS: Buyer recognizes the goods are utilized in many regulated applica tions and that from
time to time standards and regulations are in conflict with one another. SELLER makes no promise or representation
that the goods will conform to any federal, state or local laws, ordinances, regulations, codes or standards, except as
particularly specified and agreed upon, in writing as part of the agreement between Buyer and SELLER. SELLER
prices do not include the cost of any related inspections, permits or inspection fees.

SPECIAL TOOLS: Unless specifically agreed in writing by SELL ER, and unless paid for by Buyer as shown on the
invoice, all special tools, dies, jigs, patterns, machinery and/or equipment needed by SELLER for the performance of
this sale are, and shall remain, the property of SELLER.

ORDER ACCEPTANCE: Buyer acknowledges that no order shall be deemed accepted unless and until it is verified
and accepted by SELLER, or any of its U.S. affiliates, subsidiaries and divisions, at a continental U.S. facility or at
any of its websites. Buyer further consents that submission of its order shall subject Buyer to the jurisdiction of the
federal courts of the United States of America and of the State where acceptance occurred in the United States of
America. EXPORT CONTROLS AND RELATED REGUL ATIONS: Buyer represents and warrants that it is not on,
or associated with any organization on the United States Department of Commerce's Bureau of Industry and
Security's Denied Persons List or Unverified List; or the United States Department of the Treasury's Office of Foreign
Assets Control lists, Specially

Designated Nationals, Specially Designated Global Terrorists, Specially Designated Narcotics Traffickers, Specially
Designated

Narcotic Traffickers-Kingpin, or Specially Designated Terrorists List; or the United States Department of State's
Designated Foreign Terrorist Organizations, Embargoed Countries list, or Debarred Persons List; or is subject to a
denial order issued by the United States Department of Commerce. Buyer shall comply with all relevant laws and
regulations of governmental bodies or agencies, including but not limited to all applicable export control laws of the
United States or other governing agencies and their successors. Any commodities, technology and software will be
exported from the U.S. in accordance with the U.S. Export Administration Regulations and other applicable laws or
regulations. Diversion contrary to U.S. law is prohibited. If requested by SELLER, Buyer shall provide documentation
satisfactory to SELLER verifying delivery at the designated country . BUYER AGREES TO INDEMNIFY AND HOLD
SELLER HARMLESS FROM ANY AND ALL COSTS, LIABILITIES, PENALTIES, SANCTIONS AND FINES
RELATED TO NON-COMPLIANCE WITH APPLICABLE EXPORT LAWS AND REGULATIONS.

FOREIGN PRINCIPAL PARTY IN INTEREST: FREIGHT FORWARDER AND DOCUMENTATION: For any export
sales, it is specifically agreed that Buyer shall be the foreign principal party in interest and/or that its freight forwarde r
shall act as Buyer's agent in such capacity for Export Administration Act or other applicable purposes; and Buyer and
freight forwarder shall assume responsibility for all export or routed transactions documentation. At SELLER's
request, Buyer or its freight forwarder shall provide copies of any export, shipping, or import documentation prepared
by Buyer or its freight forwarder related to sales to them by SELLER.

ANTI-BRIBERY AND ANTI-CORRUPTION: Buyer states that it is an independent contractor, and represents,
warrants, and covenants that it is in compliance with U.S. the Foreign Corrupt Practices Act a nd all applicable laws
and regulations relating to bribery and corruption in all countries in which Buyer conducts business.

PERMITS, EXPORT , AND IMPORT LICENSES: Buyer shall be responsible for obtaining any licenses or other
official authorizations that may be required by the country of importation and/or under the Export Administration
Regulations, International Traffic in Arms Regulations, Toxic Substances Control Act, or other applicable laws or
regulations.

GENERAL: All orders are subject to acceptance by SELLER. The terms and conditions in SELLER's forms are
incorporated herein by reference, and constitute the entire and exclusive agreement between Buyer and SELLER.
Any representation, affirmation of fact and course of dealing, promise or condition in connection therewith or usage
of trade not incorporated herein, shall not be binding on either party. If any provision hereof shall be unenforceable,
invalid or void for any reason, such provision shall be automatically voided and shall not be p art of this agreement
and the enforceability or validity of the remaining provisions shall not be affected thereby.

<!-- PageFooter="Copyright@ 2021 Applied Industrial Technologies, Inc. All Rights Reserved. (Rev. 03/10/2021)" -->
