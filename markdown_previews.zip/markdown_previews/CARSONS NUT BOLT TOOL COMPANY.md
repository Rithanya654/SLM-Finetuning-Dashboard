# CARSONS NUT BOLT TOOL COMPANY.pdf

<figure>

CARSON'S
NUT-BOLT & TOOL
EST. 1969

</figure>


REMIT TO: P.O BOX 3629 GREENVILLE, SC 29608-3629

All Claims Must Be Made Within 10 Days.
No Returns After 30 Days. No Returns Without Permission.


# INVOICE

INVOICE

4260019


<table>
<tr>
<th>Invoice Date</th>
<th>Page</th>
</tr>
<tr>
<td>02/02/2026 16:39:52</td>
<td>1 of 1</td>
</tr>
</table>


ORDER NUMBER
2260894

Branch: 03

Carsons Anderson

Bill To:

E&I ENGINEERING USA CORP.

400 SUPREME INDUSTRIAL DRIVE

ANDERSON, SC 29621

USA

Ship To:

E&I ENGINEERING USA CORP.

400 SUPREME INDUSTRIAL DRIVE

ANDERSON, SC 29621

USA

Attn: Accounts Payable

Customer ID: 113852


<table>
<tr>
<th>PO Number</th>
<th>Term Description</th>
<th>Net Due Date</th>
<th>Disc Due Date</th>
<th>Discount Amount</th>
</tr>
<tr>
<td>A107401 Call Off</td>
<td>NET 90 DAYS</td>
<td>05/03/2026</td>
<td>05/03/2026</td>
<td>0.00</td>
</tr>
</table>


<table>
<tr>
<th>Order Date</th>
<th>Pick Ticket No</th>
<th>Primary Salesrep Name</th>
<th>Taker</th>
</tr>
<tr>
<td>07/11/2025 09:48:07</td>
<td>3486629</td>
<td>Chad Amidon</td>
<td>SABLEB</td>
</tr>
</table>


<table>
<tr>
<th colspan="4">Quantities</th>
<th></th>
<th rowspan="2">Item ID Item Description</th>
<th rowspan="2">Pricing UOM Unit Size</th>
<th rowspan="2">Unit Price</th>
<th rowspan="2">Extended Price</th>
</tr>
<tr>
<th>Ordered</th>
<th>Shipped</th>
<th>Remaining</th>
<th>UOM Unit Size</th>
<th>Disp.</th>
</tr>
<tr>
<td colspan="2">Carrier:</td>
<td></td>
<td colspan="3">Tracking #:</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>30,000</td>
<td>400</td>
<td>6,250</td>
<td>EA</td>
<td>B</td>
<td>.10C60H33Z/P</td>
<td>EA</td>
<td>0.370000</td>
<td>148.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td rowspan="3"></td>
<td colspan="3" rowspan="3">1.0 M10-1.5X60 DIN 933 HX HD C/S GR8.8 PKG ZINC Ordered As: M10X60</td>
<td rowspan="3">1.0</td>
<td rowspan="3"></td>
<td rowspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Lot Number:</td>
<td>648307</td>
<td></td>
<td></td>
<td></td>
<td>Qty: 400 EA</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


Total Lines: 1


<table>
<tr>
<td>SUB-TOTAL:</td>
<td>148.00</td>
</tr>
<tr>
<td>TAX:</td>
<td>0.00</td>
</tr>
<tr>
<td>AMOUNT DUE:</td>
<td rowspan="2">148.00</td>
</tr>
<tr>
<td>U.S. Dollar</td>
</tr>
</table>


\*PLEASE NOTE\*
We charge 4% for Credit Card Processing
All Claims Must Be Made Within 10 Days.
No Returns After 30 Days. No Returns
Without Permission.

Effective February 1st, 2022
A fuel surcharge of $10 will be
added for all deliveries.
\*Subject to change\*

ORIGINAL

<!-- PageFooter="12.15.1494 - 06/02/14" -->
