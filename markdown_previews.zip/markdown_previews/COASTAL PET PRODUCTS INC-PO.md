# COASTAL PET PRODUCTS INC-PO.pdf

Coastal Pet Products, Inc.
911 Leadway Ave
Alliance OH 44601
United States
AR@CoastalPet.com
800-321-0428
330-821-2541

Order Number: Sales Order

#SO0125176

Invoice Number:
0202135

Invoice Date: 1/28/2026

Bill To:

2206804 VETERINARY SERVICE - SALIDA

PO BOX 8627

DATA SERVE

SAINT LOUIS MO 63126-0627

United States

Ship To:

2206804 WILCO - YAKIMA

5801 SUMMITVIEW AVE STE A

YAKIMA WA 98908

United States

Amount:

$1,266.40

Due Date:

2/27/2026


<table>
<tr>
<th>Terms</th>
<th>PO #</th>
<th>Shipping Method</th>
<th>Ship Date</th>
</tr>
<tr>
<td>2% 10 NET 30</td>
<td>186878009 11G44009</td>
<td></td>
<td>1/28/2026</td>
</tr>
</table>


External Notes:

Case Pack Adjustments: -


<table>
<tr>
<th>Item Item Options</th>
<th>UPC</th>
<th>SKU</th>
<th>Quantity</th>
<th>Unit Price</th>
<th>Amount</th>
</tr>
<tr>
<td>80524 NCLCAT - TRB 8 Feathr Catnp Toy Bin-51</td>
<td>076484815249</td>
<td>150793</td>
<td>1</td>
<td>$34.18</td>
<td>$34.18</td>
</tr>
<tr>
<td>00954 BCG04 - CP Dbl Hndl Bungee Lsh 1x4 BCG</td>
<td>076484009549</td>
<td>-</td>
<td>1</td>
<td>$10.57</td>
<td>$10.57</td>
</tr>
<tr>
<td>00404 BLU04 - CP Nylon Leash 5/8x4</td>
<td>076484035227</td>
<td>57018402</td>
<td>2</td>
<td>$2.50</td>
<td>$5.00</td>
</tr>
<tr>
<td>BLU</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>00406 BLK06 - CP Nylon Leash 5/8x6</td>
<td>076484035401</td>
<td>57018504</td>
<td>2</td>
<td>$2.99</td>
<td>$5.98</td>
</tr>
<tr>
<td>BLK</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>00406 LIM06 - CP Nylon Leash 5/8x6</td>
<td>076484040641</td>
<td>129190</td>
<td>2</td>
<td rowspan="2">$2.99</td>
<td>$5.98</td>
</tr>
<tr>
<td>LIM</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>06901 BLK26 - CP Nylon Collar 1x18-26 BLK</td>
<td>076484048005</td>
<td>57009904</td>
<td>2</td>
<td>$3.50</td>
<td>$7.00</td>
</tr>
<tr>
<td>06313 BLUXXS - CP C/Soft Harns 3/8x14-16 BLU</td>
<td>076484063046</td>
<td>109567</td>
<td>2</td>
<td>$3.81</td>
<td>$7.62</td>
</tr>
<tr>
<td>02901 BLU26 - CP Dbl Ply Nylon Clr</td>
<td>076484064524</td>
<td rowspan="2">57041802</td>
<td rowspan="2">2</td>
<td rowspan="2">$3.75</td>
<td rowspan="2">$7.50</td>
</tr>
<tr>
<td>1x26 BLU</td>
<td></td>
</tr>
<tr>
<td>06645 BLK32 - CP C/Wrap Harns 3/4x20-30 BLK</td>
<td>076484069635</td>
<td>57022004</td>
<td>2</td>
<td>$6.14</td>
<td>$12.28</td>
</tr>
</table>


Physical Address:
Coastal Pet Products, Inc.
911 Leadway Avenue
Alliance, Ohio 44601
FEIN: 34-1044431

Remittance Address:

Coastal Pet Products, Inc.

P.O. Box 901304

Cleveland, Ohio 44190-1304

Electronic Payments:
Account Number: 0427030745
Routing Number: 041001039
Swift Code: KEYBUS33

Remittance Advice Delivery:
Please send all remittance advice items
to: AR@CoastalPet.com

<!-- PageBreak -->

Coastal Pet Products, Inc.
911 Leadway Ave
Alliance OH 44601
United States
AR@CoastalPet.com
800-321-0428
330-821-2541


<table>
<tr>
<th>Order Number: Sales Order</th>
<th>Invoice Number:</th>
</tr>
<tr>
<td>#SO0125176</td>
<td>0202135</td>
</tr>
</table>


Invoice Date: 1/28/2026

Amount:

$1,266.40


<table>
<tr>
<th>Item</th>
<th>Item Options</th>
<th>UPC</th>
<th>SKU</th>
<th>Quantity</th>
<th>Unit Price</th>
<th>Amount</th>
</tr>
<tr>
<td>06645 BLU32 CP C/Wrap Harns 3/4x20-30 BLU</td>
<td>-</td>
<td>076484069642</td>
<td>57022002</td>
<td>2</td>
<td>$6.14</td>
<td>$12.28</td>
</tr>
<tr>
<td>01300 BLK03 CP BestFit Mesh Muzzle 03 BLK</td>
<td>-</td>
<td>076484076060</td>
<td>570251</td>
<td>2</td>
<td>$4.62</td>
<td>$9.24</td>
</tr>
<tr>
<td>01300 BLK05 CP BestFit Mesh Muzzle 05 BLK</td>
<td>-</td>
<td>076484076084</td>
<td>570253</td>
<td>2</td>
<td>$5.09</td>
<td>$10.18</td>
</tr>
<tr>
<td>01300 BLK06 CP BestFit Mesh Muzzle 6 BLK</td>
<td>-</td>
<td>076484076091</td>
<td>570254</td>
<td>2</td>
<td>$5.09</td>
<td>$10.18</td>
</tr>
<tr>
<td>08701 BLKMED CP PwrWlkr Retract Lsh MED BLK</td>
<td>-</td>
<td>076484088018</td>
<td>100093</td>
<td>2</td>
<td>$13.95</td>
<td>$27.90</td>
</tr>
<tr>
<td>08701 BLULRG CP PwrWlkr Retract Lsh LRG BLU</td>
<td>-</td>
<td>076484088063</td>
<td>101375</td>
<td>2</td>
<td>$15.26</td>
<td>$30.52</td>
</tr>
<tr>
<td>15489 IAQMED CP Inspire Harness 1×20-30 IAQ</td>
<td>-</td>
<td>076484151422</td>
<td>160464</td>
<td>1</td>
<td>$13.48</td>
<td>$13.48</td>
</tr>
<tr>
<td>15489 IGYMED CP Inspire Harness 1x20-30 IGY</td>
<td>-</td>
<td>076484151446</td>
<td>160466</td>
<td>1</td>
<td>$13.48</td>
<td>$13.48</td>
</tr>
<tr>
<td>00666 BBO06 CP Sublimated Leash 3/4x6 BBO</td>
<td>-</td>
<td>076484166761</td>
<td>107539</td>
<td>2</td>
<td>$4.62</td>
<td>$9.24</td>
</tr>
<tr>
<td>00366 SPW06</td>
<td rowspan="2">-</td>
<td rowspan="2">076484167829</td>
<td>107494</td>
<td>2</td>
<td>$4.02</td>
<td>$8.04</td>
</tr>
<tr>
<td>CP Sublimated Leash 3/8x6 SPW</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>00669 BLK36</td>
<td rowspan="2">-</td>
<td rowspan="2">076484182044</td>
<td rowspan="2">100616</td>
<td rowspan="2">2</td>
<td rowspan="2">$5.18</td>
<td rowspan="2">$10.36</td>
</tr>
<tr>
<td>CP Nylon Coupler 3/4x24-36 BLK</td>
</tr>
<tr>
<td>18830 V NCL30 CP Advance Training Pads 30-PK</td>
<td>-</td>
<td>076484188305</td>
<td>111090</td>
<td>1</td>
<td>$7.70</td>
<td>$7.70</td>
</tr>
</table>


Physical Address:
Coastal Pet Products, Inc.
911 Leadway Avenue
Alliance, Ohio 44601
FEIN: 34-1044431

Remittance Address:
Coastal Pet Products, Inc.
P.O. Box 901304
Cleveland, Ohio 44190-1304

Electronic Payments:
Account Number: 0427030745
Routing Number: 041001039
Swift Code: KEYBUS33

Remittance Advice Delivery:
Please send all remittance advice items
to: AR@CoastalPet.com

<!-- PageBreak -->

Coastal Pet Products, Inc.
911 Leadway Ave
Alliance OH 44601
United States
AR@CoastalPet.com
800-321-0428
330-821-2541


<table>
<tr>
<th>Order Number: Sales Order</th>
<th>Invoice Number:</th>
</tr>
<tr>
<td>#SO0125176</td>
<td>0202135</td>
</tr>
</table>


Invoice Date: 1/28/2026

Amount:

$1,266.40


<table>
<tr>
<th>Item Item Options</th>
<th>UPC</th>
<th>SKU</th>
<th>Quantity</th>
<th>Unit Price</th>
<th>Amount</th>
</tr>
<tr>
<td>18910 V NCL100 - CP Advanc Training Pads 100-PK</td>
<td>076484189104</td>
<td>111092</td>
<td>1</td>
<td>$23.01</td>
<td>$23.01</td>
</tr>
<tr>
<td>00206 BLU06 - CP Rope Leash 1/2x6</td>
<td>076484206023</td>
<td>140780</td>
<td>2</td>
<td>$5.50</td>
<td>$11.00</td>
</tr>
<tr>
<td>BLU</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>00206 LIM06 - CP Rope Leash 1/2x6</td>
<td>076484206030</td>
<td>140781</td>
<td rowspan="2">2</td>
<td rowspan="2">$5.50</td>
<td>$11.00</td>
</tr>
<tr>
<td>LIM</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>00206 TEL06 - CP Rope Leash 1/2x6</td>
<td>076484206757</td>
<td>-</td>
<td>2</td>
<td rowspan="2">$5.50</td>
<td>$11.00</td>
</tr>
<tr>
<td>TEL</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>16236 PNK06 -</td>
<td rowspan="2">076484282393</td>
<td rowspan="2">-</td>
<td rowspan="2">1</td>
<td rowspan="2">$6.95</td>
<td rowspan="2">$6.95</td>
</tr>
<tr>
<td>LP Wvn Lsh w/Tassel 3/8x6 PNK</td>
</tr>
<tr>
<td>84231 NCLDOG - LP Plush Outer Space 3pk Toys</td>
<td>076484324819</td>
<td>-</td>
<td>1</td>
<td>$4.19</td>
<td>$4.19</td>
</tr>
<tr>
<td>36206 ROB06 - K9 Explorer Rope Lsh 1/2×6 ROB</td>
<td>076484362019</td>
<td>138101</td>
<td>2</td>
<td>$9.98</td>
<td>$19.96</td>
</tr>
<tr>
<td>36216 GLR06 - K9 Explorer Slip Lsh 1/2×6 GLR</td>
<td>076484362026</td>
<td>138102</td>
<td>2</td>
<td>$9.34</td>
<td>$18.68</td>
</tr>
<tr>
<td>36216 ROB06 - K9 Explorer Slip Lsh 1/2×6 ROB</td>
<td>076484362033</td>
<td>138103</td>
<td>2</td>
<td>$9.98</td>
<td>$19.96</td>
</tr>
<tr>
<td>36206 BRY06 - K9 Explorer Rope Lsh 1/2×6 BRY</td>
<td>076484362064</td>
<td>128429</td>
<td>2</td>
<td>$9.98</td>
<td>$19.96</td>
</tr>
<tr>
<td>36206 COG06 - K9 Explorer Rope Lsh 1/2×6 COG</td>
<td>076484362071</td>
<td>128430</td>
<td>2</td>
<td>$9.98</td>
<td>$19.96</td>
</tr>
<tr>
<td>36206 FRN06 - K9 Explorer Rope Lsh 1/2x6 FRN</td>
<td>076484362088</td>
<td>128431</td>
<td>2</td>
<td>$9.98</td>
<td>$19.96</td>
</tr>
</table>


Physical Address:
Coastal Pet Products, Inc.
911 Leadway Avenue
Alliance, Ohio 44601
FEIN: 34-1044431

Remittance Address:
Coastal Pet Products, Inc.
P.O. Box 901304
Cleveland, Ohio 44190-1304

Electronic Payments:
Account Number: 0427030745
Routing Number: 041001039
Swift Code: KEYBUS33

Remittance Advice Delivery:
Please send all remittance advice items
to: AR@CoastalPet.com

<!-- PageBreak -->

Coastal Pet Products, Inc.
911 Leadway Ave
Alliance OH 44601
United States
AR@CoastalPet.com
800-321-0428
330-821-2541


<table>
<tr>
<th>Order Number: Sales Order</th>
<th>Invoice Number:</th>
</tr>
<tr>
<td>#SO0125176</td>
<td>0202135</td>
</tr>
</table>


Invoice Date: 1/28/2026

Amount:

$1,266.40


<table>
<tr>
<th>Item Item Options</th>
<th>UPC</th>
<th>SKU</th>
<th>Quantity</th>
<th>Unit Price</th>
<th>Amount</th>
</tr>
<tr>
<td>36206 SAP06 - K9 Explorer Rope Lsh 1/2x6 SAP</td>
<td>076484362095</td>
<td>128432</td>
<td>2</td>
<td>$9.98</td>
<td>$19.96</td>
</tr>
<tr>
<td>36216 BRY06 - K9 Explorer Slip Lsh 1/2x6 BRY</td>
<td>076484362163</td>
<td>128433</td>
<td>2</td>
<td>$9.98</td>
<td>$19.96</td>
</tr>
<tr>
<td>36216 COG06 - K9 Explorer Slip Lsh 1/2x6 COG</td>
<td>076484362170</td>
<td>128434</td>
<td>2</td>
<td>$9.98</td>
<td>$19.96</td>
</tr>
<tr>
<td>36216 FRN06 - K9 Explorer Slip Lsh 1/2x6 FRN</td>
<td>076484362187</td>
<td>128435</td>
<td>2</td>
<td>$9.98</td>
<td>$19.96</td>
</tr>
<tr>
<td>36406 COG06 - K9 Explorer Lsh 5/8x6 COG</td>
<td>076484364075</td>
<td>128422</td>
<td>2</td>
<td>$6.98</td>
<td>$13.96</td>
</tr>
<tr>
<td>36406 SAP06 - K9 Explorer Lsh 5/8x6 SAP</td>
<td>076484364099</td>
<td>128424</td>
<td>2</td>
<td>$6.98</td>
<td>$13.96</td>
</tr>
<tr>
<td>36422 BRY12 - K9 Explorer Clr 5/8x8-12 BRY</td>
<td>076484364228</td>
<td>128409</td>
<td>2</td>
<td>$5.94</td>
<td>$11.88</td>
</tr>
<tr>
<td>36422 FRN12 - K9 Explorer Clr 5/8x8-12 FRN</td>
<td>076484364242</td>
<td>128411</td>
<td>2</td>
<td>$5.94</td>
<td>$11.88</td>
</tr>
<tr>
<td>36423 BRY14 - K9 Explorer Clr 5/8x10-14 BRY</td>
<td>076484364303</td>
<td>1399814</td>
<td>2</td>
<td>$6.17</td>
<td>$12.34</td>
</tr>
<tr>
<td>36423 COG14 - K9 Explorer Clr 5/8x10-14 COG</td>
<td>076484364310</td>
<td>138108</td>
<td>2</td>
<td>$6.17</td>
<td>$12.34</td>
</tr>
<tr>
<td>36423 FRN14 - K9 Explorer Clr 5/8x10-14 FRN</td>
<td>076484364327</td>
<td>138109</td>
<td>2</td>
<td>$6.17</td>
<td>$12.34</td>
</tr>
<tr>
<td>36423 GLR14 - K9 Explorer Clr 5/8x10-14 GLR</td>
<td>076484364334</td>
<td>138110</td>
<td>2</td>
<td>$5.78</td>
<td>$11.56</td>
</tr>
</table>


Physical Address:
Coastal Pet Products, Inc.
911 Leadway Avenue
Alliance, Ohio 44601
FEIN: 34-1044431

Remittance Address:
Coastal Pet Products, Inc.
P.O. Box 901304
Cleveland, Ohio 44190-1304

Remittance Advice Delivery:
Please send all remittance advice items
to: AR@CoastalPet.com

Electronic Payments:

Account Number: 0427030745
Routing Number: 041001039
Swift Code: KEYBUS33

<!-- PageBreak -->

Coastal Pet Products, Inc.
911 Leadway Ave
Alliance OH 44601
United States
AR@CoastalPet.com
800-321-0428
330-821-2541


<table>
<tr>
<th>Order Number: Sales Order</th>
<th>Invoice Number:</th>
</tr>
<tr>
<td>#SO0125176</td>
<td>0202135</td>
</tr>
</table>


Invoice Date: 1/28/2026

Amount:

$1,266.40


<table>
<tr>
<th>Item Item Options</th>
<th>UPC</th>
<th>SKU</th>
<th>Quantity</th>
<th>Unit Price</th>
<th>Amount</th>
</tr>
<tr>
<td>36423 SAP14 - K9 Explorer Clr 5/8x10-14 SAP</td>
<td>076484364358</td>
<td>138112</td>
<td>2</td>
<td>$6.17</td>
<td>$12.34</td>
</tr>
<tr>
<td>36422 ROB12 - K9 Explorer Clr 5/8x8-12 ROB</td>
<td>076484364372</td>
<td>138107</td>
<td>2</td>
<td>$5.94</td>
<td>$11.88</td>
</tr>
<tr>
<td>36406 GLR06 - K9 Explorer Lsh 5/8x6</td>
<td>076484364389</td>
<td rowspan="2">138104</td>
<td rowspan="2">2</td>
<td rowspan="2">$6.53</td>
<td rowspan="2">$13.06</td>
</tr>
<tr>
<td>GLR</td>
<td></td>
</tr>
<tr>
<td>36445 ROB18 -</td>
<td rowspan="2">076484364419</td>
<td rowspan="2">138201</td>
<td rowspan="2">2</td>
<td rowspan="2">$7.42</td>
<td rowspan="2">$14.84</td>
</tr>
<tr>
<td>K9 Explorer Hrn 5/8x12-18 ROB</td>
</tr>
<tr>
<td>36445 BRY18 -</td>
<td rowspan="2">076484364457</td>
<td rowspan="2">128437</td>
<td rowspan="2">2</td>
<td rowspan="2">$7.42</td>
<td rowspan="2">$14.84</td>
</tr>
<tr>
<td>K9 Explorer Hrn 5/8x12-18 BRY</td>
</tr>
<tr>
<td>36445 FRN18 -</td>
<td>076484364471</td>
<td rowspan="2">128439</td>
<td rowspan="2">2</td>
<td rowspan="2">$7.42</td>
<td rowspan="2">$14.84</td>
</tr>
<tr>
<td>K9 Explorer Hrn 5/8x12-18 FRN</td>
<td></td>
</tr>
<tr>
<td>36445 SAP18 -</td>
<td rowspan="2">076484364488</td>
<td rowspan="2">128440</td>
<td rowspan="2">2</td>
<td rowspan="2">$7.42</td>
<td rowspan="2">$14.84</td>
</tr>
<tr>
<td>K9 Explorer Hrn 5/8x12-18 SAP</td>
</tr>
<tr>
<td>36923 GLR26 -</td>
<td>076484369049</td>
<td rowspan="2">138117</td>
<td rowspan="2">2</td>
<td rowspan="2">$7.86</td>
<td rowspan="2">$15.72</td>
</tr>
<tr>
<td>K9 Explorer Clr 1x18-26 GLR</td>
<td></td>
</tr>
<tr>
<td>36906 BRY06 -</td>
<td rowspan="2">076484369063</td>
<td rowspan="2">128425</td>
<td rowspan="2">2</td>
<td rowspan="2">$8.90</td>
<td rowspan="2">$17.80</td>
</tr>
<tr>
<td>K9 Explorer Leash 1x6 BRY</td>
</tr>
<tr>
<td>36906 FRN06 -</td>
<td rowspan="2">076484369087</td>
<td rowspan="2">128427</td>
<td rowspan="2">2</td>
<td rowspan="2">$8.90</td>
<td rowspan="2">$17.80</td>
</tr>
<tr>
<td>K9 Explorer Leash 1x6 FRN</td>
</tr>
<tr>
<td>36906 SAP06 -</td>
<td rowspan="2">076484369094</td>
<td rowspan="2">128428</td>
<td rowspan="2">2</td>
<td rowspan="2">$8.90</td>
<td rowspan="2">$17.80</td>
</tr>
<tr>
<td>K9 Explorer Leash 1x6 SAP</td>
</tr>
<tr>
<td>36906 ROB06 - K9 Explorer Leash 1x6 ROB</td>
<td>076484369117</td>
<td>138114</td>
<td>2</td>
<td>$8.90</td>
<td>$17.80</td>
</tr>
</table>


Physical Address:
Coastal Pet Products, Inc.
911 Leadway Avenue
Alliance, Ohio 44601
FEIN: 34-1044431

Remittance Address:
Coastal Pet Products, Inc.
P.O. Box 901304
Cleveland, Ohio 44190-1304

Electronic Payments:
Account Number: 0427030745
Routing Number: 041001039
Swift Code: KEYBUS33

Remittance Advice Delivery:
Please send all remittance advice items
to: AR@CoastalPet.com

<!-- PageBreak -->

Coastal Pet Products, Inc.
911 Leadway Ave
Alliance OH 44601
United States
AR@CoastalPet.com
800-321-0428
330-821-2541


<table>
<tr>
<th>Order Number: Sales Order</th>
<th>Invoice Number:</th>
</tr>
<tr>
<td>#SO0125176</td>
<td>0202135</td>
</tr>
</table>


Invoice Date: 1/28/2026

Amount:

$1,266.40


<table>
<tr>
<th>Item</th>
<th>Item Options</th>
<th>UPC</th>
<th>SKU</th>
<th>Quantity</th>
<th>Unit Price</th>
<th>Amount</th>
</tr>
<tr>
<td>36923 BRY26 K9 Explorer Clr 1x18-26 BRY</td>
<td>-</td>
<td>076484369209</td>
<td>128417</td>
<td>2</td>
<td>$8.39</td>
<td>$16.78</td>
</tr>
<tr>
<td>36923 COG26 K9 Explorer Clr 1x18-26 COG</td>
<td>-</td>
<td>076484369216</td>
<td>128418</td>
<td>2</td>
<td>$8.39</td>
<td>$16.78</td>
</tr>
<tr>
<td>36923 SAP26 K9 Explorer Clr 1x18-26 SAP</td>
<td>-</td>
<td>076484369230</td>
<td>128420</td>
<td>2</td>
<td>$8.39</td>
<td>$16.78</td>
</tr>
<tr>
<td>36922 BRY18 K9 Explorer Clr 1x12-18 BRY</td>
<td>-</td>
<td>076484369247</td>
<td>128413</td>
<td>2</td>
<td>$7.70</td>
<td>$15.40</td>
</tr>
<tr>
<td>36922 COG18 K9 Explorer Clr 1x12-18 COG</td>
<td>-</td>
<td>076484369254</td>
<td>128414</td>
<td>2</td>
<td>$7.70</td>
<td>$15.40</td>
</tr>
<tr>
<td>36922 FRN18 K9 Explorer Clr 1x12-18 FRN</td>
<td>-</td>
<td>076484369261</td>
<td>128415</td>
<td>2</td>
<td>$7.70</td>
<td>$15.40</td>
</tr>
<tr>
<td>36922 GLR18 K9 Explorer Clr 1x12-18 GLR</td>
<td>-</td>
<td>076484369285</td>
<td>138115</td>
<td>2</td>
<td>$7.21</td>
<td>$14.42</td>
</tr>
<tr>
<td>36922 ROB18 K9 Explorer Clr 1x12-18 ROB</td>
<td>-</td>
<td>076484369292</td>
<td>138116</td>
<td>2</td>
<td>$7.70</td>
<td>$15.40</td>
</tr>
<tr>
<td>36945 SAP30 K9 Explorer Hrn 1x20-30 SAP</td>
<td>-</td>
<td>076484369452</td>
<td>128444</td>
<td>2</td>
<td>$10.80</td>
<td>$21.60</td>
</tr>
<tr>
<td>36946 BRY38 K9 Explorer Hrn 1x26-38 BRY</td>
<td>-</td>
<td>076484369469</td>
<td>128445</td>
<td>2</td>
<td>$11.48</td>
<td>$22.96</td>
</tr>
<tr>
<td>36946 FRN38 K9 Explorer Hrn 1x26-38 FRN</td>
<td>-</td>
<td>076484369483</td>
<td>128447</td>
<td>2</td>
<td>$11.48</td>
<td>$22.96</td>
</tr>
<tr>
<td>36945 ROB30</td>
<td rowspan="2">-</td>
<td rowspan="2">076484369513</td>
<td rowspan="2">138203</td>
<td rowspan="2">2</td>
<td rowspan="2">$10.80</td>
<td rowspan="2">$21.60</td>
</tr>
<tr>
<td>K9 Explorer Hrn 1×20-30 ROB</td>
</tr>
</table>


Physical Address:
Coastal Pet Products, Inc.
911 Leadway Avenue
Alliance, Ohio 44601
FEIN: 34-1044431

Remittance Address:
Coastal Pet Products, Inc.
P.O. Box 901304
Cleveland, Ohio 44190-1304

Electronic Payments:
Account Number: 0427030745
Routing Number: 041001039
Swift Code: KEYBUS33

Remittance Advice Delivery:
Please send all remittance advice items
to: AR@CoastalPet.com

<!-- PageBreak -->

Coastal Pet Products, Inc.
911 Leadway Ave
Alliance OH 44601
United States
AR@CoastalPet.com
800-321-0428
330-821-2541


<table>
<tr>
<th>Order Number: Sales Order</th>
<th>Invoice Number:</th>
</tr>
<tr>
<td>#SO0125176</td>
<td>0202135</td>
</tr>
</table>


Invoice Date: 1/28/2026

Amount:

$1,266.40


<table>
<tr>
<th>Item Item Options</th>
<th>UPC</th>
<th>SKU</th>
<th>Quantity</th>
<th>Unit Price</th>
<th>Amount</th>
</tr>
<tr>
<td>36946 ROB38 - K9 Explorer Hrn 1x26-38 ROB</td>
<td>076484369537</td>
<td>138205</td>
<td>2</td>
<td>$11.48</td>
<td>$22.96</td>
</tr>
<tr>
<td>00404 PKB04 - CP Nylon Leash 5/8x4</td>
<td>076484404115</td>
<td rowspan="2">129186</td>
<td>2</td>
<td rowspan="2">$2.50</td>
<td rowspan="2">$5.00</td>
</tr>
<tr>
<td>PKB</td>
<td></td>
<td></td>
</tr>
<tr>
<td>07781 FF612 -</td>
<td rowspan="2">076484432453</td>
<td rowspan="2">-</td>
<td rowspan="2">1</td>
<td rowspan="2">$4.19</td>
<td rowspan="2">$4.19</td>
</tr>
<tr>
<td>CP ElstaCat FF Clr 12" 2Pk FF6</td>
</tr>
<tr>
<td>46741 ANP12 - CP LZB Cat Clr 3/8x8-12 ANP</td>
<td>076484467523</td>
<td>137796</td>
<td>2</td>
<td>$3.03</td>
<td>$6.06</td>
</tr>
<tr>
<td>W6141 PINSML - SAF Plstc Hdl Wire Pin Brsh SM</td>
<td>076484512926</td>
<td>20015409</td>
<td>2</td>
<td>$3.92</td>
<td>$7.84</td>
</tr>
<tr>
<td>06410 BLK18 - CP Check TrngClr 5/8x10-14 BLK</td>
<td>076484513541</td>
<td>101348</td>
<td>2</td>
<td>$3.15</td>
<td>$6.30</td>
</tr>
<tr>
<td>06321 BBO12 - CP Sublim Collar 3/8x8-12 BBO</td>
<td>076484551055</td>
<td>57012812 8</td>
<td>2</td>
<td>$2.20</td>
<td>$4.40</td>
</tr>
<tr>
<td>81108 MLTCAT - TRB CatScrtRainbo</td>
<td>076484596049</td>
<td>-</td>
<td>1</td>
<td>$9.69</td>
<td>$9.69</td>
</tr>
<tr>
<td>00601 PKB18 - CP Nylon Collar 3/4x18 PKB</td>
<td>076484601040</td>
<td>129242</td>
<td>2</td>
<td>$1.94</td>
<td>$3.88</td>
</tr>
<tr>
<td>W6122 NCL00 - SAF Double Row Undercoat Rake</td>
<td>076484612206</td>
<td>20015421</td>
<td>2</td>
<td>$5.25</td>
<td>$10.50</td>
</tr>
<tr>
<td>W6123 NCL00 - SAF Single Row Undercoat Rake</td>
<td>076484612305</td>
<td>20015427</td>
<td>2</td>
<td>$4.64</td>
<td>$9.28</td>
</tr>
<tr>
<td>06162 BLKXLG -</td>
<td>076484616167</td>
<td>137655</td>
<td>2</td>
<td>$11.21</td>
<td>$22.42</td>
</tr>
</table>


WR Front Connect Hrn
1 XLG BLK

Physical Address:
Coastal Pet Products, Inc.
911 Leadway Avenue
Alliance, Ohio 44601
FEIN: 34-1044431

Remittance Address:

Coastal Pet Products, Inc.

P.O. Box 901304

Cleveland, Ohio 44190-1304

Remittance Advice Delivery:
Please send all remittance advice items
to: AR@CoastalPet.com

Electronic Payments:

Account Number: 0427030745

Routing Number: 041001039
Swift Code: KEYBUS33

<!-- PageBreak -->

Coastal Pet Products, Inc.
911 Leadway Ave
Alliance OH 44601
United States
AR@CoastalPet.com
800-321-0428
330-821-2541


<table>
<tr>
<th>Order Number: Sales Order</th>
<th>Invoice Number:</th>
</tr>
<tr>
<td>#SO0125176</td>
<td>0202135</td>
</tr>
</table>


Invoice Date: 1/28/2026

Amount:

$1,266.40


<table>
<tr>
<th>Item</th>
<th>Item Options</th>
<th>UPC</th>
<th>SKU</th>
<th>Quantity</th>
<th>Unit Price</th>
<th>Amount</th>
</tr>
<tr>
<td>06301 ORD12 CP Nylon Collar 3/8x8-12 ORD</td>
<td>-</td>
<td>076484630194</td>
<td>129657</td>
<td>2</td>
<td>$2.23</td>
<td>$4.46</td>
</tr>
<tr>
<td>46331 BMB12 CP LZB Refl Clr 3/8x8-12 BMB</td>
<td>-</td>
<td>076484633119</td>
<td>-</td>
<td>2</td>
<td>$2.55</td>
<td>$5.10</td>
</tr>
<tr>
<td>61371 LBE08</td>
<td rowspan="2">-</td>
<td rowspan="2">076484637100</td>
<td rowspan="2">-</td>
<td rowspan="2">1</td>
<td rowspan="2">$2.48</td>
<td rowspan="2">$2.48</td>
</tr>
<tr>
<td>LP Charmg Rbn Clr 3/8x6-8 LBE</td>
</tr>
<tr>
<td>61376 LBE06</td>
<td>-</td>
<td>076484637605</td>
<td>-</td>
<td>1</td>
<td>$4.09</td>
<td>$4.09</td>
</tr>
<tr>
<td>LP Charming Rbn Lsh 3/8x6 LBE</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>46431 BMB18 CP LZB Refl Clr 5/8x12-18 BMB</td>
<td>-</td>
<td>076484643330</td>
<td>-</td>
<td>2</td>
<td>$3.82</td>
<td>$7.64</td>
</tr>
<tr>
<td>06613 REDSML CP C/Soft Harns 3/4x19-23 RED</td>
<td>-</td>
<td>076484661419</td>
<td>109578</td>
<td>2</td>
<td>$6.94</td>
<td>$13.88</td>
</tr>
<tr>
<td>06703 DPM12 SC Sbm HB Cat Clr 3/8x8-12 DPM</td>
<td>-</td>
<td>076484670213</td>
<td>-</td>
<td>2</td>
<td>$2.85</td>
<td>$5.70</td>
</tr>
<tr>
<td>06775 GOC12 SC GlowDk Cat Clr 3/8x8-12 GOC</td>
<td>-</td>
<td>076484677533</td>
<td>154023</td>
<td>1</td>
<td>$3.50</td>
<td>$3.50</td>
</tr>
<tr>
<td>06901 LIM26 CP Nylon Collar 1x18-26 LIM</td>
<td>-</td>
<td>076484690020</td>
<td>129896</td>
<td>2</td>
<td>$3.50</td>
<td>$7.00</td>
</tr>
<tr>
<td>S1821 ORG11</td>
<td rowspan="2">-</td>
<td rowspan="2">076484718212</td>
<td rowspan="2">2059618</td>
<td rowspan="2">1</td>
<td rowspan="2">$4.32</td>
<td rowspan="2">$4.32</td>
</tr>
<tr>
<td>WW Vinyl Trng Dummy 2x11 ORG</td>
</tr>
<tr>
<td>S1822 ORG12</td>
<td rowspan="2">-</td>
<td rowspan="2">076484718236</td>
<td rowspan="2">164728</td>
<td rowspan="2">1</td>
<td rowspan="2">$5.64</td>
<td rowspan="2">$5.64</td>
</tr>
<tr>
<td>WW Vinyl Trng Dummy 3x12 ORG</td>
</tr>
<tr>
<td>06901 PKF26</td>
<td rowspan="2">-</td>
<td rowspan="2">076484730023</td>
<td rowspan="2">57009923</td>
<td rowspan="2">2</td>
<td rowspan="2">$3.50</td>
<td rowspan="2">$7.00</td>
</tr>
<tr>
<td>CP Nylon Collar 1x18-26 PKF</td>
</tr>
</table>


Physical Address:
Coastal Pet Products, Inc.
911 Leadway Avenue
Alliance, Ohio 44601
FEIN: 34-1044431

Remittance Address:

Coastal Pet Products, Inc.

P.O. Box 901304

Cleveland, Ohio 44190-1304

Electronic Payments:
Account Number: 0427030745
Routing Number: 041001039
Swift Code: KEYBUS33

Remittance Advice Delivery:
Please send all remittance advice items
to: AR@CoastalPet.com

<!-- PageBreak -->

Coastal Pet Products, Inc.
911 Leadway Ave
Alliance OH 44601
United States
AR@CoastalPet.com
800-321-0428
330-821-2541


<table>
<tr>
<th>Order Number: Sales Order</th>
<th>Invoice Number:</th>
</tr>
<tr>
<td>#SO0125176</td>
<td>0202135</td>
</tr>
</table>


Invoice Date: 1/28/2026

Amount:

$1,266.40


<table>
<tr>
<th>Item Item Options</th>
<th>UPC</th>
<th>SKU</th>
<th>Quantity</th>
<th>Unit Price</th>
<th>Amount</th>
</tr>
<tr>
<td>07741 YLW10 - CP Ref ElastCat Clr 3/8x10 YLW</td>
<td>076484746130</td>
<td>129967</td>
<td>2</td>
<td>$2.26</td>
<td>$4.52</td>
</tr>
<tr>
<td>S6601 SOR20 - WW Polyest Collar 3/4x14-20 SOR</td>
<td>076484766244</td>
<td>-</td>
<td>1</td>
<td>$2.66</td>
<td>$2.66</td>
</tr>
<tr>
<td>S6901 WW526 - WW Sublmatd Collar 1x18-26 WW5</td>
<td>076484769573</td>
<td>-</td>
<td>1</td>
<td>$3.52</td>
<td>$3.52</td>
</tr>
<tr>
<td>00366 PDT06 - CP Sublimated Leash 3/8x6 PDT</td>
<td>076484774324</td>
<td>57003775</td>
<td>2</td>
<td>$4.02</td>
<td>$8.04</td>
</tr>
<tr>
<td>08002 V BLK00 - CP Advance Spring Scoop BLK</td>
<td>076484783333</td>
<td>100185</td>
<td>2</td>
<td>$8.17</td>
<td>$16.34</td>
</tr>
<tr>
<td rowspan="2">84207 DUCDOG - LP 4.5 Ultra Plush Duck</td>
<td>076484799013</td>
<td rowspan="2">105786</td>
<td rowspan="2">4</td>
<td rowspan="2">$2.58</td>
<td rowspan="2">$10.32</td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td>87032 R YLWDOG - CP Rascl 10" Rop Tug 2Knot YLW</td>
<td>076484879333</td>
<td>137901</td>
<td>1</td>
<td>$2.13</td>
<td>$2.13</td>
</tr>
<tr>
<td>88421 P/W28 - CP Maslow SS Paw Bowl 28oz B/W</td>
<td>076484884252</td>
<td>154111</td>
<td>3</td>
<td>$4.02</td>
<td>$12.06</td>
</tr>
</table>


<table>
<tr>
<td>Qty Total</td>
<td>187</td>
</tr>
<tr>
<td>Subtotal</td>
<td>$1,266.40</td>
</tr>
<tr>
<td>Shipping Cost</td>
<td>$0.00</td>
</tr>
<tr>
<td>Total</td>
<td>$1,266.40</td>
</tr>
</table>


Physical Address:
Coastal Pet Products, Inc.
911 Leadway Avenue
Alliance, Ohio 44601
FEIN: 34-1044431

Remittance Address:
Coastal Pet Products, Inc.
P.O. Box 901304
Cleveland, Ohio 44190-1304

Electronic Payments:

Account Number: 0427030745

Routing Number: 041001039
Swift Code: KEYBUS33

Remittance Advice Delivery:
Please send all remittance advice items
to: AR@CoastalPet.com
