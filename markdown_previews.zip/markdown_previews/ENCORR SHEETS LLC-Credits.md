# ENCORR SHEETS LLC-Credits.pdf

<figure>

Encore
SHEETS*

</figure>


Encorr Sheets
5171 E. Francis Street
Ontario, CA 91761
PH FAX


# INVOICE


<table>
<tr>
<th>SALESMAN NO.</th>
<th>BOL NUMBER</th>
<th>INVOICE DATE</th>
<th>TERMS</th>
<th>INVOICE NUMBER</th>
</tr>
<tr>
<td></td>
<td></td>
<td>01/28/2026</td>
<td>3% 10, 2% 30, Net 45</td>
<td>255864</td>
</tr>
</table>


SOLD TO

SHIP TO


<table>
<tr>
<td></td>
<td>Liberty Packaging 13100 Danielson Street</td>
</tr>
<tr>
<td>0000008</td>
<td>Poway, CA 92064</td>
</tr>
</table>


Liberty Tijuana
Sor Juana Ines La Cruz #20154-A
Tijuana, BC, MX 22440


<table>
<tr>
<th>DESCRIPTION</th>
<th>P/C QTY ORD / QTY INV</th>
<th>QTY SHIPPED</th>
<th>UNIT PRICE</th>
<th>AMOUNT</th>
</tr>
<tr>
<td>251204204 200 42WT SWB PO #: 2167335-1-1</td>
<td rowspan="2"></td>
<td rowspan="2"></td>
<td rowspan="2">76.60/MSF</td>
<td rowspan="2">-1,013.81</td>
</tr>
<tr>
<td>MSF: - 13.235 SIZE: 22.15 x 40.12</td>
</tr>
<tr>
<td>Return Orig Inv251590, CRC#: VCM 2404, Warp (2039)</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


REMIT TO:

Encorr Sheets

5171 E. Francis St.

Ontario, CA 91761


<table>
<tr>
<th rowspan="2">CODE Partial Complete</th>
<th>MSF TOTAL</th>
<th>INVOICE AMOUNT</th>
<th>TAX %</th>
<th>TAX AMOUNT</th>
<th>NET AMOUNT DUE</th>
</tr>
<tr>
<td>-13.235</td>
<td>-1,013.81</td>
<td>0.00%</td>
<td>0.00</td>
<td>-1,013.81</td>
</tr>
</table>


<figure>

\+

FSC
wwwcfea.org

</figure>


The mark of
responsible forestry
FSC C160215

Only products that are identified as such on this document are
chain of custody FSC® certified or SFI®certified.
Unless noted otherwise, all products are SFI® Certified Sourcing.


<figure>

8
SUSTAINABLE
FORESTRY
INITIATIVE
SF1-01 552

</figure>


SGSNA-SFICOC-606142
THANK YOU

Printed: 1/28/2026 9:12:48AM

<!-- PageBreak -->


<figure>

Encore
SHEETS

</figure>


Encorr Sheets
5171 E. Francis Street
Ontario, CA 91761
PH FAX


## INVOICE


<table>
<tr>
<th>SALESMAN NO. BOL NUMBER</th>
<th>INVOICE DATE</th>
<th>TERMS</th>
<th>INVOICE NUMBER</th>
</tr>
<tr>
<td></td>
<td>01/28/2026</td>
<td>3% 10, 2% 30, Net 45</td>
<td>255865</td>
</tr>
</table>


SOLD TO

SHIP TO


<table>
<tr>
<td></td>
<td>Liberty Packaging 13100 Danielson Street</td>
</tr>
<tr>
<td>0000008</td>
<td>Poway, CA 92064</td>
</tr>
</table>


Liberty Poway
13100 Danielson Street
Poway, CA 92064


<table>
<tr>
<th>DESCRIPTION</th>
<th colspan="2">P/C QTY ORD / QTY INV</th>
<th>OTY SHIPPED</th>
<th>UNIT PRICE</th>
<th>AMOUNT</th>
</tr>
<tr>
<td>251229100 44C PO #: 2172020-1-1 MSF: - 12.148 SIZE: 38.14 x 87.06</td>
<td></td>
<td></td>
<td></td>
<td>68.32/MSF</td>
<td>-829.94</td>
</tr>
<tr>
<td>Return Orig Inv253830, CRC#: VCM 2433, Mistagged Unit (515)</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


REMIT TO:

Encorr Sheets

5171 E. Francis St.

Ontario, CA 91761


<table>
<tr>
<th rowspan="2">CODE Partial® Complete</th>
<th>MSF TOTAL</th>
<th>INVOICE AMOUNT</th>
<th>TAX %</th>
<th>TAX AMOUNT</th>
<th>NET AMOUNT DUE</th>
</tr>
<tr>
<th>-12.148</th>
<th>-829.94</th>
<th>0.00%</th>
<th>0.00</th>
<th>-829.94</th>
</tr>
</table>


<figure>

FSC
www.[soxry

</figure>


The mark of
responsible forestry
FSC* C150218

Only products that are identified as such on this document are
chain of custody FSC® certified or SFI®certified.
Unless noted otherwise, all products are SFI® Certified Sourcing.


<figure>

&

SUSTAINABLE
FORESTRY
INITIATIVE
SFI-01 552

</figure>


SGSNA-SFICOC-606142
THANK YOU

Printed: 1/28/2026 9:12:53AM

<!-- PageBreak -->


<figure>

Encore
SHEETS"

</figure>


Encorr Sheets
5171 E. Francis Street
Ontario, CA 91761
PH FAX


## INVOICE


<table>
<tr>
<th>SALESMAN NO.</th>
<th>BOL NUMBER</th>
<th>INVOICE DATE</th>
<th>TERMS</th>
<th>INVOICE NUMBER</th>
</tr>
<tr>
<td></td>
<td></td>
<td>01/28/2026</td>
<td>3% 10, 2% 30, Net 45</td>
<td>255867</td>
</tr>
</table>


SOLD TO

SHIP TO

Liberty Packaging
13100 Danielson Street
Poway, CA 92064

0000008

Liberty Tijuana
Sor Juana Ines La Cruz #20154-A
Tijuana, BC, MX 22440


<table>
<tr>
<th>DESCRIPTION</th>
<th>P/G</th>
<th colspan="2">QTY ORD / QTY INV</th>
<th>QTY SHIPPED</th>
<th>UNIT PRICE</th>
<th>AMOUNT</th>
</tr>
<tr>
<td>251218163 32B PO #: 2171124-1-1</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td rowspan="2">50.89/MSF</td>
<td rowspan="2">-647.65</td>
</tr>
<tr>
<td>MSF: - 12.726 SIZE: 43:15 x 59.08</td>
<td></td>
<td colspan="2"></td>
<td></td>
</tr>
<tr>
<td>Return Orig Inv253184, CRC#: VCM 2427, Dry Board (701)</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


REMIT TO:

Encorr Sheets

5171 E. Francis St.

Ontario, CA 91761


<table>
<tr>
<th rowspan="2">CODE Partial Complete</th>
<th>MSE TOTAL</th>
<th>INVOICE AMOUNT</th>
<th>TAX %</th>
<th>TAX AMOUNT</th>
<th>NET AMOUNT DUE</th>
</tr>
<tr>
<td>-12.726</td>
<td>-647.65</td>
<td>0.00%</td>
<td>0.00</td>
<td>-647.65</td>
</tr>
</table>


<figure>

FSC
www.fsc.org

</figure>


The mark of
responsible forestry
FSC* 0150215

Only products that are identified as such on this document are
chain of custody FSC® certified or SFI®certified.
Unless noted otherwise, all products are SFI® Certified Sourcing.


<figure>

23

SUSTAINABLE
FORESTRY
INITIATIVE
SF1-01 552

</figure>


SGSNA-SFICOC-606142
THANK YOU

Printed: 1/28/2026 9:12:59AM

<!-- PageBreak -->


<figure>

Encore
SHEETS

</figure>


Encorr Sheets
5171 E. Francis Street
Ontario, CA 91761
PH FAX


## INVOICE


<table>
<tr>
<th>SALESMAN NO</th>
<th>BOL NUMBER</th>
<th>INVOICE DATE</th>
<th>TERMS</th>
<th>INVOICE NUMBER</th>
</tr>
<tr>
<td></td>
<td></td>
<td>01/28/2026</td>
<td>3% 10, 2% 30, Net 45</td>
<td>255869</td>
</tr>
</table>


SOLD TO

SHIP TO


<table>
<tr>
<td></td>
<td>Liberty Packaging 13100 Danielson Street</td>
</tr>
<tr>
<td>0000008</td>
<td rowspan="2">Poway, CA 92064</td>
</tr>
<tr>
<td></td>
</tr>
</table>


Liberty Preferred Packaging & Cont CPU
3330 W Cocopah St Ste 1
Phoenix, AZ 85009


<table>
<tr>
<th>DESCRIPTION</th>
<th>PIC</th>
<th>QTY ORD / QTY INV</th>
<th>QTY SHIPPED</th>
<th>UNIT PRICE</th>
<th>AMOUNT</th>
</tr>
<tr>
<td rowspan="2">251230186 200 SWC PO #: 2172587-1-1</td>
<td></td>
<td rowspan="2"></td>
<td></td>
<td rowspan="2"></td>
<td rowspan="2"></td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td>MSF: - 14.432 SIZE: 50.04 x 184.10</td>
<td></td>
<td></td>
<td></td>
<td>67.06/MSF</td>
<td>-967.78</td>
</tr>
<tr>
<td>Return Orig Inv253872, CRC#: VCM 2452, Mistagged Unit (224)</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


REMIT TO:

Encorr Sheets

5171 E. Francis St.

Ontario, CA 91761


<table>
<tr>
<th rowspan="2">CODE Partial Complete</th>
<th colspan="2">MSF TOTAL INVOICE AMOUNT</th>
<th>TAX %</th>
<th>TAX AMOUNT</th>
<th>NET AMOUNT DUE</th>
</tr>
<tr>
<th>-14.432</th>
<th>-967.78</th>
<th>0.00%</th>
<th>0.00</th>
<th>-967.78</th>
</tr>
</table>


<figure>

A
®

FSC
www.fsc.or

</figure>


The mark of
responsible forestry
FSC* C150215

Only products that are identified as such on this document are
chain of custody FSC® certified or SFI®certified.
Unless noted otherwise, all products are SFI®Certified Sourcing.


<figure>

{}
SUSTAINABLE
FORESTRY
INITIATIVE
5F1-01 552

</figure>


SGSNA-SFICOC-606142
THANK YOU

<!-- PageFooter="Printed: 1/28/2026 9:13:08AM" -->
<!-- PageBreak -->


<figure>

Encore
SHEETS™

</figure>


Encorr Sheets
5171 E. Francis Street
Ontario, CA 91761
PH FAX


## INVOICE


<table>
<tr>
<th>SALESMAN NO</th>
<th>BOL NUMBER</th>
<th>INVOICE DATE</th>
<th>TERMS</th>
<th>INVOICE NUMBER</th>
</tr>
<tr>
<td></td>
<td></td>
<td>01/28/2026</td>
<td>3% 10, 2% 30, Net 45</td>
<td>255871</td>
</tr>
</table>


SOLD TO

SHIP TO

Liberty Packaging
13100 Danielson Street
Poway, CA 92064

0000008

Liberty Tijuana
Sor Juana Ines La Cruz #20154-A
Tijuana, BC, MX 22440


<table>
<tr>
<th>DESCRIPTION</th>
<th>P/C</th>
<th>QTY ORD / QTY INV</th>
<th>QTY SHIPPED</th>
<th>UNIT PRICE</th>
<th>AMOUNT</th>
</tr>
<tr>
<td rowspan="2">251222118 200 SWC PO #: 2170239-1-1 MSF: - 2.160 SIZE: 13.10 x 46.02</td>
<td></td>
<td></td>
<td rowspan="2"></td>
<td rowspan="2">74.82/MSF</td>
<td rowspan="2">-161.63</td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td>Return Orig Inv253498, CRC#: VCM 2457, Delamination (495)</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


REMIT TO:

Encorr Sheets

5171 E. Francis St.

Ontario, CA 91761


<table>
<tr>
<th rowspan="2">CODE Partial Complete</th>
<th>MSF TOTAL</th>
<th>INVOICE AMOUNT</th>
<th>TAX %</th>
<th>TAX AMOUNT</th>
<th>NET AMOUNT DUE</th>
</tr>
<tr>
<td>-2.160</td>
<td>-161.63</td>
<td>0.00%</td>
<td>0.00</td>
<td>-161.63</td>
</tr>
</table>


<figure>

FSC
www.fsccory

</figure>


The mark of
responsible forestry
FSC* C160215

Only products that are identified as such on this document are
chain of custody FSC® certified or SFI®certified.
Unless noted otherwise, all products are SFI®Certified Sourcing.


<figure>

23
SUSTAINABLE
FORESTRY
INITIATIVE
SFI-01552
SGSNA-SFICOC-606142
THANK YOU

</figure>


Printed: 1/28/2026 9:13:16AM

<!-- PageBreak -->


<figure>

Encore
SHEETS™

</figure>


Encorr Sheets
5171 E. Francis Street
Ontario, CA 91761
PH FAX


## INVOICE


<table>
<tr>
<th>SALESMAN NO</th>
<th>BOL NUMBER</th>
<th>INVOICE DATE</th>
<th>TERMS</th>
<th>INVOICE NUMBER</th>
</tr>
<tr>
<td></td>
<td></td>
<td>01/28/2026</td>
<td>3% 10, 2% 30, Net 45</td>
<td>255875</td>
</tr>
</table>


SOLD TO

SHIP TO

Liberty Packaging
13100 Danielson Street
Poway, CA 92064

0000008

Liberty Tijuana
Sor Juana Ines La Cruz #20154-A
Tijuana, BC, MX 22440


<table>
<tr>
<th>DESCRIPTION</th>
<th>PIC</th>
<th>QTY ORD / QTY INV</th>
<th>QTY SHIPPED</th>
<th>UNIT PRICE</th>
<th>AMOUNT</th>
</tr>
<tr>
<td rowspan="2">260113139 32C PO #: 2173921-1-1</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>MSF: - 1.502 SIZE: 28.08 x 39.02</td>
<td></td>
<td></td>
<td></td>
<td>50.89/MSF</td>
<td>-76.45</td>
</tr>
<tr>
<td>Return Orig Inv254806, CRC#: VCM 2461, Quantity Variance (194)</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


REMIT TO:

Encorr Sheets

5171 E. Francis St.

Ontario, CA 91761


<table>
<tr>
<th rowspan="2">CODE Partial Complete</th>
<th>MSF TOTAL</th>
<th>INVOICE AMOUNT</th>
<th>TAX %</th>
<th>TAX AMOUNT</th>
<th>NET AMOUNT DUE</th>
</tr>
<tr>
<th>-1.502</th>
<th>-76.45</th>
<th>0.00%</th>
<th>0.00</th>
<th>-76.45</th>
</tr>
</table>


<figure>

4

FSC
Wwefso.oru

</figure>


The mark of
responsible forestry
FSC* C160215

Only products that are identified as such on this document are
chain of custody FSC® certified or SFI®certified.
Unless noted otherwise, all products are SFI® Certified Sourcing.


<figure>

23

SUSTAINABLE
FORESTRY
INITIATIVE
SFI-01 552

</figure>


SGSNA-SFICOC-606142
THANK YOU

Printed: 1/28/2026 9:13:21AM

<!-- PageBreak -->


<figure>

Encore
SHEETS

</figure>


Encorr Sheets
5171 E. Francis Street
Ontario, CA 91761
PH FAX


### INVOICE


<table>
<tr>
<th>SALESMAN NO. BOL NUMBER</th>
<th>INVOICE DATE</th>
<th>TERMS</th>
<th>INVOICE NUMBER</th>
</tr>
<tr>
<td></td>
<td>01/28/2026</td>
<td>3% 10, 2% 30, Net 45</td>
<td>255876</td>
</tr>
</table>


SOLD TO

SHIP TO

Liberty Packaging
13100 Danielson Street
Poway, CA 92064

0000008

Liberty Tijuana
Sor Juana Ines La Cruz #20154-A
Tijuana, BC, MX 22440


<table>
<tr>
<th>DESCRIPTION</th>
<th>P/C</th>
<th>QTY ORD / QTY INV</th>
<th>OTY SHIPPED</th>
<th>UNIT PRICE</th>
<th>AMOUNT</th>
</tr>
<tr>
<td>260121037 200 SWC PO #: 2170239-1-2</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>MSF: 2.182 SIZE: 13.10 x 46.02 Return Orig Inv255476, CRC#: VCM 2464, Mistagged Unit (500)</td>
<td></td>
<td></td>
<td></td>
<td>74.82/MSF</td>
<td>-163.26</td>
</tr>
</table>


REMIT TO:

Encorr Sheets

5171 E. Francis St.

Ontario, CA 91761


<table>
<tr>
<th rowspan="2">CODE Partial Complete</th>
<th>MSF TOTAL</th>
<th>INVOICE AMOUNT</th>
<th>TAX %</th>
<th>TAX AMOUNT</th>
<th>NET AMOUNT DUE</th>
</tr>
<tr>
<th>-2.182</th>
<th>-163.26</th>
<th>0.00%</th>
<th>0.00</th>
<th>-163.26</th>
</tr>
</table>


<figure>

®

FSC
www.tto.org

</figure>


The mark of
responsible forestry
FSC* C150216

Only products that are identified as such on this document are
chain of custody FSC® certified or SFI®certified.
Unless noted otherwise, all products are SFI® Certified Sourcing.


<figure>

3
SUSTAINABLE
FORESTRY
INITIATIVE
SFI-01 552

</figure>


SGSNA-SFICOC-606142
THANK YOU

<!-- PageFooter="Printed: 1/28/2026 9:13:26AM" -->
<!-- PageBreak -->


<figure>

Encore
SHEETS

</figure>


Encorr Sheets
5171 E. Francis Street
Ontario, CA 91761
PH FAX


#### INVOICE


<table>
<tr>
<th>SALESMAN NO.</th>
<th>BOLNUMBER</th>
<th>INVOICE DATE</th>
<th>TERMS</th>
<th>INVOICE NUMBER</th>
</tr>
<tr>
<td></td>
<td></td>
<td>01/28/2026</td>
<td>3% 10, 2% 30, Net 45</td>
<td>255879</td>
</tr>
</table>


SOLD TO

SHIP TO


<table>
<tr>
<td>0000008</td>
<td rowspan="2">Liberty Packaging 13100 Danielson Street Poway, CA 92064</td>
</tr>
<tr>
<td></td>
</tr>
</table>


Encorr/Liberty Tijuana Farm Outs
\*WILL CALL\*
Ontario, CA 91761


<table>
<tr>
<th>DESCRIPTION</th>
<th colspan="2">PIC QTY ORD / QTY INV</th>
<th>QTY SHIPPED</th>
<th>UNIT PRICE</th>
<th>AMOUNT</th>
</tr>
<tr>
<td rowspan="2">251222227 200 42WT SWC PO #: 2171360-1-1</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td rowspan="3">-394.87</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td rowspan="2">78.21/MSF</td>
</tr>
<tr>
<td>MSF: - 5.049 SIZE: 13:14 × 39.04</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Return Orig Inv253603, CRC#: VCM 2431, Farm Out: Montebello (1335)</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


REMIT TO:

Encorr Sheets

5171 E. Francis St.

Ontario, CA 91761


<table>
<tr>
<th rowspan="2">CODE Partial Complete</th>
<th>MSF TOTAL</th>
<th>INVOICE AMOUNT</th>
<th>TAX %</th>
<th colspan="2">TAX AMOUNT NET AMOUNT DUE</th>
</tr>
<tr>
<th>-5.049</th>
<th>-394.87</th>
<th>0.00%</th>
<th>0.00</th>
<th>-394.87</th>
</tr>
</table>


<figure>

€
FSC
wwfso.ort

</figure>


The mark of
responsible forastry
FBC 0150215

Only products that are identified as such on this document are
chain of custody FSC® certified or SFI®certified.
Unless noted otherwise, all products are SFI® Certified Sourcing.


<figure>

$
SUSTAINABLE
FORESTRY
INITIATIVE
SFI-01552

</figure>


SGSNA-SFICOC-606142
THANK YOU

Printed: 1/28/2026 9:13:30AM
