# WHIRLPOOL CANADA LP.pdf

<figure>

Whirlpool
CANADA

6750 Century Ave, Unit 200
Mississauga, ON L5N 0B7

</figure>


BILL TO / FACTURE À: 2130017
MARCONE APW, ULC
ATTN: ACCOUNTS PAYABLE
PO BOX 411520
SAINT LOUIS MO 63141-3520
USA

SHIP TO / EXPÉDIER À: 990473

MARCONE

505 CITYVIEW BLVD, UNIT 2

WOODBRIDGE-ONTARIO ON L4H 0L8

CANADA

SOLD TO / VENDU À: 990473

MARCONE

505 CITYVIEW BLVD, UNIT 2

WOODBRIDGE-ONTARIO ON L4H 0L8

CANADA


# INVOICE FACTURE

REMIT TO / REMETTRE À:
WHIRLPOOL CANADA LP
P.O. BOX 15537, STATION A
TORONTO ON M5W 1C1


<table>
<tr>
<td>INVOICE NO Nº de FACTURE</td>
<td>9350533809</td>
</tr>
<tr>
<td>INVOICE DATE DATE de la FACTURE</td>
<td>01/30/2026</td>
</tr>
<tr>
<td>PAGE NO Nº de PAGE</td>
<td>1 of 2</td>
</tr>
<tr>
<td>PROV. SALES TAX LIC, LIC. TAXE de VENTE PROV.</td>
<td></td>
</tr>
<tr>
<td>CUSTOMER P.O. NO</td>
<td>VA0126R26WPL</td>
</tr>
<tr>
<td>ORDER NO Nº de COMMANDE du CLIENT de COMMANDE</td>
<td>1540056046</td>
</tr>
<tr>
<td>SHIP DATE EXPEDIE LE</td>
<td>01/30/2026</td>
</tr>
<tr>
<td>MANIFEST NO Nº DE L'EXPÉDITEUR</td>
<td>9041263920</td>
</tr>
<tr>
<td>TERMS CODE CODE de TERMES</td>
<td>Y016</td>
</tr>
<tr>
<td>APPROVAL APPROBATION</td>
<td></td>
</tr>
<tr>
<td>INVOICE TOTAL TOTAL de la FACTURE</td>
<td>3176.12 CAD</td>
</tr>
<tr>
<td>DUE DATE DATE REQUISE</td>
<td></td>
</tr>
<tr>
<td>TERMS</td>
<td></td>
</tr>
<tr>
<td>TERMES</td>
<td></td>
</tr>
</table>


CONTACT INFORMATION / INFO

DU CONTACT:

Credit - Whirlpool Canada LP

1-800-663-7478


<table>
<tr>
<th>LINE NO Nº d'ITEM</th>
<th>MODEL/PART NO Nº de MODÈLE/PIÈCE</th>
<th>SHORT NAME/DESCRIPTION</th>
<th>SKU/UPC CODE Nº de MODÈLE</th>
<th>QTY SHIPPED QTÉ EXPÉDIÉE</th>
<th>UNIT PRICE PRIX PAR UNITÉ</th>
<th>TOTAL</th>
</tr>
<tr>
<td>1</td>
<td>W10818273</td>
<td>DISPLAY</td>
<td></td>
<td>1</td>
<td>240.00</td>
<td>240.00</td>
</tr>
<tr>
<td>2</td>
<td>W11157862</td>
<td>HARNS-WIRE</td>
<td></td>
<td>1</td>
<td>74.71</td>
<td>74.71</td>
</tr>
<tr>
<td>3</td>
<td>W11211500</td>
<td>GRILLE</td>
<td></td>
<td>1</td>
<td>68.55</td>
<td>68.55</td>
</tr>
<tr>
<td>4</td>
<td>W11223301</td>
<td>COOKTOP</td>
<td></td>
<td>1</td>
<td>224.99</td>
<td>224.99</td>
</tr>
<tr>
<td>5</td>
<td>W11293971</td>
<td>CNTRL-ELEC</td>
<td></td>
<td>1</td>
<td>128.29</td>
<td>128.29</td>
</tr>
<tr>
<td>6</td>
<td>W11451365</td>
<td>RESERVOIR</td>
<td></td>
<td>1</td>
<td>71.25</td>
<td>71.25</td>
</tr>
<tr>
<td>7</td>
<td>W11451366</td>
<td>HOUSING</td>
<td></td>
<td>1</td>
<td>40.84</td>
<td>40.84</td>
</tr>
<tr>
<td>8</td>
<td>W11511154</td>
<td>MOTOR-DRVE</td>
<td></td>
<td>1</td>
<td>102.13</td>
<td>102.13</td>
</tr>
<tr>
<td>9</td>
<td>W11565028</td>
<td>CNTRL-ELEC</td>
<td></td>
<td>1</td>
<td>123.79</td>
<td>123.79</td>
</tr>
<tr>
<td>10</td>
<td>W11567335</td>
<td>VALVE</td>
<td></td>
<td>1</td>
<td>22.75</td>
<td>22.75</td>
</tr>
<tr>
<td>11</td>
<td>W11608056</td>
<td>CNTRL-ELEC</td>
<td></td>
<td>7</td>
<td>137.85</td>
<td>964.95</td>
</tr>
</table>


Merchandise may not be returned without priorapproval
Aucune marchandise peut être retournée sansapprobation antérieure

<!-- PageBreak -->

INVOICE NO: 9350533809

<!-- PageNumber="PAGE NO: 2 of 2" -->


<table>
<tr>
<th>LINE NO Nº d'ITEM</th>
<th>MODEL/PART NO Nº de MODÈLE/PIÈCE</th>
<th>SHORT NAME/DESCRIPTION</th>
<th>SKU/UPC CODE Nº de MODÈLE</th>
<th>QTY SHIPPED QTÉ EXPÉDIÉE</th>
<th>UNIT PRICE PRIX PAR UNITÉ</th>
<th>TOTAL</th>
</tr>
<tr>
<td>12</td>
<td>W11728257</td>
<td>KNOB</td>
<td></td>
<td>2</td>
<td>19.26</td>
<td>38.52</td>
</tr>
<tr>
<td>13</td>
<td>W11730306</td>
<td>SWITCH-INF</td>
<td></td>
<td>1</td>
<td>49.74</td>
<td>49.74</td>
</tr>
<tr>
<td>14</td>
<td>W11750809</td>
<td>GLASS-DOOR</td>
<td></td>
<td>1</td>
<td>322.90</td>
<td>322.90</td>
</tr>
<tr>
<td>15</td>
<td>WP56076</td>
<td>SPRING- ID</td>
<td></td>
<td>1</td>
<td>28.86</td>
<td>28.86</td>
</tr>
<tr>
<td>16</td>
<td>WPW10396765</td>
<td>COOKTOP</td>
<td></td>
<td>1</td>
<td>308.45</td>
<td>308.45</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>SUBTOTAL</td>
<td></td>
<td></td>
<td>2810.72</td>
</tr>
<tr>
<td></td>
<td></td>
<td>R849582879</td>
<td colspan="2">GST/HST TAX</td>
<td></td>
<td>365.40</td>
</tr>
<tr>
<td></td>
<td></td>
<td rowspan="2"></td>
<td>TOTAL</td>
<td></td>
<td>CAD</td>
<td rowspan="2">3176.12</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>CARRIER INFO</td>
<td>INFO: DE L'EXPÉDITEUR</td>
<td>PRO Nº de</td>
<td>NO: DOCUMENT</td>
<td>Nº de</td>
<td>TRAILER NO: CAMION</td>
<td></td>
</tr>
</table>


Merchandise may not be returned without prior approval
