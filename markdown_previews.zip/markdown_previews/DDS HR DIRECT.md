# DDS HR DIRECT.pdf

<figure>
</figure>


<figure>

HRdirect®
POSTER A GUARD Plus®

</figure>


NOTE: New Remittance Address


# INVOICE

Remit in US Funds to:
P.O. Box 669390, Pompano Beach, FL 33066-9390
Customer Service: 866-463-4574


<table>
<tr>
<th>INVOICE ACCOUNT NUMBER</th>
<th>CUSTOMER ACCOUNT NUMBER</th>
</tr>
<tr>
<td>A00781442</td>
<td>A00879005</td>
</tr>
<tr>
<td>SALES ORDER NUMBER</td>
<td>PURCHASE ORDER NUMBER</td>
</tr>
<tr>
<td>SO-21184920</td>
<td>6504429</td>
</tr>
</table>


<table>
<tr>
<th>INVOICE NUMBER</th>
<th>INVOICE DATE</th>
</tr>
<tr>
<td>INV18587292</td>
<td>01/28/26</td>
</tr>
<tr>
<td>PAYMENT TERMS</td>
<td>ORDER PLACER</td>
</tr>
<tr>
<td>Net 30 Days</td>
<td>Latresha Edwards</td>
</tr>
<tr>
<td>PHONE NUMBER</td>
<td>ORDER/RENEWAL DATE</td>
</tr>
<tr>
<td></td>
<td>01/28/26</td>
</tr>
</table>


ATTN: ACCOUNTS PAYABLE

BUNZL RETAIL SERVICES, LLC

PO BOX 270099

SAINT LOUIS, MO 63127

SHIPPED TO:

STORE MANAGER

T.J. MAXX 1081679 HORIZON WEST

5758 HAMLIN GROVES TRL

WINTER GARDEN, FL 34787


<table>
<tr>
<th>Qty</th>
<th>ITEM NUMBER</th>
<th>DESCRIPTION</th>
<th>CUSTOMER ID 1</th>
<th>CUSTOMER ID 2</th>
<th>SERVICE #</th>
<th>DISCOUNT</th>
<th>AMOUNT</th>
</tr>
<tr>
<td>1</td>
<td>U1200F English FL None</td>
<td>Poster Guard 1 Year State/Fed/Local New / Florida\English\None</td>
<td></td>
<td></td>
<td>1945128</td>
<td>0.00</td>
<td>26.32</td>
</tr>
</table>


<table>
<tr>
<th>MERCHANDISE</th>
<th>DELIVERY</th>
<th>MISC. CHARGES</th>
<th>SALES TAX</th>
<th>INVOICE TOTAL</th>
<th>AMOUNT APPLIED</th>
<th>TOTAL DUE</th>
</tr>
<tr>
<td>26.32</td>
<td>9.00</td>
<td>0.00</td>
<td>0.00</td>
<td>35.32</td>
<td>0.00</td>
<td>35.32</td>
</tr>
</table>


This invoice shows the total amount due for your Poster Guard® compliance service. Note that the service will automatically renew at the end
of each term, and you will be billed for payment. Please ensure payment is made promptly to prevent a lapse in your Poster Guard service.
For more details about your protected location(s), please visit www.posterguard.com.

Liability of seller is limited to the terms of the Poster Guard compliance guarantee. Please allow 10-15 business days for payment
application. Fees and interest may apply on the collection of past due balances.

Please cut at dotted line and return with your payment.

<!-- PageNumber="Page 1 of 1" -->

REMITTANCE COPY

INVOICE EMAIL ADDRESS: bd-brs@dataserv-stl.com

Is your invoice email address correct?
☐
YES
☐
NO

If NO, please update below:

Pay your invoice online at
https://www.hrdirect.com/payment
BUNZL RETAIL SERVICES, LLC
PO BOX 270099
SAINT LOUIS, MO 63127

CHECK NUMBER:

DIRECT DEPOSIT - call 800-925-0083 for details

EASY PAY AUTO RENEW - call 866-463-4574 for details

CREDIT CARD:
☐
MC
☐
VISA
☐
AMEX
☐
DISCOVER

AUTHORIZED SIGNATURE:

CREDIT CARD #:

EXP. DATE:

MMY Y

INVOICE ACCOUNT #

CUSTOMER ACCOUNT #


<table>
<tr>
<th>A00781442</th>
<th>A00879005</th>
</tr>
<tr>
<td>INVOICE NUMBER</td>
<td>INVOICE DATE</td>
</tr>
<tr>
<td>INV18587292</td>
<td>01/28/26</td>
</tr>
<tr>
<td rowspan="2"></td>
<td>TOTAL DUE</td>
</tr>
<tr>
<td>35.32</td>
</tr>
</table>
