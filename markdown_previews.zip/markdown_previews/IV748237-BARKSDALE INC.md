# IV748237-BARKSDALE INC.pdf

<figure>

Barksdale

CONTROL PRODUCTS
CRANE
3211 Fruitland Ave.
Los angeles CA
90058-9843
Tel 323-589-6181
Fax 323-589-3463

</figure>


NEW REMITTANCE ADDRESS
EFFECTIVE SEPT 2021
*** No Change in ACH/Wire Payments ***
PO Box 945030
Atlanta, GA 30394-5030
UNITED STATES


# INVOICE


<table>
<tr>
<th>NUMBER: IV748237</th>
<th>PAGE: 1</th>
</tr>
<tr>
<td>DATE: 01/31/26</td>
<td></td>
</tr>
</table>


BILL TO:
81366
NEW FLYER PARTS DEPT
711 KERNAGHAN AVENUE
WINNIPEG, MANITOBA, . R2C 5G1
CANADA

SHIP TO:
81366.18
KYI NFI PARTS DIST CENTER
7001 UNIVERSAL COACH DRIVE
DOOR 18
LOUISVILLE, KY 40258
UNITED STATES


<table>
<tr>
<td>SALES ORDER:</td>
<td>C510831</td>
</tr>
<tr>
<td>ORDER DATE:</td>
<td>01/16/26</td>
</tr>
<tr>
<td>SALESPERSON:</td>
<td>14-A</td>
</tr>
<tr>
<td>CREDIT TERMS:</td>
<td>NET 60 DAYS Shipping</td>
</tr>
</table>


<table>
<tr>
<td>SHIP DATE:</td>
<td>01/30/26</td>
</tr>
<tr>
<td>PURCHASE ORDER:</td>
<td>8888548</td>
</tr>
<tr>
<td>SHIP VIA:</td>
<td>USP</td>
</tr>
<tr>
<td>BOL:</td>
<td>1z9123780375868436</td>
</tr>
<tr>
<td>FOB POINT:</td>
<td>ock Incoterms 2020</td>
</tr>
</table>


Remarks:
ATTENTION BARKSDALE ACCOUNTING
******* ASBN REQUIRED ****

.

MARK SHIPMENT WITH (KY1)

..
SHIP VIA LOUISVILLE, KY - 3RD PARTY BILLING: 1 - 150 LBS (NOT ON A PALLET)
UPS GROUND COLLECT (ZIP CODE 40258 WITH ADDRESS 7001 UNIVERSAL COACH DRIVE,
LOUISVILLE, KY), ACCOUNT #30E2W1 FOR ASSISTANCE CALL 1-800-742-5877

151 LBS AND OVER CONTACT
XPO
XPO - TEL: (800) 755-2728
3rd Party Bill To: Account # 946365919
NFI Parts 3229 Sawmill Pkwy
Delaware, OH 43015


<table>
<tr>
<th>ITEM NUMBER</th>
<th>UM</th>
<th>SHIPPED</th>
<th>BACK ORD</th>
<th>PRICE</th>
<th>EXTENDED PRICE</th>
</tr>
<tr>
<td>623H3-04-Q38</td>
<td>EA</td>
<td>24.0</td>
<td>0.0</td>
<td>315.10</td>
<td>7,562.40</td>
</tr>
<tr>
<td colspan="2">PRESSURE TRANSMITTER</td>
<td></td>
<td>COO- US</td>
<td></td>
<td></td>
</tr>
</table>


CONTINUED

We hereby certify that the above material was produced in compliance with the Fair Standards Act of 1938
as amended, and that the above bill is correct and just, and that payment therefore has not been received.
These items were sold in accordance with the Export Administration regulations. Diversion contrary to
U.S. law prohibited.
Ownership and risk of loss transfers upon shipment from our facilities.

Barksdale takes exception to any and all requests for conformance to all DFARs including 252.225.7014
and 252.225.7016. Item numbers shown on this document do not conform to both clauses and the
company does not warrant or represent conformance to either clause.

<!-- PageBreak -->

<!-- PageHeader="STANDARD TERMS AND CONDITIONS" -->

Barksdale, Inc. (hereinafter referred to as "Barksdale") proposes to furnish the Purchaser the
products (hereinafter termed "Products"), subject to the following terms and conditions.

1\. DELIVERY: Unless otherwise agreed, Barksdale will furnish its Products FCA its factory.
Delivery to the transporting carrier shall constitute delivery to the Purchaser, and transfer of title
subject to the provisions of paragraph 2, below.

If shipment or any other act or condition affecting payment shall be delayed on account of
Purchaser, payment shall become due when Purchaser is notified that Barksdale is ready to
ship, and the product shall thereafter be held at Purchaser's risk and expense. If partial
shipments are made, proportionate payments shall become due and payable on the partial
shipments.

The specified shipment is subject to any delay on the part of the Purchaser in supplying
Barksdale with necessary data, or approved drawings as may be required, or any changes
therein at the Purchaser's instance, and to delays due to causes beyond Barksdale's
reasonable control, including, but not limited to, acts of God, or acts of Purchaser, fires, floods,
strikes, accidents, wrecks, delays in transportation, embargoes, car shortages, acts of civil or
military authority, compliance with priority orders or preferred ratings issued by the U.S.
Government, delay by supplier of material, shortages of material, unusually severe weather, or
any inability to obtain necessary labor, materials or manufacturing facilities due to any such
causes; and in the event of delay due to any such cause, the time specified for shipment or
completion shall be extended during the continuation of such delay and a reasonable time
thereafter to allow for shipment or completion. If changes in specifications or drawings are made
at the instance of the Purchaser, and accepted by Barksdale, Barksdale shall be entitled to an
equitable adjustment in the price, delivery date, or both.

Delivery dates are approximate. Delivery dates and prices are based on prompt receipt of orders
by Barksdale and all information necessary to permit Barksdale to proceed with work
immediately and without interruption, and satisfactory assurance of compliance with the terms of
payment agreed upon. Prices will be subject to adjustment in accordance with the provisions of
the annexed price adjustment clause, if any.

2\. TITLE: Without relieving the Purchaser from obligation to make payment as provided for and
without reference to the form of invoice that may be used by Barksdale, it is agreed that title, to
the extent of a security interest in the Products furnished, is reserved in Barksdale until the
purchase price (including any extensions of payment whether evidenced by note or otherwise)
shall have been fully paid in cash, and the Products shall remain personal property whatever
may be the mode of its attachment to realty or other property, until fully paid for in cash; and the
Purchaser agrees to perform all acts which may be necessary to perfect and assure retention of
title in Barksdale as aforesaid. In case of failure by the Purchaser to make any payment when
due, it is expressly understood that it shall be optional with Barksdale to take exclusive
possession of the Products wherever found and remove same without legal process, all at the
expense of the Purchaser. In the event of default by Purchaser, the amount of damage to
Barksdale being substantial and difficult or impossible to ascertain, it is hereby agreed that any
payments which may have been made to Barksdale shall be retained by it as liquidated
damages without prejudice to its right of recovery for further damage it may suffer from any
cause arising out of such default.

3\. STANDARD WARRANTY: Barksdale warrants that the Products will be free from defects in
title, and so far as of its own manufacture, will conform, in the manner herein provided, to the
applicable specifications which are made a part hereof, and will be free from defects in material
and workmanship, and should any part of it be found, when properly installed, maintained and
used under specified service conditions, within one year after date of notification of completion
at Barksdale plant or shipment by Barksdale, whichever is the earlier, to have been defective or
nonconforming with the specifications, Barksdale will repair or replace said part f.o.b. its factory,
provided the original part is returned to its factory transportation prepaid and Barksdale
inspection reveals it to have been defective or nonconforming within the terms of this warranty.
No device or part shall be returned without giving prompt notice of nonconformance or defect to
Barksdale and obtaining its prior written authorization. Barksdale shall in no event be held liable
for damage or delay caused by nonconformance or a defect in material or workmanship, and no
allowance will be made for repairs or alterations unless made with its written approval.
Purchaser, or any user claiming through Purchaser, assumes all liability for the consequences of
the use or misuse thereof by itself, or its employees, or by other.

Equipment and accessories not of our manufacture are warranted only to the extent of the
original manufacturer. Barksdale shall not be liable for damage of any kind resulting from
erosive, corrosive or other harmful action of any gases, liquids, or any other substance handled
by the Products. The foregoing is in lieu of all other warranties by, and obligations or liabilities of,
Barksdale, or its representatives, whether express, implied or statutory; and SINCE THE
PRODUCTS ARE THE SUBJECT OF SPECIFICATIONS, AS AFORESAID, NO WARRANTY
OF MERCHANTABILITY OR FITNESS FOR PURPOSE IS APPLICABLE.

4\. INSURANCE: Fire and extended coverage insurance in an amount sufficient to protect
Barksdale's interest in the Products is to be obtained from and maintained with an insurer
satisfactory to Barksdale by and at the expense of the Purchaser from the time of delivery until
the Products have been fully paid for in cash. The Purchaser shall assume all losses resulting
from any cause that may not be covered by insurance.

5\. TAXES: The Purchaser shall pay to Barksdale in addition to the purchase price, the amount
of any excise, sales, privilege, use or any other local, state or federal tax which is payable by
Barksdale because of the acceptance of any order, or the sale, delivery, installation, or use of
the Products covered hereby.

6\. SPECIFICATIONS: Any Barksdale specifications referred to herein, or annexed hereto, are a
standard form covering products substantially identical in type and character to that purchased,
but there may be variations therefrom in the details of design and construction of any particular
Product. The provisions in the specifications are descriptive and are not to be construed as
warranties. Barksdale reserves the right to make such changes in details of design and
construction as shall, in its judgement, constitute an improvement over such former practice as
may be shown or described in the specifications. Barksdale does not supply detailed or shop
working drawings of its Products.

7\. PATENTS: Barksdale shall indemnify the Purchaser for any liability the Purchaser may incur
because of claims of infringement of United States apparatus patents by the Products
manufactured by Barksdale, as long as Purchaser shall promptly disclose in writing to Barksdale
any notice of such claim or infringement it shall receive from any third party and shall cooperate
thereafter with Barksdale (at no cost to Purchaser) as to any defense that Barksdale shall raise.
The Purchaser shall indemnify Barksdale for any liability Barksdale may incur because of claims
of infringement of United States process patents in the use of the Products furnished hereunder,
or of United States apparatus patents claiming a combination in which Products furnished
hereunder are only a component in the combination.

G0019 REV E 05/01/13 PER DPM 5110

8\. CANCELLATION: Should the order be terminated for any just cause, the Purchaser shall pay
Barksdale for all costs and expenses incurred and commitments made in connection with the
performance of the order, plus a reasonable profit thereon.

9\. EMERGENCIES: For contracts or orders with a price of $200,000 or more and/or for
development contracts of a special nature, where Barksdale performance or completion of such
contracts or orders is delayed or suspended for a protracted period, directly or indirectly, as the
result of war, national emergency, federal or state statute of government rules or regulations,
priority controls, defense efforts, or any like cause (as distinguished from the normal delays in
manufacturing caused by factors beyond the control of the Manufacturer, such as strikes, fires,
traffic embargoes, etc.), either Barksdale or the Purchaser, at any time after the end of 180 days
following the start of such delay or suspension, may terminate the contract or order upon 10 days'
written notice to the other and upon the giving of such notice the Purchaser shall pay Barksdale for
all costs and expenses incurred and commitments made in connection with performance to the
date of such suspension, plus a reasonable profit thereon. Title to all material paid for by Purchaser
shall thereupon vest in the Purchaser, and shall thereafter be held at Purchaser's risk and expense.
In the event that the contract or order has not been so terminated, Barksdale will, promptly after the
cessation of the cause of such delay or suspension, notify the Purchaser of the revised shipping
schedule and proceed with performance in accordance therewith.

10\. LIMITS OF LIABILITY: The remedies, guaranties, and warranties provided herein are in lieu of
any remedies, guaranties, indemnities, conditions or liabilities, either express of implied arising by
law or otherwise. Upon the expiration of the warranty period expressly set forth herein, all liability
for claims not asserted theretofore against Barksdale shall terminate.

The liability of Barksdale in respect of all damages, losses, costs or expenses whether suffered or
incurred by Purchaser or any third party arising in any manner, incident or related to this contract or
the performance hereunder shall be limited in the aggregate to the actual price paid by Purchaser
to Barksdale.

Notwithstanding anything to the contrary, Barksdale shall not be liable to Purchaser or Purchaser's
customers or any third party for special, punitive, incidental or consequential damages of any kind
or character, including without limitation the loss of use of the Product or associated equipment,
damage to associated equipment, loss of profit or revenue, cost of replacement power, downtime
costs or claims of Purchaser's customers or others for any such damages which might arise under
this contract or otherwise, regardless of whether such damages are based upon contract, tort, strict
liability in tort, negligence or indemnity.

11\. LAWS AND REGULATIONS: The Products to be produced by Barksdale and delivered
hereunder will be produced in compliance with the Fair Labor Standards Act of 1938 as amended,
when applicable. Barksdale will comply with federal, state and local laws, orders and regulations
applicable to it as of the date of its quotation. Barksdale shall be responsible for compliance with
the requirements and standards of OSHA, or any similar law, only to the extent that they apply to
the Product itself and are sufficiently specifically identified in the order to Barksdale's satisfaction
and accepted by it in writing. Price and delivery shall be subject to adjustment to compensate for
compliance by Barksdale with any other laws, orders, regulations or requirements.

12\. ATOMIC ENERGY USE: The Purchaser represents that the Products being supplied hereunder
are to be used for a purpose other than in, or in any way related to, the creation, handling, or use of
atomic energy or any activity associated therewith; and Barksdale shall not be responsible to the
Purchaser or any third party should the Products be used otherwise than as represented, in which
event the Purchaser shall indemnify and hold Barksdale free and harmless of any and all costs and
damages. If, upon notice to Barksdale, the Products are to be used for the purpose of, or any way
related to, the creation, handling, or use of atomic energy, or any activity associated therewith,
Purchaser agrees to comply with, and be bound by, all the terms, provisions and conditions of
Barksdale applicable Nuclear Indemnification Clause, a copy of which will be supplied upon
request.

13\. ACCEPTANCE:

(a) These terms and conditions constitute the entire agreement between the parties with regard to
the subject matter hereof, and supersede all oral or written agreements and understandings, and,
to the extent permissible by law, supersede all statutory provisions regarding scope and duration of
Seller's warranties and the availability of remedies with regard to such subject matter. No additions
to or modifications of Seller's terms and conditions shall be binding upon Seller unless agreed to by
Seller in a signed document executed by an authorized representative of Seller.

(b) If a purchase order or other communication from Buyer includes any term or condition contrary
to, or in addition to, the terms and conditions stated herein, Buyer's acceptance of the products and
services which are the subject hereof, after receipt of these terms and conditions from Seller, shall
constitute Buyer's complete and unconditional assent to the terms hereof notwithstanding anything
to the contrary in any such earlier purchase order or communication, unless Buyer clearly instructs
Seller in writing, prior to acceptance, to cancel the order.

(c) Buyer's communication of contrary or additional terms, however phrased, shall be construed as
an offer to supplement and/or amend, and not as a rejection of, Seller's terms and conditions. Such
offer to supplement and amend shall be deemed rejected unless accepted by Seller in the manner
set forth above in the second sentence of paragraph (a).

14\. GENERAL: All of the above provisions, together with those set forth in the Barksdale form to
which this is annexed, and such others as may be accepted by Barksdale in writing, all of which are
accepted by Purchaser and supersede Purchaser's order form, if any, shall be and constitute the
entire agreement for the sale of the Products. Any terms and conditions in any writing pertaining to
the sale of the Products irrespective of its wording or of when received by Barksdale which are
inconsistent with, or add to, the terms and conditions hereof, will not be acceptable or become a
part of the contract without Barksdale's written consent signed by its duly authorized representative.
Commencement of performance or shipping shall not constitute acceptance of any such
inconsistent or added terms and conditions. Any representation, promise, course of dealing, or
trade usage, not contained or referenced herein, will not be binding on Barksdale. Any dispute
arising between the parties as to any aspect of this transaction shall be filed in a court of competent
jurisdiction in Los Angeles, California and shall be governed by California law (except that any
conflict of laws provision therein shall not be applicable). The prevailing party in such litigation shall
be entitled to recover from the other party its costs of litigation, including but not limited to attorneys'
fees, in addition to any other relief it may be entitled to receive. No modification, amendment,
rescission, waiver, or other change as to the terms herein shall be binding on Barksdale unless
agreed to in writing by Barksdale.

15\. ATEX MARKINGS:

See line item description for ATEX coverage


<figure>

<CE> =
CE
<EX> =
Ex

</figure>


ALL ORDERS ARE SUBJECT TO ACCEPTANCE BY BARKSDALE, AT ITS HOME OFFICE
AND NO ORDER SHALL BE BINDING UPON BARKSDALE UNTIL SO ACCEPTED.

<!-- PageFooter="INV_08G" -->
<!-- PageBreak -->


<figure>

Barksdale

CONTROL PRODUCTS
CRANE
3211 Fruitland Ave.
Los angeles CA
90058-9843
Tel 323-589-6181
Fax 323-589-3463

</figure>


NEW REMITTANCE ADDRESS
EFFECTIVE SEPT 2021
*** No Change in ACH/Wire Payments ***
PO Box 945030
Atlanta, GA 30394-5030
UNITED STATES


# INVOICE


<table>
<tr>
<th>NUMBER: IV748237</th>
<th>PAGE: 2</th>
</tr>
<tr>
<td>DATE: 01/31/26</td>
<td></td>
</tr>
</table>


BILL TO:
81366
NEW FLYER PARTS DEPT
711 KERNAGHAN AVENUE
WINNIPEG, MANITOBA, . R2C 5G1
CANADA

SHIP TO:
81366.18
KYI NFI PARTS DIST CENTER
7001 UNIVERSAL COACH DRIVE
DOOR 18
LOUISVILLE, KY 40258
UNITED STATES


<table>
<tr>
<th>ITEM NUMBER</th>
<th>UM</th>
<th>SHIPPED</th>
<th>BACK ORD</th>
<th>PRICE</th>
<th>EXTENDED PRICE</th>
</tr>
<tr>
<td>SURCHARGE</td>
<td>EA</td>
<td>24.0</td>
<td>0.0</td>
<td>4.11</td>
<td>98.64</td>
</tr>
<tr>
<td>SURCHARGE</td>
<td></td>
<td></td>
<td>COO- US</td>
<td></td>
<td></td>
</tr>
</table>


<table>
<tr>
<td>NON-TAXABLE TOTAL:</td>
<td>7,661.04</td>
</tr>
<tr>
<td>TAXABLE:</td>
<td>0.00</td>
</tr>
<tr>
<td>TAX DATE:</td>
<td>01/30/26</td>
</tr>
<tr>
<td>CURRENCY:</td>
<td>USD</td>
</tr>
</table>


We hereby certify that the above material was produced in compliance with the Fair Standards Act of 1938
as amended, and that the above bill is correct and just, and that payment therefore has not been received.
These items were sold in accordance with the Export Administration regulations. Diversion contrary to
U.S. law prohibited.
Ownership and risk of loss transfers upon shipment from our facilities.
Barksdale takes exception to any and all requests for conformance to all DFARs including 252.225.7014
and 252.225.7016. Item numbers shown on this document do not conform to both clauses and the
company does not warrant or represent conformance to either clause.


<table>
<tr>
<td>LINE TOTAL:</td>
<td>7,661.04</td>
</tr>
<tr>
<td>0.00% DISCOUNT:</td>
<td>0.00</td>
</tr>
<tr>
<td>SHIP/HANDLING 10 :</td>
<td>0.00</td>
</tr>
<tr>
<td>:</td>
<td>0.00</td>
</tr>
<tr>
<td>:</td>
<td>0.00</td>
</tr>
<tr>
<td>TOTAL TAX:</td>
<td>0.00</td>
</tr>
<tr>
<td>TOTAL:</td>
<td>7,661.04</td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->

<!-- PageHeader="STANDARD TERMS AND CONDITIONS" -->

Barksdale, Inc. (hereinafter referred to as "Barksdale") proposes to furnish the Purchaser the
products (hereinafter termed "Products"), subject to the following terms and conditions.

1\. DELIVERY: Unless otherwise agreed, Barksdale will furnish its Products FCA its factory.
Delivery to the transporting carrier shall constitute delivery to the Purchaser, and transfer of title
subject to the provisions of paragraph 2, below.

If shipment or any other act or condition affecting payment shall be delayed on account of
Purchaser, payment shall become due when Purchaser is notified that Barksdale is ready to
ship, and the product shall thereafter be held at Purchaser's risk and expense. If partial
shipments are made, proportionate payments shall become due and payable on the partial
shipments.

The specified shipment is subject to any delay on the part of the Purchaser in supplying
Barksdale with necessary data, or approved drawings as may be required, or any changes
therein at the Purchaser's instance, and to delays due to causes beyond Barksdale's
reasonable control, including, but not limited to, acts of God, or acts of Purchaser, fires, floods,
strikes, accidents, wrecks, delays in transportation, embargoes, car shortages, acts of civil or
military authority, compliance with priority orders or preferred ratings issued by the U.S.
Government, delay by supplier of material, shortages of material, unusually severe weather, or
any inability to obtain necessary labor, materials or manufacturing facilities due to any such
causes; and in the event of delay due to any such cause, the time specified for shipment or
completion shall be extended during the continuation of such delay and a reasonable time
thereafter to allow for shipment or completion. If changes in specifications or drawings are made
at the instance of the Purchaser, and accepted by Barksdale, Barksdale shall be entitled to an
equitable adjustment in the price, delivery date, or both.

Delivery dates are approximate. Delivery dates and prices are based on prompt receipt of orders
by Barksdale and all information necessary to permit Barksdale to proceed with work
immediately and without interruption, and satisfactory assurance of compliance with the terms of
payment agreed upon. Prices will be subject to adjustment in accordance with the provisions of
the annexed price adjustment clause, if any.

2\. TITLE: Without relieving the Purchaser from obligation to make payment as provided for and
without reference to the form of invoice that may be used by Barksdale, it is agreed that title, to
the extent of a security interest in the Products furnished, is reserved in Barksdale until the
purchase price (including any extensions of payment whether evidenced by note or otherwise)
shall have been fully paid in cash, and the Products shall remain personal property whatever
may be the mode of its attachment to realty or other property, until fully paid for in cash; and the
Purchaser agrees to perform all acts which may be necessary to perfect and assure retention of
title in Barksdale as aforesaid. In case of failure by the Purchaser to make any payment when
due, it is expressly understood that it shall be optional with Barksdale to take exclusive
possession of the Products wherever found and remove same without legal process, all at the
expense of the Purchaser. In the event of default by Purchaser, the amount of damage to
Barksdale being substantial and difficult or impossible to ascertain, it is hereby agreed that any
payments which may have been made to Barksdale shall be retained by it as liquidated
damages without prejudice to its right of recovery for further damage it may suffer from any
cause arising out of such default.

3\. STANDARD WARRANTY: Barksdale warrants that the Products will be free from defects in
title, and so far as of its own manufacture, will conform, in the manner herein provided, to the
applicable specifications which are made a part hereof, and will be free from defects in material
and workmanship, and should any part of it be found, when properly installed, maintained and
used under specified service conditions, within one year after date of notification of completion
at Barksdale plant or shipment by Barksdale, whichever is the earlier, to have been defective or
nonconforming with the specifications, Barksdale will repair or replace said part f.o.b. its factory,
provided the original part is returned to its factory transportation prepaid and Barksdale
inspection reveals it to have been defective or nonconforming within the terms of this warranty.
No device or part shall be returned without giving prompt notice of nonconformance or defect to
Barksdale and obtaining its prior written authorization. Barksdale shall in no event be held liable
for damage or delay caused by nonconformance or a defect in material or workmanship, and no
allowance will be made for repairs or alterations unless made with its written approval.
Purchaser, or any user claiming through Purchaser, assumes all liability for the consequences of
the use or misuse thereof by itself, or its employees, or by other.

Equipment and accessories not of our manufacture are warranted only to the extent of the
original manufacturer. Barksdale shall not be liable for damage of any kind resulting from
erosive, corrosive or other harmful action of any gases, liquids, or any other substance handled
by the Products. The foregoing is in lieu of all other warranties by, and obligations or liabilities of,
Barksdale, or its representatives, whether express, implied or statutory; and SINCE THE
PRODUCTS ARE THE SUBJECT OF SPECIFICATIONS, AS AFORESAID, NO WARRANTY
OF MERCHANTABILITY OR FITNESS FOR PURPOSE IS APPLICABLE.

4\. INSURANCE: Fire and extended coverage insurance in an amount sufficient to protect
Barksdale's interest in the Products is to be obtained from and maintained with an insurer
satisfactory to Barksdale by and at the expense of the Purchaser from the time of delivery until
the Products have been fully paid for in cash. The Purchaser shall assume all losses resulting
from any cause that may not be covered by insurance.

5\. TAXES: The Purchaser shall pay to Barksdale in addition to the purchase price, the amount
of any excise, sales, privilege, use or any other local, state or federal tax which is payable by
Barksdale because of the acceptance of any order, or the sale, delivery, installation, or use of
the Products covered hereby.

6\. SPECIFICATIONS: Any Barksdale specifications referred to herein, or annexed hereto, are a
standard form covering products substantially identical in type and character to that purchased,
but there may be variations therefrom in the details of design and construction of any particular
Product. The provisions in the specifications are descriptive and are not to be construed as
warranties. Barksdale reserves the right to make such changes in details of design and
construction as shall, in its judgement, constitute an improvement over such former practice as
may be shown or described in the specifications. Barksdale does not supply detailed or shop
working drawings of its Products.

7\. PATENTS: Barksdale shall indemnify the Purchaser for any liability the Purchaser may incur
because of claims of infringement of United States apparatus patents by the Products
manufactured by Barksdale, as long as Purchaser shall promptly disclose in writing to Barksdale
any notice of such claim or infringement it shall receive from any third party and shall cooperate
thereafter with Barksdale (at no cost to Purchaser) as to any defense that Barksdale shall raise.
The Purchaser shall indemnify Barksdale for any liability Barksdale may incur because of claims
of infringement of United States process patents in the use of the Products furnished hereunder,
or of United States apparatus patents claiming a combination in which Products furnished
hereunder are only a component in the combination.

G0019 REV E 05/01/13 PER DPM 5110

8\. CANCELLATION: Should the order be terminated for any just cause, the Purchaser shall pay
Barksdale for all costs and expenses incurred and commitments made in connection with the
performance of the order, plus a reasonable profit thereon.

9\. EMERGENCIES: For contracts or orders with a price of $200,000 or more and/or for
development contracts of a special nature, where Barksdale performance or completion of such
contracts or orders is delayed or suspended for a protracted period, directly or indirectly, as the
result of war, national emergency, federal or state statute of government rules or regulations,
priority controls, defense efforts, or any like cause (as distinguished from the normal delays in
manufacturing caused by factors beyond the control of the Manufacturer, such as strikes, fires,
traffic embargoes, etc.), either Barksdale or the Purchaser, at any time after the end of 180 days
following the start of such delay or suspension, may terminate the contract or order upon 10 days'
written notice to the other and upon the giving of such notice the Purchaser shall pay Barksdale for
all costs and expenses incurred and commitments made in connection with performance to the
date of such suspension, plus a reasonable profit thereon. Title to all material paid for by Purchaser
shall thereupon vest in the Purchaser, and shall thereafter be held at Purchaser's risk and expense.
In the event that the contract or order has not been so terminated, Barksdale will, promptly after the
cessation of the cause of such delay or suspension, notify the Purchaser of the revised shipping
schedule and proceed with performance in accordance therewith.

10\. LIMITS OF LIABILITY: The remedies, guaranties, and warranties provided herein are in lieu of
any remedies, guaranties, indemnities, conditions or liabilities, either express of implied arising by
law or otherwise. Upon the expiration of the warranty period expressly set forth herein, all liability
for claims not asserted theretofore against Barksdale shall terminate.

The liability of Barksdale in respect of all damages, losses, costs or expenses whether suffered or
incurred by Purchaser or any third party arising in any manner, incident or related to this contract or
the performance hereunder shall be limited in the aggregate to the actual price paid by Purchaser
to Barksdale.

Notwithstanding anything to the contrary, Barksdale shall not be liable to Purchaser or Purchaser's
customers or any third party for special, punitive, incidental or consequential damages of any kind
or character, including without limitation the loss of use of the Product or associated equipment,
damage to associated equipment, loss of profit or revenue, cost of replacement power, downtime
costs or claims of Purchaser's customers or others for any such damages which might arise under
this contract or otherwise, regardless of whether such damages are based upon contract, tort, strict
liability in tort, negligence or indemnity.

11\. LAWS AND REGULATIONS: The Products to be produced by Barksdale and delivered
hereunder will be produced in compliance with the Fair Labor Standards Act of 1938 as amended,
when applicable. Barksdale will comply with federal, state and local laws, orders and regulations
applicable to it as of the date of its quotation. Barksdale shall be responsible for compliance with
the requirements and standards of OSHA, or any similar law, only to the extent that they apply to
the Product itself and are sufficiently specifically identified in the order to Barksdale's satisfaction
and accepted by it in writing. Price and delivery shall be subject to adjustment to compensate for
compliance by Barksdale with any other laws, orders, regulations or requirements.

12\. ATOMIC ENERGY USE: The Purchaser represents that the Products being supplied hereunder
are to be used for a purpose other than in, or in any way related to, the creation, handling, or use of
atomic energy or any activity associated therewith; and Barksdale shall not be responsible to the
Purchaser or any third party should the Products be used otherwise than as represented, in which
event the Purchaser shall indemnify and hold Barksdale free and harmless of any and all costs and
damages. If, upon notice to Barksdale, the Products are to be used for the purpose of, or any way
related to, the creation, handling, or use of atomic energy, or any activity associated therewith,
Purchaser agrees to comply with, and be bound by, all the terms, provisions and conditions of
Barksdale applicable Nuclear Indemnification Clause, a copy of which will be supplied upon
request.

13\. ACCEPTANCE:

(a) These terms and conditions constitute the entire agreement between the parties with regard to
the subject matter hereof, and supersede all oral or written agreements and understandings, and,
to the extent permissible by law, supersede all statutory provisions regarding scope and duration of
Seller's warranties and the availability of remedies with regard to such subject matter. No additions
to or modifications of Seller's terms and conditions shall be binding upon Seller unless agreed to by
Seller in a signed document executed by an authorized representative of Seller.

(b) If a purchase order or other communication from Buyer includes any term or condition contrary
to, or in addition to, the terms and conditions stated herein, Buyer's acceptance of the products and
services which are the subject hereof, after receipt of these terms and conditions from Seller, shall
constitute Buyer's complete and unconditional assent to the terms hereof notwithstanding anything
to the contrary in any such earlier purchase order or communication, unless Buyer clearly instructs
Seller in writing, prior to acceptance, to cancel the order.

(c) Buyer's communication of contrary or additional terms, however phrased, shall be construed as
an offer to supplement and/or amend, and not as a rejection of, Seller's terms and conditions. Such
offer to supplement and amend shall be deemed rejected unless accepted by Seller in the manner
set forth above in the second sentence of paragraph (a).

14\. GENERAL: All of the above provisions, together with those set forth in the Barksdale form to
which this is annexed, and such others as may be accepted by Barksdale in writing, all of which are
accepted by Purchaser and supersede Purchaser's order form, if any, shall be and constitute the
entire agreement for the sale of the Products. Any terms and conditions in any writing pertaining to
the sale of the Products irrespective of its wording or of when received by Barksdale which are
inconsistent with, or add to, the terms and conditions hereof, will not be acceptable or become a
part of the contract without Barksdale's written consent signed by its duly authorized representative.
Commencement of performance or shipping shall not constitute acceptance of any such
inconsistent or added terms and conditions. Any representation, promise, course of dealing, or
trade usage, not contained or referenced herein, will not be binding on Barksdale. Any dispute
arising between the parties as to any aspect of this transaction shall be filed in a court of competent
jurisdiction in Los Angeles, California and shall be governed by California law (except that any
conflict of laws provision therein shall not be applicable). The prevailing party in such litigation shall
be entitled to recover from the other party its costs of litigation, including but not limited to attorneys'
fees, in addition to any other relief it may be entitled to receive. No modification, amendment,
rescission, waiver, or other change as to the terms herein shall be binding on Barksdale unless
agreed to in writing by Barksdale.

15\. ATEX MARKINGS:

See line item description for ATEX coverage


<figure>

<CE> =
CE
<EX> =
Ex

</figure>


ALL ORDERS ARE SUBJECT TO ACCEPTANCE BY BARKSDALE, AT ITS HOME OFFICE
AND NO ORDER SHALL BE BINDING UPON BARKSDALE UNTIL SO ACCEPTED.

<!-- PageFooter="INV_08G" -->
