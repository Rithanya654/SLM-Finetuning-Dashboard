# Invoice 02296-MUDCAT  CONSTRUCTION.docx

# Finance charge (Blue Gradient design)


<table>
<tr>
<td></td>
<td>INVOICE</td>
</tr>
<tr>
<td>Mudcat Construction</td>
<td>INVOICE # RRS 2296 invoice Date: 02/02/2026</td>
</tr>
<tr>
<td>132 Richmond Dr. Phone 6016746707 Mudcatconstruction@gmail.com</td>
<td>DATE OF WORK: 01/29-30/2026</td>
</tr>
</table>


<table>
<tr>
<td>To</td>
<td>ATNN: Mike Harrison Rack Room Shoes/Off Broadway Shoes 8310 Technology Dr. Charlotte, NC 28263 FAX: 7045478153</td>
<td></td>
<td></td>
</tr>
</table>


<table>
<tr>
<td>job</td>
<td>Location</td>
</tr>
<tr>
<td>Store # 654</td>
<td>Easton, PA</td>
</tr>
</table>


<table>
<tr>
<td>DESCRIPTION</td>
<td>TOTAL</td>
</tr>
<tr>
<td>Pull and palletize fixtures for pick up and delivery</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td>Labor</td>
<td>$1200.00</td>
</tr>
<tr>
<td>Material</td>
<td>$.00</td>
</tr>
<tr>
<td>Overhead</td>
<td>$180.00</td>
</tr>
<tr>
<td>Profit</td>
<td>$165.60</td>
</tr>
<tr>
<td>total due</td>
<td>$1545.60</td>
</tr>
</table>


Make all checks payable to Mudcat Construction

Thank you for your business!
