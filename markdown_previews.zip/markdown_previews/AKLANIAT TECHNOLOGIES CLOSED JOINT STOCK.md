# AKLANIAT TECHNOLOGIES CLOSED JOINT STOCK.pdf

<!-- PageNumber="Page 1 of 3" -->


<figure>

عقلانيات للتقنية المحدودة
aklaniat technolgies ltd.

</figure>


<table>
<tr>
<td>Tax Invoice</td>
<td>الفاتورة الضريبية</td>
</tr>
<tr>
<td>INVOICE NO /</td>
<td>رقم الفاتورة</td>
</tr>
</table>


DNTC - 260400011


<table>
<tr>
<th>Issue Date</th>
<th>27/01/2026</th>
<th></th>
<th rowspan="2"></th>
<th colspan="2" rowspan="2"></th>
<th rowspan="2">27/01/2026 27/01/2026</th>
<th>تاريخ الإصدار</th>
</tr>
<tr>
<th>Due Date</th>
<th>27/01/2026</th>
<th></th>
<th>تاريخ الإستحقاق</th>
</tr>
<tr>
<td>Company</td>
<td>AKLANIAT TECHNOLOGY LTD.</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>شركة عقلانيات للتقنية</td>
<td>إسم المورد</td>
</tr>
<tr>
<td>Address</td>
<td>P.O. BOX 10586</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>مركز العليا، الدور الأول ، مقابل العليا</td>
<td>عنوان المورد</td>
</tr>
<tr>
<td></td>
<td>RIYADH 11443</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>العام، حي الورود ، الرياض ، المملكة</td>
<td></td>
</tr>
<tr>
<td></td>
<td>KINGDOM OF SAUDI ARABIA</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>صندوق بريد 10586 الرياض 11443</td>
<td></td>
</tr>
<tr>
<td>Tel</td>
<td>+966115119370</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>+966115119370</td>
<td>هاتف</td>
</tr>
<tr>
<td>Fax</td>
<td>+966112153127</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>+966112153127</td>
<td>فاکس</td>
</tr>
<tr>
<td>TRN No.</td>
<td>300049495300003</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>300049495300003</td>
<td>رقم التعريف الضريبي</td>
</tr>
<tr>
<td>Customer Name</td>
<td>VERTIV INTERNATIONAL</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>VERTIV INTERNATIONAL</td>
<td>إلى</td>
</tr>
<tr>
<td></td>
<td>GMBH</td>
<td>Sales Order</td>
<td></td>
<td colspan="2">رقم أمر البيع</td>
<td>GMBH</td>
<td></td>
</tr>
<tr>
<td>Bill To Address</td>
<td>Victor-von-Bruns Str. 21</td>
<td>Credit Term LPO</td>
<td rowspan="2">ADVANCE PAYMENT 14077000237</td>
<td colspan="2" rowspan="2">شروط الدفع رقم طلب الشراء رقم فاتورة</td>
<td rowspan="2">Victor-von-Bruns Str. 21 8212 Neuhausen am Rheinfall</td>
<td rowspan="2">فاتورة الى</td>
</tr>
<tr>
<td></td>
<td>8212 Neuhausen am Rheinfall</td>
<td>Cloud Inovice No</td>
</tr>
<tr>
<td></td>
<td>SWITZERLAND</td>
<td>Salesman</td>
<td>Saurav Mandal</td>
<td colspan="2">بائع</td>
<td></td>
<td></td>
</tr>
<tr>
<th></th>
<th>SWITZERLAND</th>
<th></th>
<th></th>
<th colspan="2"></th>
<th>0</th>
<th>هاتف</th>
</tr>
<tr>
<th></th>
<th></th>
<th>Delivery Term</th>
<th>27/01/2026</th>
<th colspan="2">شروط التوريد</th>
<th></th>
<th></th>
</tr>
<tr>
<td>Tel</td>
<td>0</td>
<td>Ship Date</td>
<td></td>
<td colspan="2">تاريخ الشحن</td>
<td>0</td>
<td>فاکس</td>
</tr>
<tr>
<td>Fax</td>
<td>0</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>CHE-293.902.351</td>
<td>رقم التعريف الضريبي</td>
</tr>
<tr>
<td>TRN</td>
<td>CHE-293.902.351</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>VERTIV INTERNATIONAL</td>
<td>شحن إلى</td>
</tr>
<tr>
<td>Ship To Address</td>
<td>VERTIV INTERNATIONAL</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>GMBH</td>
<td></td>
</tr>
<tr>
<td></td>
<td>Victor-von-Bruns Str. 21</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Victor-von-Bruns Str. 21</td>
<td></td>
</tr>
<tr>
<td></td>
<td>8212 Neuhausen am Rheinfall SWITZERLANDSWITZERLAN</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>8212 Neuhausen am Rheinfall</td>
<td></td>
</tr>
<tr>
<td></td>
<td>D</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Tel</td>
<td>0</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>0</td>
<td>هاتف</td>
</tr>
<tr>
<td>Fax</td>
<td>0 CHE-293.902.351</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>0 293.902.351-CHE</td>
<td>فاکس رقم التعريف الضريبي</td>
</tr>
</table>


TRN


<table>
<tr>
<th>رقم</th>
<th>تفاصيل المنتج/الخدمة رقم المنتج</th>
<th>الكمية</th>
<th>سعر الوحدة</th>
<th>السعر قبل</th>
<th>نسبة</th>
<th>مبلغ الضريبة</th>
<th>القيمة الاجمالية</th>
<th>القيمة الاجمالية</th>
</tr>
<tr>
<td>No</td>
<td>Item Code Item Description</td>
<td>Qty</td>
<td>Unit Price</td>
<td>Price Excl. VAT</td>
<td>الضريبة% VAT %</td>
<td>SAR VAT</td>
<td>Total SAR</td>
<td>Total USD</td>
</tr>
</table>


<!-- PageBreak -->

<!-- PageNumber="Page 2 of 3" -->


<table>
<tr>
<td>Tax Invoice</td>
<td>الفاتورة الضريبية</td>
</tr>
<tr>
<td>INVOICE NO /</td>
<td>رقم الفاتورة</td>
</tr>
</table>


DNTC - 260400011


<figure>

عقلانيات للتقنية المحدودة
aklaniat technolgies ltd.

</figure>


<table>
<tr>
<th>رقم</th>
<th>تفاصيل المنتج/الخدمة رقم المنتج</th>
<th>الكمية</th>
<th>سعر الوحدة</th>
<th>السعر قبل</th>
<th>نسبة</th>
<th>مبلغ الضريبة</th>
<th>القيمة الاجمالية</th>
<th>القيمة الاجمالية</th>
</tr>
<tr>
<td>S No</td>
<td>Item Code Item Description</td>
<td>Qty</td>
<td>Unit Price</td>
<td>Price Excl.VAT</td>
<td>الضريبة%</td>
<td>SAR VAT</td>
<td>Total SAR</td>
<td>Total USD</td>
</tr>
</table>


VAT %


<table>
<tr>
<th colspan="2">1 NS Non Stock (Software type)</th>
<th>1 33,750.00</th>
<th>33,750.00</th>
<th>15 5,062.50</th>
<th>38,812.50</th>
<th>10,350.00</th>
</tr>
<tr>
<td>Payment term</td>
<td>شروط الدفع</td>
<td></td>
<td></td>
<td>Total Excl VAT</td>
<td>الإجمالي قبل الضريبة</td>
<td>33,750.00</td>
</tr>
<tr>
<td>Cash</td>
<td>نقداً</td>
<td></td>
<td></td>
<td>Total Excl VAT USD</td>
<td>الإجمالي قبل الضريبة</td>
<td>9,000.00</td>
</tr>
<tr>
<td rowspan="2">Credit</td>
<td rowspan="4">شيك رقم على الحساب</td>
<td></td>
<td></td>
<td>Freight Charges ®</td>
<td>قيمة المصاريف</td>
<td>0.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Freight Charges USD</td>
<td>قيمة المصاريف</td>
<td>0.00</td>
</tr>
<tr>
<td>Check</td>
<td></td>
<td></td>
<td>VAT Value</td>
<td>قيمة الضريبة</td>
<td>5,062.50</td>
</tr>
<tr>
<td>Credit Details</td>
<td></td>
<td></td>
<td>VAT Value USD</td>
<td>قيمة الضريبة</td>
<td>1,350.00</td>
</tr>
<tr>
<td rowspan="4"></td>
<td rowspan="4"></td>
<td></td>
<td></td>
<td>Total Including VAT</td>
<td>الإجمالي شامل</td>
<td>38,812.50</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total Including VAT USD</td>
<td>الإجمالي شامل</td>
<td>10,350.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Due Balance</td>
<td>الرصيد المستحق</td>
<td>38,812.50</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Due Balance USD</td>
<td>الرصيد المستحق</td>
<td>10,350.00</td>
</tr>
</table>


الإجمالي كتابة

Amount In Words :

SAR Thirty Eight Thousand Eight Hundred Twelve And Halala Fifty Only

Amount In Words :

USD Ten Thousand Three Hundred Fifty Only

Bank Details
رقم الحساب/IBAN

الحساب المصرفي

العملة

اسم البنك

Swift

Acnt/IBAN

Curr

Bank Name

Swift


<table>
<tr>
<td>SA4345000000004441044080</td>
<td>USD</td>
<td>SAUDI BRITISH BANK</td>
<td>SABBSARI</td>
</tr>
<tr>
<td>SA4245000000004441044001</td>
<td>SAR</td>
<td>SAUDI BRITISH BANK</td>
<td>SABBSARI</td>
</tr>
<tr>
<td>SA7885476230062800115682</td>
<td>SAR</td>
<td>BNP Paribas</td>
<td>BNPASARI</td>
</tr>
</table>


I have inspected the items, verified the quantity and received the goods in good condition


<table>
<tr>
<td>Receiver's Name</td>
<td>:</td>
</tr>
<tr>
<td>Mobile/Tel</td>
<td>:</td>
</tr>
<tr>
<td>Date &amp; Time</td>
<td>:</td>
</tr>
</table>


<table>
<tr>
<td></td>
<td>Company Stamp</td>
<td>:</td>
</tr>
<tr>
<td></td>
<td>Signature</td>
<td>:</td>
</tr>
</table>


<!-- PageBreak -->

Vehicle#
:

No.Pkgs

<!-- PageNumber=":" -->


# AKLANIAT STANDARD TERMS AND CONDITIONS OF SALE

Aklaniat has selling right for certain hardware, software, service and related products (collectively "Products"), manufactured or sold by different suppliers ("Supplier") which are sold under marks, names and symbol having a valuable reputation and good will belonging and/ or licensed to Supplier. Aklaniat agrees to supply and Buyer agrees to purchase the Products described in Aklaniat's current
comprehensive catalogue or price list, subject to these terms and conditions, which shall supersede any terms and conditions on any purchase order form submitted to Aklaniat by Buyer.

1\. SHIPMENT AND DELIVERY. Delivery will be made ex-works Aklaniat warehouse, freight paid in accordance with its standard freight policy in effect at the time of shipment. Aklaniat will comply with all reasonable shipping and handling instructions received prior to shipment. Buyer shall bear the cost of normal, special or express shipping services which it may request. Aklaniat may charge and Buyer shall pay,
a special handling fee for any shipping less than $1000 in value. Buyer shall examine the products promptly up on receipt thereof. No later than (5) days after receipt. Buyer shall notify Aklaniat of all claiming shortage or damaged Products, or if rejection is intended, shall specify all grounds there for. Failure to give such notice shall be deemed an acceptance of the products as of the date of shipment.All risks of

2\. PRICES. All prices given by Aklaniat are on ex-works basis exclusive of all transportation, insurance, any applicable federal, state, municipal and other government taxes (such as sales, customs, legalization etc.) Unless otherwisespecified, prices do not include such expenses, and they will be added or invoiced separately. Exemption certificates, valid in the place of delivery, shall be presented to Aklaniat
prior to shipment if they are not to be honoured. Purchase price shall be determined solely by Aklaniat and may be changed from time to time, without any notice, liability or obligation to Buyer.All present or future fees, taxes, levies, imposts, duties, deductions, excises, value added tax, any income tax withheld at source, assessments charges or withholdings of any nature, together with any penalties, fines,
additions to tax or interest thereon howsoever levied or imposed by Local Government or any other Government elsewhere (including any country, state, city, county, province, department, or other subdivision of government) ("Taxes") in connection with the execution of this Contract shall be borne by the Client. All Prices mentioned in this Contract are fixed and exclusive of Taxes. The Client shall be solely liable
to pay all Taxes for or in connection with the execution of this [Contract] and the performance of its other obligations under this Contract.

3\. CREDIT AND PAYMENT TERMS. Buyer shall furnish to Aklaniat all financial reasonable requested by Aklaniat from time to time for the purpose of establishing and continuing Buyer's Credit Limit. It's being understood that Aklaniat shall have the right to decline to extend credit to buyer and to request that the applicable purchase prices be paid prior to shipment. Aklaniat shall have the right from time to time
without notice, to change or revoke Buyer's Credit Limit on the basis of changes in Aklaniat's credit policy or Buyers financial condition and /or paymentrecord.Payment terms for each shipment of Products shall be as stated on Aklaniat's invoice. A service charge of two percent (2%) per month will be charge on all past due balances to defray Aklaniat's cost carrying such balance. In the event Buyer fails to make
timely payment of any amount invoiced hereunder, Aklaniat shall have the right, in addition to any and all other rights and remedies available to Aklaniat, at law or in equity, immediately to revoke any or all credit extended, to delay or cancel future deliveries and/or to reduce or cancel any or all quantity discounts extended to Buyer, all cost of collection including reasonable attorney's fees, shall be paid by
Buyer.AKLANIAT SHALL RETAIN TITLE TO ALL PRODUCTS DELIVERD UNTIL IT HAS RECEIVED PAYMENT IN FULL OF ALL SUM DUE IN CONNECTION WITH THE SUPPLY OF ALL PRODUCTS DLIVERED AND SERVICES RENDERED TO BUYER AT ANY TIME.Any obligation of Aklaniat under this agreement to deliver Products on credit terms shall terminate without notice if Buyer ?les a voluntary
petition under a bankruptcy statute, or make an assignment for the benefit of creditors, or if an involuntary petition under a bankruptcy statute is ?led against Buyer, or of a receiver or trustee is appointed to take possession of the asset of the buyer

4\. WARRANTY. Neither Aklaniat nor supplier make any representations, warranties, guarantees or conditions, express implied, regarding the products(a) to end-users, other than as expressly set out in its warranty form, or (b) whatsoever to Buyer or any other party.IN PARTICULAR (BUT WITHOUT LIMITING THE GENERAL IT OF THE RECORDING) ALL REPRESENTATIONS, WARRANTIES,
GUARANTEES AND CONDITIONS, WHETHER EXPRESSED ORIMPLIED, AS TO MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE ARE EXPRESSLY EXCLUDED, BUYER SHALL NOT MAKE ANY ADDITIONAL REPRESENTATIONS WARRANTIES OR CONDITIONS IN THE AKLANIAT'S AND/OR SUPPLIER'S NAME, AND SHALL MAKE NO REPRESENTATIONS,
WARRANTIES OR CONDITIONS IN ITS ON NAME WHICH ARE INCONSISTENT WITH THE NATURE OR FUNCTIONALITY OF THE PRODUCTS OR THEIR PROPER USE.

5\. DEFECTIVE RETURNS. Products are accompanied by Supplier's written warranty. Suppliers reserves the right to change the warranty and service procedures set forth in such warranty or otherwise for Products not yet sold by Buyer at any time without liability to Buyer or to any other person by reason of any such change. Further Supplier's warranty to end-users does not apply to exported Products (unless
the product's warranty or license terms state otherwise).Buyers shall advise Aklaniat of any defect in Products delivered hereunder within 14 days of the invoice date and, without deduction or offset, up on obtaining prior authorization of Aklaniat, Buyer may return Products found to be defective for replacement. Aklaniat reserves the right to require Buyer to return defective Products directly to the Products
manufacturer for replacement according to the manufacturer's defective Products return policy. Buyer must pay return freight to Manufacturer and back to them on DOA and defective products. Aklaniat will accept return freight charges for Aklaniat sales and shipping errors by crediting Buyers account against Buyer's paid return freight invoices. All returns must receive an RMA (Return Merchandise
Authorization) number and be returned in the manufacture' original packaging, re-salable condition, complete and unused. Defective and DOA returns are tested and Products found not to be defective will be returned to Buyer and charged freight for both inbound and outbound transit. Credit memos are issued for use against future order only when return policies are met. Aklaniat shall not be responsible for the
cost of labor or other expenses incurred in repairing or replacing defective Products. Buyer shall bear the expense of shipping the defective Products to the Manufactures warehouse and the expense of shipping back to Buyer the repaired or replaced products

6\. MARKS, NAMES, CONFIDENTIALITY. Without Aklaniat's and/or Supplier's written agreement, buyer shall not in any event display or use any of the Aklaniat's and/or Supplier's trademarks, service marks, name or symbols whether or not registered, as part of the corporate, business or trading marks, name or symbols of Buyer. Buyer acknowledge the great value and goodwill associated with the Aklaniat's
and/or Supplier's Marks. Buyer shall not have any ownership or title interest in any mark, name symbol, patent right, model right, copyright or other intellectual or industrial property right belonging or licensed to Aklaniat's and/or Suppliers. Buyer will not remove, cancel or change any mark, name, symbol, serial number or any other designation or information marked up on the Supplier PRODUCTS or their
packaging. Buyer will not attach any additional marks, names, symbols, serial numbers or any other or information to any Supplier's Product or its packaging.

7\. TRADEMARK GUIDELINES. All users of the trade marks by Buyers shall fully comply with item and conditions of trademark usage included in Aklaniat's and/or Supplier's logo and trademark guidelines as in effect from time to time. Buyer shall use the appropriate trade symbol (either "IM" or "@" superscript) following the products name whenever a product name is mentioned in any advertisement,
brochure or other material calculated by Buyer, the appropriate trademark symbol must be used at least one for each Product in each publication in conjunction with the first reference to such Product. Buyer Acknowledges that such logos, trademarks and trade names are the exclusive property of Aklaniat and/or Suppliers and that Buyer is not entitled either by implication or otherwise to any title in the
Logos, trademarks and trade names.

8\. SOFTWARE PROPRIETARY RIGHTS. Products often consist of or certain software, including but not limited to operating systems, applications and related documentation and materials. The software may be included in ROM or other semiconductor chips embedded in hardware, or it may be contained separately on disk or other media. All software is proprietary to the Suppliers and is copyrighted with all
rights reserved. Buyer shall ensure that the appropriate Supplier license accompanies each Product distributed by Buyer. Buyer shall not manufacture, market, sell, deal in or otherwise be concerned with directly or indirectly, any product or item (under any market, name or symbol) which(i) is likely to be confused or used in unfair competition with any of the products or passed-off therefore, (ii) infringes, in
8\. SOFTWARE PROPRIETARY RIGHTS. Products often consist of or certain software, including but not limited to operating systems, applications and related documentation and materials. The software may be included in ROM or other semiconductor chips embedded in hardware, or it may be contained separately on disk or other media. All software is proprietary to the Suppliers and is copyrighted with all
rights reserved. Buyer shall ensure that the appropriate Supplier license accompanies each Product distributed by Buyer. Buyer shall not manufacture, market, sell, deal in or otherwise be concerned with directly or indirectly, any product or item (under any market, name or symbol) which(i) is likely to be confused or used in unfair competition with any of the products or passed-off therefore, (ii) infringes, in whole
or part, any Supplier's mark, copyright, patent, secret or other intellectual, industrial or other right of Supplier or, (iii) uses or is designed for use of materials which infringe, or which encourage or contribute to any infringement of, any such Supplier rights. Buyer shall not change copy or otherwise produce any software, including programs and manuals, acquired from Aklaniat by license or otherwise.

9\. LIMITATION OF LIABILITY. AKLANIAT SHALL NOT BUYER OR ANY OTHER PARTY FOR ANY LOSS, DAMAGE, OR INJURY WHICH RESULTS FROM THE USE OR APPLICATION BY BUYER OR ANY OTHER PARTY OF PRODUCTS AND/OR SERVICES DELIVERED TO BUYER, IN NO EVENT SHALL AKLANIAT BE LIABLE TO BUYER OR ANY OTHER PARTY FOR LOSS, DAMAGE
OR INJURY OF ANY KIND OR NATURE ARISING OUT OF OR IN CONNECTION WITH THESE TERMS AND CONDITIONS, OR ANY AGREEMENT IN TO WHICH THEY ARE INCORPORATED, OR ANY PERFORMANCE OR NONPERFORMANCE UNDER THESE TERMS AND CONDITIONS BY AKLANIAT, ITS EMPLOYEES, AGENTS OR SUBCONTRACTORS IN EXCESS OF THE NET
PURCHASE PRICE OF PRODUCTS AND/OR SERVICES ACTUALLY DELIVERED TO AND PAID BY BUYER HEREUNDER.IN NO EVENT, (INCLUDING EVENTS OF LOSS, DAMAGE, OR INJURY PROVIDED FOR INT THE PRECEDING PARAGRAPH) SHALL AKLANIAT BE LIABLE TO BUYER OR ANY OTHER PARTY FOR INDIRECT, SPECIAL OR CONJSEQUENTIAL DAMAGES, INCLUDING
BUT NOT LIMITED TO LOSS OF GOODWILL, LOSS OF ANTICIPATED PROFITS, OR OTHER ECONOMIC LOSS ARISING OUT OF OR IN CONNECTION WITH AKLANIAT'S BREACH OF, OR FAILURE TO PERFORM IN ACCORDANCE WITH, ANY OF THESE TERMS AND CONDITIONS OR THE FURNISHING, INSALLATION, SERVICING, USE OR PERFORMANCE OF ANY PRODUCTS OR
OTHER MATERIALS OR SERVOCES AKLANIAT SHALL PROVIDE HEREUNDER. EVEN IF NOTIFICATION HAS BEEN GIVEN AS TO THE POSSIBILITY OF SUCH DAMAGES, BUYER HEREBY EXPRESSLY WAIVES ANY ALL CLAIMS FOR SUCH DAMAGES.
10\. RESALE ONLY. All Products delivered to Buyer hereunder are for resale only and shall not be used for the internal business purpose of Buyer, or any Patent company, subsidiary, or affiliate of Buyer.

11\. This transaction may include commodities, software, or technology (Product) subject to the export laws and regulations of the United States, the European Union, or another country. The buyer agrees that it will not distribute or reexport products in violation of any of the export control laws or regulations of the United States the European Union, or another country. The buyer warrants that neither the technical
data nor the Product received from Aklaniat is intended to be shipped, either directly or indirectly, to a country prohibited by the export control laws and regulations that govern that Product, without prior approval from Aklaniat and either a validated export license or written permission from the appropriate export administration. The buyer shall be responsible to comply with all applicable export and import laws and
regulations, including those of the United States, the European Union, or other applicable country, when marketing, exporting, or importing products and technical data. The buyer warrants that it is knowledgeable with, and undertakes to comply with, applicable export and import laws, regulations, orders, and policies of the United States, the European Union, or other applicable country. Buyer further agrees to
indemnify Aklaniat and Aklaniat supplier from claims made against Aklaniat or Aklaniat supplier for the buyer's failure to comply with applicable export and import laws.

12\. GOVERNMENT APPROVAL. If the approval of any Government or governing organization with respect of this Agreement, it's registration or the distribution of the products, is required during the term of this agreement, including without limitation with respect to giving legal effect to this agreement protecting intellectual property and other rights in the Products or compliances with exchange regulations,
Buyer will at its expense, immediately take whatever steps may be necessary to secure such approvals. If any such approval or registration require or results in the deletion or amendment of any provision of this Agreement, then Aklaniat will have the right to immediately terminate this Agreement written notice to Buyer.

13\. RELATIONSHIP OF THE PARTIES. Buyer's Relationship with Aklaniat during the terms of this agreement will be that of an independent contractor. Buyer will not have and will not represent that it has any power, right or authority to bind Aklaniat, or to assume or create any obligation or responsibility, express, implied or by appearance, on behalf of Aklaniat or in Aklaniat's name except as herein expressly
provided. Nothing stated in this Agreement will be construed as consulting Buyer and Aklaniat as partners or as relationship of employer/employee, franchiser/franchisee, or principal/agent between the parties, Buyer will make no warranty, guarantee or representation, whether written or oral on Aklaniat's behalf.
14 - GOVERNING LAW. The terms and conditions of sale (and any agreement combined) shall be interpreted in accordance with and governed by the law of the country where the invoicing party is incorporated or registered and the Buyer hereby consent to the jurisdiction of the country where the invoicing party is incorporated or registered.

15\. NOTICES. All Notices, requests, demands and other communication called for or contemplated hereunder shall be in writing and shall be deemed to have been duly given when delivered or two (2) days afterMailing by certified or registered first-class mail, prepaid and addressed to the parties at their principal place of business or at such other address as the parties may designate by written notice.
16\. ASSIGNMENT. Buyer shall not assign any order or any interest herein without the written consent of Aklaniat. Any such actual or attempted assignment without Aklaniat's prior written consent shall entitle Aklaniat to cancel such order up on written notice to Buyer.

17\. SEVERABILITY. A judicial determination that any provision hereunder is invalid in whole or in part shall not affect the enforceability of those provisions found not to be valid

18\. CAPTIONS. The captions used herein are for reference purposes only and shall have no effect up on the construction or interpretation of any provision herein.

These terms and conditions constitute the entire agreement between the parties with respect to the subject matter hereof. These terms and conditions will prevail notwithstanding any different, conflicting or additional Terms and condition which may appear on any order submitted by Buyer. Deviation from these terms and conditions are not valid unless agreed to in writing by an authorised representative of
Aklaniat
