# VESTIS.pdf

<figure>

vestis
2680 Palumbo Drive
Lexington, KY 40509

</figure>


Pay your bill and view invoices and statements at
http://myaccount.vestis.com

JOE FONTANINI
FONTANINI
8751 W 50TH
PO#4131043
CHICAGO IL 60624


# INVOICE


<table>
<tr>
<td>BILLING INQUIRIES</td>
<td>(866) 837-8471</td>
</tr>
<tr>
<td>CUSTOMER SERVICE</td>
<td>(866) 837-8471</td>
</tr>
<tr>
<td>ACCOUNT NUMBER</td>
<td>9010001807</td>
</tr>
<tr>
<td>CUSTOMER NUMBER</td>
<td>7144477</td>
</tr>
<tr>
<td>INVOICE NUMBER</td>
<td>6040439529</td>
</tr>
<tr>
<td>INVOICE DATE</td>
<td>01/30/2026</td>
</tr>
<tr>
<td>TERMS</td>
<td>NET 30 EOM</td>
</tr>
<tr>
<td>PO #</td>
<td>4839189</td>
</tr>
<tr>
<td>NAID</td>
<td>N92810</td>
</tr>
<tr>
<td>MARKET CENTER</td>
<td>604</td>
</tr>
<tr>
<td>ROUTE NUMBER</td>
<td>428</td>
</tr>
<tr>
<td colspan="2">Page 1 of 3</td>
</tr>
</table>


Ship

To:

FONTANINI

8751 W 50TH

PO#4131043

CHICAGO IL 60624


<table>
<tr>
<th colspan="7">A/R BALANCES AS OF 01/30/2026</th>
</tr>
<tr>
<th>TOTAL DUE</th>
<th>CURRENT</th>
<th>1-30 DAYS</th>
<th>31-60 DAYS</th>
<th>61-90 DAYS</th>
<th>91-120 DAYS</th>
<th>OVER 120 DAYS</th>
</tr>
<tr>
<td>2921.38</td>
<td>2146.43</td>
<td>0.00</td>
<td>0.00</td>
<td>0.00</td>
<td>0.00</td>
<td>774.95</td>
</tr>
</table>


<table>
<tr>
<th>WEARER#</th>
<th>WEARER NAME</th>
<th>ITEM</th>
<th>ITEM DESCRIPTION</th>
<th>SIZE</th>
<th>TYPE</th>
<th>DLVR QTY</th>
<th>BILL QTY</th>
<th>RATE</th>
<th>TOTAL</th>
</tr>
<tr>
<td>11</td>
<td>Roy Carrillo</td>
<td>GP0292NAVY</td>
<td>PANT FR 9OZ 88/12</td>
<td>36X30</td>
<td>Rent</td>
<td>0</td>
<td>7</td>
<td>0.490</td>
<td>3.43</td>
</tr>
<tr>
<td>11</td>
<td>Roy Carrillo</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>MEDR</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>15</td>
<td>Salvador Sepulveda</td>
<td>GO0650NAVY</td>
<td>JACKET WORK FR COTTON</td>
<td>LGER</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.599</td>
<td>1.60</td>
</tr>
<tr>
<td>15</td>
<td>Salvador Sepulveda</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>34X34</td>
<td>Rent</td>
<td>1</td>
<td>7</td>
<td>1.077</td>
<td>7.54</td>
</tr>
<tr>
<td>15</td>
<td>Salvador Sepulveda</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>LGER</td>
<td>Rent</td>
<td>2</td>
<td>7</td>
<td>0.434</td>
<td>3.04</td>
</tr>
<tr>
<td>17</td>
<td>Pedro Murillo</td>
<td>GO0650NAVY</td>
<td>JACKET WORK FR COTTON</td>
<td>LGER</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.599</td>
<td>1.60</td>
</tr>
<tr>
<td>17</td>
<td>Pedro Murillo</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>38X30</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>1.077</td>
<td>6.46</td>
</tr>
<tr>
<td>17</td>
<td>Pedro Murillo</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>17</td>
<td>Pedro Murillo</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>LGER</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>19</td>
<td>Patrick Layton</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>38X32</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>1.077</td>
<td>6.46</td>
</tr>
<tr>
<td>19</td>
<td>Patrick Layton</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>3XLR</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>20</td>
<td>David Ojeda</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>3XLR</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.751</td>
<td>1.75</td>
</tr>
<tr>
<td>20</td>
<td>David Ojeda</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>48X30</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>1.077</td>
<td>6.46</td>
</tr>
<tr>
<td>20</td>
<td>David Ojeda</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>3XLR</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
</table>


See remaining pages of this invoice for a list of all included charges

An increase has been applied to your charges.For further details, ask your Route Sales Representative.Based on your usage, some inventory levels were decreased. See
Bill Qty column for updated charges.


<table>
<tr>
<td>SUBTOTAL (ALL PAGES)</td>
<td>429.71</td>
</tr>
<tr>
<td>FREIGHT</td>
<td>0.00</td>
</tr>
<tr>
<td>TAX</td>
<td>7.88</td>
</tr>
<tr>
<td>TOTAL</td>
<td>$437.59</td>
</tr>
</table>


THANK YOU FOR YOUR BUSINESS

Delivery received by:

wP

MR

Signature from handheld acknowledging delivery

To ensure proper payment application, please write your invoice number
on your check, and include the attached coupon with your payment


<figure>

vestis

</figure>


<table>
<tr>
<td>INVOICE DATE</td>
<td>01/30/2026</td>
</tr>
<tr>
<td>ACCOUNT NUMBER</td>
<td>9010001807</td>
</tr>
</table>


Bill To:

FONTANINI

8751 W 50TH

CHICAGO IL 60624


<table>
<tr>
<td>PAYMENT DUE</td>
<td>February 28, 2026</td>
</tr>
<tr>
<td>TOTAL DUE</td>
<td>$437.59</td>
</tr>
<tr>
<td>INVOICE NUMBER</td>
<td>6040439529</td>
</tr>
</table>


Payable

To:

VESTIS

25259 NETWORK PLACE

CHICAGO IL 60673-1252

1 000001139230 0006040439529 0 0000043759 0000043759 4

<!-- PageBreak -->


<figure>

vestis

</figure>


JOE FONTANINI
FONTANINI
8751 W 50TH
CHICAGO IL 60624


## INVOICE


<table>
<tr>
<td>BILLING INQUIRIES</td>
<td>(866) 837-8471</td>
</tr>
<tr>
<td>CUSTOMER SERVICE</td>
<td>(866) 837-8471</td>
</tr>
<tr>
<td>ACCOUNT NUMBER</td>
<td>9010001807</td>
</tr>
<tr>
<td>CUSTOMER NUMBER</td>
<td>7144477</td>
</tr>
<tr>
<td>INVOICE NUMBER</td>
<td>6040439529</td>
</tr>
<tr>
<td>INVOICE DATE</td>
<td>01/30/2026</td>
</tr>
</table>


<!-- PageNumber="Page 2 of 3" -->


<table>
<tr>
<th>WEARER#</th>
<th>WEARER NAME</th>
<th>ITEM</th>
<th>ITEM DESCRIPTION</th>
<th>SIZE</th>
<th>TYPE</th>
<th>DLVR QTY</th>
<th>BILL QTY</th>
<th>RATE</th>
<th>TOTAL</th>
</tr>
<tr>
<td>21</td>
<td>Fernando Valero</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>LGER</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.751</td>
<td>1.75</td>
</tr>
<tr>
<td>21</td>
<td>Fernando Valero</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>32X32</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>1.077</td>
<td>6.46</td>
</tr>
<tr>
<td>21</td>
<td>Fernando Valero</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>LGER</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>22</td>
<td>Kevin Rodriguez</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>3</td>
<td>1.751</td>
<td>5.25</td>
</tr>
<tr>
<td>22</td>
<td>Kevin Rodriguez</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>LGER</td>
<td>Rent</td>
<td>0</td>
<td>0</td>
<td>0.000</td>
<td>0.00</td>
</tr>
<tr>
<td>22</td>
<td>Kevin Rodriguez</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>LGER</td>
<td>Loss Charge</td>
<td>0</td>
<td>0</td>
<td>0.000</td>
<td>0.00</td>
</tr>
<tr>
<td>22</td>
<td>Kevin Rodriguez</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>36X32</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>1.077</td>
<td>6.46</td>
</tr>
<tr>
<td>22</td>
<td>Kevin Rodriguez</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>34X32</td>
<td>Ruin charge</td>
<td>1</td>
<td>0</td>
<td>0.000</td>
<td>0.00</td>
</tr>
<tr>
<td>22</td>
<td>Kevin Rodriguez</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>22</td>
<td>Kevin Rodriguez</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>LGER</td>
<td>Ruin charge</td>
<td>2</td>
<td>0</td>
<td>0.000</td>
<td>0.00</td>
</tr>
<tr>
<td>23</td>
<td>Libardo Coronado</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>2XLR</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.751</td>
<td>1.75</td>
</tr>
<tr>
<td>23</td>
<td>Libardo Coronado</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>42X32</td>
<td>Rent</td>
<td>1</td>
<td>7</td>
<td>1.077</td>
<td>7.54</td>
</tr>
<tr>
<td>23</td>
<td>Libardo Coronado</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>2XLR</td>
<td>Rent</td>
<td>1</td>
<td>7</td>
<td>0.434</td>
<td>3.04</td>
</tr>
<tr>
<td>24</td>
<td>Wilkin Nuñez</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.751</td>
<td>1.75</td>
</tr>
<tr>
<td>24</td>
<td>Wilkin Nuñez</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>2XLR</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.751</td>
<td>1.75</td>
</tr>
<tr>
<td>24</td>
<td>Wilkin Nuñez</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>4XLR</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.751</td>
<td>1.75</td>
</tr>
<tr>
<td>24</td>
<td>Wilkin Nuñez</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>44X28</td>
<td>Rent</td>
<td>1</td>
<td>6</td>
<td>1.077</td>
<td>6.46</td>
</tr>
<tr>
<td>24</td>
<td>Wilkin Nuñez</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>3XLR</td>
<td>Rent</td>
<td>1</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>27</td>
<td>Gerardo Gonzalez</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>3XLR</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.751</td>
<td>1.75</td>
</tr>
<tr>
<td>27</td>
<td>Gerardo Gonzalez</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>40X32</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>1.077</td>
<td>6.46</td>
</tr>
<tr>
<td>27</td>
<td>Gerardo Gonzalez</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>3XLR</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>27</td>
<td>Gerardo Gonzalez</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>2XLR</td>
<td>Rent</td>
<td>0</td>
<td>0</td>
<td>0.000</td>
<td>0.00</td>
</tr>
<tr>
<td>28</td>
<td>Jose Hernandez</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>LGER</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.751</td>
<td>1.75</td>
</tr>
<tr>
<td>28</td>
<td>Jose Hernandez</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>34X34</td>
<td>Rent</td>
<td>0</td>
<td>7</td>
<td>1.077</td>
<td>7.54</td>
</tr>
<tr>
<td>28</td>
<td>Jose Hernandez</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>LGER</td>
<td>Rent</td>
<td>0</td>
<td>7</td>
<td>0.434</td>
<td>3.04</td>
</tr>
<tr>
<td>29</td>
<td>Hany Abdin</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>LGER</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.751</td>
<td>1.75</td>
</tr>
<tr>
<td>29</td>
<td>Hany Abdin</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>34X34</td>
<td>Rent</td>
<td>0</td>
<td>7</td>
<td>1.077</td>
<td>7.54</td>
</tr>
<tr>
<td>29</td>
<td>Hany Abdin</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>LGER</td>
<td>Rent</td>
<td>0</td>
<td>7</td>
<td>0.434</td>
<td>3.04</td>
</tr>
<tr>
<td>30</td>
<td>Angel Rodriguez</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.751</td>
<td>1.75</td>
</tr>
<tr>
<td>30</td>
<td>Angel Rodriguez</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>36X30</td>
<td>Rent</td>
<td>1</td>
<td>7</td>
<td>1.077</td>
<td>7.54</td>
</tr>
<tr>
<td>30</td>
<td>Angel Rodriguez</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>1XLR</td>
<td>Rent</td>
<td>2</td>
<td>7</td>
<td>0.434</td>
<td>3.04</td>
</tr>
<tr>
<td>31</td>
<td>Dion Anderson</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.751</td>
<td>1.75</td>
</tr>
<tr>
<td>31</td>
<td>Dion Anderson</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>34X32</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>1.077</td>
<td>6.46</td>
</tr>
<tr>
<td>31</td>
<td>Dion Anderson</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>32</td>
<td>Antown Jones</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.751</td>
<td>1.75</td>
</tr>
<tr>
<td>32</td>
<td>Antown Jones</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>38X36</td>
<td>Rent</td>
<td>1</td>
<td>6</td>
<td>1.077</td>
<td>6.46</td>
</tr>
<tr>
<td>32</td>
<td>Antown Jones</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>1XLR</td>
<td>Rent</td>
<td>1</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>33</td>
<td>Jose Aveja</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.751</td>
<td>1.75</td>
</tr>
<tr>
<td>33</td>
<td>Jose Aveja</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>38X30</td>
<td>Rent</td>
<td>0</td>
<td>7</td>
<td>1.077</td>
<td>7.54</td>
</tr>
<tr>
<td>33</td>
<td>Jose Aveja</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>LGER</td>
<td>Rent</td>
<td>1</td>
<td>7</td>
<td>0.434</td>
<td>3.04</td>
</tr>
<tr>
<td>35</td>
<td>Martin Rangel</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>2XLR</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.751</td>
<td>1.75</td>
</tr>
<tr>
<td>35</td>
<td>Martin Rangel</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>2XLR</td>
<td>Loss Charge</td>
<td>0</td>
<td>0</td>
<td>0.000</td>
<td>0.00</td>
</tr>
<tr>
<td>35</td>
<td>Martin Rangel</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>38X32</td>
<td>Rent</td>
<td>0</td>
<td>7</td>
<td>1.077</td>
<td>7.54</td>
</tr>
<tr>
<td>35</td>
<td>Martin Rangel</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>38X32</td>
<td>Loss Charge</td>
<td>0</td>
<td>0</td>
<td>0.000</td>
<td>0.00</td>
</tr>
<tr>
<td>35</td>
<td>Martin Rangel</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>7</td>
<td>0.434</td>
<td>3.04</td>
</tr>
<tr>
<td>35</td>
<td>Martin Rangel</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>1XLR</td>
<td>Loss Charge</td>
<td>0</td>
<td>0</td>
<td>0.000</td>
<td>0.00</td>
</tr>
<tr>
<td>36</td>
<td>Adan Navarro</td>
<td>GO0650NAVY</td>
<td>JACKET WORK FR COTTON</td>
<td>2XLR</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.599</td>
<td>1.60</td>
</tr>
<tr>
<td>36</td>
<td>Adan Navarro</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>38X30</td>
<td>Rent</td>
<td>0</td>
<td>7</td>
<td>1.077</td>
<td>7.54</td>
</tr>
<tr>
<td>36</td>
<td>Adan Navarro</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>2XLR</td>
<td>Rent</td>
<td>0</td>
<td>7</td>
<td>0.434</td>
<td>3.04</td>
</tr>
<tr>
<td>801</td>
<td>MARIO ORDONEZ</td>
<td>GO0650NAVY</td>
<td>JACKET WORK FR COTTON</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>2</td>
<td>1.599</td>
<td>3.20</td>
</tr>
<tr>
<td>801</td>
<td>MARIO ORDONEZ</td>
<td>GP0292NAVY</td>
<td>PANT FR 9OZ 88/12</td>
<td>38X30</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.490</td>
<td>2.94</td>
</tr>
<tr>
<td>801</td>
<td>MARIO ORDONEZ</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>802</td>
<td>IVAN JUAREZ</td>
<td>GO0650NAVY</td>
<td>JACKET WORK FR COTTON</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>2</td>
<td>1.599</td>
<td>3.20</td>
</tr>
<tr>
<td>802</td>
<td>IVAN JUAREZ</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>38X32</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>1.077</td>
<td>6.46</td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="8">See remaining pages of this invoice for a list of all included charges</td>
</tr>
</table>


<!-- PageFooter="Visit us at http://myaccount.vestis.com" -->
<!-- PageBreak -->


<figure>

vestis

</figure>


JOE FONTANINI
FONTANINI
8751 W 50TH
CHICAGO IL 60624


## INVOICE


<table>
<tr>
<td>BILLING INQUIRIES</td>
<td>(866) 837-8471</td>
</tr>
<tr>
<td>CUSTOMER SERVICE</td>
<td>(866) 837-8471</td>
</tr>
<tr>
<td>ACCOUNT NUMBER</td>
<td>9010001807</td>
</tr>
<tr>
<td>CUSTOMER NUMBER</td>
<td>7144477</td>
</tr>
<tr>
<td>INVOICE NUMBER</td>
<td>6040439529</td>
</tr>
<tr>
<td>INVOICE DATE</td>
<td>01/30/2026</td>
</tr>
</table>


<!-- PageNumber="Page 3 of 3" -->


<table>
<tr>
<th>WEARER#</th>
<th>WEARER NAME</th>
<th>ITEM</th>
<th>ITEM DESCRIPTION</th>
<th>SIZE</th>
<th>TYPE</th>
<th>DLVR QTY</th>
<th>BILL QTY</th>
<th>RATE</th>
<th>TOTAL</th>
</tr>
<tr>
<td>802</td>
<td>IVAN JUAREZ</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>2XLR</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>810</td>
<td>ROBERTO LOPEZ</td>
<td>GO0650NAVY</td>
<td>JACKET WORK FR COTTON</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>2</td>
<td>1.599</td>
<td>3.20</td>
</tr>
<tr>
<td>810</td>
<td>ROBERTO LOPEZ</td>
<td>GP0292NAVY</td>
<td>PANT FR 9OZ 88/12</td>
<td>38X29</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.490</td>
<td>2.94</td>
</tr>
<tr>
<td>810</td>
<td>ROBERTO LOPEZ</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>811</td>
<td>JOSE ESTRADA</td>
<td>GO0650NAVY</td>
<td>JACKET WORK FR COTTON</td>
<td>LGER</td>
<td>Rent</td>
<td>0</td>
<td>2</td>
<td>1.599</td>
<td>3.20</td>
</tr>
<tr>
<td>811</td>
<td>JOSE ESTRADA</td>
<td>GP0292NAVY</td>
<td>PANT FR 9OZ 88/12</td>
<td>36X30</td>
<td>Rent</td>
<td>2</td>
<td>6</td>
<td>0.490</td>
<td>2.94</td>
</tr>
<tr>
<td>811</td>
<td>JOSE ESTRADA</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>MEDR</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>813</td>
<td>DZEMAL KAHREM</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>1XLR</td>
<td>Rent</td>
<td>1</td>
<td>1</td>
<td>1.751</td>
<td>1.75</td>
</tr>
<tr>
<td>813</td>
<td>DZEMAL KAHREM</td>
<td>GP0264BLDM</td>
<td>PANT FR DENIM JEAN</td>
<td>38X28</td>
<td>Rent</td>
<td>0</td>
<td>7</td>
<td>0.631</td>
<td>4.42</td>
</tr>
<tr>
<td>813</td>
<td>DZEMAL KAHREM</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>LGER</td>
<td>Rent</td>
<td>0</td>
<td>7</td>
<td>0.434</td>
<td>3.04</td>
</tr>
<tr>
<td>818</td>
<td>Jaime Guzman</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.751</td>
<td>1.75</td>
</tr>
<tr>
<td>818</td>
<td>Jaime Guzman</td>
<td>GP0264BLDM</td>
<td>PANT FR DENIM JEAN</td>
<td>36X32</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.631</td>
<td>3.79</td>
</tr>
<tr>
<td>818</td>
<td>Jaime Guzman</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>LGER</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>819</td>
<td>JORGE BERRIOS</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.751</td>
<td>1.75</td>
</tr>
<tr>
<td>819</td>
<td>JORGE BERRIOS</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>36X32</td>
<td>Rent</td>
<td>0</td>
<td>7</td>
<td>1.077</td>
<td>7.54</td>
</tr>
<tr>
<td>819</td>
<td>JORGE BERRIOS</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>LGER</td>
<td>Rent</td>
<td>1</td>
<td>7</td>
<td>0.434</td>
<td>3.04</td>
</tr>
<tr>
<td>819</td>
<td>JORGE BERRIOS</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>LGER</td>
<td>Ruin charge</td>
<td>2</td>
<td>0</td>
<td>0.000</td>
<td>0.00</td>
</tr>
<tr>
<td>823</td>
<td>ANTHONY MORDA</td>
<td>GO0650NAVY</td>
<td>JACKET WORK FR COTTON</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>2</td>
<td>1.599</td>
<td>3.20</td>
</tr>
<tr>
<td>823</td>
<td>ANTHONY MORDA</td>
<td>GP0292NAVY</td>
<td>PANT FR 9OZ 88/12</td>
<td>38X30</td>
<td>Rent</td>
<td>1</td>
<td>6</td>
<td>0.490</td>
<td>2.94</td>
</tr>
<tr>
<td>823</td>
<td>ANTHONY MORDA</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>823</td>
<td>ANTHONY MORDA</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>LGER</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>826</td>
<td>Cesar Cesar</td>
<td>GO0650NAVY</td>
<td>JACKET WORK FR COTTON</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.599</td>
<td>1.60</td>
</tr>
<tr>
<td>826</td>
<td>Cesar Cesar</td>
<td>GP0292NAVY</td>
<td>PANT FR 9OZ 88/12</td>
<td>36X30</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.490</td>
<td>2.94</td>
</tr>
<tr>
<td>826</td>
<td>Cesar Cesar</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>38X30</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>1.077</td>
<td>6.46</td>
</tr>
<tr>
<td>826</td>
<td>Cesar Cesar</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>827</td>
<td>Scaramento Galazz</td>
<td>GO0650NAVY</td>
<td>JACKET WORK FR COTTON</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>2</td>
<td>1.599</td>
<td>3.20</td>
</tr>
<tr>
<td>827</td>
<td>Scaramento Galazz</td>
<td>GP0292NAVY</td>
<td>PANT FR 9OZ 88/12</td>
<td>40X28</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.490</td>
<td>2.94</td>
</tr>
<tr>
<td>827</td>
<td>Scaramento Galazz</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>829</td>
<td>Hector Melendez</td>
<td>GO3176NAVY</td>
<td>JACKET BOMBER EXCEL FR</td>
<td>1XLR</td>
<td>Rent</td>
<td>1</td>
<td>1</td>
<td>1.751</td>
<td>1.75</td>
</tr>
<tr>
<td>829</td>
<td>Hector Melendez</td>
<td>GP0264BLDM</td>
<td>PANT FR DENIM JEAN</td>
<td>38X32</td>
<td>Rent</td>
<td>2</td>
<td>6</td>
<td>0.631</td>
<td>3.79</td>
</tr>
<tr>
<td>829</td>
<td>Hector Melendez</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>1XLL</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>830</td>
<td>Jamaul Mckay</td>
<td>GO0650NAVY</td>
<td>JACKET WORK FR COTTON</td>
<td>2XLR</td>
<td>Rent</td>
<td>0</td>
<td>2</td>
<td>1.599</td>
<td>3.20</td>
</tr>
<tr>
<td>830</td>
<td>Jamaul Mckay</td>
<td>GP0292NAVY</td>
<td>PANT FR 9OZ 88/12</td>
<td>34X34</td>
<td>Rent</td>
<td>0</td>
<td>8</td>
<td>0.490</td>
<td>3.92</td>
</tr>
<tr>
<td>830</td>
<td>Jamaul Mckay</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>1XLR</td>
<td>Rent</td>
<td>0</td>
<td>6</td>
<td>0.434</td>
<td>2.60</td>
</tr>
<tr>
<td>832</td>
<td>TOMAS BANDERA</td>
<td>GO0650NAVY</td>
<td>JACKET WORK FR COTTON</td>
<td>LGER</td>
<td>Rent</td>
<td>0</td>
<td>1</td>
<td>1.599</td>
<td>1.60</td>
</tr>
<tr>
<td>832</td>
<td>TOMAS BANDERA</td>
<td>GP1081NAVY</td>
<td>PANT FR CARGO 9OZ 88/12</td>
<td>34X30</td>
<td>Rent</td>
<td>1</td>
<td>7</td>
<td>1.077</td>
<td>7.54</td>
</tr>
<tr>
<td>832</td>
<td>TOMAS BANDERA</td>
<td>GS1038LTBL</td>
<td>SHIRT FR LS SNAP NOPKT 88/12</td>
<td>MEDR</td>
<td>Rent</td>
<td>0</td>
<td>7</td>
<td>0.434</td>
<td>3.04</td>
</tr>
<tr>
<td></td>
<td></td>
<td>DM1704BLAK</td>
<td>MAT STEADY STEP</td>
<td>3×10</td>
<td>Rent</td>
<td>2</td>
<td>2</td>
<td>5.981</td>
<td>11.96</td>
</tr>
<tr>
<td></td>
<td></td>
<td>DM1704BLAK</td>
<td>MAT STEADY STEP</td>
<td>4×6</td>
<td>Rent</td>
<td>1</td>
<td>1</td>
<td>4.894</td>
<td>4.89</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>BILL ASSURE</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>71.62</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageFooter="Visit us at http://myaccount.vestis.com" -->
