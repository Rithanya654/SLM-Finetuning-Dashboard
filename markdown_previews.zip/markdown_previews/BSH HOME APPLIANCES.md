# BSH HOME APPLIANCES.pdf

BSH Home Appliances Ltd.

B/S/H/


# Invoice

Ship-to:

MARCONE APW WOODBRIDGE (DEO)

505 CITY VIEW BLVD UNIT 2

WOODBRIDGE ON L4H 0L8

CANADA

Page No.

1 / 2

Bill To:

MARCONE APW ULC

Po Box 411340

SAINT LOUIS MO 63141

USA


<table>
<tr>
<th>Bill Nr./Date</th>
<th>Delivery Nr. / Delivery Date</th>
<th>Your Customer Nr.</th>
<th>Your VAT reg. no.</th>
<th>Order Nr.</th>
</tr>
<tr>
<td>5170000360 / 02/02/2026</td>
<td>8303563590 / 02/02/2026</td>
<td>5010159214</td>
<td></td>
<td>4005420206</td>
</tr>
</table>


<table>
<tr>
<th>Payment Terms</th>
<th>within 30 days due net</th>
<th>Customer Reference</th>
<th>VA1204R25BSH</th>
</tr>
<tr>
<td>Gross Weight</td>
<td>32.537 KG</td>
<td>Currency</td>
<td>CAD</td>
</tr>
</table>


<table>
<tr>
<th>Item No.</th>
<th>Qty</th>
<th>Material</th>
<th>Description Remarks</th>
<th>Price/Unit</th>
<th>Gross Value</th>
<th>Net Price</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Order No : 4005420206 / Date : 12/04/2025 Delivery No : 8303563590 / Date : 02/03/2026</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1</td>
<td>1</td>
<td>11050223</td>
<td>Panel</td>
<td>368.99</td>
<td>368.99</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer discount</td>
<td>-40.00%</td>
<td>-147.60</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Net</td>
<td></td>
<td></td>
<td>221.39</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Order No : 4005571435 / Date : 12/31/2025 Delivery No : 8303563590 / Date : 02/03/2026</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>2</td>
<td>1</td>
<td>12049764</td>
<td>Cutlery basket</td>
<td>19.50</td>
<td>19.50</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer discount</td>
<td>-40.00%</td>
<td>-7.80</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Net</td>
<td></td>
<td></td>
<td>11.70</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Order No : 4005627742 / Date : 01/09/2026 Delivery No : 8303563590 / Date : 02/03/2026</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>3</td>
<td>1</td>
<td>10037793</td>
<td>Fuse-thermal</td>
<td>23.50</td>
<td>23.50</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer discount</td>
<td>-40.00%</td>
<td>-9.40</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Net</td>
<td></td>
<td></td>
<td>14.10</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Order No : 4005659114 / Date : 01/14/2026 Delivery No : 8303563590 / Date : 02/03/2026</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>4</td>
<td>1</td>
<td>12021856</td>
<td>Foam piece</td>
<td>7.50</td>
<td>7.50</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer discount</td>
<td>-40.00%</td>
<td>-3.00</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Net</td>
<td></td>
<td></td>
<td>4.50</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Order No : 4005716334 / Date : 01/22/2026 Delivery No : 8303563590 / Date : 02/03/2026</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>5</td>
<td>1</td>
<td>00757900</td>
<td>Holder</td>
<td>41.99</td>
<td>41.99</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer discount</td>
<td>-40.00%</td>
<td>-16.80</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Net</td>
<td></td>
<td></td>
<td>25.19</td>
</tr>
<tr>
<td>6</td>
<td>1</td>
<td>11054887</td>
<td>Operating module</td>
<td>413.99</td>
<td>413.99</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer discount</td>
<td>-40.00%</td>
<td>-165.60</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Net</td>
<td></td>
<td></td>
<td>248.39</td>
</tr>
<tr>
<td>7</td>
<td>1</td>
<td>11056279</td>
<td>Panel-facia</td>
<td>145.50</td>
<td>145.50</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer discount</td>
<td>-40.00%</td>
<td>-58.20</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Net</td>
<td></td>
<td></td>
<td>87.30</td>
</tr>
<tr>
<td>8</td>
<td>2</td>
<td>12028553</td>
<td>Compressor</td>
<td>736.50</td>
<td>1,473.00</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer discount</td>
<td>-40.00%</td>
<td>-589.20</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Net</td>
<td></td>
<td></td>
<td>883.80</td>
</tr>
</table>


BSH Home Appliances Ltd.
Head Office: 6696 Financial Drive, Unit 3, Mississauga, Ontario L5N 7J6 Canada
Phone: 1 800-554-9043, Parts / Accessories: 1 877-403-3185, https://www.bsh-group.com/

<!-- PageBreak -->

BSH Home Appliances Ltd.

B/S/H/


## Invoice

<!-- PageNumber="Page No. 2 / 2" -->


<table>
<tr>
<th>Bill Nr./Date</th>
<th>Delivery Nr. / Delivery Date</th>
<th>Your Customer Nr.</th>
<th>Your VAT reg. no.</th>
<th>Order Nr.</th>
</tr>
<tr>
<td>5170000360 / 02/02/2026</td>
<td>8303563590 / 02/02/2026</td>
<td>5010159214</td>
<td></td>
<td>4005420206</td>
</tr>
</table>


<table>
<tr>
<th>Item No.</th>
<th>Qty</th>
<th>Material</th>
<th>Description Remarks</th>
<th>Price/Unit</th>
<th>Gross Value</th>
<th>Net Price</th>
</tr>
<tr>
<td>9</td>
<td>2</td>
<td>12033326</td>
<td>Flip tine</td>
<td>67.50</td>
<td>135.00</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer discount</td>
<td>-40.00%</td>
<td>-54.00</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Net</td>
<td></td>
<td></td>
<td>81.00</td>
</tr>
<tr>
<td>10</td>
<td>1</td>
<td>12043030</td>
<td>Power/inverter module</td>
<td>542.99</td>
<td>542.99</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer discount</td>
<td>-40.00%</td>
<td>-217.20</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Net</td>
<td></td>
<td></td>
<td>325.79</td>
</tr>
<tr>
<td>11</td>
<td>1</td>
<td>12049560</td>
<td>Sensor</td>
<td>79.50</td>
<td>79.50</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer discount</td>
<td>-40.00%</td>
<td>-31.80</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Net</td>
<td></td>
<td></td>
<td>47.70</td>
</tr>
<tr>
<td>12</td>
<td>1</td>
<td>20002406</td>
<td>Tray</td>
<td>524.99</td>
<td>524.99</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer discount</td>
<td>-40.00%</td>
<td>-210.00</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Net</td>
<td></td>
<td></td>
<td>314.99</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Order No : 4005724379 / Date : 01/23/2026 Delivery No : 8303563590 / Date : 02/03/2026</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>13</td>
<td>1</td>
<td>00665308</td>
<td>Glass panel</td>
<td>121.50</td>
<td>121.50</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer discount</td>
<td>-40.00%</td>
<td>-48.60</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Net</td>
<td></td>
<td></td>
<td>72.90</td>
</tr>
<tr>
<td>14</td>
<td>1</td>
<td>00716935</td>
<td>Glass ceramic hob top</td>
<td>1,013.99</td>
<td>1,013.99</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer discount</td>
<td>-40.00%</td>
<td>-405.60</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Net</td>
<td></td>
<td></td>
<td>608.39</td>
</tr>
<tr>
<td>15</td>
<td>1</td>
<td>11005288</td>
<td>Hinge</td>
<td>280.50</td>
<td>280.50</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer discount</td>
<td>-40.00%</td>
<td>-112.20</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Net</td>
<td></td>
<td></td>
<td>168.30</td>
</tr>
<tr>
<td>16</td>
<td>3</td>
<td>11029285</td>
<td>Tray</td>
<td>37.50</td>
<td>112.50</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer discount</td>
<td>-40.00%</td>
<td>-45.00</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Net</td>
<td></td>
<td></td>
<td>67.50</td>
</tr>
<tr>
<td>17</td>
<td>1</td>
<td>11033789</td>
<td>Operating module programmed</td>
<td>433.50</td>
<td>433.50</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer discount</td>
<td>-40.00%</td>
<td>-173.40</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Net</td>
<td></td>
<td></td>
<td>260.10</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Order No : 4005736639 / Date : 01/26/2026 Delivery No : 8303563590 / Date : 02/03/2026</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>18</td>
<td>1</td>
<td>10037793</td>
<td>Fuse-thermal</td>
<td>23.50</td>
<td>23.50</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Customer discount</td>
<td>-40.00%</td>
<td>-9.40</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Net</td>
<td></td>
<td></td>
<td>14.10</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Amount (Netprice)</td>
<td></td>
<td></td>
<td>3,457.14</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Sales tax</td>
<td></td>
<td></td>
<td>449.42</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>Total Gross</td>
<td></td>
<td></td>
<td>3,906.56</td>
</tr>
</table>


BSH Home Appliances Ltd.
Head Office: 6696 Financial Drive, Unit 3, Mississauga, Ontario L5N 7J6 Canada
Phone: 1 800-554-9043, Parts / Accessories: 1 877-403-3185, https://www.bsh-group.com/
