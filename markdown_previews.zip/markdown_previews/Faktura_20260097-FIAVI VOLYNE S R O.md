# Faktura_20260097-FIAVI VOLYNE S R O.pdf

# Daňový doklad DPH

FAKTURA

Dodavatel:
FIAVI Volyně s.r.o.

IČ: 06692389

DIČ: CZ06692389

Číslo faktury
20260097


<table>
<tr>
<td>Variabilní symbol:</td>
<td>20260097</td>
</tr>
<tr>
<td>Konstantní symbol:</td>
<td>0008</td>
</tr>
</table>


Nádražní 231
387 01 Volyně


<table>
<tr>
<td>Peněžní ústav:</td>
<td>AIR BANK</td>
</tr>
<tr>
<td>Číslo účtu:</td>
<td>3376836010/3030</td>
</tr>
<tr>
<td>IBAN:</td>
<td>CZ8430300000003376836010</td>
</tr>
<tr>
<td>SWIFT:</td>
<td>AIRACZPP</td>
</tr>
</table>


Konečný příjemce:

Odběratel:
Vertiv Czech Republic s.r.o.
Nišovice 9

387 01 Volyně


<table>
<tr>
<td>Forma úhrady:</td>
<td>převodní příkaz</td>
</tr>
<tr>
<td>Způsob dopravy:</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>DIČ: CZ62502093</th>
<th colspan="2">IČ: 62502093</th>
</tr>
<tr>
<td colspan="3">Datum splatnosti: 11.03.2026</td>
</tr>
<tr>
<td colspan="2">Datum vystavení:</td>
<td>30.01.2026</td>
</tr>
<tr>
<td colspan="2">Datum uskutečnění zdanitelného plnění:</td>
<td>30.01.2026</td>
</tr>
</table>


<table>
<tr>
<th>Dodávka</th>
<th></th>
<th>množství</th>
<th>jednotková cena</th>
<th>v ceně sleva %</th>
<th>celkem bez DPH</th>
<th>sazba DPH %</th>
</tr>
<tr>
<td></td>
<td>obj.č. 173086620</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>E37.019</td>
<td>KULIČKOVÁ JEDNOTKA</td>
<td>10,00</td>
<td>114,45</td>
<td></td>
<td>1 144,50</td>
<td>21</td>
</tr>
<tr>
<td>999.999</td>
<td>NÁKLADY NA DOPRAVU</td>
<td>1,00</td>
<td>150,00</td>
<td></td>
<td>150,00</td>
<td>21</td>
</tr>
</table>


<table>
<tr>
<th colspan="3">Rekapitulace DPH</th>
</tr>
<tr>
<th>Sazba</th>
<th>Základ Kč</th>
<th>DPH Kč</th>
</tr>
<tr>
<td>21%</td>
<td>1 294,50</td>
<td>271,85</td>
</tr>
</table>


Celkem s daní z přidané hodnoty

1 566,35 Kč

QR Platba

Děkujeme Vám za Váš nákup.
Odebrané zboží zůstává až do úplného zaplacení majetkem
firmy FIAVI Volyně s.r.o.
PO je zapsána u krajského soudu v Českých Budějovicích, odd.C, vložka 27086

razítko, podpis dodavatele

<!-- PageFooter="tel. 730518225 mail fiavi@seznam.cz www.fiavi.cz" -->
<!-- PageFooter="fakturoval: pc3" -->
<!-- PageFooter="GRAND (c) Redlich Software" -->
