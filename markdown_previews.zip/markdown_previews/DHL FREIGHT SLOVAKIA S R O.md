# DHL FREIGHT SLOVAKIA S R O.pdf

DHL FREIGHT
INVOICE / Original


<figure>
</figure>


<table>
<tr>
<td>INVOICE NO:</td>
<td>121135623</td>
</tr>
<tr>
<td>INVOICE DATE:</td>
<td>30/01/2026</td>
</tr>
<tr>
<td>DUE DATE:</td>
<td>30/04/2026</td>
</tr>
<tr>
<td>PERIOD:</td>
<td>30/01/2026</td>
</tr>
<tr>
<td>PAGES:</td>
<td>1/2</td>
</tr>
<tr>
<td>PAYER</td>
<td></td>
</tr>
</table>


VERTIV SLOVAKIA, A. S.
AC POWER & THERMAL MANAGEMENT
PIESTANSKA 1202
916 28 NOVÉ MESTO NAD VÁHOM
SLOVAKIA


<table>
<tr>
<td colspan="2"></td>
</tr>
<tr>
<td>ACCOUNT NUMBER:</td>
<td>2310014464_SKFAM</td>
</tr>
<tr>
<td>VAT NUMBER:</td>
<td>SK2020380439</td>
</tr>
<tr>
<td>LEGAL REG. NO:</td>
<td>31411606</td>
</tr>
<tr>
<td>YOUR REF:</td>
<td></td>
</tr>
<tr>
<td colspan="2">FOR INVOICE ENQUIRIES</td>
</tr>
<tr>
<td>TEL:</td>
<td>+421907855880</td>
</tr>
<tr>
<td>FAX:</td>
<td></td>
</tr>
<tr>
<td>EMAIL:</td>
<td>skfreightbilling.sm@dhl.com</td>
</tr>
</table>


VERTIV SLOVAKIA, A. S.
AC POWER & THERMAL MANAGEMENT
PIESTANSKA 1202
916 28 NOVÉ MESTO NAD VÁHOM
SLOVAKIA


<table>
<tr>
<th>SERVICE</th>
<th>DESCRIPTION</th>
<th>NET AMOUNT</th>
</tr>
<tr>
<td>TOTAL TAL</td>
<td>TRANSPORT CHARGES</td>
<td>204.03 EUR</td>
</tr>
</table>


<table>
<tr>
<th>VAT CODE</th>
<th>NET AMOUNT</th>
<th>VAT %</th>
<th>TAX AMOUNT</th>
<th>GROSS AMOUNT</th>
</tr>
<tr>
<td>TAX</td>
<td>204.03 EUR</td>
<td>23.00</td>
<td>46.93 EUR</td>
<td>250.96 EUR</td>
</tr>
<tr>
<td>TOTAL</td>
<td>204.03 EUR</td>
<td></td>
<td>46.93 EUR</td>
<td>250.96 EUR</td>
</tr>
</table>


TOTAL GROSS AMOUNT

250.96 EUR

VAT CODE

VAT DESCRIPTION

TAX

INSERT INTO PAYMENT REFERENCE THE FOLLOWING CODE: 121135623


<table>
<tr>
<th>OUR BANK:</th>
<th>IBAN:</th>
<th>PAYMENT METHOD:</th>
</tr>
<tr>
<td>UNICREDIT BANK CZECH REPUBLIC AND SLOVAK</td>
<td>SK12 1111 0000 0016 4009 5006</td>
<td>BANK TRANSFER</td>
</tr>
<tr>
<td>ŠANCOVA 1/A</td>
<td>SWIFT/BIC:</td>
<td>TAXABLE ON DATE:</td>
</tr>
<tr>
<td>SK-813 33-BRATISLAVA</td>
<td>UNCRSKBX</td>
<td>30/01/2026</td>
</tr>
</table>


ADDITIONAL INFORMATION:

ENCLOSED DOCUMENT:


<table>
<tr>
<th>ISSUING BRANCH:</th>
<th colspan="2" rowspan="2">CREST CODE: SK0180</th>
</tr>
<tr>
<th>DHL FREIGHT SLOVAKIA, SPOL. S R.O</th>
</tr>
<tr>
<td>GALVANIHO 17/B SK-821 04 BRATISLAVA - MESTSKÁ ČASŤ RUŽINOV</td>
<td>TAX NUMBER:</td>
<td>SK2121354785</td>
</tr>
</table>


TEL: +421907855880

DHL Freight - Excellence. Simply delivered.

IČO: 53186931

Obchodný register: Mestský súd Bratislava III, odd .: Sro, vložka č. 147969/B
Always include the invoice number (payment reference) within the bank transfer.
In case invoice due date is not met, we charge contractual penalty 0.05% of the invoiced amount for each and every day of delay.
We follow the General Freight Forwarder's conditions of Logistics and Freight Forwarding Association in the Slovak Republic that are available for inspection upon request.

<!-- PageBreak -->


<table>
<tr>
<td>Invoice Number:</td>
<td>121135623</td>
</tr>
<tr>
<td>Account number:</td>
<td>2310014464_SKFAM</td>
</tr>
<tr>
<td>Invoice Date:</td>
<td>30/01/2026</td>
</tr>
<tr>
<td>Number of Pages:</td>
<td>2/2</td>
</tr>
</table>


DHL FREIGHT
ATTACHMENT


<figure>

DHL

</figure>


Order number:

Consignor:

Consignee:

Net Amount

VAT Code:

Order code:

Pick up place:

Delivery place:

Invoice:

Reference number:

Pick up Date:

Delivery Date:

EUR

Delivery term:

Consignor Reference:

Consignee Reference:

Product Code:

Invoice Reference:

Invoice Reference:

Service Date:


<table>
<tr>
<td>Pack. No:</td>
<td>Gross Weight:</td>
<td>Service description:</td>
</tr>
<tr>
<td>Type of Pack .:</td>
<td>Charg. Weight:</td>
<td></td>
</tr>
<tr>
<td>Goods</td>
<td>Volume:</td>
<td></td>
</tr>
<tr>
<td>Description:</td>
<td colspan="2">Loading Meters:</td>
</tr>
</table>


<table>
<tr>
<td>00051068400</td>
<td>VERTIV SLOVAKIA, A.S. AC POWER</td>
<td colspan="2">KOVAL SYSTEM 20</td>
<td>3000.00 kg</td>
<td>FREIGHT</td>
<td>204.03 TAX</td>
</tr>
<tr>
<td>BTS-DF-0026953</td>
<td>PIESTANSKA 1202 44</td>
<td colspan="2">KRIZNA 950 10 PAL</td>
<td></td>
<td>TOTAL</td>
<td>204.03</td>
</tr>
<tr>
<td>101100907592</td>
<td>SK 91528 NOVE MESTO NAD VAHOM</td>
<td colspan="2">SK 018 61 BELUSA Spare parts</td>
<td>9.60 cbm</td>
<td></td>
<td></td>
</tr>
<tr>
<td>EXW</td>
<td>SK 91528 NOVE MESTO NAD VAHOM</td>
<td>SK 018 61</td>
<td>BELUSA</td>
<td>8.40 LDM</td>
<td></td>
<td></td>
</tr>
<tr>
<td>ELD</td>
<td>29/01/2026</td>
<td colspan="2">30/01/2026</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>30/01/2026</td>
<td>101100907592</td>
<td colspan="2">101100907592</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


FTL4_S


<table>
<tr>
<td colspan="2">Net Amount Invoice: EUR</td>
</tr>
<tr>
<td>SUB TOTAL</td>
<td>204.03</td>
</tr>
</table>
