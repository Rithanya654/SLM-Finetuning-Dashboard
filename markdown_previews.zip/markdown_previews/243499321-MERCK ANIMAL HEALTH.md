# 243499321-MERCK ANIMAL HEALTH.PDF

<figure>

MERCK
Animal Health

</figure>


800-521-5767


# Invoice 243499321

Delivery Address:
COVETRUS NORTH AMERICA
BUTLER ANIMAL HEALTH SUPPLY LLC
5999 BIXBY RD
CANAL WINCHESTER OH 43110-8542
DEA Number

Billing Address:

COVETRUS NORTH AMERICA

BUTLER ANIMAL HEALTH SUPPLY LLC

PO Box 7153

DUBLIN OH 43017


<table>
<tr>
<td>Invoice date:</td>
<td>30-Jan-2026</td>
</tr>
<tr>
<td>Order number:</td>
<td>1119855656</td>
</tr>
<tr>
<td>PO number:</td>
<td>N575176</td>
</tr>
<tr>
<td>Payment terms:</td>
<td>30 days net</td>
</tr>
<tr>
<td>Payment due date:</td>
<td>01-Mar-2026</td>
</tr>
<tr>
<td>Currency:</td>
<td>USD</td>
</tr>
<tr>
<td>Terms of delivery:</td>
<td>FOB SHIPPING POINT</td>
</tr>
</table>


<table>
<tr>
<td>Order date :</td>
<td>28-Jan-2026</td>
</tr>
<tr>
<td>Customer number:</td>
<td>10108389</td>
</tr>
<tr>
<td>Orderhandler:</td>
<td>PIREMOTE</td>
</tr>
<tr>
<td>Tel number:</td>
<td></td>
</tr>
<tr>
<td>Fax number:</td>
<td></td>
</tr>
</table>


<!-- PageNumber="Page: 1/*" -->


<table>
<tr>
<th>Line No.</th>
<th></th>
<th>Material Batch/Serial</th>
<th colspan="3">Description</th>
<th></th>
<th>Qty ord</th>
<th>Qty Shipped Price</th>
<th>Qty backord Discount value</th>
<th>Net value in USD</th>
</tr>
<tr>
<td></td>
<td>1</td>
<td>066999</td>
<td>Salix 12.5mg</td>
<td>1x500tab</td>
<td>240</td>
<td></td>
<td>100.000 EA</td>
<td>100.000 EA</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="3"></td>
<td></td>
<td>66.42</td>
<td>132.84-</td>
<td>6,509.16</td>
</tr>
<tr>
<td></td>
<td></td>
<td>A120A01</td>
<td colspan="3">Quantity: 100 Exp date:</td>
<td>Aug-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>2</td>
<td>069005</td>
<td>Salix 50mg</td>
<td colspan="2">1x500tab 240</td>
<td></td>
<td>24.000 EA</td>
<td>24.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td colspan="2"></td>
<td></td>
<td>124.65</td>
<td>59.83-</td>
<td>2,931.77</td>
</tr>
<tr>
<td></td>
<td></td>
<td>A092A01</td>
<td></td>
<td colspan="2">Quantity: 24 Exp date:</td>
<td>Apr-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>3</td>
<td>069267</td>
<td>Panacur</td>
<td colspan="2">Suspension 10% 1x1L 240</td>
<td></td>
<td>112.000 CS</td>
<td>112.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="3"></td>
<td></td>
<td>841.05</td>
<td>1,883.95-</td>
<td>92,313.65</td>
</tr>
<tr>
<td></td>
<td></td>
<td>F810XA01X</td>
<td></td>
<td>Quantity:</td>
<td colspan="2">112 Exp date: May-2028</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>**</td>
<td>regulations ** Item may ship due to Hazardous</td>
<td>separately Materials</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>4</td>
<td>042247</td>
<td>Regu-Mate</td>
<td>1x1l 240</td>
<td></td>
<td></td>
<td>792.000 EA</td>
<td>792.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>103.09</td>
<td>1,632.97-</td>
<td>80,015.63</td>
</tr>
<tr>
<td></td>
<td></td>
<td>E702A01</td>
<td></td>
<td>Quantity:</td>
<td>428 Exp date:</td>
<td>Apr-2028</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>E703A01</td>
<td colspan="3">Quantity: 364 Exp date:</td>
<td>Apr-2028</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>5</td>
<td>065478</td>
<td colspan="3">Bo-Se 1x100ml 240</td>
<td></td>
<td>72.000 EA</td>
<td>72.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="4"></td>
<td></td>
<td>27.69</td>
<td>39.87-</td>
<td>1,953.81</td>
</tr>
</table>


5696101

Quantity:
72
Exp date: Jun-2027

<!-- PageBreak -->


<figure>

MERCK
Animal Health

</figure>


800-521-5767


## Invoice 243499321

Invoice date:

30-Jan-2026

<!-- PageNumber="Page: 2/*" -->


<table>
<tr>
<th>Line No.</th>
<th>Material Batch/Serial</th>
<th colspan="3">Description</th>
<th>Qty ord</th>
<th>Qty Shipped Price</th>
<th>Qty backord Discount value</th>
<th>Net value in USD</th>
</tr>
<tr>
<td></td>
<td>6 065547</td>
<td>Mu-Se 1x100ml 240</td>
<td colspan="2"></td>
<td>12.000 EA</td>
<td>12.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>41.06</td>
<td>9.85-</td>
<td>482.87</td>
</tr>
<tr>
<td></td>
<td>5743102</td>
<td>Quantity:</td>
<td colspan="2">12 Exp date: Jul-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>7 065476</td>
<td colspan="3">Banamine 1x250ml 240</td>
<td>168.000 EA</td>
<td>168.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>44.80</td>
<td>150.53-</td>
<td>7,375.87</td>
</tr>
<tr>
<td></td>
<td>5744101</td>
<td>Quantity:</td>
<td colspan="2">168 Exp date: Jul-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>8 191271</td>
<td colspan="2">Otomax 12 x 7.5gr tubes</td>
<td></td>
<td>60.000 BOX</td>
<td>60.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>163.56</td>
<td>196.27-</td>
<td>9,617.33</td>
</tr>
<tr>
<td></td>
<td>5578101</td>
<td>Quantity:</td>
<td colspan="2">11 Exp date: Jan-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>5609201</td>
<td>Quantity:</td>
<td>49</td>
<td>Exp date: Mar-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>9 058804</td>
<td colspan="3">OPTIMMUNE OPTH OINT 6 X 3.5 GR 240</td>
<td>720.000 PK</td>
<td>720.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>212.46</td>
<td>3,059.42-</td>
<td>149,911.78</td>
</tr>
<tr>
<td></td>
<td>5895</td>
<td>Quantity:</td>
<td colspan="2">720 Exp date: May-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>0 065549</td>
<td>Nuflor 1x100ml 240</td>
<td colspan="2"></td>
<td>60.000 EA</td>
<td>60.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>63.67</td>
<td>76.40-</td>
<td>3,743.60</td>
</tr>
<tr>
<td></td>
<td>5721104</td>
<td>Quantity:</td>
<td colspan="2">60 Exp date: Jul-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>11 065553</td>
<td colspan="3">Nuflor 1x250ml 240</td>
<td>12.000 EA</td>
<td>12.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>142.31</td>
<td>34.15-</td>
<td>1,673.55</td>
</tr>
<tr>
<td></td>
<td>5783101</td>
<td>Quantity:</td>
<td colspan="2">12 Exp date: Sep-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>12 065558</td>
<td>Nuflor 1x500ml 240</td>
<td colspan="2"></td>
<td>6.000 EA</td>
<td>6.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>276.73</td>
<td>33.21-</td>
<td>1,627.18</td>
</tr>
<tr>
<td></td>
<td>5686101</td>
<td>Quantity:</td>
<td colspan="2">6 Exp date: May-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>13 163410</td>
<td colspan="3">Otomax 6 x 30gr bottles</td>
<td>96.000 BOX</td>
<td>96.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>231.30</td>
<td>444.10-</td>
<td>21,760.70</td>
</tr>
<tr>
<td></td>
<td>5552103</td>
<td>Quantity:</td>
<td colspan="2">96 Exp date: Jan-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>14 114001</td>
<td colspan="3">Panacur Equine Paste 10% 5x57gr 240</td>
<td>780.000 PK</td>
<td>780.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>69.96</td>
<td>1,091.38-</td>
<td>53,477.42</td>
</tr>
<tr>
<td></td>
<td>A522A01</td>
<td>Quantity:</td>
<td colspan="2">780 Exp date: Feb-2028</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>15 189315</td>
<td colspan="3">Estrumate 1x20ml 240</td>
<td>120.000 EA</td>
<td>120.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>17.40</td>
<td>41.75-</td>
<td>2,045.89</td>
</tr>
<tr>
<td></td>
<td>5600101</td>
<td>Quantity:</td>
<td colspan="2">120 Exp date: Feb-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>16 196398</td>
<td colspan="2">Mometamax 6 x 30gr bottles</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

MERCK
Animal Health

</figure>


800-521-5767


## Invoice 243499321

Invoice date:

30-Jan-2026

<!-- PageNumber="Page: 3/*" -->


<table>
<tr>
<th>Line No.</th>
<th></th>
<th>Material Batch/Serial</th>
<th colspan="2">Description</th>
<th></th>
<th></th>
<th colspan="2">Qty ord</th>
<th>Qty Shipped Price</th>
<th>Qty backord Discount value</th>
<th>Net value in USD</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>96.000</td>
<td>BOX</td>
<td>96.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>268.97</td>
<td>516.42-</td>
<td>25,304.70</td>
</tr>
<tr>
<td></td>
<td></td>
<td>5519103</td>
<td colspan="2">Quantity:</td>
<td>96</td>
<td>Exp date:</td>
<td colspan="2">Dec-2026</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>17</td>
<td>185393</td>
<td colspan="2">Mometamax 12 x 7.5gr</td>
<td>bottles</td>
<td></td>
<td colspan="2">120.000 BOX</td>
<td>120.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>200.11</td>
<td>480.26-</td>
<td>23,532.94</td>
</tr>
<tr>
<td></td>
<td colspan="2">5532102</td>
<td colspan="2">Quantity:</td>
<td>120</td>
<td>Exp date:</td>
<td colspan="2">Dec-2026</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>18</td>
<td>186734</td>
<td colspan="3">Mometamax 12 x 15gr bottles</td>
<td></td>
<td colspan="2">648.000 BOX</td>
<td>648.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>298.92</td>
<td>3,874.00-</td>
<td>189,826.16</td>
</tr>
<tr>
<td></td>
<td></td>
<td>5653101</td>
<td colspan="2">Quantity:</td>
<td>648</td>
<td>Exp date:</td>
<td colspan="2">Apr-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>19</td>
<td>180652</td>
<td colspan="2">Otomax 12 x 15gr bottles</td>
<td></td>
<td></td>
<td colspan="2">40.000 BOX</td>
<td>40.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>267.34</td>
<td>213.87-</td>
<td>10,479.73</td>
</tr>
<tr>
<td></td>
<td></td>
<td>5536403</td>
<td colspan="2">Quantity:</td>
<td>40</td>
<td>Exp date:</td>
<td colspan="2">Jan-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>20</td>
<td>097700</td>
<td colspan="2">ORBENIN-DC 12 x 7.5G</td>
<td>Tube</td>
<td></td>
<td colspan="2">1.000 CS</td>
<td>1.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>430.44</td>
<td>8.61-</td>
<td>421.83</td>
</tr>
<tr>
<td></td>
<td></td>
<td>G1215</td>
<td colspan="2">Quantity:</td>
<td>1</td>
<td>Exp date:</td>
<td colspan="2">Jul-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>21</td>
<td>004110</td>
<td colspan="2">Panacur C 10x3x1gr 240</td>
<td></td>
<td></td>
<td colspan="2">280.000 PK</td>
<td>280.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>50.10</td>
<td>280.57-</td>
<td>13,747.99</td>
</tr>
<tr>
<td></td>
<td></td>
<td>25U1001A02</td>
<td colspan="2">Quantity:</td>
<td>280</td>
<td>Exp date:</td>
<td>Mar-2028</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">** Item may ship due to Hazardous regulations **</td>
<td colspan="2">separately Materials</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>22</td>
<td>004111</td>
<td colspan="2">Panacur C 10x3x2g 240</td>
<td></td>
<td></td>
<td>200.000</td>
<td>PK</td>
<td>200.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>76.14</td>
<td>304.56-</td>
<td>14,923.44</td>
</tr>
<tr>
<td></td>
<td></td>
<td>25U1001A01</td>
<td colspan="2">Quantity:</td>
<td>200</td>
<td>Exp date:</td>
<td>Mar-2028</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>** due</td>
<td>Item may ship to Hazardous regulations **</td>
<td colspan="2">separately Materials</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>23</td>
<td>004112</td>
<td colspan="2">Panacur C 10x3x4g 240</td>
<td></td>
<td></td>
<td colspan="2">200.000 PK</td>
<td>200.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>120.98</td>
<td>483.91-</td>
<td>23,711.69</td>
</tr>
</table>


25U1002A01

Quantity:
200
Exp date: Mar-2028

** Item may ship separately
due to Hazardous Materials
regulations **
24
133754
Chorulon 5x10,000 .I.U + 5x10ml dil 240
36.000 PK
36.000

<!-- PageBreak -->


<figure>

MERCK
Animal Health

</figure>


800-521-5767


## Invoice 243499321

Invoice date:

30-Jan-2026

<!-- PageNumber="Page: 4/*" -->


<table>
<tr>
<th>Line No.</th>
<th colspan="2">Material Batch/Serial</th>
<th colspan="4">Description</th>
<th>Qty ord</th>
<th>Qty Shipped Price</th>
<th>Qty backord Discount value</th>
<th>Net value in USD</th>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="4"></td>
<td></td>
<td>205.29</td>
<td>147.81-</td>
<td>7,242.63</td>
</tr>
<tr>
<td></td>
<td colspan="2">A222A01</td>
<td colspan="3">Quantity: 36 Exp date:</td>
<td>May-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">25 195010</td>
<td colspan="4">Estrumate 1x100ml 240</td>
<td>30.000 EA</td>
<td>30.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>76.09</td>
<td>45.65-</td>
<td>2,236.95</td>
</tr>
<tr>
<td></td>
<td colspan="2">5574101</td>
<td colspan="3">Quantity: 30 Exp date:</td>
<td>Feb-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">26 052716</td>
<td colspan="2">TRI-HEART PLUS 6 X 68MCG</td>
<td colspan="2"></td>
<td>216.000 CS</td>
<td>216.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="3"></td>
<td></td>
<td>165.82</td>
<td>716.34-</td>
<td>35,100.78</td>
</tr>
<tr>
<td></td>
<td colspan="2">SD3194</td>
<td colspan="3">Quantity: 216 Exp date:</td>
<td>Oct-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">27 049636</td>
<td colspan="3">TRI-HEART PLUS 6 X 136MCG</td>
<td></td>
<td>144.000 CS</td>
<td>144.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="4"></td>
<td></td>
<td>222.78</td>
<td>641.61-</td>
<td>31,438.71</td>
</tr>
<tr>
<td></td>
<td colspan="2">SD3074</td>
<td>Quantity:</td>
<td colspan="2">100 Exp date:</td>
<td>Apr-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">SD3076</td>
<td>Quantity:</td>
<td colspan="2">44 Exp date:</td>
<td>Apr-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">28 073919</td>
<td colspan="3">TRI-HEART PLUS 6 X 272MCG</td>
<td></td>
<td>576.000 CS</td>
<td>576.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="3"></td>
<td></td>
<td>290.46</td>
<td>3,346.10-</td>
<td>163,958.86</td>
</tr>
<tr>
<td></td>
<td colspan="2">SD3155</td>
<td>Quantity:</td>
<td colspan="2">303 Exp date:</td>
<td>Aug-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">SD3156</td>
<td colspan="3">Quantity: 273 Exp date:</td>
<td>Aug-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">29 055301</td>
<td colspan="2">Resflor Gold 1x100ml 240</td>
<td colspan="2"></td>
<td>24.000 EA</td>
<td>24.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="3"></td>
<td></td>
<td>84.48</td>
<td>40.55-</td>
<td>1,986.93</td>
</tr>
<tr>
<td></td>
<td colspan="2">5678101</td>
<td>Quantity:</td>
<td colspan="3">24 Exp date: May-2028</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">30 055305</td>
<td colspan="4">Resflor Gold 1x250ml 240</td>
<td>12.000 EA</td>
<td>12.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td colspan="3"></td>
<td></td>
<td>183.09</td>
<td>43.94-</td>
<td>2,153.12</td>
</tr>
<tr>
<td></td>
<td colspan="2">5792101</td>
<td colspan="4">Quantity: 12 Exp date: Oct-2028</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">31 210982</td>
<td colspan="3">Safe Guard Suspension 10% 1x1gal 240</td>
<td></td>
<td>5.000 CS</td>
<td>5.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="4"></td>
<td></td>
<td>727.37</td>
<td>72.74-</td>
<td>3,564.11</td>
</tr>
<tr>
<td></td>
<td colspan="2">F828AX01</td>
<td colspan="4">Quantity: 5 Exp date: Aug-2028</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">32 055219</td>
<td colspan="3">Orbax Oral Suspension 1x20ml 240</td>
<td></td>
<td>384.000 BOX</td>
<td>384.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td colspan="3"></td>
<td></td>
<td></td>
<td>243.59</td>
<td>1,870.77-</td>
<td>91,667.79</td>
</tr>
<tr>
<td></td>
<td colspan="2">5571102</td>
<td>Quantity:</td>
<td colspan="2">151 Exp date:</td>
<td>Jan-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>5572101</td>
<td>Quantity:</td>
<td colspan="2">233 Exp date:</td>
<td>Jan-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">33 117223</td>
<td colspan="2">Posatex 12 x 7.5 gr bottles</td>
<td></td>
<td></td>
<td>108.000 BOX</td>
<td>108.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="3"></td>
<td></td>
<td>242.52</td>
<td>523.84-</td>
<td>25,668.32</td>
</tr>
</table>


5597105

Quantity:
108
Exp date: Feb-2027

<!-- PageBreak -->


<figure>

MERCK
Animal Health

</figure>


800-521-5767


## Invoice 243499321

Invoice date:

30-Jan-2026

<!-- PageNumber="Page: 5/*" -->


<table>
<tr>
<th>Line No.</th>
<th></th>
<th>Material Batch/Serial</th>
<th colspan="2">Description</th>
<th>Qty ord</th>
<th>Qty Shipped Price</th>
<th>Qty backord Discount value</th>
<th>Net value in USD</th>
</tr>
<tr>
<td></td>
<td>34</td>
<td>094137</td>
<td colspan="2">Posatex 12 x 15 gr bottles</td>
<td>600.000 BOX</td>
<td>600.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>363.10</td>
<td>4,357.20-</td>
<td>213,502.80</td>
</tr>
<tr>
<td></td>
<td colspan="2">5637101</td>
<td colspan="2">Quantity: 600 Exp date: Apr-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">35</td>
<td>116772</td>
<td colspan="2">Posatex 6 x 30 gr bottles</td>
<td>48.000 BOX</td>
<td>48.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>325.77</td>
<td>312.74-</td>
<td>15,324.22</td>
</tr>
<tr>
<td></td>
<td colspan="2">5543102</td>
<td colspan="2">Quantity: 48 Exp date:</td>
<td>Jan-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">36</td>
<td>126547</td>
<td colspan="2">Revalor G 10x10ds 240</td>
<td>5.000 PK</td>
<td>5.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>156.29</td>
<td>15.63-</td>
<td>765.82</td>
</tr>
<tr>
<td></td>
<td colspan="2">A660T01</td>
<td colspan="2">Quantity: 5 Exp date:</td>
<td>Aug-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">37</td>
<td>339273</td>
<td colspan="2">Sentinel Flavor Tabs - Toy 1x6ds 240</td>
<td>8.000 CS</td>
<td>8.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>2,645.30</td>
<td>423.25-</td>
<td>20,739.15</td>
</tr>
<tr>
<td></td>
<td colspan="2">E6966201</td>
<td colspan="3">Quantity: 8 Exp date: 31-Aug-2029</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">38</td>
<td>352038</td>
<td colspan="2">Sentinel Flavor Tabs - Sm 1x6ds 240</td>
<td>35.000 CS</td>
<td>35.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>2,766.70</td>
<td>1,936.69-</td>
<td>94,897.81</td>
</tr>
<tr>
<td></td>
<td colspan="2">E6931500</td>
<td colspan="3">Quantity: 35 Exp date: 31-Mar-2029</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>39</td>
<td>333731</td>
<td colspan="2">Sentinel Flavor Tabs - Med 1x6ds 240</td>
<td>20.000 CS</td>
<td>20.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>3,305.30</td>
<td>1,322.12-</td>
<td>64,783.88</td>
</tr>
<tr>
<td></td>
<td></td>
<td>E6927000</td>
<td colspan="2" rowspan="2">Quantity: 13.40 Exp date: 0</td>
<td>31-Mar-2029</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">E6927100</td>
<td colspan="2">Quantity: 6.600 Exp date:</td>
<td>31-Mar-2029</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">40</td>
<td>327553</td>
<td colspan="2">Sentinel Flavor Tabs - Lrg 1x6ds 240</td>
<td>40.000 CS</td>
<td>40.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>3,997.00</td>
<td>3,197.60-</td>
<td>156,682.40</td>
</tr>
<tr>
<td></td>
<td colspan="2">E6924700</td>
<td colspan="3">Quantity: 40 Exp date: 31-Mar-2029</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">41</td>
<td>392869</td>
<td colspan="2">Sentinel Spectrum Chews - Toy 1X6ds 240</td>
<td>10.000 CS</td>
<td>10.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>1,694.88</td>
<td>338.98-</td>
<td>16,609.82</td>
</tr>
<tr>
<td></td>
<td colspan="2">241193</td>
<td colspan="2">Quantity: 10 Exp date:</td>
<td>30-Nov-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">42</td>
<td>363306</td>
<td colspan="2">Sentinel Spectrum Chews - Sm 1x6ds 240</td>
<td>83.000 CS</td>
<td>83.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>1,748.76</td>
<td>2,902.94-</td>
<td>142,244.14</td>
</tr>
<tr>
<td></td>
<td colspan="2">241128</td>
<td colspan="3">Quantity: 83 Exp date: 31-Oct-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>43</td>
<td>348483</td>
<td colspan="2">Sentinel Spectrum Chews - Med 1x6ds 240</td>
<td>110.000 CS</td>
<td>110.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>2,132.04</td>
<td>4,690.48-</td>
<td>229,833.92</td>
</tr>
</table>


250002

Quantity:

79.41 Exp date: 30-Nov-2027

<!-- PageBreak -->


<figure>

MERCK
Animal Health

</figure>


800-521-5767


# Invoice 243499321

Invoice date:

30-Jan-2026

<!-- PageNumber="Page: 6/*" -->


<table>
<tr>
<th>Line No.</th>
<th></th>
<th>Material Batch/Serial</th>
<th colspan="4">Description</th>
<th>Qty ord</th>
<th></th>
<th>Qty Shipped Price</th>
<th></th>
<th>Qty backord Discount value</th>
<th>Net value in USD</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="4">7</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>250400</td>
<td>Quantity:</td>
<td colspan="3">30.58 Exp date: 31-Mar-2028</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="3">3</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>44</td>
<td>091739</td>
<td>HomeAgain ISO 134kHz</td>
<td colspan="2">Microchip w/12G</td>
<td></td>
<td>2.000</td>
<td>BOX</td>
<td>2.000</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>574.75</td>
<td></td>
<td>22.99-</td>
<td>1,126.51</td>
</tr>
<tr>
<td></td>
<td></td>
<td>1903441</td>
<td colspan="4">Quantity: 2 Exp date: 31-Jul-2029</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>45</td>
<td>148253</td>
<td colspan="3">Universal Worldscan Reader Plus</td>
<td></td>
<td>3.000</td>
<td>EA</td>
<td>3.000</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>375.00</td>
<td></td>
<td>22.50-</td>
<td>1,102.50</td>
</tr>
<tr>
<td></td>
<td></td>
<td>2350</td>
<td>Quantity:</td>
<td colspan="2">3 Exp date:</td>
<td>2029</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>46</td>
<td>138942</td>
<td colspan="3">HomeAgain XS 134kHz Microchip w_15G</td>
<td></td>
<td>1.000</td>
<td>BOX</td>
<td>1.000</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>574.75</td>
<td></td>
<td>11.50-</td>
<td>563.25</td>
</tr>
<tr>
<td></td>
<td></td>
<td>2081343</td>
<td colspan="3">Quantity: 1 Exp date:</td>
<td>Jun-2030</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>47</td>
<td>189185</td>
<td colspan="3">HomeAgain TempScan134kHz Microchip</td>
<td></td>
<td>4.000</td>
<td>BOX</td>
<td>4.000</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="3">w/12G</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>574.75</td>
<td></td>
<td>45.98-</td>
<td>2,253.02</td>
</tr>
<tr>
<td></td>
<td></td>
<td>2064088</td>
<td>Quantity:</td>
<td colspan="2">4 Exp date:</td>
<td>May-2030</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>48</td>
<td>375676</td>
<td>Reader Handheld GPR+</td>
<td colspan="2">Microchip + Temp</td>
<td></td>
<td>5.000</td>
<td>EA</td>
<td>5.000</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td>324.45</td>
<td></td>
<td>32.45-</td>
<td>1,589.80</td>
</tr>
<tr>
<td></td>
<td></td>
<td>CN20250101</td>
<td colspan="3">Quantity: 5 Exp date:</td>
<td>Jan-2028</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>49</td>
<td>384603</td>
<td colspan="3">Sentinel Spectrum Chews - Lrg 1x6ds 240</td>
<td></td>
<td>115.000</td>
<td>CS</td>
<td>115.000</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="3"></td>
<td></td>
<td></td>
<td></td>
<td>2,569.20</td>
<td></td>
<td>5,909.16-</td>
<td>289,548.84</td>
</tr>
<tr>
<td></td>
<td></td>
<td>250303</td>
<td>Quantity:</td>
<td>4</td>
<td colspan="2">Exp date: 29-Feb-2028</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>250304</td>
<td colspan="3">Quantity: 111 Exp date:</td>
<td>29-Feb-2028</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>50</td>
<td>065237</td>
<td colspan="3">Cannulas bag of 10 240</td>
<td></td>
<td>50.000</td>
<td>BG</td>
<td>50.000</td>
<td>BG</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="3"></td>
<td></td>
<td></td>
<td></td>
<td>0.00</td>
<td></td>
<td></td>
<td>0.00</td>
</tr>
<tr>
<td></td>
<td>51</td>
<td>139552</td>
<td colspan="3">Bravecto 112.5mg 1x1tab 240</td>
<td></td>
<td>450.000</td>
<td>BOX</td>
<td>450.000</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="3"></td>
<td></td>
<td></td>
<td></td>
<td>422.73</td>
<td></td>
<td>3,804.57-</td>
<td>186,423.93</td>
</tr>
<tr>
<td></td>
<td></td>
<td>25M1004M02</td>
<td>Quantity:</td>
<td colspan="2">450 Exp date:</td>
<td>Feb-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>52</td>
<td>143323</td>
<td colspan="3">Bravecto 250mg 1x1tab 240</td>
<td></td>
<td>3,150.000</td>
<td>BOX</td>
<td>3,150.000</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="3"></td>
<td></td>
<td></td>
<td></td>
<td>430.74</td>
<td></td>
<td>27,136.62-</td>
<td>1,329,694.38</td>
</tr>
<tr>
<td></td>
<td></td>
<td>25M2025C02</td>
<td>Quantity:</td>
<td colspan="2">1,783 Exp date:</td>
<td>Jun-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>25M2036C01</td>
<td>Quantity:</td>
<td colspan="2">1,367 Exp date:</td>
<td>Aug-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>53</td>
<td>128951</td>
<td colspan="3">Bravecto 500mg 1x1tab 240</td>
<td></td>
<td colspan="2">3,150.000 BOX</td>
<td>3,150.000</td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

MERCK
Animal Health

</figure>


800-521-5767


## Invoice 243499321

Invoice date:

30-Jan-2026

<!-- PageNumber="Page: 7/*" -->


<table>
<tr>
<th>Line No.</th>
<th>Material Batch/Serial</th>
<th colspan="3">Description</th>
<th>Qty ord</th>
<th>Qty Shipped Price</th>
<th>Qty backord Discount value</th>
<th>Net value in USD</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>441.81</td>
<td>27,834.03-</td>
<td>1,363,867.47</td>
</tr>
<tr>
<td></td>
<td>25M3037C01</td>
<td>Quantity:</td>
<td colspan="2">3,150 Exp date:</td>
<td>Apr-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>54 144000</td>
<td colspan="3">Bravecto 1000mg 1x1tab 240</td>
<td>7,200.000 BOX</td>
<td>7,200.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>447.84</td>
<td>64,488.96-</td>
<td>3,159,959.04</td>
</tr>
<tr>
<td></td>
<td>25M4126S01</td>
<td>Quantity:</td>
<td>3,391</td>
<td>Exp date:</td>
<td>May-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>25M4127S01</td>
<td>Quantity:</td>
<td>3,809</td>
<td>Exp date:</td>
<td>May-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>55 147371</td>
<td colspan="3">Bravecto 1400mg 1x1tab 240</td>
<td>1,350.000 BOX</td>
<td>1,350.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>451.89</td>
<td>12,201.03-</td>
<td>597,850.47</td>
</tr>
<tr>
<td></td>
<td>25M5046C01</td>
<td>Quantity:</td>
<td colspan="2">1,350 Exp date:</td>
<td>Jul-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>56 150801</td>
<td colspan="3">Bravecto Topical Cat 112.5mg 1x1ds 240</td>
<td>20.000 BOX</td>
<td>20.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>393.30</td>
<td>157.32-</td>
<td>7,708.68</td>
</tr>
<tr>
<td></td>
<td>AX1602A</td>
<td colspan="2">Quantity: 20</td>
<td>Exp date:</td>
<td>Mar-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>57 154801</td>
<td colspan="3">Bravecto Topical Cat 250mg 1x1ds 240</td>
<td>1,000.000 BOX</td>
<td>1,000.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>401.40</td>
<td>8,028.00-</td>
<td>393,372.00</td>
</tr>
<tr>
<td></td>
<td>AX1603A</td>
<td>Quantity:</td>
<td colspan="2">1,000 Exp date:</td>
<td>Mar-2028</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>58 156857</td>
<td colspan="3">Bravecto Topical Cat 500mg 1x1ds 240</td>
<td>240.000 BOX</td>
<td>240.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>409.59</td>
<td>1,966.03-</td>
<td>96,335.57</td>
</tr>
<tr>
<td></td>
<td>AW8572C</td>
<td>Quantity:</td>
<td>240</td>
<td>Exp date:</td>
<td>Dec-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>59 162700</td>
<td colspan="2">Incurin 1mg 1x30tab 240</td>
<td></td>
<td>630.000 BOX</td>
<td>630.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>174.84</td>
<td>2,202.98-</td>
<td>107,946.22</td>
</tr>
<tr>
<td></td>
<td>340420</td>
<td colspan="2">Quantity: 630</td>
<td>Exp date:</td>
<td>30-Apr-2028</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>60 164452</td>
<td colspan="3">Vetsulin Syringes 100 X 1 ml x 29g</td>
<td>24.000 PK</td>
<td>24.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>33.84</td>
<td>16.24-</td>
<td>795.92</td>
</tr>
<tr>
<td></td>
<td>07201018</td>
<td>Quantity:</td>
<td>24</td>
<td colspan="2">Exp date: 31-Dec-2026</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>61 164948</td>
<td colspan="3">Vetsulin Syringes 100 × 0.5 ml x 29g</td>
<td>36.000 PK</td>
<td>36.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>33.84</td>
<td>24.36-</td>
<td>1,193.88</td>
</tr>
<tr>
<td></td>
<td>04503021</td>
<td colspan="2">Quantity: 36</td>
<td>Exp date:</td>
<td>28-Feb-2030</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>62 145738</td>
<td colspan="3">Safe-guard paste 10% 12x290gr 240</td>
<td>12.000 EA</td>
<td>12.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>56.61</td>
<td>13.59-</td>
<td>665.73</td>
</tr>
<tr>
<td></td>
<td>A527A01V</td>
<td>Quantity:</td>
<td>12</td>
<td>Exp date:</td>
<td>Mar-2028</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>63 225309</td>
<td colspan="3">S-G 290g DISPENSING KIT- 3 wing</td>
<td>1.000 EA</td>
<td>1.000</td>
<td>EA</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>0.00</td>
<td></td>
<td>0.00</td>
</tr>
</table>


<!-- PageBreak -->


<figure>

MERCK
Animal Health

</figure>


800-521-5767


## Invoice 243499321

Invoice date:

30-Jan-2026

<!-- PageNumber="Page: 8/*" -->


<table>
<tr>
<th>Line No.</th>
<th colspan="2">Material Batch/Serial</th>
<th>Description</th>
<th></th>
<th colspan="2">Qty ord</th>
<th>Qty Shipped Price</th>
<th colspan="2">Qty backord Discount value</th>
<th>Net value in USD</th>
</tr>
<tr>
<td></td>
<td colspan="2">64 092206</td>
<td colspan="2">Revalor S 10x10ds 240</td>
<td>1.000</td>
<td>PK</td>
<td>1.000</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>351.35</td>
<td></td>
<td>7.03-</td>
<td>344.32</td>
</tr>
<tr>
<td></td>
<td colspan="2">A644A02</td>
<td>Quantity:</td>
<td>1 Exp date:</td>
<td>Dec-2026</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2">65</td>
<td>155012</td>
<td colspan="2">Revalor Universal Implanting Tool</td>
<td colspan="2">2.000 EA</td>
<td>2.000</td>
<td>EA</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>0.00</td>
<td></td>
<td></td>
<td>0.00</td>
</tr>
<tr>
<td colspan="2">66</td>
<td>155802</td>
<td colspan="2">Bravecto Topical Dog 112.5mg 1x1ds 240</td>
<td>20.000</td>
<td>BOX</td>
<td>20.000</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>382.41</td>
<td></td>
<td>152.96-</td>
<td>7,495.24</td>
</tr>
<tr>
<td></td>
<td colspan="2">AX6144B</td>
<td>Quantity:</td>
<td>20 Exp date:</td>
<td>Apr-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>67</td>
<td>151483</td>
<td colspan="2">Bravecto Topical Dog 250mg 1x1ds 240</td>
<td>40.000</td>
<td>BOX</td>
<td>40.000</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>389.52</td>
<td></td>
<td>311.62-</td>
<td>15,269.18</td>
</tr>
<tr>
<td></td>
<td colspan="2">AX7079A</td>
<td>Quantity:</td>
<td>40 Exp date:</td>
<td>Aug-2028</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>68</td>
<td>158128</td>
<td colspan="2">Bravecto Topical Dog 500mg 1x1ds 240</td>
<td>20.000</td>
<td>BOX</td>
<td>20.000</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>397.53</td>
<td></td>
<td>159.01-</td>
<td>7,791.59</td>
</tr>
<tr>
<td></td>
<td colspan="2">AW8572A</td>
<td>Quantity:</td>
<td>20 Exp date:</td>
<td>Dec-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>69</td>
<td>158345</td>
<td colspan="2">Bravecto Topical Dog 1000mg 1x1ds 240</td>
<td>60.000</td>
<td>BOX</td>
<td>60.000</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>401.49</td>
<td></td>
<td>481.79-</td>
<td>23,607.61</td>
</tr>
<tr>
<td></td>
<td colspan="2">AW8573A</td>
<td>Quantity:</td>
<td>60 Exp date:</td>
<td>Dec-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>70</td>
<td>153307</td>
<td colspan="2">Bravecto Topical Dog 1400mg 1x1ds 240</td>
<td>20.000</td>
<td>BOX</td>
<td>20.000</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>405.63</td>
<td></td>
<td>162.25-</td>
<td>7,950.35</td>
</tr>
<tr>
<td></td>
<td colspan="2">AW8574A</td>
<td>Quantity:</td>
<td>20 Exp date:</td>
<td>Dec-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>71</td>
<td>135722</td>
<td colspan="2">Revalor-XH 10x10ds 240</td>
<td>1.000</td>
<td>PK</td>
<td>1.000</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>766.70</td>
<td></td>
<td>15.33-</td>
<td>751.37</td>
</tr>
<tr>
<td></td>
<td colspan="2">A098T01</td>
<td>Quantity:</td>
<td>1 Exp date:</td>
<td>Mar-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>72</td>
<td>138977</td>
<td colspan="2">Banamine Transdermal 1x250ml 240</td>
<td colspan="2">36.000 EA</td>
<td>36.000</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>57.59</td>
<td></td>
<td>41.47-</td>
<td>2,031.80</td>
</tr>
<tr>
<td></td>
<td colspan="2">5701201</td>
<td>Quantity:</td>
<td>36 Exp date:</td>
<td>Jun-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>73</td>
<td>144915</td>
<td colspan="2">Banamine Transdermal 1x1l 240</td>
<td colspan="2">8.000 EA</td>
<td>8.000</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td>206.54</td>
<td></td>
<td>33.05-</td>
<td>1,619.27</td>
</tr>
<tr>
<td></td>
<td colspan="2">5680101</td>
<td>Quantity:</td>
<td>8 Exp date:</td>
<td>Jun-2027</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td colspan="2" rowspan="2">74</td>
<td>006768</td>
<td colspan="2">SAFE-GUARD GOAT DOSING SYRINGE</td>
<td>1.000</td>
<td>EA</td>
<td rowspan="2">1.000</td>
<td>EA</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">20ML</td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


<!-- PageBreak -->


<figure>

MERCK
Animal Health

</figure>


800-521-5767


## Invoice 243499321

Invoice date:

30-Jan-2026

Page: 9/*


<table>
<tr>
<th>Line No.</th>
<th>Material Batch/Serial</th>
<th colspan="2">Description</th>
<th>Qty ord</th>
<th>Qty Shipped Price</th>
<th>Qty backord Discount value</th>
<th>Net value in USD</th>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>24.04</td>
<td>0.48-</td>
<td>23.56</td>
</tr>
<tr>
<td></td>
<td>75 065439</td>
<td colspan="2">Needles 36mg 6 ea/Needles per vl</td>
<td>7.000 PK</td>
<td>7.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>0.00</td>
<td></td>
<td>0.00</td>
</tr>
<tr>
<td></td>
<td>8003A017</td>
<td colspan="2">Quantity: 7 Exp date:</td>
<td>Jun-2030</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>76 213142</td>
<td colspan="2">Bravecto Plus for Cat 112.5mg 1x1ds 240</td>
<td>20.000 BOX</td>
<td>20.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>280.08</td>
<td>112.03-</td>
<td>5,489.57</td>
</tr>
<tr>
<td></td>
<td>L41B01</td>
<td>Quantity:</td>
<td>20 Exp date:</td>
<td>May-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>77 213143</td>
<td colspan="2">Bravecto Plus for Cat 250mg 1x1ds 240</td>
<td>1,200.000 BOX</td>
<td>1,200.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>286.11</td>
<td>6,866.64-</td>
<td>336,465.36</td>
</tr>
<tr>
<td></td>
<td>L37C01</td>
<td>Quantity:</td>
<td>1,200 Exp date:</td>
<td>Nov-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>78 213144</td>
<td colspan="2">Bravecto Plus for Cat 500mg 1x1ds 240</td>
<td>300.000 BOX</td>
<td>300.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>291.24</td>
<td>1,747.44-</td>
<td>85,624.56</td>
</tr>
<tr>
<td></td>
<td>L41A07</td>
<td>Quantity:</td>
<td colspan="2">300 Exp date: May-2028</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>79 385742</td>
<td colspan="2">Bravecto 1-Month 45mg 1x1tab 240</td>
<td>150.000 BOX</td>
<td>150.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>134.82</td>
<td>404.46-</td>
<td>19,818.54</td>
</tr>
<tr>
<td></td>
<td>25E1002C08</td>
<td>Quantity:</td>
<td colspan="2">150 Exp date: May-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>80 345070</td>
<td colspan="2">Bravecto 1-Month 100mg 1x1tab 240</td>
<td>240.000 BOX</td>
<td>240.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>137.88</td>
<td>661.82-</td>
<td>32,429.38</td>
</tr>
<tr>
<td></td>
<td>25E2003C02</td>
<td colspan="2">Quantity: 240 Exp date:</td>
<td>May-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>81 390622</td>
<td colspan="2">Bravecto 1-Month 200mg 1x1tab 240</td>
<td>270.000 BOX</td>
<td>270.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>140.40</td>
<td>758.16-</td>
<td>37,149.84</td>
</tr>
<tr>
<td></td>
<td>25E3004C03</td>
<td colspan="2">Quantity: 270 Exp date:</td>
<td>May-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>82 342516</td>
<td colspan="2">Bravecto 1-Month 400mg 1x1tab 240</td>
<td>140.000 BOX</td>
<td>140.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>141.93</td>
<td>397.40-</td>
<td>19,472.80</td>
</tr>
<tr>
<td></td>
<td>25E4007C02</td>
<td colspan="3">Quantity: 140 Exp date: Aug-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>83 351525</td>
<td colspan="2">ORBENIN-DC Pail 144 x 7.5G Tube</td>
<td>10.000 BUC</td>
<td>10.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>382.69</td>
<td>76.54-</td>
<td>3,750.36</td>
</tr>
<tr>
<td></td>
<td>G1162</td>
<td>Quantity:</td>
<td>10 Exp date:</td>
<td>Jul-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td>84 382608</td>
<td colspan="2">Arovyn 1x100ml 240</td>
<td>40.000 VL</td>
<td>40.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>74.80</td>
<td>59.84-</td>
<td>2,932.16</td>
</tr>
</table>


A236A01

Quantity:
40
Exp date: Mar-2027

<!-- PageBreak -->


<figure>

MERCK
Animal Health

</figure>


800-521-5767


## Invoice 243499321

Invoice date:

30-Jan-2026

<!-- PageNumber="Page: 10/11" -->


<table>
<tr>
<th>Line No.</th>
<th colspan="2">Material Batch/Serial</th>
<th>Description</th>
<th>Qty ord</th>
<th>Qty Shipped Price</th>
<th>Qty backord Discount value</th>
<th>Net value in USD</th>
</tr>
<tr>
<td></td>
<td>85</td>
<td>168042</td>
<td>Synergized DeLice 4x5L 240</td>
<td>1.000 CS</td>
<td>1.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>154.30</td>
<td>3.09-</td>
<td>151.21</td>
</tr>
<tr>
<td></td>
<td colspan="2">004/25</td>
<td colspan="2">Quantity: 1 Exp date: May-2030</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">86 228979</td>
<td>Mometamax Single 1x20ds 240</td>
<td>600.000 EA</td>
<td>600.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>324.00</td>
<td>3,888.00-</td>
<td>190,512.00</td>
</tr>
<tr>
<td></td>
<td colspan="2">5698116</td>
<td colspan="2">Quantity: 600 Exp date: Jun-2027</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2">87 355595</td>
<td>Arovyn 1x250ml 240</td>
<td>24.000 EA</td>
<td>24.000</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td>187.00</td>
<td>89.76-</td>
<td>4,398.24</td>
</tr>
</table>


A242A01

Quantity:

24

Exp date: Jul-2027

Delivery note no:

1223480714 28-Jan-2026, 1223480715 28-Jan-2026, 1223480716 28-Jan-2026, 1223480717 28-Jan-2026,1223480


<table>
<tr>
<td>Total gross value:</td>
<td>10,617,210.55</td>
</tr>
<tr>
<td>Total discount:</td>
<td>212,344.18-</td>
</tr>
<tr>
<td>Total net value:</td>
<td>10,404,866.37</td>
</tr>
<tr>
<td>Total amount due in USD:</td>
<td>10,404,866.37</td>
</tr>
</table>


Payment Methods:

ACH:
INTERVET INC / Bank of America / Routing # 111000012 / Account 3750886487

Wire Information: INTERVET INC / ABA: 026009593 / SWIFT: BOFAUS3N

Checks remit to: INTERVET INC / PO Box 198428 -Atlanta, GA 30384-8428

To expedite payment, please add your invoice (document) numbers or account number to the details of your payment.
You may also forward payment details/remittance to our Accounts Receivable email address: usah_inquiries@merck.com.
For statement or invoice copies please contact us at: 800-225-0113 or usah_inquiries@merck.com.

Go green & save paper!
Contact us at customerservice.ah@merck.com to receive your invoices via email instead of paper copies.
Contact us at usah_inquiries@merck.com or 1-704-345-6373 for statement or invoice copies.

CA Mill Paid

<!-- PageBreak -->


<figure>

MERCK
Animal Health

</figure>


800-521-5767


# Invoice 243499321

Invoice date:

30-Jan-2026

<!-- PageNumber="Page: 11/11" -->

Exclusion of Warranties

THE WARRANTY OF SELLER SET FORTH HEREIN AND THE OBLIGATIONS AND LIABILITIES OF SELLER THEREUNDER ARE
EXLUSIVE AND IN LIEU OF ALL OTHER REMEDIES, WARRANTIES, GUARANTEES OR LIABILITIES, EXPRESSED OR IMPLIED, ARISING
BY LAW OR OTHERWISE, WITH RESPECT TO THE PRODUCTS DELIVERED HEREUNDER. IN NO EVENT SHALL SELLER BE LIABLE
FOR INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES, ARISING FROM ANY CAUSE WHATSOEVER, NOR FOR ANY AMOUNT
EXCEEDING THE PURCHASE PRICE OF THE PRODUCTS.

The Customer shall be responsible for compliance with all applicable federal, state and local laws and regulations including any and all US
export laws and regulations. All products are subject to United States export regulations.
