# wurth media - kmtv invoice (16).png

<figure>

WURTH MEDIA

</figure>


WURTH MEDIA

BILLED TO:

KMTV-TV 3 News Now

10714 Mockingbird Drive Omaha, NE 68127

INVOICE: #2026-03
3 February, 2026


<table>
<tr>
<th>TASK</th>
<th>RATE</th>
<th>HOURS</th>
<th>TOTAL</th>
</tr>
<tr>
<td>On Air Talent 2/3/2025</td>
<td>$150/hr</td>
<td>1</td>
<td>$150.00</td>
</tr>
</table>


SubTotal

$150.00

TOTAL DUE
$150.00

Thank you

PAYMENT INFORMATION:

Wurth Media, LLC
18515 Wirt Circle
Elkhorn, NE 68022
402-507-8583

Or by direct deposit.

WURTH MEDIA

402-507-8583
karywurth@wurthmedia.com
18515 Wirt Circle, Elkhorn, NE 68022
