# DHL EXPRESS (CHILE) LIMITADA.pdf

# DHL EXPRESS (CHILE) LIMITADA SERVICIO INTERNACIONAL DE TRANSPORTE DE DOCUMENTOS Y CARGA AEREA

RIO ITATA 9651
PUDAHUEL-

R.U.T. 86.966.100- 7
FACTURA ELECTRONICA
N 4679651


<table>
<tr>
<td>Fecha</td>
<td>: 30 de Enero de 2026</td>
</tr>
<tr>
<td>Señor(es)</td>
<td>: VERTIV CONO SUR LIMITADA</td>
</tr>
<tr>
<td>Direccion</td>
<td>: AVENIDA EL BOSQUE NORTE 500 OF 1601</td>
</tr>
<tr>
<td>Comuna</td>
<td>: SANTIAGO</td>
</tr>
<tr>
<td>Giro</td>
<td>: VENTA DE OTROS PRODUCTOS N.C.P</td>
</tr>
<tr>
<td>Contacto</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
</table>


<table>
<tr>
<td>Fecha vencimiento</td>
<td>: 31-03-2026</td>
</tr>
<tr>
<td>RUT</td>
<td>: 76.219.663- 8</td>
</tr>
<tr>
<td>Ciudad</td>
<td>:</td>
</tr>
<tr>
<td>Forma de pago</td>
<td>: Crdito</td>
</tr>
</table>


<table>
<tr>
<th>Codigo</th>
<th>Cantidad</th>
<th>Descripcion</th>
<th>Precio Unitario</th>
<th>Descuento</th>
<th>Precio Total</th>
</tr>
<tr>
<td>1</td>
<td>1.000000</td>
<td>Servicio Afecto.</td>
<td>46.854</td>
<td></td>
<td>46.854</td>
</tr>
<tr>
<td>1</td>
<td>1.000000</td>
<td>Servicio Exento1</td>
<td>743.693</td>
<td></td>
<td>743.693</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Servicio : TRANSPORTE EXPRESO INTERNACIONAL (INBOUND).</td>
<td></td>
<td></td>
<td>0</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Total de AWB: 1.</td>
<td></td>
<td></td>
<td>0</td>
</tr>
<tr>
<td></td>
<td></td>
<td>Peso: 37,50.</td>
<td></td>
<td></td>
<td>0</td>
</tr>
</table>


SUB-TOTAL $ 790.547

REFERENCIAS

ORDEN DE COMPRA Nº 67502002 del 2025-02-07. -


<table>
<tr>
<td colspan="2">TOTALES</td>
</tr>
<tr>
<td>DESCUENTO</td>
<td>$</td>
</tr>
<tr>
<td>NETO</td>
<td>$ 46.854</td>
</tr>
<tr>
<td>EXENTO</td>
<td>$ 743.693</td>
</tr>
<tr>
<td>IVA 19.00%</td>
<td>$ 8.902</td>
</tr>
<tr>
<td>TOTAL</td>
<td>$ 799.449</td>
</tr>
</table>


Timbre Electronico SII
