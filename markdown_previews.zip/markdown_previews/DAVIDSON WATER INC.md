# DAVIDSON WATER INC.html

Current Amount63.00Total Bill63.00Davidson Water, Inc.P.O. Box 969Welcome, NC 27374-0969Post Office Will Not Deliver Without Proper Postage70-507-80Asco Power Tech325 Welcome Center B*IrrService From9/22/25Service To10/21/25GallonsReading100Reading100Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00Our office will be closed November 27th - 28th
to observe ThanksgivingInvoice Date 11/03/25AccountTotal DuePaid70-507-8063.00Please Return This Stub With PaymentAsco Power TechPO Box 270780 Att Rogelio GarcSaint Louis MO         63127-0000
Current Amount63.00Total Bill63.00Davidson Water, Inc.P.O. Box 969Welcome, NC 27374-0969Post Office Will Not Deliver Without Proper Postage70-507-80Asco Power Tech325 Welcome Center B*IrrService From9/22/25Service To10/21/25GallonsReading100Reading100Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00Our office will be closed November 27th - 28th
to observe ThanksgivingInvoice Date 11/03/25AccountTotal DuePaid70-507-8063.00Please Return This Stub With PaymentAsco Power TechPO Box 270780 Att Rogelio GarcSaint Louis MO         63127-0000
| Current Amount63.00Total Bill63.00Davidson Water, Inc.P.O. Box 969Welcome, NC 27374-0969Post Office Will Not Deliver Without Proper Postage70-507-80Asco Power Tech325 Welcome Center B*IrrService From9/22/25Service To10/21/25GallonsReading100Reading100Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00Our office will be closed November 27th - 28th
to observe ThanksgivingInvoice Date 11/03/25AccountTotal DuePaid70-507-8063.00Please Return This Stub With PaymentAsco Power TechPO Box 270780 Att Rogelio GarcSaint Louis MO         63127-0000 | Current Amount63.00Total Bill63.00 |  | Current Amount |  | 63.00 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Total Bill | 63.00 |  | Davidson Water, Inc.P.O. Box 969Welcome, NC 27374-0969Post Office Will Not Deliver Without Proper Postage70-507-80Asco Power Tech325 Welcome Center B*IrrService From9/22/25Service To10/21/25GallonsReading100Reading100Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Davidson Water, Inc.P.O. Box 969Welcome, NC 27374-0969 | Post Office Will Not Deliver Without Proper Postage | 70-507-80Asco Power Tech325 Welcome Center B*Irr |  | Service From9/22/25Service To10/21/25GallonsReading100Reading100Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Service From9/22/25Service To10/21/25GallonsReading100Reading100 | Service From | 9/22/25 | Service To | 10/21/25 | Gallons | Reading | 100 | Reading | 100 |  | Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Date Mailed | Past Due On | Days | Total Due | 11/03/25 | 11/18/25 | 29 | 63.00 |  |  | Our office will be closed November 27th - 28th
to observe ThanksgivingInvoice Date 11/03/25AccountTotal DuePaid70-507-8063.00Please Return This Stub With PaymentAsco Power TechPO Box 270780 Att Rogelio GarcSaint Louis MO         63127-0000 |  |  | Our office will be closed November 27th - 28th
to observe Thanksgiving |  |  | Invoice Date 11/03/25AccountTotal DuePaid70-507-8063.00Please Return This Stub With Payment |  | Invoice Date 11/03/25 |  | AccountTotal DuePaid70-507-8063.00 | Account | Total Due | Paid | 70-507-80 | 63.00 |  |  | Please Return This Stub With Payment |  | Asco Power TechPO Box 270780 Att Rogelio GarcSaint Louis MO         63127-0000 | Asco Power Tech | PO Box 270780 Att Rogelio Garc | Saint Louis MO         63127-0000 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Current Amount63.00Total Bill63.00 |  | Current Amount |  | 63.00 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Total Bill | 63.00 |  | Davidson Water, Inc.P.O. Box 969Welcome, NC 27374-0969Post Office Will Not Deliver Without Proper Postage70-507-80Asco Power Tech325 Welcome Center B*IrrService From9/22/25Service To10/21/25GallonsReading100Reading100Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Davidson Water, Inc.P.O. Box 969Welcome, NC 27374-0969 | Post Office Will Not Deliver Without Proper Postage | 70-507-80Asco Power Tech325 Welcome Center B*Irr |  | Service From9/22/25Service To10/21/25GallonsReading100Reading100Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Service From9/22/25Service To10/21/25GallonsReading100Reading100 | Service From | 9/22/25 | Service To | 10/21/25 | Gallons | Reading | 100 | Reading | 100 |  | Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Date Mailed | Past Due On | Days | Total Due | 11/03/25 | 11/18/25 | 29 | 63.00 |
|  | Current Amount |  | 63.00 |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |
|  | Total Bill | 63.00 |
| Davidson Water, Inc.P.O. Box 969Welcome, NC 27374-0969 | Post Office Will Not Deliver Without Proper Postage |
| 70-507-80Asco Power Tech325 Welcome Center B*Irr |  |
| Service From9/22/25Service To10/21/25GallonsReading100Reading100Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Service From9/22/25Service To10/21/25GallonsReading100Reading100 | Service From | 9/22/25 | Service To | 10/21/25 | Gallons | Reading | 100 | Reading | 100 |  | Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Date Mailed | Past Due On | Days | Total Due | 11/03/25 | 11/18/25 | 29 | 63.00 |
| Service From9/22/25Service To10/21/25GallonsReading100Reading100 | Service From | 9/22/25 | Service To | 10/21/25 | Gallons | Reading | 100 | Reading | 100 |  |
| Service From | 9/22/25 | Service To | 10/21/25 | Gallons |
| Reading | 100 | Reading | 100 |  |
| Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Date Mailed | Past Due On | Days | Total Due | 11/03/25 | 11/18/25 | 29 | 63.00 |
| Date Mailed | Past Due On | Days | Total Due |
| 11/03/25 | 11/18/25 | 29 | 63.00 |
|  |
|  |
| Our office will be closed November 27th - 28th
to observe ThanksgivingInvoice Date 11/03/25AccountTotal DuePaid70-507-8063.00Please Return This Stub With PaymentAsco Power TechPO Box 270780 Att Rogelio GarcSaint Louis MO         63127-0000 |  |  | Our office will be closed November 27th - 28th
to observe Thanksgiving |  |  | Invoice Date 11/03/25AccountTotal DuePaid70-507-8063.00Please Return This Stub With Payment |  | Invoice Date 11/03/25 |  | AccountTotal DuePaid70-507-8063.00 | Account | Total Due | Paid | 70-507-80 | 63.00 |  |  | Please Return This Stub With Payment |  | Asco Power TechPO Box 270780 Att Rogelio GarcSaint Louis MO         63127-0000 | Asco Power Tech | PO Box 270780 Att Rogelio Garc | Saint Louis MO         63127-0000 |
|  |  | Our office will be closed November 27th - 28th
to observe Thanksgiving |
|  |
|  |
| Invoice Date 11/03/25AccountTotal DuePaid70-507-8063.00Please Return This Stub With Payment |  | Invoice Date 11/03/25 |  | AccountTotal DuePaid70-507-8063.00 | Account | Total Due | Paid | 70-507-80 | 63.00 |  |  | Please Return This Stub With Payment |  | Asco Power TechPO Box 270780 Att Rogelio GarcSaint Louis MO         63127-0000 | Asco Power Tech | PO Box 270780 Att Rogelio Garc | Saint Louis MO         63127-0000 |
|  | Invoice Date 11/03/25 |
|  | AccountTotal DuePaid70-507-8063.00 | Account | Total Due | Paid | 70-507-80 | 63.00 |  |
| Account | Total Due | Paid |
| 70-507-80 | 63.00 |  |
|  | Please Return This Stub With Payment |
| Asco Power Tech |
| PO Box 270780 Att Rogelio Garc |
| Saint Louis MO         63127-0000 |

Current Amount63.00Total Bill63.00Davidson Water, Inc.P.O. Box 969Welcome, NC 27374-0969Post Office Will Not Deliver Without Proper Postage70-507-80Asco Power Tech325 Welcome Center B*IrrService From9/22/25Service To10/21/25GallonsReading100Reading100Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00Our office will be closed November 27th - 28th
to observe ThanksgivingInvoice Date 11/03/25AccountTotal DuePaid70-507-8063.00Please Return This Stub With PaymentAsco Power TechPO Box 270780 Att Rogelio GarcSaint Louis MO         63127-0000
| Current Amount63.00Total Bill63.00 |  | Current Amount |  | 63.00 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Total Bill | 63.00 |  | Davidson Water, Inc.P.O. Box 969Welcome, NC 27374-0969Post Office Will Not Deliver Without Proper Postage70-507-80Asco Power Tech325 Welcome Center B*IrrService From9/22/25Service To10/21/25GallonsReading100Reading100Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Davidson Water, Inc.P.O. Box 969Welcome, NC 27374-0969 | Post Office Will Not Deliver Without Proper Postage | 70-507-80Asco Power Tech325 Welcome Center B*Irr |  | Service From9/22/25Service To10/21/25GallonsReading100Reading100Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Service From9/22/25Service To10/21/25GallonsReading100Reading100 | Service From | 9/22/25 | Service To | 10/21/25 | Gallons | Reading | 100 | Reading | 100 |  | Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Date Mailed | Past Due On | Days | Total Due | 11/03/25 | 11/18/25 | 29 | 63.00 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|  | Current Amount |  | 63.00 |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |
|  | Total Bill | 63.00 |
| Davidson Water, Inc.P.O. Box 969Welcome, NC 27374-0969 | Post Office Will Not Deliver Without Proper Postage |
| 70-507-80Asco Power Tech325 Welcome Center B*Irr |  |
| Service From9/22/25Service To10/21/25GallonsReading100Reading100Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Service From9/22/25Service To10/21/25GallonsReading100Reading100 | Service From | 9/22/25 | Service To | 10/21/25 | Gallons | Reading | 100 | Reading | 100 |  | Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Date Mailed | Past Due On | Days | Total Due | 11/03/25 | 11/18/25 | 29 | 63.00 |
| Service From9/22/25Service To10/21/25GallonsReading100Reading100 | Service From | 9/22/25 | Service To | 10/21/25 | Gallons | Reading | 100 | Reading | 100 |  |
| Service From | 9/22/25 | Service To | 10/21/25 | Gallons |
| Reading | 100 | Reading | 100 |  |
| Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Date Mailed | Past Due On | Days | Total Due | 11/03/25 | 11/18/25 | 29 | 63.00 |
| Date Mailed | Past Due On | Days | Total Due |
| 11/03/25 | 11/18/25 | 29 | 63.00 |
|  |
|  |
| Our office will be closed November 27th - 28th
to observe ThanksgivingInvoice Date 11/03/25AccountTotal DuePaid70-507-8063.00Please Return This Stub With PaymentAsco Power TechPO Box 270780 Att Rogelio GarcSaint Louis MO         63127-0000 |  |  | Our office will be closed November 27th - 28th
to observe Thanksgiving |  |  | Invoice Date 11/03/25AccountTotal DuePaid70-507-8063.00Please Return This Stub With Payment |  | Invoice Date 11/03/25 |  | AccountTotal DuePaid70-507-8063.00 | Account | Total Due | Paid | 70-507-80 | 63.00 |  |  | Please Return This Stub With Payment |  | Asco Power TechPO Box 270780 Att Rogelio GarcSaint Louis MO         63127-0000 | Asco Power Tech | PO Box 270780 Att Rogelio Garc | Saint Louis MO         63127-0000 |
|  |  | Our office will be closed November 27th - 28th
to observe Thanksgiving |
|  |
|  |
| Invoice Date 11/03/25AccountTotal DuePaid70-507-8063.00Please Return This Stub With Payment |  | Invoice Date 11/03/25 |  | AccountTotal DuePaid70-507-8063.00 | Account | Total Due | Paid | 70-507-80 | 63.00 |  |  | Please Return This Stub With Payment |  | Asco Power TechPO Box 270780 Att Rogelio GarcSaint Louis MO         63127-0000 | Asco Power Tech | PO Box 270780 Att Rogelio Garc | Saint Louis MO         63127-0000 |
|  | Invoice Date 11/03/25 |
|  | AccountTotal DuePaid70-507-8063.00 | Account | Total Due | Paid | 70-507-80 | 63.00 |  |
| Account | Total Due | Paid |
| 70-507-80 | 63.00 |  |
|  | Please Return This Stub With Payment |
| Asco Power Tech |
| PO Box 270780 Att Rogelio Garc |
| Saint Louis MO         63127-0000 |

|  | Current Amount |  | 63.00 |
|---|---|---|---|
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |
|  | Total Bill | 63.00 |

Current Amount
63.00
Total Bill
63.00
| Davidson Water, Inc.P.O. Box 969Welcome, NC 27374-0969 | Post Office Will Not Deliver Without Proper Postage |
|---|---|
| 70-507-80Asco Power Tech325 Welcome Center B*Irr |  |
| Service From9/22/25Service To10/21/25GallonsReading100Reading100Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Service From9/22/25Service To10/21/25GallonsReading100Reading100 | Service From | 9/22/25 | Service To | 10/21/25 | Gallons | Reading | 100 | Reading | 100 |  | Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Date Mailed | Past Due On | Days | Total Due | 11/03/25 | 11/18/25 | 29 | 63.00 |
| Service From9/22/25Service To10/21/25GallonsReading100Reading100 | Service From | 9/22/25 | Service To | 10/21/25 | Gallons | Reading | 100 | Reading | 100 |  |
| Service From | 9/22/25 | Service To | 10/21/25 | Gallons |
| Reading | 100 | Reading | 100 |  |
| Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Date Mailed | Past Due On | Days | Total Due | 11/03/25 | 11/18/25 | 29 | 63.00 |
| Date Mailed | Past Due On | Days | Total Due |
| 11/03/25 | 11/18/25 | 29 | 63.00 |

Davidson Water, Inc.
P.O. Box 969
Welcome, NC 27374-0969
Post Office Will Not Deliver Without Proper Postage
Post Office Will Not Deliver Without Proper Postage
70-507-80
Asco Power Tech
325 Welcome Center B*Irr
| Service From9/22/25Service To10/21/25GallonsReading100Reading100 | Service From | 9/22/25 | Service To | 10/21/25 | Gallons | Reading | 100 | Reading | 100 |  |
|---|---|---|---|---|---|---|---|---|---|---|
| Service From | 9/22/25 | Service To | 10/21/25 | Gallons |
| Reading | 100 | Reading | 100 |  |
| Date MailedPast Due OnDaysTotal Due11/03/2511/18/252963.00 | Date Mailed | Past Due On | Days | Total Due | 11/03/25 | 11/18/25 | 29 | 63.00 |
| Date Mailed | Past Due On | Days | Total Due |
| 11/03/25 | 11/18/25 | 29 | 63.00 |

| Service From | 9/22/25 | Service To | 10/21/25 | Gallons |
|---|---|---|---|---|
| Reading | 100 | Reading | 100 |  |

Service From
9/22/25
Service To
10/21/25
Gallons
Reading
100
Reading
100
| Date Mailed | Past Due On | Days | Total Due |
|---|---|---|---|
| 11/03/25 | 11/18/25 | 29 | 63.00 |

Date Mailed
Past Due On
Days
Total Due
11/03/25
11/18/25
29
63.00
|  |  | Our office will be closed November 27th - 28th
to observe Thanksgiving |
|---|---|---|
|  |
|  |
| Invoice Date 11/03/25AccountTotal DuePaid70-507-8063.00Please Return This Stub With Payment |  | Invoice Date 11/03/25 |  | AccountTotal DuePaid70-507-8063.00 | Account | Total Due | Paid | 70-507-80 | 63.00 |  |  | Please Return This Stub With Payment |  | Asco Power TechPO Box 270780 Att Rogelio GarcSaint Louis MO         63127-0000 | Asco Power Tech | PO Box 270780 Att Rogelio Garc | Saint Louis MO         63127-0000 |
|  | Invoice Date 11/03/25 |
|  | AccountTotal DuePaid70-507-8063.00 | Account | Total Due | Paid | 70-507-80 | 63.00 |  |
| Account | Total Due | Paid |
| 70-507-80 | 63.00 |  |
|  | Please Return This Stub With Payment |
| Asco Power Tech |
| PO Box 270780 Att Rogelio Garc |
| Saint Louis MO         63127-0000 |

Our office will be closed November 27th - 28th
to observe Thanksgiving
|  | Invoice Date 11/03/25 |
|---|---|
|  | AccountTotal DuePaid70-507-8063.00 | Account | Total Due | Paid | 70-507-80 | 63.00 |  |
| Account | Total Due | Paid |
| 70-507-80 | 63.00 |  |
|  | Please Return This Stub With Payment |

Invoice Date 11/03/25
| Account | Total Due | Paid |
|---|---|---|
| 70-507-80 | 63.00 |  |

Account
Total Due
Paid
70-507-80
63.00
Please Return This Stub With Payment
| Asco Power Tech |
|---|
| PO Box 270780 Att Rogelio Garc |
| Saint Louis MO         63127-0000 |

Asco Power Tech
PO Box 270780 Att Rogelio Garc
Saint Louis MO         63127-0000