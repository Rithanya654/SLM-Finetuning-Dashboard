# RECEIPT_AMERICOLD.pdf

FORM IB301A - WAREHOUSE RECEIVING

TX-MANFD - AMC-TX-MANFD FACILITY

Inbound Shipment ID: 117253

Client ID: 48026 - Hormel Food Corporation

Planned Inbound Order Number: 117253

Supplier:

1212 - AMC MANSFIELD TX

Shipped Date:


<figure>

americoLO.

</figure>


<table>
<tr>
<td>Appointment #:</td>
<td>APP0670969</td>
</tr>
<tr>
<td>Appt. Date/Time:</td>
<td>02/03/2026 08:30</td>
</tr>
<tr>
<td>Arrival</td>
<td>02/03/2026 08:59</td>
</tr>
<tr>
<td>Receiving Door:</td>
<td>DD031</td>
</tr>
</table>


<table>
<tr>
<td>Carrier: FIRST FLEET</td>
<td colspan="2">INC</td>
</tr>
<tr>
<td>Cust Ref:</td>
<td colspan="2"></td>
</tr>
<tr>
<td>Waybill:</td>
<td></td>
<td></td>
</tr>
<tr>
<td>Transport Equipment</td>
<td colspan="2">931762 670969</td>
</tr>
<tr>
<td>Seal #:</td>
<td colspan="2"></td>
</tr>
<tr>
<td>Trailer Status: DROP</td>
<td colspan="2">SCAC: FFTI</td>
</tr>
</table>


Temperature Information

Nose Temp:

Mid Temp:

Tail Temp:

Part Information


<table>
<tr>
<th>Shipped Qty</th>
<th>Received Qty</th>
<th>Part Code &amp; Description</th>
<th>Lot Code</th>
<th>Revision Level</th>
<th>Manuf. Date</th>
<th>Pull Date</th>
<th>Net Weight</th>
<th>Gross Weight</th>
<th>Inv. Status</th>
<th>Temp. Category</th>
</tr>
<tr>
<td>19</td>
<td>0</td>
<td>221802R3 - SHIPPER DIE CUT DISPLAY SAMS (17938) (QTY:320)</td>
<td>----</td>
<td>----</td>
<td></td>
<td></td>
<td>0.00</td>
<td>0.00</td>
<td>A-Available</td>
<td>C</td>
</tr>
<tr>
<td>0</td>
<td>19</td>
<td>221802R3 - SHIPPER DIE CUT DISPLAY SAMS (17938) (QTY:320)</td>
<td>20260107</td>
<td></td>
<td>01/07/2026 02:00</td>
<td>01/07/2027 02:00</td>
<td>15.20</td>
<td>15.20</td>
<td>A-Available</td>
<td>C</td>
</tr>
<tr>
<td>19</td>
<td>0</td>
<td>228935 - DISPLAY SHIPPER DIE CUT USA/CAN BURRITOS 360</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>0.00</td>
<td>0.00</td>
<td>A-Available</td>
<td>C</td>
</tr>
<tr>
<td>0</td>
<td>19</td>
<td>228935 - DISPLAY SHIPPER DIE CUT USA/CAN BURRITOS 360</td>
<td>20260119</td>
<td>----</td>
<td>01/19/2026 02:00</td>
<td>01/19/2027 02:00</td>
<td>17,100.00</td>
<td>17,290.00</td>
<td>A-Available</td>
<td>C</td>
</tr>
<tr>
<td>38</td>
<td>38</td>
<td></td>
<td></td>
<td></td>
<td>Totals &gt;</td>
<td></td>
<td>17,115.20</td>
<td>17,305.20</td>
<td></td>
<td></td>
</tr>
</table>


Remarks

Load Information
Pallets Received: 38 WHITE B

Completed Date/Time: 02/03/2026 11:32

Departure Date/Time: 02/03/2026 11:32

I hereby certify that the information contained on this warehouse receiving document is accurate. Any
discrepancies from original Bill of Ladings have been noted, and verified. I understand that this is a
summary of information received by the warehouse, and not a billable document.

Driver
AMC

<!-- PageFooter="Printed: 2/3/2026 11:32:18 AM Americold | 10 Glenlake Parkway | South Tower, Suite 600 | Atlanta, GA 30328 | 678.441.1400" -->
<!-- PageNumber="Page 1 of 1" -->
