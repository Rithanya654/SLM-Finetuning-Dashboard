# ENCORR TIJUANA-PO.pdf

<figure>

Encore
SHEETS"

</figure>


Encorr Sheets
5171 E. Francis Street
Ontario, CA 91761
PH FAX


# INVOICE


<table>
<tr>
<th>SALESMAN NO.</th>
<th>BOL NUMBER</th>
<th>INVOICE DATE</th>
<th>TERMS</th>
<th>INVOICE NUMBER</th>
</tr>
<tr>
<td></td>
<td>168664</td>
<td>01/27/2026</td>
<td>3% 10, 2% 30, Net 45</td>
<td>255812</td>
</tr>
</table>


SOLD TO

SHIP TO

Liberty Packaging
13100 Danielson Street
Poway, CA 92064

0000008

Liberty Tijuana
Sor Juana Ines La Cruz #20154-A
Tijuana, BC, MX 22440


<table>
<tr>
<th>DESCRIPTION</th>
<th>P/C QTY ORD / QTY INV</th>
<th>QTY SHIPPED</th>
<th>UNIT PRICE</th>
<th>AMOUNT</th>
</tr>
<tr>
<td>260126134 200 42WT SWE PO #: 2172641-1-1 MSF: 3.226 SIZE: 19.11 x 34</td>
<td>1,000 / 694</td>
<td>694</td>
<td>86.12/MSF</td>
<td>277.83</td>
</tr>
<tr>
<td>260126150 44C PO #: 2173386-1-1 MSF: 16.965 SIZE: 28 x 84.10</td>
<td>938 / 1,031</td>
<td>1,031</td>
<td>74.10/MSF</td>
<td>1,257.11</td>
</tr>
<tr>
<td>260126147 32 33WTE PO #: 2173840-1-1 MSF: 3.350 SIZE: 24.06 x 36.04</td>
<td>500 / 546</td>
<td>546</td>
<td>79.13/MSF</td>
<td>265.11</td>
</tr>
<tr>
<td>260126133 200 SWE PO #: 2174564-1-1 MSF: 13.781 SIZE: 16.07 x 31.15</td>
<td>3,600 / 3,780</td>
<td>3,780</td>
<td>67.06/MSF</td>
<td>924.13</td>
</tr>
<tr>
<td>260123042 44C PO #: 2174892-1-1 MSF: 3.871 SIZE: 28.10 x 67.06</td>
<td>15,000 / 289</td>
<td>289</td>
<td>68.32/MSF</td>
<td>264.45</td>
</tr>
<tr>
<td>260123047 48BC PO #: 2174992-1-1 MSF: 4.372 SIZE: 30.15 x 37</td>
<td rowspan="2">500 / 550</td>
<td rowspan="2">550</td>
<td rowspan="2">124.86/MSF</td>
<td rowspan="2">545.90</td>
</tr>
<tr>
<td></td>
</tr>
</table>


REMIT TO:

Encorr Sheets

5171 E. Francis St.

Ontario, CA 91761


<table>
<tr>
<th>CODE</th>
<th>MSF TOTAL</th>
<th>INVOICE AMOUNT</th>
<th>TAX %</th>
<th>TAX AMOUNT</th>
<th>NET AMOUNT DUE</th>
</tr>
<tr>
<td>Partial Complete</td>
<td>229.605</td>
<td></td>
<td></td>
<td></td>
<td>CONTINUED</td>
</tr>
</table>


<figure>

®

FSC
www.fsc.org

</figure>


The mark of
responsible forestry
FSC® C150215

Only products that are identified as such on this document are
chain of custody FSC® certified or SFI®certified.
Unless noted otherwise, all products are SFI® Certified Sourcing.


<figure>

SUSTAINABLE
FORESTRY
INITIATIVE
SFI-01 552

SGSNA-SFICOC-606142
THANK YOU

</figure>


Printed: 1/27/2026 9:11:29AM

<!-- PageBreak -->


<figure>

Encore
SHEETS"

</figure>


Encorr Sheets
5171 E. Francis Street
Ontario, CA 91761
PH FAX


# INVOICE


<table>
<tr>
<th>SALESMAN NO.</th>
<th>BOL NUMBER</th>
<th>INVOICE DATE</th>
<th>TERMS</th>
<th>INVOICE NUMBER</th>
</tr>
<tr>
<td></td>
<td>168664</td>
<td>01/27/2026</td>
<td>3% 10, 2% 30, Net 45</td>
<td>255812</td>
</tr>
</table>


SOLD TO

SHIP TO

Liberty Packaging
13100 Danielson Street
Poway, CA 92064

0000008

Liberty Tijuana
Sor Juana Ines La Cruz #20154-A
Tijuana, BC, MX 22440


<table>
<tr>
<th>DESCRIPTION</th>
<th colspan="2">P/C QTY ORD / QTY INV</th>
<th>QTY SHIPPED</th>
<th>UNIT PRICE</th>
<th>AMOUNT</th>
</tr>
<tr>
<td>260122110 32C PO #: 2175139-1-1 MSF: 3.304 SIZE: 24.02 × 60.08</td>
<td></td>
<td>10,000 / 326</td>
<td>326</td>
<td>50.89/MSF</td>
<td>168.16</td>
</tr>
<tr>
<td>260126126 200 SWB PO #: 2175584-1-1 MSF: 18.345 SIZE: 16.14 x 48.06</td>
<td colspan="2">3,200 / 3,236</td>
<td>3,236</td>
<td>67.06/MSF</td>
<td>1,230.20</td>
</tr>
<tr>
<td>260123066 32E PO #: 2175812-1-1 MSF: 5.172 SIZE: 20.07 x 38.11</td>
<td colspan="2">900 / 942</td>
<td>942</td>
<td>69.39/MSF</td>
<td>358.91</td>
</tr>
<tr>
<td>260126121 44C PO #: 2175858-1-1 MSF: 4.465 SIZE: 24.02 x 77.04</td>
<td colspan="2">300 / 345</td>
<td>345</td>
<td>81.85/MSF</td>
<td>365.47</td>
</tr>
<tr>
<td>260126120 44C PO #: 2175902-1-1 MSF: 5.744 SIZE: 19.03 x 75.08</td>
<td colspan="2">520 / 571</td>
<td>571</td>
<td>74.10/MSF</td>
<td>425.66</td>
</tr>
<tr>
<td>260126151 44C PO #: 2176149-1-1 MSF: 3.006 SIZE: 37 x 22.10</td>
<td colspan="2" rowspan="2">450 / 517</td>
<td rowspan="2">517</td>
<td rowspan="2">81.85/MSF</td>
<td rowspan="2">246.01</td>
</tr>
<tr>
<td></td>
</tr>
</table>


REMIT TO:

Encorr Sheets

5171 E. Francis St.

Ontario, CA 91761


<table>
<tr>
<th>CODE</th>
<th>MSF TOTAL</th>
<th>INVOICE AMOUNT</th>
<th>TAX %</th>
<th>TAX AMOUNT</th>
<th>NET AMOUNT DUE</th>
</tr>
<tr>
<td>Partial Complete</td>
<td>229.605</td>
<td></td>
<td></td>
<td></td>
<td>CONTINUED</td>
</tr>
</table>


<figure>

®

FSC
www.fsc.org

</figure>


The mark of
responsible forestry
FSC® C150215

Only products that are identified as such on this document are
chain of custody FSC® certified or SFI®certified.
Unless noted otherwise, all products are SFI® Certified Sourcing.


<figure>

SUSTAINABLE
FORESTRY
INITIATIVE
SFI-01 552

SGSNA-SFICOC-606142
THANK YOU

</figure>


Printed: 1/27/2026 9:11:29AM

<!-- PageBreak -->


<figure>

Encore
SHEETS"

</figure>


Encorr Sheets
5171 E. Francis Street
Ontario, CA 91761
PH FAX


# INVOICE


<table>
<tr>
<th>SALESMAN NO.</th>
<th>BOL NUMBER</th>
<th>INVOICE DATE</th>
<th>TERMS</th>
<th>INVOICE NUMBER</th>
</tr>
<tr>
<td></td>
<td>168664</td>
<td>01/27/2026</td>
<td>3% 10, 2% 30, Net 45</td>
<td>255812</td>
</tr>
</table>


SOLD TO

SHIP TO

Liberty Packaging
13100 Danielson Street
Poway, CA 92064

0000008

Liberty Tijuana
Sor Juana Ines La Cruz #20154-A
Tijuana, BC, MX 22440


<table>
<tr>
<th>DESCRIPTION</th>
<th>P/C QTY ORD / QTY INV</th>
<th>QTY SHIPPED</th>
<th>UNIT PRICE</th>
<th>AMOUNT</th>
</tr>
<tr>
<td>260126152 44C PO #: 2176149-2-1 MSF: 4.550 SIZE: 37 x 34.04</td>
<td>450 / 517</td>
<td>517</td>
<td>81.85/MSF</td>
<td>372.40</td>
</tr>
<tr>
<td>260126149 44C PO #: 2176149-3-1 MSF: 1.709 SIZE: 21.04 x 22.10</td>
<td>450 / 512</td>
<td>512</td>
<td>81.85/MSF</td>
<td>139.92</td>
</tr>
<tr>
<td>260126118 32E PO #: 2176184-1-1 MSF: 15.049 SIZE: 35.15 x 20.12</td>
<td>2,800 / 2,906</td>
<td>2,906</td>
<td>50.89/MSF</td>
<td>765.83</td>
</tr>
<tr>
<td>260123038 32E PO #: 2176216-1-1 MSF: 18.523 SIZE: 24.11 x 30.10</td>
<td>3,360 / 3,528</td>
<td>3,528</td>
<td>50.89/MSF</td>
<td>942.66</td>
</tr>
<tr>
<td>260123279 200 SWE PO #: 2176808-1-1 MSF: 17.682 SIZE: 16 x 36.06</td>
<td>4,167 / 4,375</td>
<td>4,375</td>
<td>67.06/MSF</td>
<td>1,185.78</td>
</tr>
<tr>
<td>260126112 44C PO #: 2176845-1-1 MSF: 6.153 SIZE: 48.14 × 88</td>
<td rowspan="2">180 / 206</td>
<td rowspan="2">206</td>
<td rowspan="2">74.10/MSF</td>
<td rowspan="2">455.93</td>
</tr>
<tr>
<td></td>
</tr>
</table>


REMIT TO:

Encorr Sheets

5171 E. Francis St.

Ontario, CA 91761


<table>
<tr>
<th>CODE</th>
<th>MSF TOTAL</th>
<th>INVOICE AMOUNT</th>
<th>TAX %</th>
<th>TAX AMOUNT</th>
<th>NET AMOUNT DUE</th>
</tr>
<tr>
<td>Partial Complete</td>
<td>229.605</td>
<td></td>
<td></td>
<td></td>
<td>CONTINUED</td>
</tr>
</table>


<figure>

®

FSC
www.fsc.org

</figure>


The mark of
responsible forestry
FSC® C150215

Only products that are identified as such on this document are
chain of custody FSC® certified or SFI®certified.
Unless noted otherwise, all products are SFI® Certified Sourcing.


<figure>

SUSTAINABLE
FORESTRY
INITIATIVE
SFI-01 552

SGSNA-SFICOC-606142
THANK YOU

</figure>


Printed: 1/27/2026 9:11:29AM

<!-- PageBreak -->


<figure>

Encore
SHEETS"

</figure>


Encorr Sheets
5171 E. Francis Street
Ontario, CA 91761
PH FAX


## INVOICE


<table>
<tr>
<th>SALESMAN NO.</th>
<th>BOL NUMBER</th>
<th>INVOICE DATE</th>
<th>TERMS</th>
<th>INVOICE NUMBER</th>
</tr>
<tr>
<td></td>
<td>168664</td>
<td>01/27/2026</td>
<td>3% 10, 2% 30, Net 45</td>
<td>255812</td>
</tr>
</table>


SOLD TO

SHIP TO

Liberty Packaging
13100 Danielson Street
Poway, CA 92064

0000008

Liberty Tijuana
Sor Juana Ines La Cruz #20154-A
Tijuana, BC, MX 22440


<table>
<tr>
<th>DESCRIPTION</th>
<th>P/C</th>
<th>QTY ORD / QTY INV</th>
<th>QTY SHIPPED</th>
<th>UNIT PRICE</th>
<th>AMOUNT</th>
</tr>
<tr>
<td>260126104 200 42WT SWB PO #: 2176852-1-1 MSF: 7.389 SIZE: 45.08 x 74</td>
<td></td>
<td>275 / 316</td>
<td>316</td>
<td>78.21/MSF</td>
<td>577.87</td>
</tr>
<tr>
<td>260126111 32E PO #: 2176862-1-1 MSF: 8.292 SIZE: 78 x 97.08</td>
<td></td>
<td>125 / 157</td>
<td>157</td>
<td>50.89/MSF</td>
<td>421.96</td>
</tr>
<tr>
<td>260126105 200 42WT SWB PO #: 2176865-1-1 MSF: 3.609 SIZE: 73 x 56.08</td>
<td></td>
<td>110 / 126</td>
<td>126</td>
<td>86.12/MSF</td>
<td>310.81</td>
</tr>
<tr>
<td>260126119 32 33WTE PO #: 2176874-1-1 MSF: 44.316 SIZE: 27.06 x 39.15</td>
<td></td>
<td>5,600 / 5,837</td>
<td>5,837</td>
<td>60.30/MSF</td>
<td>2,672.27</td>
</tr>
<tr>
<td>260126102 32C PO #: 2177053-1-1 MSF: 16.733 SIZE: 13.14 x 27.12</td>
<td></td>
<td>6,000 / 6,258</td>
<td>6,258</td>
<td>50.89/MSF</td>
<td>851.54</td>
</tr>
<tr>
<td>Total Discount will be 450.77 IF PAID BEFORE 2/6/2026. DISCOUNT TERMS: 3.00 % 10</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


REMIT TO:

Encorr Sheets

5171 E. Francis St.

Ontario, CA 91761


<table>
<tr>
<th rowspan="2">CODE Partial Complete</th>
<th>MSF TOTAL</th>
<th>INVOICE AMOUNT</th>
<th>TAX %</th>
<th>TAX AMOUNT</th>
<th>NET AMOUNT DUE</th>
</tr>
<tr>
<td>229.605</td>
<td>15,025.91</td>
<td>0.00%</td>
<td>0.00</td>
<td>15,025.91</td>
</tr>
</table>


<figure>

®

FSC
www.fsc.org

</figure>


The mark of
responsible forestry
FSC® C150215

Only products that are identified as such on this document are
chain of custody FSC® certified or SFI®certified.
Unless noted otherwise, all products are SFI® Certified Sourcing.


<figure>

SUSTAINABLE
FORESTRY
INITIATIVE
SFI-01 552

SGSNA-SFICOC-606142
THANK YOU

</figure>


Printed: 1/27/2026 9:11:29AM
