# CHADWICKS-NonInv.pdf

<figure>

CHADWICKS
LET'S GET IT DONE

</figure>


The Panelling Centre
kitchens appliances wardrobes

CHADWICKS Port Road Letterkenny CO. DONEGAL F92CK85
Phone 074 9121055 e-Mail : creditcontroller20@chadwicks.ie


# O/I ACCOUNT STATEMENT


<table>
<tr>
<td>Account</td>
<td>: E &amp; I ENGINEERING LTD</td>
</tr>
<tr>
<td rowspan="2">Address</td>
<td>: BALLYDEROWEN</td>
</tr>
<tr>
<td>: BURNFOOT : CO. DONEGAL F93HYH4</td>
</tr>
</table>


<table>
<tr>
<td>Account No.</td>
<td>: 260572</td>
<td>Page 1 of 1</td>
</tr>
<tr>
<td>Printed By</td>
<td colspan="2">: VALERIE DELAP [28/1/26]</td>
</tr>
<tr>
<td>Date</td>
<td colspan="2">: 31/12/25</td>
</tr>
</table>


<table>
<tr>
<th>Date</th>
<th>Transaction Type</th>
<th>Our Reference</th>
<th>Your Reference</th>
<th>Amount</th>
<th>Balance</th>
</tr>
<tr>
<td>9/7/25</td>
<td>Invoice</td>
<td>LY176439</td>
<td></td>
<td>20.39</td>
<td>20.39</td>
</tr>
<tr>
<td>13/10/25</td>
<td>Invoice</td>
<td>LY183425</td>
<td>14075028179</td>
<td>2444.00</td>
<td>2444.00</td>
</tr>
<tr>
<td>14/10/25</td>
<td>Invoice</td>
<td>LY183508</td>
<td>14075028413</td>
<td>468.60</td>
<td>468.60</td>
</tr>
<tr>
<td>20/10/25</td>
<td>Invoice</td>
<td>LY183883</td>
<td>14075028723 REV</td>
<td>409.13</td>
<td>0.00</td>
</tr>
<tr>
<td>30/10/25</td>
<td>Invoice</td>
<td>LY184696</td>
<td>14075029835</td>
<td>410.83</td>
<td>0.00</td>
</tr>
<tr>
<td>18/11/25</td>
<td>Invoice</td>
<td>LY186185</td>
<td>14075029372</td>
<td>617.50</td>
<td>0.00</td>
</tr>
<tr>
<td>18/11/25</td>
<td>Invoice</td>
<td>LY186186</td>
<td>14075031084</td>
<td>1267.50</td>
<td>0.00</td>
</tr>
<tr>
<td>21/11/25</td>
<td>Invoice</td>
<td>LY186479</td>
<td>14075031817</td>
<td>2444.00</td>
<td>0.00</td>
</tr>
<tr>
<td>26/11/25</td>
<td>Invoice</td>
<td>LY186805</td>
<td>14075031084</td>
<td>195.00</td>
<td>0.00</td>
</tr>
<tr>
<td>2/12/25</td>
<td>Invoice</td>
<td>LY187289</td>
<td>14075032661</td>
<td>43.02</td>
<td>43.02</td>
</tr>
<tr>
<td>2/12/25</td>
<td>Invoice</td>
<td>LY187363</td>
<td>14075032597</td>
<td>159.00</td>
<td>159.00</td>
</tr>
<tr>
<td>9/12/25</td>
<td>Payment Received</td>
<td></td>
<td></td>
<td>-819.96</td>
<td>0.00</td>
</tr>
<tr>
<td>12/12/25</td>
<td>Invoice</td>
<td>LY188172</td>
<td>14075033429</td>
<td>2444.00</td>
<td>2444.00</td>
</tr>
<tr>
<td>15/12/25</td>
<td>Invoice</td>
<td>LY188291</td>
<td>14075033904</td>
<td>1634.83</td>
<td>1634.83</td>
</tr>
<tr>
<td>15/12/25</td>
<td>Invoice</td>
<td>LY188292</td>
<td>14075033781</td>
<td>110.25</td>
<td>110.25</td>
</tr>
<tr>
<td>31/12/25</td>
<td>Payment Received</td>
<td></td>
<td></td>
<td>-4524.00</td>
<td>0.00</td>
</tr>
</table>


<table>
<tr>
<th>DEC 2025</th>
<th>NOV 2025</th>
<th>OCT 2025</th>
<th>SEP 2025</th>
<th>AUG 25 &amp; PREV</th>
<th>TOTAL DUE</th>
</tr>
<tr>
<td>4391.10</td>
<td>0.00</td>
<td>2912.60</td>
<td>0.00</td>
<td>20.39</td>
<td>7324.09</td>
</tr>
</table>


Payment Now Overdue EURO 2932.99 [Due On 31/12/25]

Bank Account Details

Bank of Ireland
6 Lower O'Connell St
Dublin 1
Ireland

Phone: 01 8787870


<table>
<tr>
<td>Account Name</td>
<td>Chadwicks Group Ltd</td>
</tr>
<tr>
<td>IBAN</td>
<td>IE45BOFI90003312550181</td>
</tr>
<tr>
<td>BIC Code</td>
<td>B0FIIE2D</td>
</tr>
</table>


<!-- PageFooter="Chadwicks Group Ltd. c/o Grafton Group plc, The Hive, Carmanhall Road, Sandyford Business Park, Dublin 18, D18 Y2C9. Reg. No. 3510. VAT Reg. No. IE 8Q53150B WEEE No. 2572W" -->

Source : eMail
