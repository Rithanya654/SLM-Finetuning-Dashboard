# RAMPART SUPPLY INC.pdf

\*


<figure>

Rampart
SUPPLY
a division of CREGGER COMPANY INC.

</figure>


Cregger Company #71 - Col. Springs
1801 N UNION BLVD
COLORADO SPRINGS CO 80909-2228
719-471-7200

"Our Pride Makes The Difference"


# INVOICE


<table>
<tr>
<th>INVOICE NUMBER</th>
<th>INVOICE DATE</th>
</tr>
<tr>
<td>S7940707.001</td>
<td>02/02/26</td>
</tr>
<tr>
<td colspan="2">PLEASE REMIT PAYMENT TO:</td>
</tr>
<tr>
<td colspan="2">RAMPART COS REMIT-TO PO BOX 1089</td>
</tr>
<tr>
<td colspan="2">COLORADO SPRINGS CO 80901-1089</td>
</tr>
<tr>
<td colspan="2">719-482-7335</td>
</tr>
<tr>
<td colspan="2">TO PAY/VIEW ONLINE:</td>
</tr>
<tr>
<td colspan="2">https://rampartsupply.com/login</td>
</tr>
</table>


MURPHY COMPANY
12789 EMERSON ST
THORNTON CO 80241-3396

SHIPPING ADDRESS
COS SHOP-MURPHY - COSSHOP
4630 FORGE RD STE D
COLORADO SPRINGS CO 80907-3552


<table>
<tr>
<th>CUSTOMER NUMBER</th>
<th>CUSTOMER ORDER NUMBER</th>
<th>ORDERED BY</th>
<th>SALESPERSON</th>
</tr>
<tr>
<td>57628</td>
<td>969313</td>
<td>KIMBERLY CORONADO</td>
<td>KEVIN PRUITT - 71</td>
</tr>
</table>


<table>
<tr>
<th>WRITER</th>
<th>SHIP VIA</th>
<th>TERMS</th>
<th>SHIP DATE</th>
<th>ORDER DATE</th>
</tr>
<tr>
<td>DAVE OLSEN - 75</td>
<td>OT OUR-TRUCK</td>
<td>NET 30 DAYS</td>
<td>02/02/26</td>
<td>02/02/26</td>
</tr>
</table>


<table>
<tr>
<th>PART NO</th>
<th>DESCRIPTION</th>
<th>ORDER QTY</th>
<th>SHIP QTY</th>
<th>NET PRICE</th>
<th>EXTENDED PRICE</th>
</tr>
<tr>
<td>10137</td>
<td>COP-LS-12X60 1/2" X 60' L SOFT COPPER PIPE</td>
<td>60</td>
<td>60</td>
<td>5.370ft</td>
<td>322.20</td>
</tr>
</table>


<figure>

=
S

O

</figure>


Want to manage your billing on your time schedule?
Invoices and Statements are now available 24/7 for you to view, download, pay, and even import into your accounting software.
Create your account and learn more today by visiting https://rampartsupply.com and clicking on the "Bill Pay" link in the navigation
menu.

Have questions? Contact our billing team at billtrust@rampartsupply.com or call 719.482.7335 (Colo. Springs/Pueblo) or
303.575.9875 (Denver).

Invoice is due by 03/04/26.

02-02-2026 01:11:19 PM
S7940707.001

82

MARK


<table>
<tr>
<td>SUB TOTAL</td>
<td>322.20</td>
</tr>
<tr>
<td>S&amp;H CHGS</td>
<td>0.00</td>
</tr>
<tr>
<td>SALES TAX</td>
<td>0.00</td>
</tr>
<tr>
<td>INVOICE TOTAL</td>
<td>322.20</td>
</tr>
</table>


Past due invoices are subject to up to a 2% per month service charge.
Returns of merchandise require company approval and are subject to a minimum 15% restocking fee. Items defined by the
company as Non-stock are non-cancellable and non-refundable for any reason. Claims for shortages or damage in transit must
be filed with the transportation company. Paying via check authorizes us to make a one-time electronic fund transfer from your
account or process payment as a check transaction.

<!-- PageNumber="Page 1 of 1" -->
