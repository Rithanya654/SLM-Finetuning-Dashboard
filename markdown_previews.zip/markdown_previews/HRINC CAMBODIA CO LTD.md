# HRINC CAMBODIA CO LTD.pdf

<figure>

HRINC. Cambodia

</figure>


# 6ม3 5 เกษ5 มิล ศรี (เอยหูยว) ภูมิกซีซี HRINC(Cambodia) Co., Ltd


<table>
<tr>
<td colspan="4">แถวมูเตาณาหมู มตบ (VAT TIN) L001-100084478</td>
</tr>
<tr>
<td>ราญพบผู้าระ สูะเถระ</td>
<td colspan="2">10 ผู้ส์ 242 y</td>
<td>บุโรพุทส์ บุชุ2</td>
</tr>
<tr>
<td>Address Nº</td>
<td>10</td>
<td>Street 242</td>
<td>Commune/Sangkat Chaktumuk</td>
</tr>
<tr>
<td>หุง/[ ชุด/ชญา ผู้สเตต</td>
<td colspan="2">12สุ/ภสตรี ภู่โตต</td>
<td>ธูรณีตณะ ๐๒๓ ๒๑๑ ๔๓๗</td>
</tr>
<tr>
<td>Town/District/Khan Daun Penh</td>
<td colspan="2">Province/City Phnom Penh</td>
<td>Telephone Nº 023 211 437</td>
</tr>
<tr>
<td colspan="4">HIUNU / E-mail: accounts@hrinc.com.kh</td>
</tr>
</table>


5 9,2555555558555
TAX INVOICE


<table>
<tr>
<th>สถิติพิธ / Customer:</th>
<th>Chinnarat Buttho</th>
</tr>
<tr>
<td>เณกะเยบุ๊ก บุคลิชิตร: Company name / Customer:</td>
<td>ซีรี (ณิตูบุรี) กีฬีมี,ภิญพีชี. VERTIV (SINGAPORE) PTE.LTD.</td>
</tr>
<tr>
<td>รองผบผ้าละ Address:</td>
<td>๑๕๑ รุฬ ณีธ #๐๕-๐๔ ตำ ถิง ฝาก ณิตบุรี Gab(2 9151 Lorong Chuan, #05-04 New Tech Park, 556741 Singapore</td>
</tr>
<tr>
<td>ธูรณ์ตูและ Telephone Nº</td>
<td>66 2481 6889</td>
</tr>
<tr>
<td colspan="2">เขมนูญญาณาหมู มทบ(VAT TIN) 198205102D</td>
</tr>
<tr>
<td colspan="2">เถระบฤทธิญารมณ์มติชิพs Customer PO: None</td>
</tr>
</table>


<table>
<tr>
<td>โถ2ฟู่ฟริคพบา / Invoice Nº :</td>
<td>HRKH-TI-26-0151</td>
</tr>
<tr>
<td>กาญบริษ 9 / Date :</td>
<td>31-01-2026</td>
</tr>
<tr>
<td>ชุดกิฌาถ์ / Due by:</td>
<td>15-02-2026</td>
</tr>
</table>


<table>
<tr>
<td>โถะห์นาน (Project Ref.):</td>
<td>EMS1112</td>
</tr>
<tr>
<td>หูกเลย์โคนส์ซาฟ้ (Project M.):</td>
<td>PAN Pagnavorth (Mr.)</td>
</tr>
<tr>
<td>พลูผการคำถาม (Project A.):</td>
<td>SEANG Sokly (Ms.)</td>
</tr>
</table>


<table>
<tr>
<th>ถ.ร Nº</th>
<th>บริษภพ แบกหมู บุ ยุทธ์ธัญ Description</th>
<th>มาลา บุ บริษาณา Rate/Quantity</th>
<th>ซูฉกลา Agreed Fee/Unit Price</th>
<th>โรงภาหมู บุ เชอริญ Amount in USD Currency</th>
</tr>
<tr>
<td>1</td>
<td>Fee as per Contract: EMS1112</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>2</td>
<td>ฮิราพรรคมีเหษุ กุม12 บกภ ๓๋๒๐๒๖ Business Expense in January-2026_Mr. Bunyeng</td>
<td>1.0</td>
<td>15.72</td>
<td>$ 15.72</td>
</tr>
<tr>
<td colspan="3"></td>
<td>ชุบ / Sub Total</td>
<td>$ 15.72</td>
</tr>
<tr>
<td colspan="4">1กรณีตามบรุษ 90% / VAT 10%</td>
<td>$ 1.57</td>
</tr>
<tr>
<td colspan="4">ณุบรูช / Grand Total</td>
<td>$ 17.29</td>
</tr>
<tr>
<td colspan="2">มาลาบูทนาที / Exchange Rate : 1 US Dollar = 4026.0</td>
<td colspan="2">สรุปษ (ฟุ้๗) / Grand Total (KH Riels)</td>
<td>៛ 69,610</td>
</tr>
</table>


ญุษณีการอุราสํภารพระคณาธีตราคารอามิถุภาษ (Please make payment to the following bank account detail)


<table>
<tr>
<td>Beneficiary Account Name :</td>
<td>HRINC (Cambodia) Co., Ltd</td>
<td></td>
<td></td>
</tr>
<tr>
<td>Beneficiary Account Number :</td>
<td>000604527</td>
<td colspan="2"></td>
</tr>
<tr>
<td>Beneficiary Account Currency :</td>
<td>USD</td>
<td></td>
<td></td>
</tr>
<tr>
<td>Beneficiary Bank Name :</td>
<td>ADVANCED BANK OF ASIA LTD</td>
<td>Correspondent Banks</td>
<td>Standard Chartered Bank</td>
</tr>
<tr>
<td>Beneficiary Bank Address :</td>
<td>Phnom Penh, Cambodia</td>
<td>Correspondent Bank Address</td>
<td>NEW YORK , USA.</td>
</tr>
<tr>
<td>Beneficiary SWIFT Number :</td>
<td>ABAAKHPP</td>
<td>Correspondent SWIFT CODE</td>
<td>SCBLUS33</td>
</tr>
</table>


ยาฮูเขา ธิน เณกะมุกริญ
Customer's Signature & Name
ถูกณ์: ฌาย์เขียดทุกข์มูลรัญ ฌาย์หมูและซูภย์มูกณฑ์
Note: Original Invoice for Customer, copied invoice for seller


<figure>

Ho

HRINC (CAMBODIA)
Co.,Liel

</figure>


บาทแบขา ซิ่ง แกะมูกเก่
Seller's Signature & Name

<!-- PageBreak -->


<figure>

HRINC. Cambodia

</figure>


Project Name: Vertiv (SINGAPORE) Co.,Ltd
Date: Saturday, January 31, 2026


<table>
<tr>
<th>#</th>
<th>Date:</th>
<th>EXPENSE CODE</th>
<th>Comments</th>
<th>Dollar Amount</th>
<th>TOTAL USD</th>
</tr>
<tr>
<td>1</td>
<td>31-Jan-2026</td>
<td>Business expense</td>
<td>Mobile Phone in January-2026 for Mr.Bunyeng</td>
<td>$ 6.00</td>
<td>$ 6.00</td>
</tr>
<tr>
<td>2</td>
<td>31-Jan-2026</td>
<td>Business expense</td>
<td>Fuel/Gasoline in January-2026 for Mr. Bunyeng</td>
<td>$ 7.65</td>
<td>$ 7.65</td>
</tr>
<tr>
<td>3</td>
<td>31-Jan-2026</td>
<td>Other Tax</td>
<td>Gross tax on Business expense in January-2026 for Mr.Bunyeng</td>
<td>$ 1.91</td>
<td>$ 1.91</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>$ 15.56</td>
<td>$ 15.56</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>1% compliance Tax</td>
<td>$ 0.16</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Grand Total Expsene</td>
<td>$ 15.72</td>
</tr>
</table>


Manager Authorisation
