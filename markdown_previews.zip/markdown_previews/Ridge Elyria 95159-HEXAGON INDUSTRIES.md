# Ridge Elyria 95159-HEXAGON INDUSTRIES.jpg

<figure>

Hexagon Industries,Inc.

</figure>


1135 IVANHOE ROAD
CLEVELAND, OH 44110 USA
PHONE (216) 249-0200 · FAX (216) 249-1441
ISO 9001:2015 CERTIFIED

BILL TO
31A1
RIDGE TOOL COMPANY
(ELYRIA DOMESTIC)
P.O. BOX 270496
ST.LOUIS, MO 63127


<table>
<tr>
<th></th>
<th>DATE</th>
<th>NUMBER</th>
</tr>
<tr>
<td>INVOICE *</td>
<td>01/29/26</td>
<td>95159</td>
</tr>
</table>


PLEASE REMIT TO:

P.O.Box 71341

Cleveland, OH 44191-0541

SHIP TO

RIDGE TOOL COMPANY

229 WINCKLES STREET

ELYRIA, OW 44035

VIa: DAYTON FREIGHT
QUANTITY


<table>
<tr>
<th></th>
<th>SHIPPED</th>
<th>UM</th>
<th>PRICE</th>
<th>AMOUNT</th>
</tr>
<tr>
<td>1 PN 980-3066-19</td>
<td>40.0</td>
<td>EA</td>
<td>14.0460</td>
<td>4,775.64</td>
</tr>
<tr>
<td>RATCHET, 1/2"DRIVE (050-506-914)</td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td colspan="3">INVOICE TOTAL</td>
<td>4,775.64</td>
</tr>
</table>


Your PO# 1479203-001

Our Order#185746

Terms: NET-30

Salesman

FOR : OUR PLANT

These articles may be imported. The requirements of the 19 U.S.C. 1304
and 19 C.F.R. part 134 requires that if imported articles are repackaged,
the country of origin must be marked legibly on the new container.

BG
I
