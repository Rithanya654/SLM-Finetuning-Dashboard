# invoice-9378913-WESTBURNE ELECTRIC.pdf

<figure>

Westburne

</figure>


REXEL GROUP

R
P
WESTBURNE ELECTRIC SUPPLY (MIDWEST)

E

A

DIVISION OF REXEL CANADA ELECTRICAL INC.

M

Y

PO BOX 1220 STN B MISSISSAUGA ON L4Y 3W5

I

E

CREDIT DEPT 1-888-712-4020 / 905-712-4040

T

R

T

À

O

00539-INVSTM G0801 L001 AUTO

000001

S

V
☒

NEW FLYER INDUSTRIES LIMITED
PO BOX 245 TRANSCONA PO

O

E

L

N

711 KERNAGHAN AVE

D

D

WINNIPEG MB MB R2C3T4

U

T

O

À


# INVOICE


<table>
<tr>
<th>INVOICE DATE : DATE DE FACTURE : Jan 30 26</th>
<th>INVOICE NO : NO DE FACTURE : 9378913</th>
</tr>
<tr>
<td>OUR ORDER NO .: NOT. NO COM .: 4160970-01</td>
<td>TERMS - CONDITIONS NET 60TH</td>
</tr>
<tr>
<td>CUSTOMER ORDER NO .: N0 COMM DU CLIENT:</td>
<td>AAAL 1718</td>
</tr>
</table>


SELLING LOCATION / POINT DE VENTE
WESTBURNE WPG BRANCH VMI
VMI - WPG BRANCH
1313 KING EDWARD ST.
WINNIPEG
R3H0R6

SHIP TO / EXPÉDIA À

NEW FLYER OF AMERICA INC

KANBAN

106 NATIONAL DRIVE

ANNISTON AL *362070000 US

This document is subject to our standard Terms and conditions available upon request or at our website www.westburne.ca
Ce document est soumis à nos conditions de vente standard disponibles sur demande ou sur notre site Web à l'adresse www.westburne.ca

CUSTOMER NO CLIENT
70010

CUSTOMER PROV. LIC#

EXPORT

COMMANDE
Jan 28 26

Jan 29 26

SHIP VIA
OUR TRUCK


<table>
<tr>
<th># ITEM</th>
<th>DESCRIPTION</th>
<th>B/O A/V</th>
<th>QTY.SHP'D QTE.EXP.</th>
<th>U/M</th>
<th>UNIT PRICE PRIX UNITAIRE</th>
<th>NET</th>
</tr>
<tr>
<td>THSTC347FR</td>
<td>TC347FR CABLE TIE 1" FLMRTD MTG BAS 277973</td>
<td>.00</td>
<td>150.0</td>
<td>C</td>
<td>USD: $48.00</td>
<td>USD: $0.00 USD: $72.00</td>
</tr>
<tr>
<td>WPGS2CM258HIRHSH1</td>
<td>S2CM258HIRHSH1 TYTON 1/4" BOLT 293522 COUNTRY OF ORIGIN UNITED STATES OF AMERICA</td>
<td>.00</td>
<td>40.0</td>
<td>EA</td>
<td>USD: $0.30</td>
<td>USD: $0.00 USD: $12.00</td>
</tr>
</table>


ORDERED BY : 7400-7600
CHARGE TO : 7400-7600

MESSAGE

VMI
SELL-VENTE

VMI
SHIP EXP.

VMI
A/R - C/R


<table>
<tr>
<td>SUBTOTAL</td>
<td>$84.00</td>
</tr>
<tr>
<td>GST REG. NO. Nº LIC.</td>
<td>$0.00</td>
</tr>
<tr>
<td>SUBTOTAL</td>
<td>$84.00</td>
</tr>
<tr>
<td>PST REG. NO. Nº LIC. PROVINCIAL TAX</td>
<td>$0.00</td>
</tr>
<tr>
<td>TOTAL</td>
<td>USD: $84.00</td>
</tr>
</table>


SHIP JAN 30

$84.00
INTEREST OF 2% PER MONTH ON OVERDUE ACCOUNT (26.8% PER ANNUM).
INTÉRÊT AU TAUX DE 2% PAR MOIS SUR COMPTE EN SOUFFRANCE (26.8% PAR AN).
$0.00 MAY BE DEDUCTED FROM BALANCE IF PAID IN FULL WITHIN TERMS
Escompte de $0.00 peut être déduit si facture payée en entier avant la date d'escompte limite

ORDER DATE

SHIP DATE EXPÉDIÉ
