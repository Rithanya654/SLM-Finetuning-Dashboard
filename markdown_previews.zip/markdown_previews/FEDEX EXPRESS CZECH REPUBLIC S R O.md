# FEDEX EXPRESS CZECH REPUBLIC S R O.pdf

<figure>

FedEx
®

</figure>


Platba na účet:
FedEx Express Czech Republic s.r.o.
Radlická 354/107b
158 00 - Praha 5 Radlice
Czech Republic

4008-226018738-06698-03987-1of4-O5G-5B1 06698

Kontakt:fedex.com/cs-cz/invoice

DJČ: CZ15888959
IČ: 15888959

Číslo účtu: 1000503630

BIC/SWIFT Kód: INGBCZPP

Název banky: ING Bank

IBAN: CZ6035000000001000503630

Číslo pobočky: 3500

Online: https://www.fedex.com/payment/

<!-- PageNumber="Strana 1 / 1" -->

QR kód platebního
portálu FedEx:

Zákaznický účet:

953106515

Číslo faktury:

535691701

Datum vystavení (DUZP):

26/01/2026

Datum splatnosti:

Po obdržení

Splatná částka:

7.877,18 CZK

DIČ zákazníka:
CZ62502093

VERTIV CZECH REPUBLIC ŚRO
BLANKA HRONKOVA
NISOVICE 9
38701 VOLYNE
CZECH REPUBLIC

003987


# Faktura za cla a dane


<table>
<tr>
<th>Číslo zásilky</th>
<th>Datum odeslání</th>
<th>Služba</th>
<th>Reference</th>
<th>Importní clo</th>
<th>Importní daň</th>
<th colspan="2">Další poplatky zdanitelné</th>
<th>Další poplatky nazdanitelné</th>
<th>Celkem</th>
</tr>
<tr>
<td>888012817310</td>
<td>19/01/2026</td>
<td>Economy Service</td>
<td>test Sturma</td>
<td>0,00</td>
<td>0,00</td>
<td colspan="2">0,00</td>
<td>507,18</td>
<td>507,18</td>
</tr>
<tr>
<td colspan="2">Objemová hmotnost</td>
<td>Fakturovaná váha 6,40 kg</td>
<td>Cena</td>
<td></td>
<td></td>
<td colspan="2">Stanovená</td>
<td>částka (USD)</td>
<td>Částka(CZK)</td>
</tr>
<tr>
<td colspan="2">Odesílatel</td>
<td>Příjemce</td>
<td>Speciální</td>
<td>zpracování provize</td>
<td></td>
<td colspan="2"></td>
<td>23,75</td>
<td>507,18</td>
</tr>
<tr>
<td colspan="2">MICHAELA JUZKOVA</td>
<td>JOSH WONG</td>
<td></td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td>VERTIV CZECH</td>
<td>REPUBLIC SRO</td>
<td>VERTIV GROUP CORPORATION</td>
<td rowspan="2"></td>
<td rowspan="4"></td>
<td rowspan="2"></td>
<td colspan="2" rowspan="2"></td>
<td></td>
<td></td>
</tr>
<tr>
<td>NISOVICE 9</td>
<td></td>
<td>1777 YOLANDE AVE</td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="2">38701 VOLYNE CZECH REPUBLIC</td>
<td rowspan="2"></td>
<td rowspan="2">LINCOLN 68521 UNITED STATES</td>
<td rowspan="2"></td>
<td rowspan="2"></td>
<td colspan="2" rowspan="2"></td>
<td rowspan="2"></td>
<td></td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td>Podpis:</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="3">Celkem CZK</td>
<td>507,18</td>
</tr>
<tr>
<th>Číslo zásilky</th>
<th>Datum odeslání</th>
<th>Služba</th>
<th>Reference</th>
<th>Importni clo</th>
<th>Importní daň</th>
<th colspan="2">Další poplatky zdanitelné</th>
<th>Další poplatky nezdanitelné</th>
<th>Celkem</th>
</tr>
<tr>
<td>486827604100</td>
<td>08/01/2026</td>
<td>Economy Service</td>
<td>78255-3</td>
<td>7.006,00</td>
<td>0,00</td>
<td colspan="2">0,00</td>
<td>364,00</td>
<td>7.370,00</td>
</tr>
<tr>
<td colspan="2">Objemová hmotnost</td>
<td>Fakturovaná váha 24,22 kg</td>
<td>Cena</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Částka(CZK)</td>
</tr>
<tr>
<td>Odesílatel</td>
<td></td>
<td>Příjemce</td>
<td>Poplatek za</td>
<td>platbu předem</td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>364,00</td>
</tr>
<tr>
<td>JORGE ANDRADE</td>
<td></td>
<td>IVANA ZDVORACKOVA</td>
<td>Clo původní</td>
<td></td>
<td></td>
<td colspan="2"></td>
<td></td>
<td>7.006,00</td>
</tr>
<tr>
<td colspan="2">INTERCONNECT SOLUTIONS COMPANY 17595 MT HERRMANN ST</td>
<td>VERTIV CZECH REPUBLIC SRO NISOVICE 9 387 01 VOLYNE</td>
<td rowspan="2"></td>
<td rowspan="2"></td>
<td rowspan="2"></td>
<td colspan="2" rowspan="2"></td>
<td rowspan="2"></td>
<td rowspan="2"></td>
</tr>
<tr>
<td colspan="2">FOUNTAIN VALLEY 92708 UNITED STATES</td>
<td>38701 VOLYNE CZECH REPUBLIC</td>
</tr>
<tr>
<td>Podpis:</td>
<td colspan="2">X.MRZENOVA 19/01/2026</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="2">Celkem CZK</td>
<td>7.370,00</td>
</tr>
</table>


K 1. březnu 2022 společnost Federal Express Czech s.r.o. (i) byla sloučena fúzí se společností TNT Express Worldwide, spol. s r.o. a (ii)
zanikla. Nástupnická společnost byla přejmenována na FedEx Express Czech Republic s.r.o. a její sídlo bylo přemístěno na adresu
Radlická 354/107b, Radlice, 150 00 Praha. V důsledku fúze IČO a DIČ společnosti, která vám poskytuje služby a vystavuje
faktury/dobropisy, je 15888959 (IC) a CZ15888959 (DIČ).

Společnost je registrovaná u Městského soudu v Praze, C1215
Případné námitky je nutné odeslat do 30 dnů. Další informace najdete v Přepravních podmínkách na fedex.com

Dejte nám vědět, co si myslíte o našem fakturačním procesu a fakturách. Navštivte internetové stránky www.fedex.com/cz/feedback1
Chcete-li uhradit fakturu společnosti FedEx, přejděte na následující adresu https://www.fedex.com/payment/ Děkujeme Vám, že využíváte
služeb společnosti FedEx.
Pro více informací týkající se faktur a plateb, prosíme Vás o navštívení fedex.com/cs-cz/invoice


<table>
<tr>
<td>Celní poplatky mimo predmet DPH v EU</td>
<td>CZK</td>
<td>7.513,18</td>
</tr>
<tr>
<td>Manipulacní poplatek zdanitelný 0,00 %</td>
<td>CZK</td>
<td>364,00</td>
</tr>
<tr>
<td>Další poplatky nezdanitelné</td>
<td>CZK</td>
<td>0,00</td>
</tr>
<tr>
<td>DPH na 0,00 %</td>
<td>CZK</td>
<td>0,00</td>
</tr>
<tr>
<td>Celkem k úhradě</td>
<td>CZK</td>
<td>7.877,18</td>
</tr>
</table>


Při platbě prosím uveďte VS = číslo faktury
Podmínky přepravy zásilek společností FedEx Express jsou upraveny v dokumentu “Přepravní podmínky", který je dostupný na www.fedex.com
