# UNITED RENTALS.PDF

<figure>

United Rentals®

</figure>


Job Site

BRANCH DE5
5478 WASHINGTON ST
DENVER CO 80216-1731
303-297-1580
303-297-8889 FAX
MURPHY CO
5400 PECOS ST
DENVER CO 80221-6404

Office: 303-371-6600 Job: 303-371-6600

MURPHY CO DENVER CO
12789 EMERSON ST
THORNTON CO 80241-3396

4 WEEK BILLING
INVOICE
\# 243556169-014


<table>
<tr>
<td>Customer #</td>
<td>: 178621</td>
</tr>
<tr>
<td>Invoice Date</td>
<td>: 02/01/26</td>
</tr>
<tr>
<td>Date Out</td>
<td>: 01/21/25 09:00 AM</td>
</tr>
<tr>
<td>Billed Through</td>
<td>: 02/17/26 00:00</td>
</tr>
<tr>
<td>UR Job Loc</td>
<td>: 5400 PECOS ST, DENVE</td>
</tr>
<tr>
<td colspan="2">UR Job # : 382</td>
</tr>
<tr>
<td colspan="2">Customer Job ID:</td>
</tr>
<tr>
<td>P.O. #</td>
<td>: 896969</td>
</tr>
<tr>
<td>Requested By</td>
<td>: DAVID GERARD</td>
</tr>
<tr>
<td>Approved By</td>
<td>: JASON BROKAW</td>
</tr>
<tr>
<td>Salesperson</td>
<td>: ABRAHAM GUZMAN</td>
</tr>
</table>


Invoice Amount: $381.44


<table>
<tr>
<td rowspan="2">Terms: Payment options: REMIT TO:</td>
<td>Net 30 Days Contact our credit office 704-916-4944</td>
</tr>
<tr>
<td>UNITED RENTALS (NORTH AMERICA), INC. PO BOX 840514 DALLAS TX 75284-0514</td>
</tr>
</table>


<table>
<tr>
<th>RENTAL Qty</th>
<th>ITEMS : Equipment</th>
<th>Description</th>
<th>Minimum</th>
<th>Day</th>
<th>Week</th>
<th>4 Week</th>
<th>Amount</th>
</tr>
<tr>
<td>1</td>
<td>11048013</td>
<td>VERTICAL LIFT 18-20' ELEC SELF PROPELLED Make: GENIE Model: GR-20 Serial: GRP-58422 Meter out: 207.30 Meter</td>
<td>in: . 00</td>
<td>200.00</td>
<td>283.00</td>
<td>357.00</td>
<td>357.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Rental</td>
<td>Subtotal:</td>
<td>357.00</td>
</tr>
</table>


SALES/MISCELLANEOUS ITEMS :


<table>
<tr>
<th>Qty</th>
<th colspan="2">Item</th>
<th>Price</th>
<th>Unit of Measure</th>
<th>Extended Amt.</th>
</tr>
<tr>
<td>1</td>
<td colspan="2">SMM FEE [ SMM/MCI ]</td>
<td>7.140</td>
<td>EACH</td>
<td>7.14</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td>Sales/Misc Subtotal:</td>
<td>7.14</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Agreement Subtotal:</td>
<td>364.14</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td>Tax:</td>
<td>17.30</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td>Total:</td>
<td>381.44</td>
</tr>
</table>


COMMENTS/NOTES :
ONSITE CONTACT: DAVID GERARD
Billing period: 28 Days From 1/20/26 09:00 AM Thru 2/17/26 09:00 AM

Effective February 1, 2024 and where permitted by law, United Rentals may impose a surcharge of 2.0% for credit card payments on
charge accounts. This surcharge is not greater than our merchant discount rate for credit card transactions and is subject to sales
tax.
NOTICE: This invoice is subject to the terms and conditions of the Rental and Service Agreement, which are available at
https : //www.unitedrentals. com/legal/rental-service-terms-US and which are incorporated herein by reference. A COPY OF THE RENTAL
AND SERVICE AGREEMENT TERMS ARE AVAILABLE IN PAPER FORM UPON REQUEST.

<!-- PageNumber="Page: 1" -->
