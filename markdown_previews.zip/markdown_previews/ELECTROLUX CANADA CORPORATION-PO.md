# ELECTROLUX CANADA CORPORATION-PO.pdf

<figure>

Electrolux
Electrolux Canada Corporation

</figure>


<table>
<tr>
<td>Bill To / Facturer:</td>
<td>Sold To / Vendu à:</td>
</tr>
<tr>
<td>68007212</td>
<td>50301908</td>
</tr>
<tr>
<td>MARCONE-APW ULC</td>
<td>MARCONE-APW, ULC</td>
</tr>
<tr>
<td>PO BOX 411340</td>
<td>PO BOX 411340</td>
</tr>
<tr>
<td>SAINT LOUIS MO 63141</td>
<td>SAINT LOUIS MO 63141</td>
</tr>
<tr>
<td>USA</td>
<td>USA</td>
</tr>
</table>


Ship To / EXPÉDIÉ:

70278206

MARCONE-APW, VAUGHN

505 CITYVIEW BLVD UNIT 2

WOODBRIDGE ON L4H 0L8

Canada

Incoterms: FCA, Free Carrier

INVOICE/FACTURE 7321714510


<table>
<tr>
<td>Document date / Date du document:</td>
<td>[page 1 of 7] 01/29/2026</td>
</tr>
<tr>
<td>Net due date / Date d'échéance nette:</td>
<td>03/30/2026</td>
</tr>
<tr>
<td>Currency / Devise:</td>
<td>CAD</td>
</tr>
<tr>
<td>Payment Terms / Modalités de paiement:</td>
<td>60 days net</td>
</tr>
<tr>
<td>Your account with us / Votre compte avec nous:</td>
<td>68007212</td>
</tr>
<tr>
<td>G.S.T / H.S.T:</td>
<td>865645212</td>
</tr>
<tr>
<td>Q.S.T:</td>
<td>1089062485</td>
</tr>
</table>


<table>
<tr>
<th>PO Number / Commande n º VA0128F1</th>
<th>Order No / Numéro de commande.</th>
<th>Order Date / Date de commande</th>
<th>Delivery No/ Numéro de livraison</th>
<th>BOL No / Numéro de borderau</th>
<th>RG / ZN Région / Zone</th>
<th>PC / Liste de prix</th>
<th>SCAC Code PU99</th>
<th>PRO No / Numéro PRO</th>
<th>LOT No / Numéro de lot.</th>
</tr>
<tr>
<td></td>
<td>7405199913</td>
<td>01/28/2026</td>
<td>7814639857</td>
<td>d'expedition 2116493</td>
<td>CA50/CC5</td>
<td></td>
<td></td>
<td>94345928</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Item / Article</th>
<th>Model Id / Identifiant du modèle</th>
<th>Description / La description</th>
<th>Quantity/ Quantité</th>
<th>Unit price / Prix unitaire</th>
<th>Rate Unit / Unité tarifaire</th>
<th>Amount / Montante</th>
</tr>
<tr>
<td rowspan="2">10</td>
<td>PAULTRA</td>
<td>PAULTRA FRIG PA ULTRA AIR FILTER</td>
<td>5</td>
<td>14.99</td>
<td>CAD</td>
<td>74.95</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>14.99</td>
<td>CAD</td>
<td>74.95</td>
</tr>
<tr>
<td rowspan="2">20</td>
<td>FPPWFU02</td>
<td>FRIGIDAIRE PUREPOUR PWF2 WATER FILTER</td>
<td>3</td>
<td>58.73</td>
<td>CAD</td>
<td>176.19</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>58.73</td>
<td>CAD</td>
<td>176.19</td>
</tr>
<tr>
<td rowspan="2">30</td>
<td>A23242801</td>
<td>INTERLOCK,ASSEMBLY,LH SAFETY</td>
<td>17</td>
<td>52.20</td>
<td>CAD</td>
<td>887.40</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>52.20</td>
<td>CAD</td>
<td>887.40</td>
</tr>
<tr>
<td rowspan="2">40</td>
<td>808844401</td>
<td>POWER SUPPLY - SMPS1 PULSAR</td>
<td>1</td>
<td>152.51</td>
<td>CAD</td>
<td>152.51</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>152.51</td>
<td>CAD</td>
<td>152.51</td>
</tr>
<tr>
<td rowspan="2">60</td>
<td>807145201</td>
<td>COVER, VOLUTE</td>
<td>2</td>
<td>8.81</td>
<td>CAD</td>
<td>17.62</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>8.81</td>
<td>CAD</td>
<td>17.62</td>
</tr>
<tr>
<td rowspan="2">80</td>
<td>5304537911</td>
<td>BOARD ASSEMBLY,MAIN CONTROL</td>
<td>1</td>
<td>69.83</td>
<td>CAD</td>
<td>69.83</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>69.83</td>
<td>CAD</td>
<td>69.83</td>
</tr>
<tr>
<td rowspan="2">91</td>
<td>140156193181</td>
<td>ELEMENT HEATING -PUR</td>
<td>1</td>
<td>37.65</td>
<td>CAD</td>
<td>37.65</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>37.65</td>
<td>CAD</td>
<td>37.65</td>
</tr>
</table>


ALL LATE PAYMENTS MAY BE SUBJECT TO A LATE PAYMENT PENALTY CALCULATED AT THE RATE OF ONE AND ONE-HALF PERCENT (1.5%)
PER MONTH OR THE MAXIMUM ALLOWABLE BY LAW, WHICHEVER IS LESS.
TOUS LES PAIEMENTS EN RETARD PEUVENT ÊTRE SOUMIS À UNE PENALITE DE PAIEMENT DE RETARD CALCULÉE AU TAUX D'UN ET DEMI
(1.5%) POUR CENT PAR MOIS OU AU MAXIMUM PERMIS PAR LA LOI, SI CELA EST MOINS.

ALL ORDERS ARE CONSIDERED FOB ORIGIN UNLESS COVERED BY A SPECIFIC AGREEMENT WITH ELECTROLUX.
TOUTES LES COMMANDES SONT CONSIDÉRÉES FOB ORIGINE SAUF COUVERT D'UN ACCORD SPÉCIFIQUE AVEC ELECTROLUX.

For Billing Inquires/
Pour demandes
de facturation:

Telephone: 905-813-7700
Fax: 905-813-1220

Payment via EFT
Beneficiary: Electrolux Canada Corp
Account Number: 4011784709
ABA/Routing Number: 0270 00012
SWIFT: CHASCATTCTS
BankName: JPMorgan ChaseBank NA

<!-- PageBreak -->


<figure>

Electrolux
Electrolux Canada Corporation

</figure>


<table>
<tr>
<td>Bill To / Facturer:</td>
<td>Sold To / Vendu à:</td>
</tr>
<tr>
<td>68007212</td>
<td>50301908</td>
</tr>
<tr>
<td>MARCONE-APW ULC</td>
<td>MARCONE-APW, ULC</td>
</tr>
<tr>
<td>PO BOX 411340</td>
<td>PO BOX 411340</td>
</tr>
<tr>
<td>SAINT LOUIS MO 63141</td>
<td>SAINT LOUIS MO 63141</td>
</tr>
<tr>
<td>USA</td>
<td>USA</td>
</tr>
</table>


Ship To / EXPÉDIÉ:

70278206

MARCONE-APW, VAUGHN

505 CITYVIEW BLVD UNIT 2

WOODBRIDGE ON L4H 0L8

Canada

Incoterms: FCA, Free Carrier

INVOICE/FACTURE 7321714510


<table>
<tr>
<td>Document date / Date du document:</td>
<td>[page 2 of 7] 01/29/2026</td>
</tr>
<tr>
<td>Net due date / Date d'échéance nette:</td>
<td>03/30/2026</td>
</tr>
<tr>
<td>Currency / Devise:</td>
<td>CAD</td>
</tr>
<tr>
<td>Payment Terms / Modalités de paiement:</td>
<td>60 days net</td>
</tr>
<tr>
<td>Your account with us / Votre compte avec nous:</td>
<td>68007212</td>
</tr>
<tr>
<td>G.S.T / H.S.T:</td>
<td>865645212</td>
</tr>
<tr>
<td>Q.S.T:</td>
<td>1089062485</td>
</tr>
</table>


<table>
<tr>
<th>PO Number / Commande n º VA0128F1</th>
<th>Order No / Numéro de commande.</th>
<th>Order Date / Date de commande</th>
<th>Delivery No/ Numéro de livraison</th>
<th>BOL No / Numéro de borderau</th>
<th>RG / ZN Région / Zone</th>
<th>PC / Liste de prix</th>
<th>SCAC Code PU99</th>
<th>PRO No / Numéro PRO</th>
<th>LOT No / Numéro de lot.</th>
</tr>
<tr>
<td></td>
<td>7405199913</td>
<td>01/28/2026</td>
<td>7814639857</td>
<td>d'expedition 2116493</td>
<td>CA50/CC5</td>
<td></td>
<td></td>
<td>94345928</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Item / Article</th>
<th>Model Id / Identifiant du modèle</th>
<th>Description / La description</th>
<th>Quantity/ Quantité</th>
<th>Unit price / Prix unitaire</th>
<th>Rate Unit / Unité tarifaire</th>
<th>Amount / Montante</th>
</tr>
<tr>
<td rowspan="2">110</td>
<td>5304536387</td>
<td>DOOR ASSEMBLY,STAINLESS</td>
<td>2</td>
<td>11.55</td>
<td>CAD</td>
<td>23.10</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>11.55</td>
<td>CAD</td>
<td>23.10</td>
</tr>
<tr>
<td rowspan="2">120</td>
<td>5304536038</td>
<td>USER INTERFACE BOARD,ASSEMBLY</td>
<td>1</td>
<td>95.10</td>
<td>CAD</td>
<td>95.10</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>95.10</td>
<td>CAD</td>
<td>95.10</td>
</tr>
<tr>
<td rowspan="2">140</td>
<td>5304535562</td>
<td>DOOR ASSEMBLY, OUTER, STAINLESS</td>
<td>1</td>
<td>83.96</td>
<td>CAD</td>
<td>83.96</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>83.96</td>
<td>CAD</td>
<td>83.96</td>
</tr>
<tr>
<td rowspan="2">150</td>
<td>5304535379</td>
<td>RACK ASSEMBLY,LOWER,GREY</td>
<td>6</td>
<td>63.45</td>
<td>CAD</td>
<td>380.70</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>63.45</td>
<td>CAD</td>
<td>380.70</td>
</tr>
<tr>
<td rowspan="2">170</td>
<td>5304535144</td>
<td>IGNITOR/ORIFICE,ASSEMBLY,18K B</td>
<td>1</td>
<td>21.15</td>
<td>CAD</td>
<td>21.15</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>21.15</td>
<td>CAD</td>
<td>21.15</td>
</tr>
<tr>
<td rowspan="2">180</td>
<td>5304534157</td>
<td>COOKING TOP</td>
<td>1</td>
<td>295.88</td>
<td>CAD</td>
<td>295.88</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>295.88</td>
<td>CAD</td>
<td>295.88</td>
</tr>
<tr>
<td rowspan="2">190</td>
<td>5304533959</td>
<td>HARNESS, WIRING,COMMUNICATION</td>
<td>1</td>
<td>22.39</td>
<td>CAD</td>
<td>22.39</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>22.39</td>
<td>CAD</td>
<td>22.39</td>
</tr>
</table>


ALL LATE PAYMENTS MAY BE SUBJECT TO A LATE PAYMENT PENALTY CALCULATED AT THE RATE OF ONE AND ONE-HALF PERCENT (1.5%)
PER MONTH OR THE MAXIMUM ALLOWABLE BY LAW, WHICHEVER IS LESS.
TOUS LES PAIEMENTS EN RETARD PEUVENT ÊTRE SOUMIS À UNE PENALITE DE PAIEMENT DE RETARD CALCULÉE AU TAUX D'UN ET DEMI
(1.5%) POUR CENT PAR MOIS OU AU MAXIMUM PERMIS PAR LA LOI, SI CELA EST MOINS.

ALL ORDERS ARE CONSIDERED FOB ORIGIN UNLESS COVERED BY A SPECIFIC AGREEMENT WITH ELECTROLUX.
TOUTES LES COMMANDES SONT CONSIDÉRÉES FOB ORIGINE SAUF COUVERT D'UN ACCORD SPÉCIFIQUE AVEC ELECTROLUX.

For Billing Inquires/
Pour demandes
de facturation:

Telephone: 905-813-7700
Fax: 905-813-1220

Payment via EFT
Beneficiary: Electrolux Canada Corp
Account Number: 4011784709
ABA/Routing Number: 0270 00012
SWIFT: CHASCATTCTS
BankName: JPMorgan ChaseBank NA

<!-- PageBreak -->


<figure>

Electrolux
Electrolux Canada Corporation

</figure>


<table>
<tr>
<td>Bill To / Facturer:</td>
<td>Sold To / Vendu à:</td>
</tr>
<tr>
<td>68007212</td>
<td>50301908</td>
</tr>
<tr>
<td>MARCONE-APW ULC</td>
<td>MARCONE-APW, ULC</td>
</tr>
<tr>
<td>PO BOX 411340</td>
<td>PO BOX 411340</td>
</tr>
<tr>
<td>SAINT LOUIS MO 63141</td>
<td>SAINT LOUIS MO 63141</td>
</tr>
<tr>
<td>USA</td>
<td>USA</td>
</tr>
</table>


Ship To / EXPÉDIÉ:

70278206

MARCONE-APW, VAUGHN

505 CITYVIEW BLVD UNIT 2

WOODBRIDGE ON L4H 0L8

Canada

Incoterms: FCA, Free Carrier

INVOICE/FACTURE 7321714510


<table>
<tr>
<td>Document date / Date du document:</td>
<td>[page 3 of 7] 01/29/2026</td>
</tr>
<tr>
<td>Net due date / Date d'échéance nette:</td>
<td>03/30/2026</td>
</tr>
<tr>
<td>Currency / Devise:</td>
<td>CAD</td>
</tr>
<tr>
<td>Payment Terms / Modalités de paiement:</td>
<td>60 days net</td>
</tr>
<tr>
<td>Your account with us / Votre compte avec nous:</td>
<td>68007212</td>
</tr>
<tr>
<td>G.S.T / H.S.T:</td>
<td>865645212</td>
</tr>
<tr>
<td>Q.S.T:</td>
<td>1089062485</td>
</tr>
</table>


<table>
<tr>
<th>PO Number / Commande n º VA0128F1</th>
<th>Order No / Numéro de commande.</th>
<th>Order Date / Date de commande</th>
<th>Delivery No/ Numéro de livraison</th>
<th>BOL No / Numéro de borderau</th>
<th>RG / ZN Région / Zone</th>
<th>PC / Liste de prix</th>
<th>SCAC Code PU99</th>
<th>PRO No / Numéro PRO</th>
<th>LOT No / Numéro de lot.</th>
</tr>
<tr>
<td></td>
<td>7405199913</td>
<td>01/28/2026</td>
<td>7814639857</td>
<td>d'expedition 2116493</td>
<td>CA50/CC5</td>
<td></td>
<td></td>
<td>94345928</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Item / Article</th>
<th>Model Id / Identifiant du modèle</th>
<th>Description / La description</th>
<th>Quantity/ Quantité</th>
<th>Unit price / Prix unitaire</th>
<th>Rate Unit / Unité tarifaire</th>
<th>Amount / Montante</th>
</tr>
<tr>
<td rowspan="2">200</td>
<td>5304532784</td>
<td>DOOR-KIT,REFR SS,SVC ASMY</td>
<td>1</td>
<td>186.75</td>
<td>CAD</td>
<td>186.75</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>186.75</td>
<td>CAD</td>
<td>186.75</td>
</tr>
<tr>
<td rowspan="2">210</td>
<td>5304532685</td>
<td>PC BOARD,ELECTRONIC UNIT, VALVE</td>
<td>1</td>
<td>279.08</td>
<td>CAD</td>
<td>279.08</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>279.08</td>
<td>CAD</td>
<td>279.08</td>
</tr>
<tr>
<td rowspan="2">240</td>
<td>5304528825</td>
<td>MOTOR ASSEMBLY,FAN</td>
<td>1</td>
<td>85.13</td>
<td>CAD</td>
<td>85.13</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>85.13</td>
<td>CAD</td>
<td>85.13</td>
</tr>
<tr>
<td rowspan="2">250</td>
<td>5304528706</td>
<td>TRIM, REAR VENT,STAINLESS</td>
<td>1</td>
<td>32.78</td>
<td>CAD</td>
<td>32.78</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>32.78</td>
<td>CAD</td>
<td>32.78</td>
</tr>
<tr>
<td rowspan="2">260</td>
<td>5304528694</td>
<td>SMOOTHTOP,ASSEMBLY,BLACK</td>
<td>1</td>
<td>200.18</td>
<td>CAD</td>
<td>200.18</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>200.18</td>
<td>CAD</td>
<td>200.18</td>
</tr>
<tr>
<td rowspan="2">280</td>
<td>5304526053</td>
<td>HOUSING ASSEMBLY, WATER FILTER</td>
<td>1</td>
<td>12.11</td>
<td>CAD</td>
<td>12.11</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>12.11</td>
<td>CAD</td>
<td>12.11</td>
</tr>
<tr>
<td rowspan="2">290</td>
<td>5304524342</td>
<td>SCREW</td>
<td>1</td>
<td>5.21</td>
<td>CAD</td>
<td>5.21</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>5.21</td>
<td>CAD</td>
<td>5.21</td>
</tr>
</table>


ALL LATE PAYMENTS MAY BE SUBJECT TO A LATE PAYMENT PENALTY CALCULATED AT THE RATE OF ONE AND ONE-HALF PERCENT (1.5%)
PER MONTH OR THE MAXIMUM ALLOWABLE BY LAW, WHICHEVER IS LESS.
TOUS LES PAIEMENTS EN RETARD PEUVENT ÊTRE SOUMIS À UNE PENALITE DE PAIEMENT DE RETARD CALCULÉE AU TAUX D'UN ET DEMI
(1.5%) POUR CENT PAR MOIS OU AU MAXIMUM PERMIS PAR LA LOI, SI CELA EST MOINS.

ALL ORDERS ARE CONSIDERED FOB ORIGIN UNLESS COVERED BY A SPECIFIC AGREEMENT WITH ELECTROLUX.
TOUTES LES COMMANDES SONT CONSIDÉRÉES FOB ORIGINE SAUF COUVERT D'UN ACCORD SPÉCIFIQUE AVEC ELECTROLUX.

For Billing Inquires/
Pour demandes
de facturation:

Telephone: 905-813-7700
Fax: 905-813-1220

Payment via EFT
Beneficiary: Electrolux Canada Corp
Account Number: 4011784709
ABA/Routing Number: 0270 00012
SWIFT: CHASCATTCTS
BankName: JPMorgan ChaseBank NA

<!-- PageBreak -->


<figure>

Electrolux
Electrolux Canada Corporation

</figure>


<table>
<tr>
<td>Bill To / Facturer:</td>
<td>Sold To / Vendu à:</td>
</tr>
<tr>
<td>68007212</td>
<td>50301908</td>
</tr>
<tr>
<td>MARCONE-APW ULC</td>
<td>MARCONE-APW, ULC</td>
</tr>
<tr>
<td>PO BOX 411340</td>
<td>PO BOX 411340</td>
</tr>
<tr>
<td>SAINT LOUIS MO 63141</td>
<td>SAINT LOUIS MO 63141</td>
</tr>
<tr>
<td>USA</td>
<td>USA</td>
</tr>
</table>


Ship To / EXPÉDIÉ:

70278206

MARCONE-APW, VAUGHN

505 CITYVIEW BLVD UNIT 2

WOODBRIDGE ON L4H 0L8

Canada

Incoterms: FCA, Free Carrier

INVOICE/FACTURE 7321714510


<table>
<tr>
<td>Document date / Date du document:</td>
<td>[page 4 of 7] 01/29/2026</td>
</tr>
<tr>
<td>Net due date / Date d'échéance nette:</td>
<td>03/30/2026</td>
</tr>
<tr>
<td>Currency / Devise:</td>
<td>CAD</td>
</tr>
<tr>
<td>Payment Terms / Modalités de paiement:</td>
<td rowspan="2">60 days net 68007212</td>
</tr>
<tr>
<td>Your account with us / Votre compte avec nous:</td>
</tr>
<tr>
<td>G.S.T / H.S.T:</td>
<td>865645212</td>
</tr>
<tr>
<td>Q.S.T:</td>
<td>1089062485</td>
</tr>
</table>


<table>
<tr>
<th>PO Number / Commande n º VA0128F1</th>
<th>Order No / Numéro de commande.</th>
<th>Order Date / Date de commande</th>
<th>Delivery No/ Numéro de livraison</th>
<th>BOL No / Numéro de borderau</th>
<th>RG / ZN Région / Zone</th>
<th>PC / Liste de prix</th>
<th>SCAC Code PU99</th>
<th>PRO No / Numéro PRO</th>
<th>LOT No / Numéro de lot.</th>
</tr>
<tr>
<td></td>
<td>7405199913</td>
<td>01/28/2026</td>
<td>7814639857</td>
<td>d'expedition 2116493</td>
<td>CA50/CC5</td>
<td></td>
<td></td>
<td>94345928</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Item / Article</th>
<th>Model Id / Identifiant du modèle</th>
<th>Description / La description</th>
<th>Quantity/ Quantité</th>
<th>Unit price / Prix unitaire</th>
<th>Rate Unit / Unité tarifaire</th>
<th>Amount / Montante</th>
</tr>
<tr>
<td rowspan="2">300</td>
<td>5304523183</td>
<td>BOARD ASSEMBLY,USER INTERFACE</td>
<td>2</td>
<td>123.86</td>
<td>CAD</td>
<td>247.72</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>123.86</td>
<td>CAD</td>
<td>247.72</td>
</tr>
<tr>
<td rowspan="2">310</td>
<td>5304520007</td>
<td>LINER ASSEMBLY,DOOR,W/WIPER</td>
<td>1</td>
<td>79.01</td>
<td>CAD</td>
<td>79.01</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>79.01</td>
<td>CAD</td>
<td>79.01</td>
</tr>
<tr>
<td rowspan="2">330</td>
<td>5304518507</td>
<td>CONTROL BOARD,ELECTRONIC</td>
<td>1</td>
<td>211.35</td>
<td>CAD</td>
<td>211.35</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>211.35</td>
<td>CAD</td>
<td>211.35</td>
</tr>
<tr>
<td rowspan="2">360</td>
<td>5304513766</td>
<td>EVAPORATOR, REFRIGERATOR, VERTIC</td>
<td>1</td>
<td>66.53</td>
<td>CAD</td>
<td>66.53</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>66.53</td>
<td>CAD</td>
<td>66.53</td>
</tr>
<tr>
<td rowspan="2">380</td>
<td>5304509229</td>
<td>CONTROLLER,ELECTRONIC,ES541MP</td>
<td>2</td>
<td>217.35</td>
<td>CAD</td>
<td>434.70</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>217.35</td>
<td>CAD</td>
<td>434.70</td>
</tr>
<tr>
<td rowspan="2">390</td>
<td>5304499489</td>
<td>SEAL,FELT,PURPLE STITCHES,DRUM</td>
<td>7</td>
<td>34.58</td>
<td>CAD</td>
<td>242.06</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>34.58</td>
<td>CAD</td>
<td>242.06</td>
</tr>
<tr>
<td rowspan="2">400</td>
<td>5304404821</td>
<td>THERMOSTAT,REFRIG.TEMP</td>
<td>1</td>
<td>79.76</td>
<td>CAD</td>
<td>79.76</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>79.76</td>
<td>CAD</td>
<td>79.76</td>
</tr>
</table>


ALL LATE PAYMENTS MAY BE SUBJECT TO A LATE PAYMENT PENALTY CALCULATED AT THE RATE OF ONE AND ONE-HALF PERCENT (1.5%)
PER MONTH OR THE MAXIMUM ALLOWABLE BY LAW, WHICHEVER IS LESS.
TOUS LES PAIEMENTS EN RETARD PEUVENT ÊTRE SOUMIS À UNE PENALITE DE PAIEMENT DE RETARD CALCULÉE AU TAUX D'UN ET DEMI
(1.5%) POUR CENT PAR MOIS OU AU MAXIMUM PERMIS PAR LA LOI, SI CELA EST MOINS.

ALL ORDERS ARE CONSIDERED FOB ORIGIN UNLESS COVERED BY A SPECIFIC AGREEMENT WITH ELECTROLUX.
TOUTES LES COMMANDES SONT CONSIDÉRÉES FOB ORIGINE SAUF COUVERT D'UN ACCORD SPÉCIFIQUE AVEC ELECTROLUX.

For Billing Inquires/
Pour demandes
de facturation:

Telephone: 905-813-7700
Fax: 905-813-1220

Payment via EFT
Beneficiary: Electrolux Canada Corp
Account Number: 4011784709
ABA/Routing Number: 0270 00012
SWIFT: CHASCATTCTS
BankName: JPMorgan ChaseBank NA

<!-- PageBreak -->


<figure>

Electrolux
Electrolux Canada Corporation

</figure>


<table>
<tr>
<td>Bill To / Facturer:</td>
<td>Sold To / Vendu à:</td>
</tr>
<tr>
<td>68007212</td>
<td>50301908</td>
</tr>
<tr>
<td>MARCONE-APW ULC</td>
<td>MARCONE-APW, ULC</td>
</tr>
<tr>
<td>PO BOX 411340</td>
<td>PO BOX 411340</td>
</tr>
<tr>
<td>SAINT LOUIS MO 63141</td>
<td>SAINT LOUIS MO 63141</td>
</tr>
<tr>
<td>USA</td>
<td>USA</td>
</tr>
</table>


Ship To / EXPÉDIÉ:

70278206

MARCONE-APW, VAUGHN

505 CITYVIEW BLVD UNIT 2

WOODBRIDGE ON L4H 0L8

Canada

Incoterms: FCA, Free Carrier

INVOICE/FACTURE 7321714510


<table>
<tr>
<td>Document date / Date du document:</td>
<td>[page 5 of 7] 01/29/2026</td>
</tr>
<tr>
<td>Net due date / Date d'échéance nette:</td>
<td>03/30/2026</td>
</tr>
<tr>
<td>Currency / Devise:</td>
<td>CAD</td>
</tr>
<tr>
<td>Payment Terms / Modalités de paiement:</td>
<td rowspan="2">60 days net 68007212</td>
</tr>
<tr>
<td>Your account with us / Votre compte avec nous:</td>
</tr>
<tr>
<td>G.S.T / H.S.T:</td>
<td>865645212</td>
</tr>
<tr>
<td>Q.S.T:</td>
<td>1089062485</td>
</tr>
</table>


<table>
<tr>
<th>PO Number / Commande n º VA0128F1</th>
<th>Order No / Numéro de commande.</th>
<th>Order Date / Date de commande</th>
<th>Delivery No/ Numéro de livraison</th>
<th>BOL No / Numéro de borderau</th>
<th>RG / ZN Région / Zone</th>
<th>PC / Liste de prix</th>
<th>SCAC Code PU99</th>
<th>PRO No / Numéro PRO</th>
<th>LOT No / Numéro de lot.</th>
</tr>
<tr>
<td></td>
<td>7405199913</td>
<td>01/28/2026</td>
<td>7814639857</td>
<td>d'expedition 2116493</td>
<td>CA50/CC5</td>
<td></td>
<td></td>
<td>94345928</td>
<td></td>
</tr>
</table>


<table>
<tr>
<th>Item / Article</th>
<th>Model Id / Identifiant du modèle</th>
<th>Description / La description</th>
<th>Quantity/ Quantité</th>
<th>Unit price / Prix unitaire</th>
<th>Rate Unit / Unité tarifaire</th>
<th>Amount / Montante</th>
</tr>
<tr>
<td rowspan="2">410</td>
<td>318183603</td>
<td>CLOCK/TIMER,ELECTRONIC,BLACK</td>
<td>1</td>
<td>267.64</td>
<td>CAD</td>
<td>267.64</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>267.64</td>
<td>CAD</td>
<td>267.64</td>
</tr>
<tr>
<td rowspan="2">450</td>
<td>316473503</td>
<td>BOARD,ESEC-20,7 RELAY,W/CHASSI</td>
<td>1</td>
<td>179.89</td>
<td>CAD</td>
<td>179.89</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>179.89</td>
<td>CAD</td>
<td>179.89</td>
</tr>
<tr>
<td rowspan="2">460</td>
<td>316352207</td>
<td>OVERLAY,CONTROL,BLACK,ES535</td>
<td>2</td>
<td>34.20</td>
<td>CAD</td>
<td>68.40</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>34.20</td>
<td>CAD</td>
<td>68.40</td>
</tr>
<tr>
<td rowspan="2">470</td>
<td>316031501</td>
<td>VALVE,SAFETY</td>
<td>1</td>
<td>153.60</td>
<td>CAD</td>
<td>153.60</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>153.60</td>
<td>CAD</td>
<td>153.60</td>
</tr>
<tr>
<td rowspan="2">490</td>
<td>241972905</td>
<td>GRILLE/KICKPLATE MET 244 SS</td>
<td>1</td>
<td>44.10</td>
<td>CAD</td>
<td>44.10</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>44.10</td>
<td>CAD</td>
<td>44.10</td>
</tr>
<tr>
<td rowspan="2">500</td>
<td>241872509</td>
<td>GASKET-FRZR DOOR,BLACK,MAGNETI</td>
<td>1</td>
<td>85.13</td>
<td>CAD</td>
<td>85.13</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>85.13</td>
<td>CAD</td>
<td>85.13</td>
</tr>
<tr>
<td rowspan="2">510</td>
<td>240521303</td>
<td>SCREW,#10-16 X 1/2</td>
<td>2</td>
<td>7.35</td>
<td>CAD</td>
<td>14.70</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>7.35</td>
<td>CAD</td>
<td>14.70</td>
</tr>
</table>


ALL LATE PAYMENTS MAY BE SUBJECT TO A LATE PAYMENT PENALTY CALCULATED AT THE RATE OF ONE AND ONE-HALF PERCENT (1.5%)
PER MONTH OR THE MAXIMUM ALLOWABLE BY LAW, WHICHEVER IS LESS.
TOUS LES PAIEMENTS EN RETARD PEUVENT ÊTRE SOUMIS À UNE PENALITE DE PAIEMENT DE RETARD CALCULÉE AU TAUX D'UN ET DEMI
(1.5%) POUR CENT PAR MOIS OU AU MAXIMUM PERMIS PAR LA LOI, SI CELA EST MOINS.

ALL ORDERS ARE CONSIDERED FOB ORIGIN UNLESS COVERED BY A SPECIFIC AGREEMENT WITH ELECTROLUX.
TOUTES LES COMMANDES SONT CONSIDÉRÉES FOB ORIGINE SAUF COUVERT D'UN ACCORD SPÉCIFIQUE AVEC ELECTROLUX.

For Billing Inquires/
Pour demandes
de facturation:

Telephone: 905-813-7700
Fax: 905-813-1220

Payment via EFT
Beneficiary: Electrolux Canada Corp
Account Number: 4011784709
ABA/Routing Number: 0270 00012
SWIFT: CHASCATTCTS
BankName: JPMorgan ChaseBank NA

<!-- PageBreak -->


<figure>

Electrolux
Electrolux Canada Corporation

</figure>


<table>
<tr>
<td>Bill To / Facturer:</td>
<td>Sold To / Vendu à:</td>
</tr>
<tr>
<td>68007212</td>
<td>50301908</td>
</tr>
<tr>
<td>MARCONE-APW ULC</td>
<td>MARCONE-APW, ULC</td>
</tr>
<tr>
<td>PO BOX 411340</td>
<td>PO BOX 411340</td>
</tr>
<tr>
<td>SAINT LOUIS MO 63141</td>
<td>SAINT LOUIS MO 63141</td>
</tr>
<tr>
<td>USA</td>
<td>USA</td>
</tr>
</table>


Ship To / EXPÉDIÉ:

70278206

MARCONE-APW, VAUGHN

505 CITYVIEW BLVD UNIT 2

WOODBRIDGE ON L4H 0L8

Canada

Incoterms: FCA, Free Carrier

INVOICE/FACTURE 7321714510


<table>
<tr>
<td>Document date / Date du document:</td>
<td>[page 6 of 7] 01/29/2026</td>
</tr>
<tr>
<td>Net due date / Date d'échéance nette:</td>
<td>03/30/2026</td>
</tr>
<tr>
<td>Currency / Devise:</td>
<td>CAD</td>
</tr>
<tr>
<td>Payment Terms / Modalités de paiement:</td>
<td rowspan="2">60 days net 68007212</td>
</tr>
<tr>
<td>Your account with us / Votre compte avec nous:</td>
</tr>
<tr>
<td>G.S.T / H.S.T:</td>
<td>865645212</td>
</tr>
<tr>
<td>Q.S.T:</td>
<td>1089062485</td>
</tr>
</table>


<table>
<tr>
<th rowspan="2">PO Number / Commande n º VA0128F1</th>
<th>Order No / Numéro de commande.</th>
<th rowspan="2">Order Date / Date de commande 01/28/2026</th>
<th rowspan="2">Delivery No/ Numéro de livraison 7814639857</th>
<th rowspan="2">BOL No / Numéro de borderau d'expedition 2116493</th>
<th rowspan="2">RG / ZN Région / Zone CA50/CC5</th>
<th rowspan="2">PC / Liste de prix</th>
<th rowspan="2">SCAC Code PU99</th>
<th rowspan="2">PRO No / Numéro PRO 94345928</th>
<th rowspan="2">LOT No / Numéro de lot.</th>
</tr>
<tr>
<td>7405199913</td>
</tr>
</table>


<table>
<tr>
<th>Item / Article</th>
<th>Model Id / Identifiant du modèle</th>
<th>Description / La description</th>
<th>Quantity/ Quantité</th>
<th>Unit price / Prix unitaire</th>
<th>Rate Unit / Unité tarifaire</th>
<th>Amount / Montante</th>
</tr>
<tr>
<td rowspan="2">520</td>
<td>218976409</td>
<td>HOSE</td>
<td>1</td>
<td>31.24</td>
<td>CAD</td>
<td>31.24</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>31.24</td>
<td>CAD</td>
<td>31.24</td>
</tr>
<tr>
<td rowspan="2">530</td>
<td>140225820251</td>
<td>CONTROL-ELECTRICAL</td>
<td>2</td>
<td>61.20</td>
<td>CAD</td>
<td>122.40</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>61.20</td>
<td>CAD</td>
<td>122.40</td>
</tr>
<tr>
<td rowspan="2">540</td>
<td>140212880110</td>
<td>CONTROL-ELECTRICAL</td>
<td>1</td>
<td>70.97</td>
<td>CAD</td>
<td>70.97</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>70.97</td>
<td>CAD</td>
<td>70.97</td>
</tr>
<tr>
<td rowspan="2">550</td>
<td>140173679048</td>
<td>SWITCH, SURFACE UNIT,DUAL</td>
<td>1</td>
<td>43.05</td>
<td>CAD</td>
<td>43.05</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>43.05</td>
<td>CAD</td>
<td>43.05</td>
</tr>
<tr>
<td rowspan="2">560</td>
<td>134440200</td>
<td>Seal,Felt,Upper (134036400)</td>
<td>1</td>
<td>24.26</td>
<td>CAD</td>
<td>24.26</td>
</tr>
<tr>
<td>Net Price</td>
<td></td>
<td></td>
<td>24.26</td>
<td>CAD</td>
<td>24.26</td>
</tr>
</table>


ALL LATE PAYMENTS MAY BE SUBJECT TO A LATE PAYMENT PENALTY CALCULATED AT THE RATE OF ONE AND ONE-HALF PERCENT (1.5%)
PER MONTH OR THE MAXIMUM ALLOWABLE BY LAW, WHICHEVER IS LESS.
TOUS LES PAIEMENTS EN RETARD PEUVENT ÊTRE SOUMIS À UNE PENALITE DE PAIEMENT DE RETARD CALCULÉE AU TAUX D'UN ET DEMI
(1.5%) POUR CENT PAR MOIS OU AU MAXIMUM PERMIS PAR LA LOI, SI CELA EST MOINS.

ALL ORDERS ARE CONSIDERED FOB ORIGIN UNLESS COVERED BY A SPECIFIC AGREEMENT WITH ELECTROLUX.
TOUTES LES COMMANDES SONT CONSIDÉRÉES FOB ORIGINE SAUF COUVERT D'UN ACCORD SPÉCIFIQUE AVEC ELECTROLUX.

For Billing Inquires/
Pour demandes
de facturation:

Telephone: 905-813-7700
Fax: 905-813-1220

Payment via EFT
Beneficiary: Electrolux Canada Corp
Account Number: 4011784709
ABA/Routing Number: 0270 00012
SWIFT: CHASCATTCTS
BankName: JPMorgan ChaseBank NA

<!-- PageBreak -->


<figure>

Electrolux
Electrolux Canada Corporation

</figure>


<table>
<tr>
<td>Bill To / Facturer:</td>
<td>Sold To / Vendu à:</td>
</tr>
<tr>
<td>68007212</td>
<td>50301908</td>
</tr>
<tr>
<td>MARCONE-APW ULC</td>
<td>MARCONE-APW, ULC</td>
</tr>
<tr>
<td>PO BOX 411340</td>
<td>PO BOX 411340</td>
</tr>
<tr>
<td>SAINT LOUIS MO 63141</td>
<td>SAINT LOUIS MO 63141</td>
</tr>
<tr>
<td>USA</td>
<td>USA</td>
</tr>
</table>


Ship To / EXPÉDIÉ:

70278206

MARCONE-APW, VAUGHN

505 CITYVIEW BLVD UNIT 2

WOODBRIDGE ON L4H 0L8

Canada

Incoterms: FCA, Free Carrier

INVOICE/FACTURE 7321714510


<table>
<tr>
<td>Document date / Date du document:</td>
<td>[page 7 of 7] 01/29/2026</td>
</tr>
<tr>
<td>Net due date / Date d'échéance nette:</td>
<td>03/30/2026</td>
</tr>
<tr>
<td>Currency / Devise:</td>
<td>CAD</td>
</tr>
<tr>
<td>Payment Terms / Modalités de paiement:</td>
<td rowspan="2">60 days net 68007212</td>
</tr>
<tr>
<td>Your account with us / Votre compte avec nous:</td>
</tr>
<tr>
<td>G.S.T / H.S.T:</td>
<td>865645212</td>
</tr>
<tr>
<td>Q.S.T:</td>
<td>1089062485</td>
</tr>
</table>


<table>
<tr>
<td>Total Freight / Fret</td>
<td>0.00</td>
</tr>
<tr>
<td>Sub-Total / Total Partiel</td>
<td>5,606.18</td>
</tr>
<tr>
<td>P.S.T / T.V.Q</td>
<td>0.00</td>
</tr>
<tr>
<td>G.S.T / H.S.T</td>
<td>728.80</td>
</tr>
<tr>
<td>Total / Totale</td>
<td>6,334.98</td>
</tr>
</table>


ALL LATE PAYMENTS MAY BE SUBJECT TO A LATE PAYMENT PENALTY CALCULATED AT THE RATE OF ONE AND ONE-HALF PERCENT (1.5%)
PER MONTH OR THE MAXIMUM ALLOWABLE BY LAW, WHICHEVER IS LESS.
TOUS LES PAIEMENTS EN RETARD PEUVENT ÊTRE SOUMIS À UNE PENALITE DE PAIEMENT DE RETARD CALCULÉE AU TAUX D'UN ET DEMI
(1.5%) POUR CENT PAR MOIS OU AU MAXIMUM PERMIS PAR LA LOI, SI CELA EST MOINS.

ALL ORDERS ARE CONSIDERED FOB ORIGIN UNLESS COVERED BY A SPECIFIC AGREEMENT WITH ELECTROLUX.
TOUTES LES COMMANDES SONT CONSIDEREES FOB ORIGINE SAUF COUVERT D'UN ACCORD SPÉCIFIQUE AVEC ELECTROLUX.

For Billing Inquires/
Pour demandes
de facturation:

Telephone: 905-813-7700
Fax: 905-813-1220

Payment via EFT
Beneficiary: Electrolux Canada Corp
Account Number: 4011784709
ABA/Routing Number: 0270 00012
SWIFT: CHASCATTCTS
BankName: JPMorgan ChaseBank NA
