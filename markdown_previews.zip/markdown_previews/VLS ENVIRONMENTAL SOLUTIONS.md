# VLS ENVIRONMENTAL SOLUTIONS.pdf

<figure>

VLS
ENVIRONMENTAL
SOLUTIONS

</figure>


1076 MANHEIM PIKE
LANCASTER, PA, 17601
Web: https://www.vlses.com


# Invoice


<table>
<tr>
<td>Invoice #:</td>
<td>291686</td>
</tr>
<tr>
<td>Document #:</td>
<td>DW291686</td>
</tr>
<tr>
<td>Railcar #:</td>
<td></td>
</tr>
<tr>
<td>Date:</td>
<td>03-Feb-2026</td>
</tr>
<tr>
<td>Due Date:</td>
<td>04-Apr-2026</td>
</tr>
<tr>
<td>Customer ID:</td>
<td>C07245</td>
</tr>
<tr>
<td>Customer PO:</td>
<td>OU36010</td>
</tr>
<tr>
<td>Page</td>
<td>1 of 1</td>
</tr>
</table>


BILL TO:

Generator:

Veolia ES Technical Solutions LLC-Flanders, NJ
1 Eden Lane
Flanders NJ 07836

Stryker Orthopedics
325 Corporate Drive
Mahwah NJ 07430


<table>
<tr>
<th>WASTE DESCRIPTION</th>
<th>UOM</th>
<th>QTY.</th>
<th>UNIT PRICE</th>
<th>EXTENDED PRICE</th>
</tr>
<tr>
<td>Profile LN100386 | Manifest ZZ01302959 Landfill - Solid, Liquid, Sludge Service Date: 01-12-2026</td>
<td>DM 55</td>
<td>3.00</td>
<td>50.7500</td>
<td>152.25</td>
</tr>
<tr>
<td>Profile LN100487 | Manifest ZZ01302959 Landfill - Solid, Liquid, Sludge | Service Date: 01-12-2026</td>
<td>DM 55</td>
<td>5.00</td>
<td>50.7500</td>
<td>253.75</td>
</tr>
<tr>
<td>Profile LN103168 | Manifest ZZ01302959 Landfill - Solid, Liquid, Sludge | Service Date: 01-12-2026</td>
<td>DM 55</td>
<td>6.00</td>
<td>50.7500</td>
<td>304.50</td>
</tr>
<tr>
<td>Profile LN100592 | Manifest ZZ01302959 Landfill - Solid, Liquid, Sludge | Service Date: 01-12-2026</td>
<td>DM 55</td>
<td>12.00</td>
<td>50.7500</td>
<td>609.00</td>
</tr>
<tr>
<td>Profile LN100332 | Manifest ZZ01302959 Landfill - Solid, Liquid, Sludge| Service Date: 01-12-2026</td>
<td>DM 55</td>
<td>4.00</td>
<td>50.7500</td>
<td>203.00</td>
</tr>
<tr>
<td>Profile LN103173 | Manifest ZZ01302959 | VIBRATORY MEDIA WASTE | Service Date: 01-12-2026</td>
<td>DM 30</td>
<td>4.00</td>
<td>49.4700</td>
<td>197.88</td>
</tr>
<tr>
<td>Impact fee</td>
<td>EACH</td>
<td>1.00</td>
<td>383.6447</td>
<td>383.64</td>
</tr>
<tr>
<td>Trans Fee LTL - Stryker Orthopedics - Mahwah, NJ</td>
<td>EACH</td>
<td>1.00</td>
<td>441.7800</td>
<td>441.78</td>
</tr>
<tr>
<td>Fuel Surcharge</td>
<td>EACH</td>
<td>1.00</td>
<td>141.3696</td>
<td>141.37</td>
</tr>
</table>


Thank You For Your Business


<table>
<tr>
<th colspan="3">Please Remit To:</th>
</tr>
<tr>
<td rowspan="3">Payment By Mail: P.O. Box 737765 Dallas, TX 75373-7765</td>
<td>Payment By ACH:</td>
<td>Payment By Wire:</td>
</tr>
<tr>
<td>VLS Environmental Solutions, LLC</td>
<td>VLS Environmental Solutions, LLC</td>
</tr>
<tr>
<td>Bank ABA Number: 111000614 Account Number: 935076775</td>
<td>Bank ABA Number: 021000021 Account Number: 935076775</td>
</tr>
</table>


<table>
<tr>
<td>Subtotal</td>
<td>2,687.17</td>
</tr>
<tr>
<td>Tax</td>
<td>0.00</td>
</tr>
<tr>
<td>Total (USD):</td>
<td>2,687.17</td>
</tr>
</table>


Email Remittance Advise To: AR@vises.com
A 1.5% Per month late charge will be added to all invoices not paid within terms.

<!-- PageBreak -->


<figure>

VEOLIA
ENVIRONMENTAL SERVICES

</figure>


SHIPPING

DOCUMENT

1\. Generator ID Number

NJR000032086

2\. Page 1 of

2

3\. Emergency Response Phone

(877) 818-0087

4\. Shipping Document Tracking Number

ZZ 01302959

5 Generator's, Name and Mailing Address

STRYKER ORTHOPAEDICS

325 CORPORATE DR

MAHWAH, NJ 07430-2006

Generator's Site Address (if different than mailing address)

SAME

Generator's Phone:

201 831-5000


<table>
<tr>
<td>6_ Transporter 1 Company Name VLS LANCASTER LLC</td>
<td>U.SpEPAID Number 8 7 2 6 6 7 4 9</td>
</tr>
<tr>
<td>7. Transporter 2 Company Name</td>
<td>U.S. EPA ID Number</td>
</tr>
</table>


8\. Designated Facility Name and Site Address VLS LANCASTER LLC

Facility's Phone:

717 393-2627

1076 OLD MANHEIM PIKE

LANCASTER, PA 17601

U.S. EPA ID Number
PAD 9 8 7 2 66749


<table>
<tr>
<th rowspan="2"></th>
<th rowspan="2">9a. HM</th>
<th rowspan="2">9b. U.S. DOT Description (including Proper Shipping Name, Hazard Class, ID Number, and Packing Group (if any))</th>
<th colspan="2">10. Containers</th>
<th rowspan="2">11. Total Quantity</th>
<th rowspan="2">12. Unit Wt./Vol.</th>
<th colspan="3" rowspan="2">13. Codes ID29</th>
</tr>
<tr>
<th>No.</th>
<th>Type</th>
</tr>
<tr>
<td>GENERATOR</td>
<td></td>
<td>NON HAZARDOUS MATERIAL 1. NON HAZARDOUS MATERIAL</td>
<td>4</td>
<td>D F</td>
<td>64 0</td>
<td>P</td>
<td>ID27</td>
<td></td>
<td></td>
</tr>
<tr>
<td rowspan="4"></td>
<td rowspan="2"></td>
<td rowspan="2">2. NON REGULATED MATERIAL</td>
<td rowspan="2">6</td>
<td rowspan="2">D M</td>
<td rowspan="2">2400</td>
<td rowspan="2">P</td>
<td></td>
<td rowspan="2"></td>
<td rowspan="2"></td>
</tr>
<tr>
<td>ID72</td>
</tr>
<tr>
<td rowspan="2"></td>
<td rowspan="2">3. NON REGULATED MATERIAL</td>
<td rowspan="2">3</td>
<td rowspan="2">D F</td>
<td rowspan="2">1200</td>
<td rowspan="2">P</td>
<td></td>
<td rowspan="2"></td>
<td rowspan="2"></td>
</tr>
<tr>
<td>ID72</td>
</tr>
<tr>
<td></td>
<td></td>
<td>4. ER Service Contracted by</td>
<td>VESTS -|- 9</td>
<td>Contract D M</td>
<td>retained by 3600</td>
<td>generator P</td>
<td>confers</td>
<td></td>
<td></td>
</tr>
</table>


14\. Special Handling Instructions and Additional Information
agency authority on initial transporter to add or substitute additional transporters on generator's behalf.

15\. GENERATOR S/OFFEROR S CERTIFICATION: I hereby declare that the contents of this consignment are fully and accurately described above by the proper shipping name, and are classified, packaged,
marked and labeled/placarded, and are in all respects in proper condition for transport according to applicable international and national governmental regulations.

Generator's/Offeror's Printed/Typed Name

Jason Parke

Signature

Month

Day

01 1 2 2 6

Year

INT'L

16\. International Shipments
☐
Import to U.S.
☐
Export from U.S.

Transporter signature (for exports only):

17\. Transporter Acknowledgment of Receipt of Shipment

Signature

Month

Year
Day
/ 12/26

Transporter 2 Printed/Typed Name

Signature

Month

Day

Year

18\. Discrepancy

18a. Discrepancy Indication Space
☐
Quantity
☐
Type

☐
Residue
☐
Partial Rejection
☐
Full Rejection

Shipping Document Tracking Number:

18b. Alternate Facility (or Generator)

U.S. EPA ID Number


<table>
<tr>
<th rowspan="2">DESIGNATED FACILITY</th>
<th>18c. Signature of Alternate Facility (or Generator)</th>
<th>Month Day</th>
<th>Year</th>
</tr>
<tr>
<td>19. Report Management Method Codes (i.e., codes for treatment, disposal, and recycling systems)</td>
<td></td>
<td></td>
</tr>
</table>


1\.

2\.

3\.

4\.

20\. Designated Facility Owner or Operator: Certification of receipt of shipment except as noted in Item 18a

Printed/Tyned Name
Erin Reedy

Signature
needy

Month
Day
011226
Year

DESIGNATED FACILITY TO GENERATOR

Port of entry/exit:
Date leaving U.S .:

TRANSPORTER

Transporter 1 Printed/Typed Name

Howard JBrenner Jr.

Facility's Phone:

<!-- PageBreak -->


<figure>

VEOLIA
ENVIRONMENTAL SERVICES

</figure>


<figure>

☒

</figure>


<table>
<tr>
<th rowspan="2">SHIPPING DOCUMENT (Continuation Sheet)</th>
<th>21. Generator ID Number</th>
<th>22. Page</th>
<th>23. Shipping Document Tracking Number</th>
</tr>
<tr>
<td>NJR000032086 STRYKER ORTHOPAEDICS</td>
<td>2 of 2</td>
<td>ZZ01302959</td>
</tr>
</table>


24\. Generator's Name


<table>
<tr>
<th>25. Transporter</th>
<th>Company Name</th>
<th>U.S. EPA ID Number</th>
</tr>
<tr>
<td>26. Transporter</td>
<td>Company Name</td>
<td>U.S. EPA ID Number</td>
</tr>
</table>


<table>
<tr>
<th rowspan="13">GENERATOR</th>
<th rowspan="2">27a. HM</th>
<th rowspan="2">27b. U.S. DOT Description (including Proper Shipping Name, Hazard Class, ID Number, and Packing Group (if any))</th>
<th colspan="2">28. Containers</th>
<th rowspan="2">29. Total Quantity</th>
<th rowspan="2">30. Unit Wt./Vol.</th>
<th colspan="2" rowspan="2">31. Codes</th>
<th rowspan="2"></th>
</tr>
<tr>
<th>No.</th>
<th>Type</th>
</tr>
<tr>
<td rowspan="2"></td>
<td rowspan="2">5. NON REGULATED MATERIAL</td>
<td rowspan="2">12</td>
<td rowspan="2">DM</td>
<td rowspan="2">4800</td>
<td rowspan="2">p</td>
<td>ID27</td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


32\. Special Handling instructions and Additional Information


<table>
<tr>
<th rowspan="3">TRANSPORTER</th>
<th colspan="5">33. Transporter Acknowledgment of Receipt of Shipment</th>
</tr>
<tr>
<th>Printed/Typed Name</th>
<th></th>
<th>Signature</th>
<th>Month Day</th>
<th>Year</th>
</tr>
<tr>
<td colspan="5">34. Transporter Acknowledgment of Receipt of Shipment</td>
</tr>
<tr>
<td></td>
<td colspan="2">Printed/Typed Name</td>
<td>Signature</td>
<td>Month Day</td>
<td>Year</td>
</tr>
<tr>
<td></td>
<td colspan="2"></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>


35\. Discrepancy


<table>
<tr>
<th></th>
<th>36. Report Management Method Codes (i.e., codes for treatment, disposal, and recycling systems)</th>
</tr>
<tr>
<td></td>
<td>5.</td>
</tr>
<tr>
<td>DESIGNATED FACILITY</td>
<td></td>
</tr>
</table>


DESIGNATED FACILITY TO GENERATOR
