# STACKPOLE ELECTRONICS INC..pdf

Shipped From:

STACKPOLE ELECTRONICS, INC.

STE A3

543 S AMERICAS AVE

EL PASO, TX 79907-5647

United States

Stackpole Electronics, Inc.
Invoice

Mail Remittances To:

STACKPOLE ELECTRONICS INC

3110 Edwards Mill Road

Suite 207

Attn: A/R

Raleigh, NC 27612 United States

(919) 875-2452

<!-- PageNumber="Page 1 of 1" -->

Ship To:

Copeland Comfort Control LP - Chihuahua

White-Rodgers - Chihuahua

1281 Joe Battle Blvd Suite B

El Paso, TX 79936-0987

United States

Tax ID: 92-1599081

Bill To:

COPELAND COMFORT CONTROL LP

8100 WEST FLORISSANT AVE

SAINT LOUIS, MO 63136-1417

United States


<table>
<tr>
<th>Shipment Method</th>
<th>FOB</th>
<th>Cartons</th>
<th>Total Wgt</th>
<th>Invoice Number</th>
<th>Invoice Date</th>
<th>Payment Terms:</th>
<th>Settlement:</th>
<th>Shipment Value</th>
</tr>
<tr>
<td>PILOT</td>
<td>El Paso, TX</td>
<td>1</td>
<td>0.00lbs</td>
<td>71320534</td>
<td>01/28/2026</td>
<td>NET 75</td>
<td>US DOLLARS</td>
<td>$37.50</td>
</tr>
</table>


<table>
<tr>
<th>Pack Slip</th>
<th>Customer PO</th>
<th>Line</th>
<th>Part Number</th>
<th>Classifcation</th>
<th>COO</th>
<th>Quantity</th>
<th>Unit Price</th>
<th>Extended Sale</th>
</tr>
<tr>
<td>3566931</td>
<td>517-1262413 Rel: 01262413OP 34.000</td>
<td>0</td>
<td>0067 85119A RMCF0603JT220R RMCF 1/16 220 5% R</td>
<td>8533210030 Thick Film Chip Resistors</td>
<td>TW</td>
<td>15,000</td>
<td>0.00075 ea</td>
<td>$11.25</td>
</tr>
<tr>
<td>3566932</td>
<td>517-1262413 Rel: 01262413OP 35.000</td>
<td>0</td>
<td>0067 85119A RMCF0603JT220R RMCF 1/16 220 5% R</td>
<td>8533210030 Thick Film Chip Resistors</td>
<td>TW</td>
<td>15,000</td>
<td>0.00075 ea</td>
<td>$11.25</td>
</tr>
<tr>
<td>3566933</td>
<td>517-1262413 Rel: 01262413OP 36.000</td>
<td>0</td>
<td>0067 85119A RMCF0603JT220R RMCF 1/16 220 5% R</td>
<td>8533210030 Thick Film Chip Resistors</td>
<td>TW</td>
<td>20,000</td>
<td>0.00075 ea</td>
<td>$15.00</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="3">Invoiced Freight:</td>
<td rowspan="2">$0.00 $37.50</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td colspan="4">71320534 Invoice Total:</td>
</tr>
</table>


Invoice Number 71320534 notes:


<table>
<tr>
<th rowspan="4">Bill of Lading #s:</th>
<th>Box ID:</th>
<th>Bill Of Lading</th>
<th>Carrier/Ship Method</th>
</tr>
<tr>
<td>1537682</td>
<td>TBD</td>
<td>PILOT</td>
</tr>
<tr>
<td>1537683</td>
<td>TBD</td>
<td>PILOT</td>
</tr>
<tr>
<td>1537684</td>
<td>TBD</td>
<td>PILOT</td>
</tr>
</table>


Certified Correct by:
Authorized Signature Marisol Alvarado, QA Manager

Marisol aborado

\- CERTIFICATE OF COMPLIANCE -
Stackpole Electronics, Inc. certifies that the products delivered under this contract meet or exceed published
specifications. Where applicable, Stackpole Electronics also certifies that the products delivered meet or exceed customer
